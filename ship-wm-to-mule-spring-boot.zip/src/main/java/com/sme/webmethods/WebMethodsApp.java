package com.sme.webmethods;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebMethodsApp {

    public static void main(String[] args) {
        SpringApplication.run(WebMethodsApp.class, args);
    }

}

package com.sme.webmethods.utility;

import java.io.StringWriter;
import java.sql.SQLException;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Node;

import com.sme.webmethods.service.Commons;

public class DbInsert {
	
	public void insertService(String serviceName, int seqId, String acName, Node acNode) throws SQLException {
		String acXslt = nodeToString(acNode); 
		Commons.jdbcConnection.insertToFlow(serviceName,seqId,acName,acXslt);
	}
	
	public void insertServiceGroup(String groupName,String serviceName, int seqId, int groupId, String acName, Node acNode, String condition) throws SQLException {
		String acXslt = nodeToString(acNode); 
		Commons.jdbcConnection.insertToGroup(groupName,serviceName,seqId,groupId,acName,acXslt,condition);
	}
	
	public static String nodeToString(Node node) {
		StringWriter sw = new StringWriter();
		try {
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			// t.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(new DOMSource(node), new StreamResult(sw));
		} catch (TransformerException te) {
			System.out.println("nodeToString Transformer Exception");
		}
		return sw.toString();
	}
}

package com.sme.webmethods.utility;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Files;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.print.Doc;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.sme.webmethods.service.Commons;
import com.sme.webmethods.service.FileOperations;

@Component
public class GlobalElements {
	
	@Autowired
	private FileOperations fileOps;
	
	static ArrayList<String> globalElementsList = new ArrayList<>();
	
	public void createJdbcGlobalElement(String configContent) throws SQLException, SAXException, IOException, ParserConfigurationException {
		String connectionName = configContent.substring(configContent.indexOf("connectionName"));
		connectionName = connectionName.substring(connectionName.indexOf("=")+1,connectionName.indexOf(","));
		
		if(!globalElementsList.contains(connectionName)) {
			
			File globalElements = new File(fileOps.getTargetPrjDir().getAbsolutePath()+"\\src\\main\\mule\\GlobalElements.xml");
			Document tDocGlobal = null;
			if(globalElements.exists()) {
				tDocGlobal = Commons.getDocBuilder().parse(globalElements);
			}else {
				tDocGlobal = Commons.getDocBuilder().parse(Commons.template);
			}
			Commons.fileOps.removeBlankLines(tDocGlobal);
			
			if(tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:db") == null) {
				Element mule = (Element) tDocGlobal.getFirstChild();
				mule.setAttribute("xmlns:db","http://www.mulesoft.org/schema/mule/db");
				String schemaLocation = mule.getAttribute("xsi:schemaLocation");
				schemaLocation += " http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd";
				mule.setAttribute("xsi:schemaLocation", schemaLocation);
			}
			String connectionConfig = null;
			ResultSet connectionRs = Commons.jdbcConnection.getServiceFromConfigFiles(connectionName);
			while(connectionRs.next()) {
				connectionConfig = connectionRs.getString(2);
			}
			
			Element config = tDocGlobal.createElement("db:config");
			config.setAttribute("name", connectionName);
			config.setAttribute("doc:name", "Database_Config");
			config.setAttribute("doc:id", Commons.generateRandom(8) + "-cc1e-44ea-8a3d-d56cb1a380a5");

			Element connection = tDocGlobal.createElement("db:oracle-connection");
			System.out.println(connectionConfig+"          444444444444444");
			String hostName = connectionConfig.substring(connectionConfig.indexOf("serverName"));
			hostName = hostName.substring(hostName.indexOf("=")+1,hostName.indexOf(","));
			
			String userName = connectionConfig.substring(connectionConfig.indexOf("user"));
			userName = userName.substring(userName.indexOf("=")+1,userName.indexOf(","));
			
			String password = connectionConfig.substring(connectionConfig.indexOf("password"));
			password = password.substring(password.indexOf("=")+1,password.indexOf(","));
			
			String databaseName = connectionConfig.substring(connectionConfig.indexOf("databaseName"));
			databaseName = databaseName.substring(databaseName.indexOf("=")+1,databaseName.indexOf(","));
			
			String portNum = connectionConfig.substring(connectionConfig.indexOf("portNumber"));
			portNum = portNum.substring(portNum.indexOf("=")+1,portNum.indexOf(","));
			
			connection.setAttribute("host", hostName);
			connection.setAttribute("user", userName);
			connection.setAttribute("password", password);
			connection.setAttribute("instance", databaseName);
			
			
			config.appendChild(connection);
			tDocGlobal.getFirstChild().appendChild(config);
			Commons.fileOps.writeFile(tDocGlobal,globalElements);
			
			globalElementsList.add(connectionName);
		}
		
	}
	
	public String apikitConfigTag( Document tDoc, Element flow, String resourceName) throws ParserConfigurationException, SAXException, IOException{

		if(!globalElementsList.contains(resourceName)) {
			File globalElements = new File(fileOps.getTargetPrjDir().getAbsolutePath()+"\\src\\main\\mule\\GlobalElements.xml");
			Document tDocGlobal = null;
			if(globalElements.exists()) {
				tDocGlobal = Commons.getDocBuilder().parse(globalElements);
			}else {
				tDocGlobal = Commons.getDocBuilder().parse(Commons.template);
			}
			Commons.fileOps.removeBlankLines(tDocGlobal);
			
		if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:apikit") == null) {
			Element mule = (Element) tDocGlobal.getFirstChild();
			mule.setAttribute("xmlns:apikit", "http://www.mulesoft.org/schema/mule/mule-apikit");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/mule-apikit http://www.mulesoft.org/schema/mule/mule-apikit/current/mule-apikit.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
			Element apikitConfig = tDocGlobal.createElement("apikit:config");

			apikitConfig.setAttribute("doc:id", Commons.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
			apikitConfig.setAttribute("name", resourceName);
			apikitConfig.setAttribute("doc:name", "Router");
			apikitConfig.setAttribute("api", "api\\api.raml");
			apikitConfig.setAttribute("outboundHeadersMapName", "outboundHeadersMapName");
			apikitConfig.setAttribute("httpStatusVarName", "httpStatus");
			
			tDocGlobal.getFirstChild().appendChild(apikitConfig);
			Commons.fileOps.writeFile(tDocGlobal,globalElements);
			
			globalElementsList.add(resourceName);
		}
			return resourceName;
	}
	
	public void addHttpListenerConfigTag(Document tDoc, Element flow, String resourceName)
			throws SQLException, ParserConfigurationException, SAXException, IOException {
		if(!globalElementsList.contains(resourceName)) {
			File globalElements = new File(fileOps.getTargetPrjDir().getAbsolutePath()+"\\src\\main\\mule\\GlobalElements.xml");
			Document tDocGlobal = null;
			if(globalElements.exists()) {
				tDocGlobal = Commons.getDocBuilder().parse(globalElements);
			}else {
				tDocGlobal = Commons.getDocBuilder().parse(Commons.template);
			}
			Commons.fileOps.removeBlankLines(tDocGlobal);
			
			if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:http") == null) {
				Element mule = (Element) tDocGlobal.getFirstChild();
				mule.setAttribute("xmlns:http", "http://www.mulesoft.org/schema/mule/http");
				String schemaLocation = mule.getAttribute("xsi:schemaLocation");
				schemaLocation += " http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd";
				mule.setAttribute("xsi:schemaLocation", schemaLocation);
			}
	
		
			Element httpListenerConfig = tDocGlobal.createElement("http:listener-config");
			Element httplistenerconnection = tDocGlobal.createElement("http:listener-connection");
	
			httpListenerConfig.setAttribute("doc:name", "HTTP Listener config");
			httpListenerConfig.setAttribute("doc:id", Commons.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
			httpListenerConfig.setAttribute("name", resourceName);
			httplistenerconnection.setAttribute("host", "localhost");
			httplistenerconnection.setAttribute("port", "5555");
	
			httpListenerConfig.appendChild(httplistenerconnection);
			
			tDocGlobal.getFirstChild().appendChild(httpListenerConfig);
			Commons.fileOps.writeFile(tDocGlobal,globalElements);
			
			globalElementsList.add(resourceName);
		}
	}
		
		
		
		public void addFileConfigTag() throws SAXException, IOException, ParserConfigurationException{
			if(!globalElementsList.contains("File_config1")) {
					
					File globalElements = new File(fileOps.getTargetPrjDir().getAbsolutePath()+"\\src\\main\\mule\\GlobalElements.xml");
					Document tDocGlobal = null;
					if(globalElements.exists()) {
						tDocGlobal = Commons.getDocBuilder().parse(globalElements);
					}else {
						tDocGlobal = Commons.getDocBuilder().parse(Commons.template);
					}
					Commons.fileOps.removeBlankLines(tDocGlobal);
					
				if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
					Element mule = (Element) tDocGlobal.getFirstChild();
					mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");
					String schemaLocation = mule.getAttribute("xsi:schemaLocation");
					schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";
					mule.setAttribute("xsi:schemaLocation", schemaLocation);
					// create driver depencency in pom.xml
				}

					Element fileConfig = tDocGlobal.createElement("file:config");
					fileConfig.setAttribute("name", "File_config1");
					fileConfig.setAttribute("doc:name", "File config");
					fileConfig.setAttribute("doc:id", Commons.generateRandom(8) + "-cc1e-44ea-8a3d-d56cb1a380a5");
					tDocGlobal.getFirstChild().insertBefore(fileConfig, tDocGlobal.getElementsByTagName("flow").item(0));
					globalElementsList.add("File_config1");
					tDocGlobal.getFirstChild().appendChild(fileConfig);
					Commons.fileOps.writeFile(tDocGlobal,globalElements);
			}
		}
		
		public void addJmsConfigTag(String connName) throws SAXException, IOException, ParserConfigurationException {
			if(!globalElementsList.contains(connName)) {
				System.out.println("Target folder"+ fileOps.getTargetPrjDir().getAbsolutePath());
					File globalElements = new File(fileOps.getTargetPrjDir().getAbsolutePath()+"\\src\\main\\mule\\GlobalElements.xml");
					Document tDocGlobal = null;
					if(globalElements.exists()) {
						tDocGlobal = Commons.getDocBuilder().parse(globalElements);
					}else {
						tDocGlobal = Commons.getDocBuilder().parse(Commons.template);
					}
					Commons.fileOps.removeBlankLines(tDocGlobal);
					
				if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:jms") == null) {
					Element mule = (Element) tDocGlobal.getFirstChild();
					mule.setAttribute("xmlns:jms", "http://www.mulesoft.org/schema/mule/jms");
					String schemaLocation = mule.getAttribute("xsi:schemaLocation");
					schemaLocation += " http://www.mulesoft.org/schema/mule/jms http://www.mulesoft.org/schema/mule/jms/current/mule-jms.xsd";
					mule.setAttribute("xsi:schemaLocation", schemaLocation);
					// create driver depencency in pom.xml
				}
				
				Element jmsconfig = tDocGlobal.createElement("jms:config");
				Element jmsActiveConnection = tDocGlobal.createElement("jms:active-mq-connection");
				Element jmsConnectionFactory = tDocGlobal.createElement("jms:factory-configuration");
				
				jmsconfig.setAttribute("name", connName);
				jmsconfig.setAttribute("doc:name", "Jms Config");
				jmsconfig.setAttribute("doc:id", Commons.generateRandom(8) + "-91ee-4acd-b62e-9317139d9ff7");
				jmsActiveConnection.setAttribute("specification", "JMS_2_0");

				jmsActiveConnection.setAttribute("username", "username");
				jmsActiveConnection.setAttribute("password", "password");
				jmsActiveConnection.setAttribute("clientId", "clientId");
					
				jmsConnectionFactory.setAttribute("brokerUrl", "tcp://localhost:61616");
	
				jmsActiveConnection.appendChild(jmsConnectionFactory);
				jmsconfig.appendChild(jmsActiveConnection);
				tDocGlobal.getFirstChild().insertBefore(jmsconfig, tDocGlobal.getElementsByTagName("flow").item(0));
				globalElementsList.add(connName);
				tDocGlobal.getFirstChild().appendChild(jmsconfig);
				Commons.fileOps.writeFile(tDocGlobal,globalElements);
			}
		}
		
		public void addJmsMQConfigTag(String connName) throws SAXException, IOException, ParserConfigurationException {
			if(!globalElementsList.contains(connName)) {
					File globalElements = new File(fileOps.getTargetPrjDir().getAbsolutePath()+"\\src\\main\\mule\\GlobalElements.xml");
					Document tDocGlobal = null;
					if(globalElements.exists()) {
						tDocGlobal = Commons.getDocBuilder().parse(globalElements);
					}else {
						tDocGlobal = Commons.getDocBuilder().parse(Commons.template);
					}
					Commons.fileOps.removeBlankLines(tDocGlobal);
					
				if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:ibm-mq") == null) {
					Element mule = (Element) tDocGlobal.getFirstChild();
					mule.setAttribute("xmlns:ibm-mq", "http://www.mulesoft.org/schema/mule/ibm-mq");
					String schemaLocation = mule.getAttribute("xsi:schemaLocation");
					schemaLocation += " http://www.mulesoft.org/schema/mule/ibm-mq http://www.mulesoft.org/schema/mule/ibm-mq/current/mule-ibm-mq.xsd";
					mule.setAttribute("xsi:schemaLocation", schemaLocation);
					// create driver depencency in pom.xml
				}
				
				Element jmsconfig = tDocGlobal.createElement("ibm-mq:config");
				Element jmsMQConnection = tDocGlobal.createElement("ibm-mq:connection");
				Element jmsConnectionFactory = tDocGlobal.createElement("ibm-mq:connection-mode");
				Element jmsJndiConnectionFactory = tDocGlobal.createElement("ibm-mq:binding");
				
				jmsconfig.setAttribute("name", connName);
				jmsconfig.setAttribute("doc:name", "IBM MQ Config");
				jmsconfig.setAttribute("doc:id", Commons.generateRandom(8) + "-91ee-4acd-b62e-9317139d9ff7");
				//jmsMQConnection.setAttribute("specification", "JMS_2_0");
				//jmsJndiConnectionFactory.setAttribute("connectionFactoryJndiName", "ConnectionFactory");
	
			
						jmsMQConnection.setAttribute("username", "username");
					
						jmsMQConnection.setAttribute("password", "password");
				
						jmsMQConnection.setAttribute("clientId", "clientId");
					
			
				jmsConnectionFactory.appendChild(jmsJndiConnectionFactory);
				jmsMQConnection.appendChild(jmsConnectionFactory);
				jmsconfig.appendChild(jmsMQConnection);
				tDocGlobal.getFirstChild().insertBefore(jmsconfig, tDocGlobal.getElementsByTagName("flow").item(0));
				globalElementsList.add(connName);
				tDocGlobal.getFirstChild().appendChild(jmsconfig);
				Commons.fileOps.writeFile(tDocGlobal,globalElements);
			}
		}

	// Soap Global Elements
		
		public void addWebServiceConfigTag(String wsdlName,Node webNode, String connName) throws SQLException, ParserConfigurationException, SAXException, IOException {
			
			if(!globalElementsList.contains(connName)) {
				File globalElements = new File(fileOps.getTargetPrjDir().getAbsolutePath()+"\\src\\main\\mule\\GlobalElements.xml");
				Document tDocGlobal = null;
				if(globalElements.exists()) {
					tDocGlobal = Commons.getDocBuilder().parse(globalElements);
				}else {
					tDocGlobal = Commons.getDocBuilder().parse(Commons.template);
				}
				Commons.fileOps.removeBlankLines(tDocGlobal);
				
			
			if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:wsc") == null) {
				Element mule = (Element) tDocGlobal.getFirstChild();
				mule.setAttribute("xmlns:wsc", "http://www.mulesoft.org/schema/mule/wsc");
				String schemaLocation = mule.getAttribute("xsi:schemaLocation");
				schemaLocation += " http://www.mulesoft.org/schema/mule/wsc http://www.mulesoft.org/schema/mule/wsc/current/mule-wsc.xsd";
				mule.setAttribute("xsi:schemaLocation", schemaLocation);
			}

			Element webServiceConfig = tDocGlobal.createElement("wsc:config");
			Element webServiceConnConfig = tDocGlobal.createElement("wsc:connection");
			Element webServiceSecurityConfig = tDocGlobal.createElement("wsc:web-service-security");

			webServiceConfig.setAttribute("doc:name", "Web Service Consumer Config");
			webServiceConfig.setAttribute("doc:id", Commons.generateRandom(8) + "-cc1e-44ea-8a3d-d56cb1a380a5");
			String configNameWSDL = wsdlName.substring(0,wsdlName.lastIndexOf("."))+".wsdl";
			ResultSet rsWsdl = Commons.jdbcConnection.getConfigFile(configNameWSDL);
			String wsdlConfigContent = null;
			while (rsWsdl.next()) {
				wsdlConfigContent = rsWsdl.getString("CONFIG").toString();
			}
			
			 Document wsdlDoc = Commons.getDocBuilder().parse(new InputSource(new StringReader(wsdlConfigContent)));

		//	Document wsdlDoc = Commons.getDocBuilder().parse(wsdlConfigContent);
			Commons.fileOps.removeBlankLines(wsdlDoc);
			
			wsdlName = wsdlName.substring(0,wsdlName.lastIndexOf("."));
			webServiceConnConfig.setAttribute("wsdlLocation","api\\"+ wsdlName.replace("\\", "-") + ".wsdl" );
			
			
			String serviceName = "";
			String portName = "";
			String addressName = "";
			
			for(int i = 0; i< wsdlDoc.getFirstChild().getChildNodes().getLength();i++) {
				Node node = wsdlDoc.getFirstChild().getChildNodes().item(i);
														   
				try {
					
					if( node.getNodeName().contentEquals("wsdl:service")) {
						serviceName = node.getAttributes().getNamedItem("name").getNodeValue();
						portName = node.getFirstChild().getAttributes().getNamedItem("name").getNodeValue();
						addressName = node.getFirstChild().getFirstChild().getAttributes().getNamedItem("location").getNodeValue();
					}
				}catch(Exception e) {}
				
			}
			
			webServiceConnConfig.setAttribute("service", serviceName);
			webServiceConnConfig.setAttribute("port", portName);
			webServiceConnConfig.setAttribute("address", addressName);
			webServiceConnConfig.setAttribute("soapVersion", "SOAP11");
			webServiceConfig.setAttribute("name", connName);
			
			webServiceConfig.appendChild(webServiceConnConfig);
			
			
			tDocGlobal.getFirstChild().appendChild(webServiceConfig);
			Commons.fileOps.writeFile(tDocGlobal,globalElements);
			
			globalElementsList.add(connName);
			
			}
		}

		
		
		
		
		
		public void addAPIKITforSoapConfigTag(Node webNode, String connName, String serviceNameWsdl, String portNameWsdl)
				throws SQLException, ParserConfigurationException, SAXException, IOException {
		
			
			if(!globalElementsList.contains(connName)) {
				File globalElements = new File(fileOps.getTargetPrjDir().getAbsolutePath()+"\\src\\main\\mule\\GlobalElements.xml");
				Document tDocGlobal = null;
				if(globalElements.exists()) {
					tDocGlobal = Commons.getDocBuilder().parse(globalElements);
				}else {
					tDocGlobal = Commons.getDocBuilder().parse(Commons.template);
				}
				Commons.fileOps.removeBlankLines(tDocGlobal);
				
			
			Element apiKitSoapConfig = tDocGlobal.createElement("apikit-soap:config");

			if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:apikit-soap") == null) {
				Element mule = (Element) tDocGlobal.getFirstChild();
				mule.setAttribute("xmlns:apikit-soap", "http://www.mulesoft.org/schema/mule/apikit-soap");
				String schemaLocation = mule.getAttribute("xsi:schemaLocation");
				schemaLocation += " http://www.mulesoft.org/schema/mule/apikit-soap http://www.mulesoft.org/schema/mule/apikit-soap/current/mule-apikit-soap.xsd";
				mule.setAttribute("xsi:schemaLocation", schemaLocation);
			}
			
			for(int i = 0; i< webNode.getChildNodes().getLength();i++) {
				Node node = webNode.getChildNodes().item(i);
				
				try {
					if(node.getAttributes().getNamedItem("name").getNodeValue().contentEquals("SOAPProtocol")) {
						if(node.getTextContent().contains("1.1")) {
						apiKitSoapConfig.setAttribute("soapVersion","SOAP11" );
						}
						else {
							apiKitSoapConfig.setAttribute("soapVersion","SOAP12" );
						}
					}
					
					if(node.getAttributes().getNamedItem("name").getNodeValue().contentEquals("WSDLURL")) {
						String wsdlName = node.getTextContent();
						wsdlName = wsdlName.substring(wsdlName.lastIndexOf("/")+1,wsdlName.indexOf("?"));
						apiKitSoapConfig.setAttribute("wsdlLocation",wsdlName.replace(".", "-").replace(":", "-")+".wsdl" );
						apiKitSoapConfig.setAttribute("service",serviceNameWsdl );
						apiKitSoapConfig.setAttribute("port", portNameWsdl);
					}
				}catch(Exception e) {}
				
			}
			apiKitSoapConfig.setAttribute("name", connName);
			apiKitSoapConfig.setAttribute("doc:name", "APIKit for SOAP Configuration");
			apiKitSoapConfig.setAttribute("doc:id", Commons.generateRandom(8) + "-cc1e-44ea-8a3d-d56cb1a380a5");
			
   
													 
		
			tDocGlobal.getFirstChild().appendChild(apiKitSoapConfig);
			Commons.fileOps.writeFile(tDocGlobal,globalElements);
			
			globalElementsList.add(connName+"_conn");
			}
			
		}
  
		public void addObjectStoreConfigTag(String connName, String cache_time)
				throws SQLException, ParserConfigurationException, SAXException, IOException {
				if(!globalElementsList.contains(connName)) {
					File globalElements = new File(fileOps.getTargetPrjDir().getAbsolutePath()+"\\src\\main\\mule\\GlobalElements.xml");
					Document tDocGlobal = null;
					if(globalElements.exists()) {
						tDocGlobal = Commons.getDocBuilder().parse(globalElements);
					}else {
						tDocGlobal = Commons.getDocBuilder().parse(Commons.template);
					}
					Commons.fileOps.removeBlankLines(tDocGlobal);
					
					if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:os") == null) {
						Element mule = (Element) tDocGlobal.getFirstChild();
						mule.setAttribute("xmlns:os", "http://www.mulesoft.org/schema/mule/os");
						String schemaLocation = mule.getAttribute("xsi:schemaLocation");
						schemaLocation += " http://www.mulesoft.org/schema/mule/os http://www.mulesoft.org/schema/mule/os/current/mule-os.xsd";
						mule.setAttribute("xsi:schemaLocation", schemaLocation);
					}
					
					
				Element storeConfig = tDocGlobal.createElement("os:object-store");
				storeConfig.setAttribute("name", connName);
	
				storeConfig.setAttribute("doc:name", "Object store");
				storeConfig.setAttribute("doc:id", Commons.generateRandom(8) + "-cc1e-44ea-8a3d-d56cb1a380a5");
	
				storeConfig.setAttribute("maxEntries","1000" );
				storeConfig.setAttribute("entryTtl","1" );
				if(cache_time!=null) {
					storeConfig.setAttribute("expirationInterval",cache_time );
				}
				else {
					storeConfig.setAttribute("expirationInterval","15" );
				}
				
				
				 
					
				tDocGlobal.getFirstChild().appendChild(storeConfig);
				Commons.fileOps.writeFile(tDocGlobal,globalElements);
				
				globalElementsList.add(connName);
			}
		}
		public void addCachingStradegy(String connName, String objStoreName) throws SAXException, IOException, ParserConfigurationException {
			if(!globalElementsList.contains(connName)) {
				File globalElements = new File(fileOps.getTargetPrjDir().getAbsolutePath()+"\\src\\main\\mule\\GlobalElements.xml");
				Document tDocGlobal = null;
				if(globalElements.exists()) {
					tDocGlobal = Commons.getDocBuilder().parse(globalElements);
				}else {
					tDocGlobal = Commons.getDocBuilder().parse(Commons.template);
				}
				Commons.fileOps.removeBlankLines(tDocGlobal);
				
				if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:ee") == null) {
					Element mule = (Element) tDocGlobal.getFirstChild();
					mule.setAttribute("xmlns:ee", "http://www.mulesoft.org/schema/mule/ee/core");
					String schemaLocation = mule.getAttribute("xsi:schemaLocation");
					schemaLocation += " http://www.mulesoft.org/schema/mule/ee/core http://www.mulesoft.org/schema/mule/ee/core/current/mule-ee.xsd";
					mule.setAttribute("xsi:schemaLocation", schemaLocation);
				}
				
				Element cacheConfig = tDocGlobal.createElement("ee:object-store-caching-strategy");
				cacheConfig.setAttribute("name", connName);
	
				cacheConfig.setAttribute("doc:name", "Caching Strategy");
				cacheConfig.setAttribute("doc:id", Commons.generateRandom(8) + "-cc1e-44ea-8a3d-d56cb1a380a5");
				cacheConfig.setAttribute("objectStore", objStoreName);
				cacheConfig.setAttribute("keyGenerationExpression", "#[payload]");
				
				tDocGlobal.getFirstChild().appendChild(cacheConfig);
				Commons.fileOps.writeFile(tDocGlobal,globalElements);
				
				globalElementsList.add(connName);
				
			}
		}
		
}

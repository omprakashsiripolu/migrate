package com.sme.webmethods.utility;


import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.sme.webmethods.service.Commons;


public class ActivityOperations {				 
		public Element addMulesoftActivity(String acName, Node acNode, Document tDoc, Element flow, String string) throws SQLException, SAXException, IOException, ParserConfigurationException {
			Element activity = null;
			
			if(acName.contentEquals("FirstProject.mq:mqsdp")) {
				System.out.println();
			}
			
			ResultSet serviceRs = Commons.jdbcConnection.getServiceFromConfigFiles(acName);
			while(serviceRs.next()) {
				String configContent = serviceRs.getString(2);
				String serviceTemplateName = configContent.substring(configContent.indexOf("serviceTemplateName"));
				serviceTemplateName = serviceTemplateName.substring(serviceTemplateName.indexOf("=")+1,serviceTemplateName.indexOf(","));
				switch(serviceTemplateName) {
				case "com.wm.adapter.wmjdbc.services.Insert":
					Commons.globalElements.createJdbcGlobalElement(configContent);
					activity = Commons.jdbcElements.sqlInsertActivity( acName, acNode, tDoc, flow, configContent );
					break;
				case "com.wm.adapter.wmjdbc.services.Select":
					Commons.globalElements.createJdbcGlobalElement(configContent);
					activity = Commons.jdbcElements.sqlSelectActivity( acName, acNode, tDoc, flow, configContent );
					break;
					
				case "com.wm.adapter.wmjdbc.services.Delete":
					Commons.globalElements.createJdbcGlobalElement(configContent);
					activity = Commons.jdbcElements.sqlDeleteActivity( acName, acNode, tDoc, flow, configContent );
					break;
				case "com.wm.adapter.wmjdbc.services.Update":
					Commons.globalElements.createJdbcGlobalElement(configContent);
					activity = Commons.jdbcElements.sqlUpdateActivity( acName, acNode, tDoc, flow, configContent );
					break;
				case "com.wm.adapter.wmjdbc.services.StoredProcedure":
					Commons.globalElements.createJdbcGlobalElement(configContent);
					activity = Commons.jdbcElements.sqlStoredProcActivity( acName, acNode, tDoc, flow, configContent );
					break;	
				case "com.wm.adapter.wmjdbc.services.BatchInsertSQL":
					Commons.globalElements.createJdbcGlobalElement(configContent);
					activity = Commons.jdbcElements.batchInsertActivity( acName, acNode, tDoc, flow, configContent );
	 
					break;	
				case "com.wm.adapter.wmjdbc.services.BatchUpdateSQL":
					Commons.globalElements.createJdbcGlobalElement(configContent);
					activity = Commons.jdbcElements.batchUpdateActivity( acName, acNode, tDoc, flow, configContent );
					break;	
				case "com.wm.adapter.wmjdbc.services.CustomSQL":
					Commons.globalElements.createJdbcGlobalElement(configContent);
					String queryName = configContent.substring(configContent.indexOf("BasicData:sql"));
					queryName = queryName.substring(queryName.indexOf("=")+1,queryName.indexOf(",sqlFieldType="));
					if(queryName.toUpperCase().contains("CREATE")||queryName.toUpperCase().contains("DROP")||queryName.toUpperCase().contains("ALTER")) {
						Commons.globalElements.createJdbcGlobalElement(configContent);
						activity = Commons.jdbcElements.customSqlActivity( acName, acNode, tDoc, flow, configContent );
					}
					else if(queryName.toUpperCase().contains("INSERT")) {
						Commons.globalElements.createJdbcGlobalElement(configContent);
						activity = Commons.jdbcElements.sqlInsertActivity( acName, acNode, tDoc, flow, configContent );
					}
					else if(queryName.toUpperCase().contains("UPDATE")) {
						Commons.globalElements.createJdbcGlobalElement(configContent);
						activity = Commons.jdbcElements.sqlUpdateActivity( acName, acNode, tDoc, flow, configContent );
					}
					else if(queryName.toUpperCase().contains("DELETE")) {
						Commons.globalElements.createJdbcGlobalElement(configContent);
						activity = Commons.jdbcElements.sqlDeleteActivity( acName, acNode, tDoc, flow, configContent );
					}
					else if(queryName.toUpperCase().contains("SELECT")) {
						Commons.globalElements.createJdbcGlobalElement(configContent);
						activity = Commons.jdbcElements.sqlSelectActivity( acName, acNode, tDoc, flow, configContent );
					}
					break;
					
				case "com.wm.adapter.wmjdbc.services.DynamicSQL":
					Commons.globalElements.createJdbcGlobalElement(configContent);
					String dynaQueryName = configContent.substring(configContent.indexOf("BasicData:sql"));
					dynaQueryName = dynaQueryName.substring(dynaQueryName.indexOf("=")+1,dynaQueryName.indexOf(",sqlFieldType="));
					if(dynaQueryName.toUpperCase().contains("CREATE")||dynaQueryName.toUpperCase().contains("DROP")||dynaQueryName.toUpperCase().contains("ALTER")) {
						Commons.globalElements.createJdbcGlobalElement(configContent);
						activity = Commons.jdbcElements.customSqlActivity( acName, acNode, tDoc, flow, configContent );
					}
					else if(dynaQueryName.toUpperCase().contains("INSERT")) {
						Commons.globalElements.createJdbcGlobalElement(configContent);
						activity = Commons.jdbcElements.sqlInsertActivity( acName, acNode, tDoc, flow, configContent );
					}
					else if(dynaQueryName.toUpperCase().contains("UPDATE")) {
						Commons.globalElements.createJdbcGlobalElement(configContent);
						activity = Commons.jdbcElements.sqlUpdateActivity( acName, acNode, tDoc, flow, configContent );
					}
					else if(dynaQueryName.toUpperCase().contains("DELETE")) {
						Commons.globalElements.createJdbcGlobalElement(configContent);
						activity = Commons.jdbcElements.sqlDeleteActivity( acName, acNode, tDoc, flow, configContent );
					}
					else if(dynaQueryName.toUpperCase().contains("SELECT")) {
						Commons.globalElements.createJdbcGlobalElement(configContent);
						activity = Commons.jdbcElements.sqlDynSelectActivity( acName, acNode, tDoc, flow, configContent );
					}
					break;
					
				default :
					activity = loggerActivity( acName, acNode, tDoc, flow, string);
					break;
					
				}
				return activity;
			}
			serviceRs.close();
			String mulesoftActivityName = null;
			ResultSet wmRef = Commons.jdbcConnection.getMulesoftForWm(acName);
			while(wmRef.next()) {
				mulesoftActivityName = wmRef.getString("MULESOFT");
			}
			wmRef.close();
			
			if(mulesoftActivityName==null) {
				mulesoftActivityName="logger";
			}
			
			switch(mulesoftActivityName) {
			
					case "logger" :
						activity = loggerActivity( acName, acNode, tDoc, flow, string);
						break;
					
				// File Elements
					case "file:read" :
						Commons.globalElements.addFileConfigTag();
						activity = Commons.fileElements.fileReadActivity( acName, acNode, tDoc, flow, string);
						break;
						
					case "file:copy" :
						Commons.globalElements.addFileConfigTag();
						activity = Commons.fileElements.copyFileActivity( acName, acNode, tDoc, flow);
						break;
						
					case "file:delete" :
						Commons.globalElements.addFileConfigTag();
						activity = Commons.fileElements.removeFileActivity( acName, acNode, tDoc, flow);
						break;
						
					case "file:list" :
						Commons.globalElements.addFileConfigTag();
						activity = Commons.fileElements.listFilesActivity( acName, acNode, tDoc, flow);
						break;
						
					case "file:write" :
						Commons.globalElements.addFileConfigTag();
						activity = Commons.fileElements.writeFileActivity( acName, acNode, tDoc, flow);
						break;
				// FTP Elements
					case "ftp:list" :
						activity = Commons.ftpElements.addFtpListActivity( acName, acNode, tDoc, flow);
						break;
						
					case "ftp:read" :
						activity = Commons.ftpElements.addFtpReadActivity( acName, acNode, tDoc, flow);
						break;
						
					case "ftp:rename" :
						activity = Commons.ftpElements.addFtpRenameActivity( acName, acNode, tDoc, flow);
						break;
						
					case "ftp:write" :
						activity = Commons.ftpElements.addFtpWriteActivity( acName, acNode, tDoc, flow);
						break;
						
					case "ftp:delete" :
						activity = Commons.ftpElements.addFtpDeleteActivity( acName, acNode, tDoc, flow);
						break;
				// JMS Elements
//					case "jms:listener" :
//						activity = Commons.jmsElements.addJMSOnNewMessageActivity( acName, acNode, tDoc, flow);
//						break;
//					
					case "jms:publish" :
						activity = Commons.jmsElements.addJMSPublishActivity( acName, acNode, tDoc, string);
						break;
					
					case "jms:publish-consume" :
						activity = Commons.jmsElements.addJMSPublishConsumeActivity( acName, acNode, tDoc, flow);
						break;
						
					case "ibm-mq:publish" :
						activity = Commons.jmsElements.jmsMQPublish( acName, acNode, tDoc, string);
						break;
					
						
				// SET and GET Shared Variables
					case "os:store" :
						activity = setVariableActivity( acName, acNode, tDoc, flow);
						break;
					
					case "os:retrieve" :
						activity = getVariableActivity( acName, acNode, tDoc, flow);
						break;
				// Scheduler Or Timer
					case "scheduler" :
						activity = addSchedulerActivity( acName, acNode, tDoc, flow);
						break;
				// Tranform activities
					case "ee:transform" :
						activity = transformActivity( acName, acNode, tDoc, flow, string);
						break;
						
					// Rest Activities
					case "pub." :
						activity = transformActivity( acName, acNode, tDoc, flow, string);
						break;		
				  
					// Soap Activities
						
					case "" :
						activity = transformActivity( acName, acNode, tDoc, flow, string);
						break;		
				  
			 
						
					default:
						
						ResultSet serviceRefRs = Commons.jdbcConnection.getServiceFromFlow(acName.replace(".", "\\").replace(":", "\\"));
						while(serviceRefRs.next()) {
							activity = flowRefActivity( acName, tDoc);
							break;
						}
						serviceRefRs.close();
						if(activity==null) {
							activity = loggerActivity( acName, acNode, tDoc, flow, string);
							break;
						}
					}
			return activity;
		}

		public Element transformActivity(String acName, Node acNode, Document tDoc, Element flow, String string) {
			if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:ee") == null) {
				Element mule = (Element) tDoc.getFirstChild();
				mule.setAttribute("xmlns:ee", "http://www.mulesoft.org/schema/mule/ee/core");
				String schemaLocation = mule.getAttribute("xsi:schemaLocation");
				schemaLocation += " http://www.mulesoft.org/schema/mule/ee/core http://www.mulesoft.org/schema/mule/ee/core/current/mule-ee.xsd";
				mule.setAttribute("xsi:schemaLocation", schemaLocation);

				// create driver depencency in pom.xml
			}
			
			Element transform = tDoc.createElement("ee:transform");
			transform.setAttribute("doc:name", acName);
			transform.setAttribute("doc:id", Commons.generateRandom(8) + "-9b5e-4a86-b01c-cd738c5276d4");

			Element variables = tDoc.createElement("ee:variables");
			Element setVariable = tDoc.createElement("ee:set-variable");
			setVariable.setAttribute("variableName", acName.replace(" ", "-"));
			setVariable.setTextContent("%dw 2.0\n" + "output application/json"  + "\n" + "---\n" + "vars."+"\"\"");

			variables.appendChild(setVariable);
			transform.appendChild(variables);

			return transform;
			
		}
		
		
		public Element flowRefActivity(String acName,Document tDoc) {
			Element flowRef = tDoc.createElement("flow-ref");
			flowRef.setAttribute("doc:name", acName);
			flowRef.setAttribute("name", acName.replace(".", "-").replace(":", "-"));
			flowRef.setAttribute("docid", Commons.generateRandom(8)+"-eadc-40b9-98cc-268d14076da0");
			
			return flowRef;
		}



		// Activities Configuration
		
			public Element loggerActivity(String acName, Node acNode, Document tDoc, Element flow, String string) {
			Element  logger = tDoc.createElement("logger");
			logger.setAttribute("level", "INFO");
			logger.setAttribute("doc:name", acName);
			logger.setAttribute("doc:id", Commons.generateRandom(8)+"-eadc-40b9-98cc-268d14076da0");
			return logger;
		}
	
			// Set and Get Shared Variables
			public Element setVariableActivity(String acName, Node acNode, Document tDoc, Element flow) throws SQLException, ParserConfigurationException, SAXException, IOException{
				if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:os") == null) {
					Element mule = (Element) tDoc.getFirstChild();
					mule.setAttribute("xmlns:os", "http://www.mulesoft.org/schema/mule/os");
					String schemaLocation = mule.getAttribute("xsi:schemaLocation");
					schemaLocation += " http://www.mulesoft.org/schema/mule/os  http://www.mulesoft.org/schema/mule/os/current/mule-os.xsd";
					mule.setAttribute("xsi:schemaLocation", schemaLocation);
				}
				String resourceName = null;
				Element muleSetVariable = tDoc.createElement("os:store");
				Element valueOfSetVar = tDoc.createElement("os:value");
				muleSetVariable.setAttribute("name", acName);
				muleSetVariable.setAttribute("doc:name", acName);
				muleSetVariable.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
				muleSetVariable.setAttribute("key", "#[attributes.headers.key]");
				valueOfSetVar.setTextContent("#[ payload ]");
				String connName = acName.replace(":", "-")+"_conn";
				Commons.globalElements.addObjectStoreConfigTag(connName, resourceName);
				muleSetVariable.setAttribute("objectStore", connName);
				muleSetVariable.appendChild(valueOfSetVar);
				return muleSetVariable;
			}

			public Element getVariableActivity(String acName, Node acNode, Document tDoc, Element flow) throws SQLException, ParserConfigurationException, SAXException, IOException{

				if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:os") == null) {
					Element mule = (Element) tDoc.getFirstChild();
					mule.setAttribute("xmlns:os", "http://www.mulesoft.org/schema/mule/os");
					String schemaLocation = mule.getAttribute("xsi:schemaLocation");
					schemaLocation += " http://www.mulesoft.org/schema/mule/os  http://www.mulesoft.org/schema/mule/os/current/mule-os.xsd";
					mule.setAttribute("xsi:schemaLocation", schemaLocation);
				}
				String resourceName = null;

				Element muleGetVariable = tDoc.createElement("os:retrieve");
				Element valueOfGetVar = tDoc.createElement("os:default-value");
				
				muleGetVariable.setAttribute("name", acName);
				muleGetVariable.setAttribute("doc:name", acName);
				muleGetVariable.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
				muleGetVariable.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
				muleGetVariable.setAttribute("key", "#[attributes.headers.key]");
				String connName = acName.replace(":", "-")+"_conn";
				Commons.globalElements.addObjectStoreConfigTag(connName, resourceName);
				muleGetVariable.setAttribute("objectStore", connName);
				
				
				muleGetVariable.appendChild(valueOfGetVar);
				return muleGetVariable;
			}
			
			
			// Timer or Scheduler
			public Element addSchedulerActivity(String acName, Node acNode, Document tDoc, Element flow) {

				String frequencyRunOnce = "true";
				String frequencyRange = "";
				Element scheduler = tDoc.createElement("scheduler");
				Element strategy = tDoc.createElement("scheduling-strategy");
				Element frequency = tDoc.createElement("fixed-frequency");
				scheduler.setAttribute("doc:name", acName);
				scheduler.setAttribute("doc:id", Commons.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");

				
				strategy.appendChild(frequency);
				scheduler.appendChild(strategy);

				return scheduler;
			}
   
			
			public void soapReqReplyActivity(String wsdlName, Node webNode) throws SAXException, IOException, ParserConfigurationException, SQLException {
				try {
					
					int count =0;
				Document tDocSoapCon = Commons.getDocBuilder().parse(Commons.template);
				Element flow = tDocSoapCon.createElement("flow");
				String acName = "SoapConsume"+count;
				 flow.setAttribute("name", Commons.getSrcPrjDir().getName()+"_SoapConsume"+count);
				 flow.setAttribute("doc:id", Commons.generateRandom(8)+"-eadc-40b9-98cc-268d14076da0");
				 flow.appendChild(Commons.actOps.transformActivity(acName+"_transform", webNode, tDocSoapCon, flow, wsdlName));
				
				if (tDocSoapCon.getFirstChild().getAttributes().getNamedItem("xmlns:wsc") == null) {
					Element mule = (Element) tDocSoapCon.getFirstChild();
					mule.setAttribute("xmlns:wsc", "http://www.mulesoft.org/schema/mule/wsc");
					String schemaLocation = mule.getAttribute("xsi:schemaLocation");
					schemaLocation += " http://www.mulesoft.org/schema/mule/wsc http://www.mulesoft.org/schema/mule/wsc/current/mule-wsc.xsd";
					mule.setAttribute("xsi:schemaLocation", schemaLocation);
				}
				Element soapReqReply = tDocSoapCon.createElement("wsc:consume");
				
				soapReqReply.setAttribute("doc:name", acName);
				soapReqReply.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
				soapReqReply.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
				
				String configNameWSDL = wsdlName.substring(0,wsdlName.lastIndexOf("."))+".wsdl";
				ResultSet rsWsdl = Commons.jdbcConnection.getConfigFile(configNameWSDL);
				String wsdlConfigContent = null;
				while (rsWsdl.next()) {
					wsdlConfigContent = rsWsdl.getString(2).toString();
				}
				
				Node wsdlNode = Commons.getDocBuilder().parse(new InputSource(new StringReader(wsdlConfigContent))).getDocumentElement();
				ArrayList<Node> node = new ArrayList<>();
											  
				
				Commons.fileOps.getNode(wsdlNode.getChildNodes(), 0, node, "wsdl:binding");
				
				System.out.println(wsdlConfigContent);
				
				for(int i = 0; i<node.get(0).getChildNodes().getLength(); i++) {
								if(node.get(0).getChildNodes().item(i).getNodeName().contentEquals("wsdl:operation")) {
									String operationName = node.get(0).getChildNodes().item(i).getAttributes().getNamedItem("name").getNodeValue();
									soapReqReply.setAttribute("operation", operationName);
								}
				}
				String connName = wsdlName.substring(0,wsdlName.lastIndexOf(".")).replace("\\","_")+"_conn";
				Commons.globalElements.addWebServiceConfigTag(wsdlName, webNode, connName );
				
				soapReqReply.setAttribute("config-ref", connName);
			
				flow.appendChild(soapReqReply);
				tDocSoapCon.getFirstChild().insertBefore(flow, tDocSoapCon.getFirstChild().getChildNodes().item(0));

				Commons.fileOps.writeFile(tDocSoapCon, new File(Commons.getMule().getAbsolutePath()+"\\"+acName.replace(" ", "_")+".xml"));
				count++;
				} catch (Exception e) {
				        e.printStackTrace();
				    }

			}

			public void soapRouterActivity(String wsdlName, Node webNode) throws SQLException, ParserConfigurationException, SAXException, IOException{
				int count =0;
				Document tDocSoap = Commons.getDocBuilder().parse(Commons.template);
				Element flow = tDocSoap.createElement("flow");
				System.out.println(wsdlName);
				String acName = wsdlName.substring(0,wsdlName.lastIndexOf(".")).replace("\\", "-");
				acName = acName.substring(acName.indexOf("ns-")+3);
				 flow.setAttribute("name", acName);
				 flow.setAttribute("doc:id", Commons.generateRandom(8)+"-eadc-40b9-98cc-268d14076da0");
				
				
				if (tDocSoap.getFirstChild().getAttributes().getNamedItem("xmlns:apikit-soap") == null) {
					Element mule = (Element) tDocSoap.getFirstChild();
					mule.setAttribute("xmlns:apikit-soap", "http://www.mulesoft.org/schema/mule/apikit-soap");
					String schemaLocation = mule.getAttribute("xsi:schemaLocation");
					schemaLocation += " http://www.mulesoft.org/schema/mule/apikit-soap http://www.mulesoft.org/schema/mule/apikit-soap/current/mule-apikit-soap.xsd";
					mule.setAttribute("xsi:schemaLocation", schemaLocation);
				}
				
				Element soapRouterEle = tDocSoap.createElement("apikit-soap:router");
				Element soapRouterAttr = tDocSoap.createElement("apikit-soap:attributes");

				soapRouterEle.setAttribute("doc:name", acName);
				soapRouterEle.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
				

				soapRouterEle.setAttribute("config-ref", acName+"_conn");
				
	  
				
				for(int i = 0; i<webNode.getChildNodes().getLength(); i++) {
					try {
						if(webNode.getChildNodes().item(i).getAttributes().getNamedItem("name").getNodeValue().contentEquals("operationList")) {
							Node opsListNode = webNode.getChildNodes().item(i);
							for(int j = 0 ; j<opsListNode.getChildNodes().getLength(); j++) {
								for(int k = 0; k<opsListNode.getChildNodes().item(j).getChildNodes().getLength(); k++) {
									try {
										if(opsListNode.getChildNodes().item(j).getChildNodes().item(k).getAttributes().getNamedItem("name").getNodeValue().contentEquals("serviceName")) {
											String serviceName = opsListNode.getChildNodes().item(j).getChildNodes().item(k).getTextContent();
											
											
											Element addFlow = tDocSoap.createElement("flow");
											addFlow.setAttribute("name", serviceName.substring(serviceName.indexOf(":")+1) +":\\"+acName+"_conn" );
						
												Element flowRef = tDocSoap.createElement("flow-ref");
												flowRef.setAttribute("doc:name", "Flow Reference");
												flowRef.setAttribute("doc:id", Commons.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
												flowRef.setAttribute("name", serviceName.replace(".", "-").replace(":", "-") );
												
												 addFlow.appendChild(flowRef);
											tDocSoap.getFirstChild().appendChild(addFlow);
										}
									}catch(Exception e) {}
								}
							}
						}
					}catch(Exception e) {}
				}
				soapRouterAttr.setTextContent("#["+"%dw 2.0\r\n"
						+ "              output application/java\r\n"
						+ "              ---\r\n"
						+ "              {\r\n"
						+ "                  headers: attributes.headers,\r\n"
						+ "                  method: attributes.method,\r\n"
						+ "                  queryString: attributes.queryString\r\n"
						+ "            }"+"]");
				
				
				// Retrieving path for http connection
				

				
				
				String configNameWSDL = wsdlName.substring(0,wsdlName.lastIndexOf("."))+".wsdl";
				ResultSet rsWsdl = Commons.jdbcConnection.getConfigFile(configNameWSDL);
				String wsdlConfigContent = null;
				while (rsWsdl.next()) {
					wsdlConfigContent = rsWsdl.getString(2).toString();
				}
				String addressName = "";
				String addressNameHTTP = "";
				String serviceNameWsdl = "";
				String portNameWsdl = "";
						
				System.out.println(wsdlConfigContent+" wsdl contenttttt of --- "+ wsdlName);
			if(wsdlConfigContent!=null) {
				Document wsdlDoc = Commons.getDocBuilder().parse(new InputSource(new StringReader(wsdlConfigContent)));
				Commons.fileOps.removeBlankLines(wsdlDoc);

				
				for(int i = 0; i< wsdlDoc.getFirstChild().getChildNodes().getLength();i++) {
					Node node = wsdlDoc.getFirstChild().getChildNodes().item(i);
					try {
						if( node.getNodeName().contentEquals("wsdl:service")) {
							addressName = node.getFirstChild().getFirstChild().getAttributes().getNamedItem("location").getNodeValue();
							addressNameHTTP = addressName.substring(addressName.indexOf("ws")+2,addressName.length());
							addressNameHTTP = addressNameHTTP.replace(":", ".");

							serviceNameWsdl = node.getAttributes().getNamedItem("name").getNodeValue();
							portNameWsdl = node.getFirstChild().getAttributes().getNamedItem("name").getNodeValue();
						}
					}catch(Exception e) {}

				}
			}else {
				System.out.println("---> ERROR : "+configNameWSDL + " is not exist in the DataBase ");
			}
				Commons.globalElements.addAPIKITforSoapConfigTag(webNode, acName+"_conn", serviceNameWsdl,portNameWsdl);
				Commons.restElements.addHttpListener(tDocSoap, flow, "SoapRouter", acName+"_HttpLsnr",addressNameHTTP);
				soapRouterEle.appendChild(soapRouterAttr);
				flow.appendChild(soapRouterEle);
				tDocSoap.getFirstChild().insertBefore(flow, tDocSoap.getFirstChild().getChildNodes().item(0));
   
				Commons.fileOps.writeFile(tDocSoap, new File(Commons.getMule().getAbsolutePath()+"\\"+acName.replace(" ", "_")+".xml"));
				 count++;
				
			}

			public Element sizeAgregator(String acName,String serviceName, Document tDoc) throws SQLException, ParserConfigurationException, SAXException, IOException {
				// TODO Auto-generated method stub
				if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:aggregators") == null) {
					Element mule = (Element) tDoc.getFirstChild();
					mule.setAttribute("xmlns:aggregators", "http://www.mulesoft.org/schema/mule/aggregators");
					String schemaLocation = mule.getAttribute("xsi:schemaLocation");
					schemaLocation += " http://www.mulesoft.org/schema/mule/os  http://www.mulesoft.org/schema/mule/os/current/mule-os.xsd";
					mule.setAttribute("xsi:schemaLocation", schemaLocation);
				}
				
				Element sizeAggr = tDoc.createElement("aggregators:size-based-aggregator");
				Element aggrComp = tDoc.createElement("aggregators:aggregation-complete");
				
				sizeAggr.setAttribute("name", acName);
				sizeAggr.setAttribute("doc:name", "Size based aggregator");
				sizeAggr.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
				sizeAggr.setAttribute("maxSize", "2");
				sizeAggr.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
				sizeAggr.setAttribute("objectStore", acName+"_conn");
				
				Commons.globalElements.addObjectStoreConfigTag(acName+"_conn",null);
				
				sizeAggr.appendChild(aggrComp);
				return sizeAggr;
				
			}
			public Element cacheElement(Document tDoc, String serviceName_cache, String cache_time) throws SQLException, ParserConfigurationException, SAXException, IOException {
				if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:ee") == null) {
					Element mule = (Element) tDoc.getFirstChild();
					mule.setAttribute("xmlns:ee", "http://www.mulesoft.org/schema/mule/ee/core");
					String schemaLocation = mule.getAttribute("xsi:schemaLocation");
					schemaLocation += " http://www.mulesoft.org/schema/mule/ee/core http://www.mulesoft.org/schema/mule/ee/core/current/mule-ee.xsd";
					mule.setAttribute("xsi:schemaLocation", schemaLocation);
				}
				Element cacheEle = tDoc.createElement("ee:cache");
				
				cacheEle.setAttribute("doc:name", "Cache");
				cacheEle.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
				cacheEle.setAttribute("cachingStrategy-ref", serviceName_cache+"_Strg");
				Commons.globalElements.addCachingStradegy(serviceName_cache+"_Strg",serviceName_cache);
				Commons.globalElements.addObjectStoreConfigTag(serviceName_cache, cache_time);
				return cacheEle;
				
			}

}
   

package com.sme.webmethods.utility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.stream.StreamResult;

import org.apache.xerces.xs.XSModel;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.sme.webmethods.service.Commons;

import jlibs.xml.sax.XMLDocument;
import jlibs.xml.xsd.XSInstance;
import jlibs.xml.xsd.XSParser;



public class RestElements {
	
	
	public void generateRaml() throws SQLException {
		String mainRaml = "#%RAML 1.0\r\n"
				+ "title: Member System API\r\n"
				+ "description: This RAML file desribe structure of all member system API.\r\n"
				+ "types:\r\n";
		
		String types = "";
		
		
		
		ResultSet rs = Commons.jdbcConnection.getRestResultSet();
		try {
		while(rs.next()) {
			String processName = rs.getString(1);
			String resourceName = rs.getString(2);
			String path = rs.getString(3);
			String base = rs.getString(4);
			String methodName = rs.getString(5);
			String inp = rs.getString(6);
			String out = rs.getString(7);
			String inpSchema = rs.getString(8);
			String outSchema = rs.getString(9);
			
			String inpType = null;
			String inpExp = null;
			String outType = null;
			String outExp = null;
			
			String inpFileName = Commons.getTrgPrjDir()+"\\src\\main\\resources\\docTypes\\"+resourceName+"_"+path.substring(1).replace("/", "-").replace("{", "").replace("}", "")+"_"+methodName+"_"+"request"+"_"+inp+".xsd";
			
			try (BufferedWriter writer = new BufferedWriter(new FileWriter(inpFileName))) {
				if(inpSchema.contains("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")) {
	        		writer.write(inpSchema);
	        	}
				else{
					writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
			        		+ "<xsd:schema xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">"+inpSchema.replace("xs:", "xsd:")+"</xsd:schema>");
			        
				}
		    } catch (IOException e) {
		        System.err.println("An error occurred: " + e.getMessage());
		    }
			File xmlFile1 = convertXsdToXml(inpFileName,inp);
			File jsonFile1 = convertXmlToJson(xmlFile1,"\\api\\examples\\","-example.json");
			convertJsonToRamlTypes(jsonFile1);
			
			String outFileName = Commons.getTrgPrjDir()+"\\src\\main\\resources\\docTypes\\"+resourceName+"_"+path.substring(1).replace("/", "-").replace("{", "").replace("}", "")+"_"+methodName+"_"+"response"+"_"+out+".xsd";
	        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outFileName))) {
	        	if(outSchema.contains("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")) {
	        		writer.write(outSchema);
	        	}
	        	else {
	        		writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
			        		+ "<xsd:schema xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">"+outSchema.replace("xs:", "xsd:")+"</xsd:schema>");
	        	}
		    } catch (IOException e) {
		        System.err.println("An error occurred: " + e.getMessage());
		    }
	        File xmlFile2 = convertXsdToXml(outFileName,out);
	        File jsonFile2 = convertXmlToJson(xmlFile2,"\\api\\examples\\","-example.json");
	        convertJsonToRamlTypes(jsonFile2);
		}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(rs != null) {
				rs.close();
			}
		}
		
		String resources = "";
		String resource = "";
		String tempResource = "";
		
		ResultSet rs1 = Commons.jdbcConnection.getRestResultSet();
		try {
		while(rs1.next()) {
			String processName = rs1.getString(1);
			String resourceName = rs1.getString(2);
			String path = rs1.getString(3);
			String base = rs1.getString(4);
			String methodName = rs1.getString(5);
			String inp = rs1.getString(6);
			String out = rs1.getString(7);
			String inpSchema = rs1.getString(8);
			String outSchema = rs1.getString(9);
			if(!tempResource.contentEquals(path)) {
				resources += resource;
				resource = path+":\r\n";
				tempResource=path;
			}
			String typein = resourceName+"_"+path.substring(1).replace("/", "-").replace("{", "").replace("}", "")+"_"+methodName+"_"+"request"+"_"+inp;
			String typeout = resourceName+"_"+path.substring(1).replace("/", "-").replace("{", "").replace("}", "")+"_"+methodName+"_"+"response"+"_"+out;
			
			types += "  "+typein+": !include types/"+typein+".raml\r\n";
			types += "  "+typeout+": !include types/"+typeout+".raml\r\n";
			
			
			if(methodName.toLowerCase().contentEquals("get")) {
                resource += "  "+methodName.toLowerCase()+":\r\n"
                         +"    responses:\r\n"
                         +"      200:\r\n"
                         +"        body:\r\n"
                         +"          application/json:\r\n"
                         +"            type: "+typeout+"\r\n"
                         +"            example: !include examples/"+typeout+"-example.json\r\n";
            }else {
                resource += "  "+methodName.toLowerCase()+":\r\n"
                         +"    body:\r\n"
                         +"      application/json:\r\n"
                         +"        type: "+typein+"\r\n"
                         +"        example: !include examples/"+typein+"-example.json\r\n"
                         +"    responses:\r\n"
                         +"      200:\r\n"
                         +"        body:\r\n"
                         +"          application/json:\r\n"
                         +"            type: "+typeout+"\r\n"
                         +"            example: !include examples/"+typeout+"-example.json\r\n";
            }
		}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(rs1 != null) {
				rs1.close();
			}
		}
		resources += resource;
		
		mainRaml += types + resources;
		
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(Commons.getTrgPrjDir()+"\\src\\main\\resources\\api\\api.raml"))) {
            writer.write(mainRaml);
        } catch (IOException e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
	}
	
	public File convertXsdToXml(String filename, String elementName) throws IOException, TransformerConfigurationException, ParserConfigurationException, SAXException, JSONException {
		
		Document doc = loadXsdDocument(filename);
		
		String fileStr = readFileToString(filename);

		final Element rootElem = doc.getDocumentElement();
		String nodeName = rootElem.getNodeName();
		String targetNamespace = null;
		if (rootElem != null && rootElem.getNodeName().equals(nodeName)) {
		    targetNamespace = rootElem.getAttribute("targetNamespace");
		}
		XSModel xsModel = new XSParser().parse(filename);
		XSInstance instance = new XSInstance();
		instance.minimumElementsGenerated = 1;
		instance.maximumElementsGenerated = 1;
		instance.generateDefaultAttributes = true;
		instance.generateOptionalAttributes = true;
		instance.maximumRecursionDepth = 0;
		instance.generateAllChoices = true;
		instance.showContentModel = true;
		instance.generateOptionalElements = true;
		
		QName rootElement = new QName(targetNamespace, elementName);
		XMLDocument sampleXml = new XMLDocument(new StreamResult(filename.replace("\\docTypes\\", "\\xmls\\").replace(".xsd", ".xml")), true, 4, null);
		instance.generate(xsModel, rootElement, sampleXml);
		
		String xmlStr = Commons.readFileToString(new File (filename.replace("\\docTypes\\", "\\xmls\\").replace(".xsd", ".xml")));
		xmlStr = xmlStr.replace("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"", "");
		
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename.replace("\\docTypes\\", "\\xmls\\").replace(".xsd", ".xml")))) {
			writer.write(xmlStr);
		} catch (IOException e) {
		    System.err.println("An error occurred: " + e.getMessage());
		}
		
		return new File(filename.replace("\\docTypes\\", "\\xmls\\").replace(".xsd", ".xml"));

	}
	
	
	public File convertXmlToJson(File xmlFile, String location, String extension) throws SAXException, IOException, ParserConfigurationException {
		
		// Create an XmlMapper instance
        XmlMapper xmlMapper = new XmlMapper();
        
        // Configure the XmlMapper to enable indentation
        xmlMapper.enable(SerializationFeature.INDENT_OUTPUT);

        // Parse the XML file into a JsonNode while preserving order
        JsonNode jsonNode = xmlMapper.readTree(xmlFile);

        // Wrap the single element in a root object if it's not already a JSON object
        if (!jsonNode.isObject()) {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
            ObjectWriter writer = objectMapper.writerWithDefaultPrettyPrinter();
            File jsonOutputFile = new File(xmlFile.getAbsolutePath().replace("\\xmls\\", location).replace(".xml", extension));
            
            // Create a JSON object with a root element
            jsonNode = objectMapper.createObjectNode().set("Response", jsonNode);

            // Convert the JsonNode to a JSON file with pretty printing
            writer.writeValue(jsonOutputFile, jsonNode);
            return jsonOutputFile;
        }

        // Create a JSON file with pretty printing
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
        ObjectWriter writer = objectMapper.writerWithDefaultPrettyPrinter();
        File jsonOutputFile = new File(xmlFile.getAbsolutePath().replace("\\xmls\\", location).replace(".xml", extension));
        writer.writeValue(jsonOutputFile, jsonNode);

        return jsonOutputFile;
		
		
		
//		XmlMapper xmlMapper = new XmlMapper();
//        xmlMapper.enable(SerializationFeature.INDENT_OUTPUT);
//        JsonNode jsonNode = xmlMapper.readTree(Commons.readFileToString(xmlFile));
//
//        ObjectMapper objectMapper = new ObjectMapper();
//        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
//        ObjectWriter writer = objectMapper.writerWithDefaultPrettyPrinter();
//
//        String jsonString = writer.writeValueAsString(jsonNode);
//        try (BufferedWriter writer1 = new BufferedWriter(new FileWriter(xmlFile.getAbsolutePath().replace("\\xmls\\", "\\api\\examples\\").replace(".xml", "-example.json")))) {
//			writer1.write(jsonString);
//		} catch (IOException e) {
//		    System.err.println("An error occurred: " + e.getMessage());
//		}
//        return new File(xmlFile.getAbsolutePath().replace("\\xmls\\", "\\api\\examples\\").replace(".xml", "-example.json"));
	}
	
	public void convertJsonToRamlTypes(File jsonFile) throws IOException {
		String json = Commons.readFileToString(jsonFile);
		
		JSONObject jsonNode = new JSONObject(json);
		
		String raml = generateRaml(jsonNode);
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(jsonFile.getAbsolutePath().replace("\\api\\examples\\","\\api\\types\\").replace("-example.json",".raml")))) {
		    writer.write(raml);
		} catch (IOException e) {
			System.err.println("An error occurred: " + e.getMessage());
		}
	}
	
	public static String readFileToString(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        byte[] bytes = Files.readAllBytes(path);
        return new String(bytes, StandardCharsets.UTF_8);
    }
	
	public static Document loadXsdDocument(String inputName) {
		final String filename = inputName;

		final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setValidating(false);
		factory.setIgnoringElementContentWhitespace(true);
		factory.setIgnoringComments(true);
		Document doc = null;

		try {
		    final DocumentBuilder builder = factory.newDocumentBuilder();
		    final File inputFile = new File(filename);
		    doc = builder.parse(inputFile);
		    Commons.fileOps.removeBlankLines(doc);
		} catch (final Exception e) {
		    e.printStackTrace();
		    // throw new ContentLoadException(msg);
		}

		return doc;
	}

	
	private static String generateRaml(JSONObject json) {
        StringBuilder ramlBuilder = new StringBuilder("#%RAML 1.0 DataType\n");

        generateRamlType(json, ramlBuilder, 0);

        return ramlBuilder.toString();
    }
	
	private static void generateRamlType(JSONObject json, StringBuilder ramlBuilder, int indentationLevel) {
        String indentation = getIndentation(indentationLevel);

        ramlBuilder.append(indentation).append("type: object\n");
        ramlBuilder.append(indentation).append("properties:\n");

        try {
            // Get the keys of the JSON object
            String[] keys = JSONObject.getNames(json);

            if (keys != null) {
                // Iterate over the keys
                for (String key : keys) {
                    Object value = json.get(key);

                    ramlBuilder.append(indentation).append("  ").append(key).append(":\n");
                    generateProperty(value, ramlBuilder, indentationLevel + 2);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private static void generateProperty(Object value, StringBuilder ramlBuilder, int indentationLevel) throws JSONException {
	    String indentation = getIndentation(indentationLevel);

	    if (value instanceof JSONObject) {
	        generateRamlType((JSONObject) value, ramlBuilder, indentationLevel);
	    } else if (value instanceof JSONArray) {
	        JSONArray jsonArray = (JSONArray) value;
	        if (jsonArray.length() > 0) {
	            Object firstElement = jsonArray.get(0);
	            if (firstElement instanceof JSONObject) {
	                ramlBuilder.append(indentation).append("  ").append("type: array\n");
	                ramlBuilder.append(indentation).append("  ").append("items:\n");
	                generateRamlType((JSONObject) firstElement, ramlBuilder, indentationLevel + 2);
	            } else {
	                ramlBuilder.append(indentation).append("  ").append("type: ").append(getRamlType(firstElement)).append("[]\n");
	            }
	        }
	    } else {
	        ramlBuilder.append(indentation).append("  ").append("type: ").append(getRamlType(value)).append("\n");
	    }
	}

    private static String getRamlType(Object value) {
        if (value instanceof String) {
            return "string";
        } else if (value instanceof Number) {
            return "number";
        } else if (value instanceof Boolean) {
            return "boolean";
        }
        return "any";
    }

    private static String getIndentation(int indentationLevel) {
        StringBuilder indentation = new StringBuilder();
        for (int i = 0; i < indentationLevel; i++) {
            indentation.append("  ");
        }
        return indentation.toString();
    }
	

//
	public void deleteMethod(Document tDocRest, String methodName, String resourcePath,String serviceName , String resourceName ) throws SAXException, IOException, ParserConfigurationException {

		Element deleteFlow = tDocRest.createElement("flow");
		deleteFlow.setAttribute("name",
				"delete:\\" + resourcePath.replace("{","(").replace("}",")")+ ":application\\json:" + resourceName);

		if (methodName.contentEquals("DELETE")) {

			Element flowRef = tDocRest.createElement("flow-ref");
			flowRef.setAttribute("doc:name", "Flow Reference");
			flowRef.setAttribute("doc:id", Commons.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
			 flowRef.setAttribute("name", serviceName.replace(".","-").replace(":","-"));
			
			
			deleteFlow.appendChild(flowRef);
		}

		tDocRest.getFirstChild().appendChild(deleteFlow);

	}

	public void putMethod(Document tDocRest, String methodName, String resourcePath,String serviceName , String resourceName ) {

		Element putFlow = tDocRest.createElement("flow");
		putFlow.setAttribute("name", "put:\\" + resourcePath.replace("{","(").replace("}",")")+ ":application\\json:" + resourceName);

		if (methodName.contentEquals("PUT")) {

			Element flowRef = tDocRest.createElement("flow-ref");
			flowRef.setAttribute("doc:name", "Flow Reference");
			flowRef.setAttribute("doc:id", Commons.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
			flowRef.setAttribute("name", serviceName.replace(".","-").replace(":","-"));

			putFlow.appendChild(flowRef);
		}

		tDocRest.getFirstChild().appendChild(putFlow);

	}

	public void getMethod(Document tDocRest, String methodName, String resourcePath,String serviceName , String resourceName ) {

		Element getFlow = tDocRest.createElement("flow");
		getFlow.setAttribute("name", "get:\\" + resourcePath.replace("{","(").replace("}",")")+ ":"+resourceName);

		if (methodName.contentEquals("GET")) {

			Element flowRef = tDocRest.createElement("flow-ref");
			flowRef.setAttribute("doc:name", "Flow Reference");
			flowRef.setAttribute("doc:id", Commons.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
			flowRef.setAttribute("name", serviceName.replace(".","-").replace(":","-"));

			getFlow.appendChild(flowRef);
		}

		tDocRest.getFirstChild().appendChild(getFlow);

	}

	public void postMethod(Document tDocRest, String methodName, String resourcePath,String serviceName , String resourceName ) {

		Element postFlow = tDocRest.createElement("flow");
		postFlow.setAttribute("name", "post:\\" + resourcePath.replace("{","(").replace("}",")") + ":application\\json:" + resourceName);

		if (methodName.contentEquals("POST")) {

			Element flowRef = tDocRest.createElement("flow-ref");
			flowRef.setAttribute("doc:name", "Flow Reference");
			flowRef.setAttribute("doc:id", Commons.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
			flowRef.setAttribute("name", serviceName.replace(".","-").replace(":","-"));

			postFlow.appendChild(flowRef);
		}

		tDocRest.getFirstChild().appendChild(postFlow);

	}

	public static int apikitConfigCount = 0;

	public void addApikitRouterActivity()
			throws ParserConfigurationException, SAXException, IOException, SQLException {

		
		
		Document tDocRest = Commons.getDocBuilder().parse(Commons.template);
		Element flow = tDocRest.createElement("flow");
		
		if (tDocRest.getFirstChild().getAttributes().getNamedItem("xmlns:apikit") == null) {
			Element mule = (Element) tDocRest.getFirstChild();
			mule.setAttribute("xmlns:apikit", "http://www.mulesoft.org/schema/mule/mule-apikit");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/mule-apikit http://www.mulesoft.org/schema/mule/mule-apikit/current/mule-apikit.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
		
		//
		 flow.setAttribute("name", Commons.getSrcPrjDir().getName()+"_Rest");
		 flow.setAttribute("doc:id", Commons.generateRandom(8)+"-eadc-40b9-98cc-268d14076da0");
		ArrayList<String> flows = new ArrayList<>();
		Element apikitRouter = tDocRest.createElement("apikit:router");
		//
		apikitRouter.setAttribute("doc:name", Commons.getSrcPrjDir().getName()+"_Rest");
		apikitRouter.setAttribute("doc:id", Commons.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
		
		 ArrayList<String> serviceName = new ArrayList<>();
		 for(File ndfFile : Commons.getNdfs()) {
				Document ndfDoc = Commons.getDocBuilder().parse(ndfFile);
				Commons.fileOps.removeBlankLines(ndfDoc);
				ArrayList<Node> node = new ArrayList<>();
				Commons.fileOps.getNodeWithAttribute(ndfDoc.getChildNodes(), 0, node, "value", "name", "serviceName");
				for(Node n : node) {
					serviceName.add(n.getTextContent());
				}
		 }
		ResultSet rs1 = Commons.jdbcConnection.getRestService();
		 
		String resourceName = "";
		String resourcePathIni = "";
		String methodNameIni = "";
		ArrayList<String> resPaths = new ArrayList<>();
		ArrayList<String> methods = new ArrayList<>();
		 while(rs1.next()) {
			  resourceName = rs1.getString("RESOURCE_NAME");
			  resourcePathIni = rs1.getString("PATH");
			 resPaths.add(resourcePathIni);
			  methodNameIni = rs1.getString("METHOD_NAME");
			  methods.add(methodNameIni);
		 }
		 
		 for (int i = 0; i < methods.size(); i++) {
			 					String methodName = methods.get(i);
			 					String resourcePath = resPaths.get(i);
			 					resourcePath = resourcePath.substring(1).replace("/", "\\");
			 
			 					if (methodName.contentEquals("DELETE")) {
			 						deleteMethod(tDocRest, methodName, resourcePath, serviceName.get(i), resourceName);
			 					}
			 					if (methodName.contentEquals("PUT")) {
			 						putMethod(tDocRest, methodName, resourcePath,serviceName.get(i),  resourceName);
			 					}
			 					if (methodName.contentEquals("GET")) {
			 						getMethod(tDocRest, methodName, resourcePath, serviceName.get(i),  resourceName);
			 					}
			 					if (methodName.contentEquals("POST")) {
			 						postMethod(tDocRest, methodName, resourcePath, serviceName.get(i),  resourceName);
			 					}
		 
		 }
		 
		Commons.globalElements.apikitConfigTag( tDocRest, flow, resourceName);
		 apikitRouter.setAttribute("config-ref", resourceName);
		
		addHttpListener(tDocRest, flow, resourceName, resourceName+"_HttpLsnr",null);
		tDocRest.getFirstChild().insertBefore(flow, tDocRest.getFirstChild().getChildNodes().item(0));
		flow.appendChild(apikitRouter);
		Commons.fileOps.writeFile(tDocRest, new File(Commons.getMule().getAbsolutePath()+"\\"+resourceName.replace(" ", "_")+".xml"));
		 
	}

	
	public void addHttpListener(Document tDoc, Element flow, String acName, String resourceName, String addressName) throws SQLException, ParserConfigurationException, SAXException, IOException {
		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:http") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:http", "http://www.mulesoft.org/schema/mule/http");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
		Element listener = tDoc.createElement("http:listener");
		listener.setAttribute("doc:name", "Listener");
		listener.setAttribute("doc:id", Commons.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
		if(acName.contains("SoapRouter")) {
			listener.setAttribute("path", addressName);
		}
		else {
			listener.setAttribute("path", "*");
		}
		Commons.globalElements.addHttpListenerConfigTag(tDoc, flow, resourceName);
		listener.setAttribute("config-ref", resourceName);
		flow.appendChild(listener);
	} 

}
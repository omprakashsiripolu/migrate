package com.sme.webmethods.utility;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.sme.webmethods.service.Commons;

public class FTPElements {
	 public void muleFTPNamespace(Document tDoc) {
		 if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:ftp") == null) {
				Element mule = (Element) tDoc.getFirstChild();
				mule.setAttribute("xmlns:ftp", "http://www.mulesoft.org/schema/mule/ftp");
				String schemaLocation = mule.getAttribute("xsi:schemaLocation");
				schemaLocation += " http://www.mulesoft.org/schema/mule/ftp http://www.mulesoft.org/schema/mule/ftp/current/mule-ftp.xsd";
				mule.setAttribute("xsi:schemaLocation", schemaLocation);
			}
	 }
	
	public Element addFtpDeleteActivity(String acName, Node acNode, Document tDoc, Element flow) {
		muleFTPNamespace( tDoc);
		Element ftpDelete = tDoc.createElement("ftp:delete");

		ftpDelete.setAttribute("doc:id", Commons.generateRandom(8) + "-4f56-9c63-d1d76a5d22ca");
		ftpDelete.setAttribute("doc:name", acName);

		return ftpDelete;

	}

	public Element addFtpRenameActivity(String acName, Node acNode, Document tDoc, Element flow) {
		muleFTPNamespace( tDoc);
		Element ftpRename = tDoc.createElement("ftp:rename");

		ftpRename.setAttribute("doc:id", Commons.generateRandom(8) + "-4f56-9c63-d1d76a5d22ca");
		ftpRename.setAttribute("doc:name", acName);

		return ftpRename;

	}

	public Element addFtpListActivity(String acName, Node acNode, Document tDoc, Element flow) {
		muleFTPNamespace( tDoc);
		Element ftpList = tDoc.createElement("ftp:list");

		ftpList.setAttribute("doc:id", Commons.generateRandom(8) + "-4f56-9c63-d1d76a5d22ca");
		ftpList.setAttribute("doc:name", acName);
		ftpList.setAttribute("target", acName.toLowerCase().replace(" ", "_"));

		return ftpList;

	}

	public Element addFtpReadActivity(String acName, Node acNode, Document tDoc, Element flow) {
		muleFTPNamespace( tDoc);
		Element ftpRead = tDoc.createElement("ftp:read");

		ftpRead.setAttribute("doc:id", Commons.generateRandom(8) + "-4f56-9c63-d1d76a5d22ca");
		ftpRead.setAttribute("doc:name", acName);
		ftpRead.setAttribute("target", acName.toLowerCase().replace(" ", "_"));

		return ftpRead;

	}
	public Element addFtpWriteActivity(String acName, Node acNode, Document tDoc, Element flow) {
		muleFTPNamespace( tDoc);
		Element ftpWrite = tDoc.createElement("ftp:write");
		Element ftpContent = tDoc.createElement("ftp:content");

		ftpWrite.setAttribute("doc:id", Commons.generateRandom(8) + "-4f56-9c63-d1d76a5d22ca");
		ftpWrite.setAttribute("doc:name", acName);
		return ftpWrite;

	}

}

package com.sme.webmethods.utility;

import java.util.ArrayList;
import java.util.stream.Collectors;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.mysql.cj.Query;
import com.sme.webmethods.service.Commons;

public class JdbcElements {
	public Element setJDBCActivtyConfig(String acName, Node acNode, Document tDoc, Element flow, String mulesoftActivity ) {

		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:db") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:db", "http://www.mulesoft.org/schema/mule/db");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
		Element activity = tDoc.createElement(mulesoftActivity);

		activity.setAttribute("doc:name", acName);
		activity.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
		activity.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
		
		return activity;

	}
	public Element sqlSelectActivity(String acName, Node acNode, Document tDoc, Element flow, String configContent) {

		
		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:db") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:db", "http://www.mulesoft.org/schema/mule/db");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
	
		
	//	Element sqlDirect = setJDBCActivtyConfig(acName, acNode, tDoc,flow);
		Element sqlSelect = tDoc.createElement("db:select");
		Element dbSql = tDoc.createElement("db:sql");
		Element dbInpParams = tDoc.createElement("db:input-parameters");
		
		
		
		String connectionName = configContent.substring(configContent.indexOf("connectionName"));
		connectionName = connectionName.substring(connectionName.indexOf("=")+1,connectionName.indexOf(","));
		
		String customQeryName = null;
		if(configContent.contains("BasicData:sql")) {
			customQeryName = configContent.substring(configContent.indexOf("BasicData:sql"));
			customQeryName = customQeryName.substring(customQeryName.indexOf("=")+1,customQeryName.indexOf(",sqlFieldType="));
		}
		else {
		String tableName = configContent.substring(configContent.indexOf("tables.tableName"));
		tableName = tableName.substring(tableName.indexOf("]")+1,tableName.indexOf("[Ljava"));
		
		
		// ------- If joins used, captures table name here
		String joinCndtn = null;
		if(tableName.contains("[")) {
			String[] multiTables = tableName.split(",");
			ArrayList<String> tbNames =new  ArrayList<String>();
			int count =1;
			for (String tbleName : multiTables) {
				String  addColumn = "";
				if(tbleName.contains("[")) {
					addColumn = tbleName.substring(tbleName.indexOf("]")+1,tbleName.length());
				}
				else {
					addColumn = tbleName;
				}
				
				if(addColumn.length()>0) {
					String t = "t";
					tbNames.add(addColumn +" " + t + count + ",");
					count++;
				}
			}
			
			tableName = tbNames.stream().collect(Collectors.joining(" "));	
			tableName = tableName.substring(0, tableName.length()-1);
			
			// ------- If joins used, captures left and right column Names here
			String leftJoinclmn = configContent.substring(configContent.indexOf("joins.leftColumn"));
			leftJoinclmn = leftJoinclmn.substring(leftJoinclmn.indexOf("=")+1,leftJoinclmn.indexOf("[Ljava"));
			if(leftJoinclmn.contains("]")){
				leftJoinclmn = leftJoinclmn.substring(leftJoinclmn.indexOf("]")+1);
			}
			
			String rightJoinclmn = configContent.substring(configContent.indexOf("joins.rightColumn"));
			rightJoinclmn = rightJoinclmn.substring(rightJoinclmn.indexOf("=")+1,rightJoinclmn.indexOf("[Ljava"));
			if(rightJoinclmn.contains("]")){
				rightJoinclmn = rightJoinclmn.substring(rightJoinclmn.indexOf("]")+1);
			}
			
			joinCndtn =tbNames.get(0).substring(0,tbNames.get(0).indexOf(",")) + " FULL JOIN " + tbNames.get(1).substring(0,tbNames.get(1).indexOf(",")) + " ON " + leftJoinclmn + " = " + rightJoinclmn;
		
		}
		
		else {
			tableName = tableName+" t1 ";
		}
	
		
		// Select Expression 
		String selectExpCnt = null;
		String selectContent = configContent.substring(configContent.indexOf("select.expression"));
		selectContent = selectContent.substring(selectContent.indexOf("=")+1,selectContent.indexOf("[Ljava"));
		String[] selectCntent = selectContent.split(",");
		ArrayList<String> slctNames =new  ArrayList<String>();
		for (String expName : selectCntent) {
			String  addColumn = "";
			if(expName.contains("[")) {
				addColumn = expName.substring(expName.indexOf("]")+1,expName.length());
			}
			else {
				addColumn = expName;
			}
			
			if(addColumn.length()>0) {
				slctNames.add(addColumn +" ,");
				
			}
		}
		selectExpCnt = slctNames.stream().collect(Collectors.joining(" "));	
		selectExpCnt = selectExpCnt.substring(0, selectExpCnt.length()-1);

		// Select Expression closed
		
		//  If where condition exists
		String condLeftName = configContent.substring(configContent.indexOf("where.leftExpr"));
		condLeftName = condLeftName.substring(condLeftName.indexOf("=")+1,condLeftName.indexOf("[Ljava"));
		ArrayList<String> condtnNames =new  ArrayList<String>();
		String[] leftVariables = condLeftName.split(",");
		
		for (String leftVar : leftVariables) {
			String  addColumn = "";
			if(leftVar.contains("[")) {
				addColumn = leftVar.substring(leftVar.indexOf("]")+1,leftVar.length());
			}
			else {
				addColumn = leftVar;
			}
				if(addColumn.length()>0) {
					condtnNames.add(addColumn );
				}
			}
		
		String valueParams = "";
		String inputValueParams = "{ \n";
		if(condtnNames.size()>0) {
			valueParams = " WHERE ";
			for(int i=0; i<condtnNames.size();i++) {
				valueParams += condtnNames.get(i) + " = " + ":" + condtnNames.get(i).substring(condtnNames.get(i).indexOf(".")+1) ;
				inputValueParams += condtnNames.get(i).substring(condtnNames.get(i).indexOf(".")+1) + " : " + "payload." + condtnNames.get(i).substring(condtnNames.get(i).indexOf(".")+1) + ",\n";
			}
			inputValueParams = inputValueParams.substring(0,inputValueParams.lastIndexOf(",")) + " \n}";
		}
		
		dbInpParams.setTextContent(inputValueParams);
		
		//  If Where condition closed
		
		// Input params
		/*if(configContent.contains("where.inputFieldName")) {
			String condRightName = configContent.substring(configContent.indexOf("where.inputFieldName"));
			condRightName = condRightName.substring(condRightName.indexOf("=")+1,condRightName.indexOf("[Ljava"));

			ArrayList<String> condtnRightNames =new  ArrayList<String>();
			String[] rightVariables = condRightName.split(",");
			
			for (String rightVar : rightVariables) {
					String  addColumn = rightVar.substring(0,rightVar.length());
					if(addColumn.length()>0) {
						condtnRightNames.add(addColumn.substring(addColumn.indexOf("]"),addColumn.length()));
					}
				}
			String whereCondtn = null;
			String valueRightParams = "";
			if(condtnNames.size()>0) {
				for(int i=0; i<condtnRightNames.size();i++) {
					//valueRightParams += condtnRightNames.get(i).substring(condtnRightNames.get(i).indexOf("]")+1,condtnRightNames.get(i).length()) + " = " + " ? " ;
					valueRightParams = condtnRightNames.get(i) + " = " + " ? " ;
					whereCondtn += condtnNames.get(i) + " = ?";
					
				}
			}
		}*/
	//  ------ input Params closed
		
		if(joinCndtn != null) {
			dbSql.setTextContent("SELECT " + selectExpCnt + " FROM " + joinCndtn + valueParams);
		}
		else {
			dbSql.setTextContent("SELECT " + selectExpCnt + " FROM " + tableName + valueParams);
		}
	
	}
		if(customQeryName!=null) {
			dbSql.setTextContent(customQeryName);
		}
			
		
		sqlSelect.setAttribute("config-ref", connectionName);
		sqlSelect.setAttribute("doc:name", acName);
		sqlSelect.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
		sqlSelect.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
		
		sqlSelect.appendChild(dbSql);
		sqlSelect.appendChild(dbInpParams);
		return sqlSelect;
	}
	
	public Element sqlDynSelectActivity(String acName, Node acNode, Document tDoc, Element flow, String configContent) {

		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:db") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:db", "http://www.mulesoft.org/schema/mule/db");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
	//	Element sqlDirect = setJDBCActivtyConfig(acName, acNode, tDoc,flow);
		Element sqlSelect = tDoc.createElement("db:select");
		Element dbSql = tDoc.createElement("db:sql");
		Element dbInpParams = tDoc.createElement("db:input-parameters");
		String connectionName = configContent.substring(configContent.indexOf("connectionName"));
		connectionName = connectionName.substring(connectionName.indexOf("=")+1,connectionName.indexOf(","));
		
		String queryName = configContent.substring(configContent.indexOf("BasicData:sql"));
		queryName = queryName.substring(queryName.indexOf("=")+1,queryName.indexOf(",sqlFieldType"));
		
		
		
		sqlSelect.setAttribute("config-ref", connectionName);
		sqlSelect.setAttribute("doc:name", acName);
		sqlSelect.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
		sqlSelect.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
		
		dbSql.setTextContent(queryName);
		
		sqlSelect.appendChild(dbSql);
		return sqlSelect;
		
	}
	
	public Element sqlInsertActivity(String acName, Node acNode, Document tDoc, Element flow, String configContent) {
		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:db") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:db", "http://www.mulesoft.org/schema/mule/db");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
		//	Element sqlDirect = setJDBCActivtyConfig(acName, acNode, tDoc,flow);
		
		Element sqlInsert = tDoc.createElement("db:insert");
		Element dbSql = tDoc.createElement("db:sql");
		Element dbInpParams = tDoc.createElement("db:input-parameters");
		String connectionName = configContent.substring(configContent.indexOf("connectionName"));
		connectionName = connectionName.substring(connectionName.indexOf("=")+1,connectionName.indexOf(","));
		sqlInsert.setAttribute("config-ref", connectionName);
		sqlInsert.setAttribute("doc:name", acName);
		sqlInsert.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
		sqlInsert.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
		
		String tableName = configContent.substring(configContent.indexOf("tables.tableName"));
		tableName = tableName.substring(tableName.indexOf("]")+1,tableName.indexOf("[Ljava"));
		
		String columnName = configContent.substring(configContent.indexOf("tables.columnInfo"));
		columnName = columnName.substring(columnName.indexOf("=")+1,columnName.indexOf("[Ljava"));
		
		ArrayList<String> columnNames =new  ArrayList<String>();
		String[] lines = columnName.split("\n");
		
		for (String line : lines) {
			
			if(line.contains("[0]")) {
				columnNames.add(line.substring(line.indexOf("]")+1,line.indexOf("\\")));
			}
			else {
				String  addColumn = line.substring(0,line.indexOf("\\"));
				columnNames.add(addColumn);
			}
		}
		String valueParams = "";
		valueParams += "(";
		for(int i=0; i<columnNames.size();i++) {
			if(i==columnNames.size()-1) {
				valueParams += "?)";
				break;
			}
			valueParams += "?,";
		}
		
		String inpParamsQuery = "(";
		for(int i=0; i<columnNames.size();i++) {
			if(i<=columnNames.size()-1) {
				inpParamsQuery +=": " + columnNames.get(i) + ",";
			}
		}
		inpParamsQuery = inpParamsQuery.substring(0,inpParamsQuery.length()-1);
		inpParamsQuery += ")";
		
		String inpParams = "";
		for(int i=0; i<columnNames.size();i++) {
			if(i<=columnNames.size()-1) {
				inpParams +="\n" +"\"" + columnNames.get(i) + "\"" + ":" + "\"\"" + ",";
			}
		}
		
		dbSql.setTextContent("INSERT INTO " + tableName + " " + columnNames.toString().replace("[", "(") .replace("]", ")")+ " VALUES " + inpParamsQuery );
		
		
	//	dbSql.setTextContent("INSERT INTO " + tableName + " " + columnNames.toString().replace("[", "(") .replace("]", ")")+ " VALUES " + valueParams );
		dbInpParams.setTextContent("#[{"+  inpParams.substring(0,inpParams.length()-1) + "\n" +"}]");
		
		
		sqlInsert.appendChild(dbSql);
		sqlInsert.appendChild(dbInpParams);
		return sqlInsert;
	}
	
	public Element sqlDeleteActivity(String acName, Node acNode, Document tDoc, Element flow, String configContent) {
		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:db") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:db", "http://www.mulesoft.org/schema/mule/db");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
		//	Element sqlDirect = setJDBCActivtyConfig(acName, acNode, tDoc,flow);
			Element sqlDelete = tDoc.createElement("db:delete");
			Element dbSql = tDoc.createElement("db:sql");
			Element dbInpParams = tDoc.createElement("db:input-parameters");
			String connectionName = configContent.substring(configContent.indexOf("connectionName"));
			connectionName = connectionName.substring(connectionName.indexOf("=")+1,connectionName.indexOf(","));
			sqlDelete.setAttribute("config-ref", connectionName);
			sqlDelete.setAttribute("doc:name", acName);
			sqlDelete.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
			sqlDelete.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
			
			String tableName = configContent.substring(configContent.indexOf("tables.tableName"));
			tableName = tableName.substring(tableName.indexOf("]")+1,tableName.indexOf("[Ljava"));
			
			String columnName = configContent.substring(configContent.indexOf("where.leftExpr"));
			columnName = columnName.substring(columnName.indexOf("=")+1,columnName.indexOf("[Ljava"));
			
			ArrayList<String> columnNames =new  ArrayList<String>();
			String[] paramNames = columnName.split(",");
			for (String paramName : paramNames) {
				String  addColumn = paramName.substring(paramName.indexOf("]")+1);
				columnNames.add(addColumn + " = ?  ");
			}
			
			String inpParams = "";
			for(int i=0; i<columnNames.size();i++) {
				if(i<=columnNames.size()-1) {
					inpParams +="\n" +"\"" + columnNames.get(i) + "\"" + ":" + "\"\"" + ",";
				}
			}
			dbSql.setTextContent("DELETE FROM " + tableName + " WHERE " + columnNames.toString().replace("[", "") .replace("]", ""));
			dbInpParams.setTextContent("#[{"+  inpParams.substring(0,inpParams.length()-1) + "\n" +"}]");
			
			sqlDelete.appendChild(dbSql);
			sqlDelete.appendChild(dbInpParams);
			return sqlDelete;
		}
	
	public Element sqlUpdateActivity(String acName, Node acNode, Document tDoc, Element flow, String configContent) {
		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:db") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:db", "http://www.mulesoft.org/schema/mule/db");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
		//	Element sqlDirect = setJDBCActivtyConfig(acName, acNode, tDoc,flow);
			Element sqlUpdate = tDoc.createElement("db:update");
			Element dbSql = tDoc.createElement("db:sql");
			Element dbInpParams = tDoc.createElement("db:input-parameters");
			String connectionName = configContent.substring(configContent.indexOf("connectionName"));
			connectionName = connectionName.substring(connectionName.indexOf("=")+1,connectionName.indexOf(","));
			sqlUpdate.setAttribute("config-ref", connectionName);
			sqlUpdate.setAttribute("doc:name", acName);
			sqlUpdate.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
			sqlUpdate.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
			
			String tableName = configContent.substring(configContent.indexOf("tables.tableName"));
			tableName = tableName.substring(tableName.indexOf("]")+1,tableName.indexOf("[Ljava"));
			
			String columnName = configContent.substring(configContent.indexOf("update.column"));
			columnName = columnName.substring(columnName.indexOf("=")+1,columnName.indexOf("[Ljava"));

			ArrayList<String> columnNames =new  ArrayList<String>();
			String[] paramNames = columnName.split(",");
			for (String paramName : paramNames) {
				String  addColumn = paramName.substring(paramName.indexOf("]")+1);
				columnNames.add(addColumn + " = ?  ");
			}
			
			String inpParams = "";
			for(int i=0; i<columnNames.size();i++) {
				if(i<=columnNames.size()-1) {
					inpParams +="\n" +"\"" + columnNames.get(i) + "\"" + ":" + "\"\"" + ",";
				}
			}
			
			dbSql.setTextContent("UPDATE " + tableName+ " SET " +  columnNames.toString().replace("[", "") .replace("]", ""));
			dbInpParams.setTextContent("#[{"+  inpParams.substring(0,inpParams.length()-1) + "\n" +"}]");
			

			sqlUpdate.appendChild(dbSql);
			sqlUpdate.appendChild(dbInpParams);
			return sqlUpdate;
		}
	
	public Element sqlStoredProcActivity(String acName, Node acNode, Document tDoc, Element flow, String configContent) {
		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:db") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:db", "http://www.mulesoft.org/schema/mule/db");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
		//	Element sqlDirect = setJDBCActivtyConfig(acName, acNode, tDoc,flow);
			Element sqlStoredProc = tDoc.createElement("db:stored-procedure");
			Element dbSql = tDoc.createElement("db:sql");
			String connectionName = configContent.substring(configContent.indexOf("connectionName"));
			connectionName = connectionName.substring(connectionName.indexOf("=")+1,connectionName.indexOf(","));
			sqlStoredProc.setAttribute("config-ref", connectionName);
			sqlStoredProc.setAttribute("doc:name", acName);
			sqlStoredProc.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
			sqlStoredProc.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
			
			sqlStoredProc.appendChild(dbSql);
			return sqlStoredProc;
		}
	
	
	
	
	
	

	
	public Element batchInsertActivity(String acName, Node acNode, Document tDoc, Element flow, String configContent) {
		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:db") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:db", "http://www.mulesoft.org/schema/mule/db");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
		//	Element sqlDirect = setJDBCActivtyConfig(acName, acNode, tDoc,flow);
			Element sqlBulkInsert = tDoc.createElement("db:bulk-insert");
			Element dbSql = tDoc.createElement("db:sql");
			String connectionName = configContent.substring(configContent.indexOf("connectionName"));
			connectionName = connectionName.substring(connectionName.indexOf("=")+1,connectionName.indexOf(","));
			sqlBulkInsert.setAttribute("config-ref", connectionName);
			sqlBulkInsert.setAttribute("doc:name", acName);
			sqlBulkInsert.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
			sqlBulkInsert.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
			
			String tableName = configContent.substring(configContent.indexOf("tables.tableName"));
			tableName = tableName.substring(tableName.indexOf("]")+1,tableName.indexOf("[Ljava"));
			
			String columnName = configContent.substring(configContent.indexOf("tables.columnInfo"));
			columnName = columnName.substring(columnName.indexOf("=")+1,columnName.indexOf("[Ljava"));
			
			ArrayList<String> columnNames =new  ArrayList<String>();
			String[] lines = columnName.split("\n");
			for (String line : lines) {
				
				if(line.contains("[0]")) {
					columnNames.add(line.substring(line.indexOf("]")+1,line.indexOf("\\")));
				}
				else {
					String  addColumn = line.substring(0,columnName.indexOf("\\"));
					columnNames.add(addColumn.substring(0,addColumn.indexOf("\\")));
				}
			}
			String valueParams = "";
			valueParams += "(";
			for(int i=0; i<columnNames.size();i++) {
				if(i==columnNames.size()-1) {
					valueParams += "?)";
					break;
				}
				valueParams += "?,";
			}
			
			dbSql.setTextContent("INSERT INTO " + tableName + " " + columnNames.toString().replace("[", "(") .replace("]", ")")+ " VALUES " + valueParams );
			
			
			sqlBulkInsert.appendChild(dbSql);
			return sqlBulkInsert;
	}
	public Element batchUpdateActivity(String acName, Node acNode, Document tDoc, Element flow, String configContent) {
		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:db") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:db", "http://www.mulesoft.org/schema/mule/db");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
		
		//	Element sqlDirect = setJDBCActivtyConfig(acName, acNode, tDoc,flow);
			Element sqlBulkUpdate = tDoc.createElement("db:bulk-update");
			Element dbSql = tDoc.createElement("db:sql");
			String connectionName = configContent.substring(configContent.indexOf("connectionName"));
			connectionName = connectionName.substring(connectionName.indexOf("=")+1,connectionName.indexOf(","));
			sqlBulkUpdate.setAttribute("config-ref", connectionName);
			sqlBulkUpdate.setAttribute("doc:name", acName);
			sqlBulkUpdate.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
			sqlBulkUpdate.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
			
			String tableName = configContent.substring(configContent.indexOf("tables.tableName"));
			tableName = tableName.substring(tableName.indexOf("]")+1,tableName.indexOf("[Ljava"));
			
			String columnName = configContent.substring(configContent.indexOf("update.column"));
			columnName = columnName.substring(columnName.indexOf("=")+1,columnName.indexOf("[Ljava"));

			ArrayList<String> columnNames =new  ArrayList<String>();
			String[] paramNames = columnName.split(",");
			for (String paramName : paramNames) {
				String  addColumn = paramName.substring(paramName.indexOf("]")+1);
				columnNames.add(addColumn + " = ?  ");
			}
			
			dbSql.setTextContent("UPDATE " + tableName+ " SET " +  columnNames.toString().replace("[", "") .replace("]", "")+  ";");

			
			sqlBulkUpdate.appendChild(dbSql);
			return sqlBulkUpdate;
	}
	public Element customSqlActivity(String acName, Node acNode, Document tDoc, Element flow, String configContent) {
		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:db") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:db", "http://www.mulesoft.org/schema/mule/db");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
		//	Element sqlDirect = setJDBCActivtyConfig(acName, acNode, tDoc,flow);
			Element customSql = tDoc.createElement("db:execute-ddl");
			Element dbSql = tDoc.createElement("db:sql");
			String connectionName = configContent.substring(configContent.indexOf("connectionName"));
			connectionName = connectionName.substring(connectionName.indexOf("=")+1,connectionName.indexOf(","));
			customSql.setAttribute("config-ref", connectionName);
			customSql.setAttribute("doc:name", acName);
			customSql.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
			customSql.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
			
			String queryName = configContent.substring(configContent.indexOf("BasicData:sql"));
			queryName = queryName.substring(queryName.indexOf("=")+1,queryName.indexOf(",sqlFieldType="));
			dbSql.setTextContent(queryName + ";");
			
			
			customSql.appendChild(dbSql);
			return customSql;
	}

	
	
	

}

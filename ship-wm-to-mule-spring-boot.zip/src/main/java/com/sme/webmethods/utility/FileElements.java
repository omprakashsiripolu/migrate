package com.sme.webmethods.utility;

import java.util.ArrayList;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.sme.webmethods.service.Commons;

public class FileElements {

	
	public Element fileReadActivity(String acName, Node acNode, Document tDoc, Element flow, String string) {
		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");

			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";

			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
		ArrayList<Node> node  = new ArrayList<>();
		Commons.fileOps.getNodeWithAttribute(acNode.getChildNodes(), 0, node, "MAPSET", "NAME", "Setter");
		Commons.fileOps.getNode(node.get(0).getChildNodes(), 0, node, "Values");
		String filePath = node.get(1).getFirstChild().getTextContent();
		
		
		Element fileRead = tDoc.createElement("file:read");

		fileRead.setAttribute("doc:name", acName);
		fileRead.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
		fileRead.setAttribute("config-ref", "File_config1");
		fileRead.setAttribute("target", acName.replace(" ", "-"));
		fileRead.setAttribute("path", filePath);
		return fileRead;
	}
	public Element copyFileActivity(String acName, Node acNode, Document tDoc, Element flow) {

		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");

			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";

			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}

		Element copyFile = tDoc.createElement("file:copy");
		copyFile.setAttribute("doc:name", acName);
		copyFile.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
		copyFile.setAttribute("config-ref", "File_config1");

		return copyFile;
	}
	public Element removeFileActivity(String acName, Node acNode, Document tDoc, Element flow) {

		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");

			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";

			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}

		Element deleteFile = tDoc.createElement("file:delete");

		deleteFile.setAttribute("doc:name", acName);
		deleteFile.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
		deleteFile.setAttribute("config-ref", "File_config1");
		deleteFile.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
		return deleteFile;
	}
	public Element listFilesActivity(String acName, Node acNode, Document tDoc, Element flow) {

		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
		Element listFiles = tDoc.createElement("file:list");
		Element fileMatcher = tDoc.createElement("file:matcher");


		listFiles.setAttribute("doc:name", acName);
		listFiles.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
		listFiles.setAttribute("config-ref", "File_config1");
		listFiles.setAttribute("target", acName.toLowerCase().replace(" ", "_"));

		// substring(pName.lastIndexOf('/')+1,pName.lastIndexOf('.');
		// System.out.println(directoryName.substring(directoryName.lastIndexOf("\\")+1));
		listFiles.appendChild(fileMatcher);
		return listFiles;
	}
	public Element writeFileActivity(String acName, Node acNode, Document tDoc, Element flow) {
		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}

		Element writeFile = tDoc.createElement("file:write");
		Element fileContent = tDoc.createElement("file:content");
		writeFile.setAttribute("doc:name", acName);
		writeFile.setAttribute("doc:id", Commons.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
		writeFile.setAttribute("config-ref", "File_config1");

		
		writeFile.appendChild(fileContent);
		return writeFile;
	}

	



}

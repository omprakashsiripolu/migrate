package com.sme.webmethods.utility;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.sme.webmethods.service.Commons;

public class JMSElements {
	
	 public void muleJMSNamespace(Document tDoc) {
		 if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:jms") == null) {
				Element mule = (Element) tDoc.getFirstChild();
				mule.setAttribute("xmlns:jms", "http://www.mulesoft.org/schema/mule/jms");
				String schemaLocation = mule.getAttribute("xsi:schemaLocation");
				schemaLocation += " http://www.mulesoft.org/schema/mule/jms http://www.mulesoft.org/schema/mule/jms/current/mule-jms.xsd";
				mule.setAttribute("xsi:schemaLocation", schemaLocation);
			}
	 }
	 public void jmsMQNamespace(Document tDoc) {
		 if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:ibm-mq") == null) {
				Element mule = (Element) tDoc.getFirstChild();
				mule.setAttribute("xmlns:ibm-mq", "http://www.mulesoft.org/schema/mule/ibm-mq");
				String schemaLocation = mule.getAttribute("xsi:schemaLocation");
				schemaLocation += " http://www.mulesoft.org/schema/mule/ibm-mq http://www.mulesoft.org/schema/mule/ibm-mq/current/mule-ibm-mq.xsd";
				mule.setAttribute("xsi:schemaLocation", schemaLocation);
			}
	 }
	 public Element jmsMQSubscriber(String messTypeDestn,String acName, String destnName, Document tDoc) throws SAXException, IOException, ParserConfigurationException {
		 acName = acName;
		 jmsMQNamespace(tDoc);
		 Element consumeMQ = tDoc.createElement("ibm-mq:consume");

		 consumeMQ.setAttribute("doc:id", Commons.generateRandom(8) + "ba44-4f56-9c63-d1d76a5d22ca");
		 consumeMQ.setAttribute("doc:name", "Consume");
		 consumeMQ.setAttribute("destination", messTypeDestn );

		 consumeMQ.setAttribute("config-ref", messTypeDestn+"_conn");
		 Commons.globalElements.addJmsMQConfigTag(messTypeDestn+"_conn");
			
		return consumeMQ;
			
		 
	 }
	 
	 public Element jmsMQPublish(String acName,Node acNode, Document tDoc,String destnName) throws SAXException, IOException, ParserConfigurationException {
			
		 jmsMQNamespace(tDoc);
			 Element publishMQ = tDoc.createElement("ibm-mq:publish");
			 
			 publishMQ.setAttribute("name", acName);
			 publishMQ.setAttribute("doc:id", Commons.generateRandom(8) + "ba44-4f56-9c63-d1d76a5d22ca");
			 publishMQ.setAttribute("doc:name", "Publish");
			 
			 ArrayList<Node> destnNodes = new ArrayList<>();
			 Commons.fileOps.getNodeWithAttribute(acNode.getChildNodes(), 0, destnNodes, "MAPSET", "NAME", "Setter");
			 ArrayList<Node> destnNode = new ArrayList<>();
			 Commons.fileOps.getNodeWithAttribute(destnNodes.get(0).getChildNodes(), 0, destnNode, "value", "name", "xml");
			 destnName = destnNode.get(0).getTextContent();
			 publishMQ.setAttribute("destination", destnName );
			 publishMQ.setAttribute("destinationType", "TOPIC");
			 
			 publishMQ.setAttribute("config-ref", destnName+"_conn");
			 Commons.globalElements.addJmsMQConfigTag(destnName+"_conn");
			return publishMQ;
				
			 
		 }
	 
	 public Element jmsMQOnNewMessageActivity(String messTypeDestn,String acName, String destnName, Document tDoc) throws SAXException, IOException, ParserConfigurationException{
		 jmsMQNamespace(tDoc);
		String queueRecXSLT = null;
		String jmsRepActXSLT = null;

			Element jmsListener = tDoc.createElement("ibm-mq:listener");
			Element jmsConsumerType = tDoc.createElement("ibm-mq:consumer-type");
			Element jmsResponse = tDoc.createElement("ibm-mq:topic-consumer");
	
			jmsListener.setAttribute("name", acName);
			jmsListener.setAttribute("doc:id", Commons.generateRandom(8) + "ba44-4f56-9c63-d1d76a5d22ca");
			jmsListener.setAttribute("doc:name", "On New Message");
			jmsListener.setAttribute("destination", messTypeDestn);
			jmsListener.setAttribute("config-ref", messTypeDestn+"_conn");
			Commons.globalElements.addJmsMQConfigTag(messTypeDestn+"_conn");
			
			jmsConsumerType.appendChild(jmsResponse);
			jmsListener.appendChild(jmsConsumerType);
			return jmsListener;
		}

	 
	 
	 
	 public Element addJMSPublishActivity(String acName,Node acNode, Document tDoc,String destnName) throws SAXException, IOException, ParserConfigurationException {
		 	muleJMSNamespace(tDoc);
			Element publish = tDoc.createElement("jms:publish");
			Element body = tDoc.createElement("jms:body");
			Element message = tDoc.createElement("jms:message");
			Element jmsReplyTo = tDoc.createElement("jms:reply-to");
			
			
			 publish.setAttribute("name", acName);
			 publish.setAttribute("doc:id", Commons.generateRandom(8) + "ba44-4f56-9c63-d1d76a5d22ca");
			 publish.setAttribute("doc:name", "Publish");
			 
			 ArrayList<Node> destnNodes = new ArrayList<>();
			 Commons.fileOps.getNodeWithAttribute(acNode.getChildNodes(), 0, destnNodes, "MAPSET", "NAME", "Setter");
			 ArrayList<Node> destnNode = new ArrayList<>();
			 Commons.fileOps.getNodeWithAttribute(destnNodes.get(0).getChildNodes(), 0, destnNode, "value", "name", "xml");
			 if(destnNode.size()>0) {
				 destnName = destnNode.get(0).getTextContent();
			 }
			 
			 publish.setAttribute("destination", destnName );
			 publish.setAttribute("destinationType", "TOPIC");
			 
			 publish.setAttribute("config-ref", destnName+"_conn");
			 Commons.globalElements.addJmsConfigTag(destnName+"_conn");
			
			message.appendChild(body);
			publish.appendChild(message);

			return publish;
		}

		public Element addJMSOnNewMessageActivity(String topicName,String acName, Document tDoc) throws SAXException, IOException, ParserConfigurationException{
			 muleJMSNamespace(tDoc);
				Element jmsListener = tDoc.createElement("jms:listener");
				Element jmsConsumerType = tDoc.createElement("jms:consumer-type");
				Element jmsTopicConsumer = tDoc.createElement("jms:topic-consumer");
				Element jmsResponse = tDoc.createElement("jms:response");
				
				jmsListener.setAttribute("name", acName);
				jmsListener.setAttribute("doc:id", Commons.generateRandom(8) + "ba44-4f56-9c63-d1d76a5d22ca");
				jmsListener.setAttribute("doc:name", "On New Message");
				jmsListener.setAttribute("destination", topicName);
				jmsListener.setAttribute("config-ref", topicName+"_conn");
				Commons.globalElements.addJmsConfigTag(topicName+"_conn");
				
				//jmsConsumerType.appendChild(jmsResponse);
				jmsConsumerType.appendChild(jmsTopicConsumer);
				jmsListener.appendChild(jmsConsumerType);
				return jmsListener;
			}

		
		
				

		public Element addJMSPublishConsumeActivity(String acName, Node acNode, Document tDoc, Element flow) {
			muleJMSNamespace(tDoc);
			Element publishConsume = tDoc.createElement("jms:publish-consume");
			Element jmsMessage = tDoc.createElement("jms:message");
			Element jmsBody = tDoc.createElement("jms:body");
			Element jmsPublishConfiguration = tDoc.createElement("jms:publish-configuration");
			Element jmsConsumeConfiguration = tDoc.createElement("jms:consume-configuration");
			Element jmsReplyTo = tDoc.createElement("jms:reply-to");

			publishConsume.setAttribute("doc:id", Commons.generateRandom(8) + "ba44-4f56-9c63-d1d76a5d22ca");
			publishConsume.setAttribute("doc:name", acName);

			String activityType = "";
			boolean replyToQueue = false;


			publishConsume.appendChild(jmsMessage);
			jmsMessage.appendChild(jmsBody);
			jmsMessage.appendChild(jmsReplyTo);
			publishConsume.appendChild(jmsPublishConfiguration);
			publishConsume.appendChild(jmsConsumeConfiguration);

			return publishConsume;
		}

}

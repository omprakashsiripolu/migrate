package com.sme.webmethods.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.sme.webmethods.utility.ActivityOperations;
import com.sme.webmethods.utility.DbInsert;
import com.sme.webmethods.utility.FTPElements;
import com.sme.webmethods.utility.FileElements;
import com.sme.webmethods.utility.GlobalElements;
import com.sme.webmethods.utility.JMSElements;
import com.sme.webmethods.utility.JdbcElements;
import com.sme.webmethods.utility.RestElements;

public class Commons {
	
	//public static WmAccelerator wmAcc = new  WmAccelerator();
	public static FileOperations fileOps = new FileOperations();
	public static Migrate migrate = new Migrate();
	public static ActivityOperations actOps = new ActivityOperations();
	public static JdbcConnection jdbcConnection = new JdbcConnection();
	public static DbInsert dbInsert = new DbInsert();
	public static FileElements fileElements = new FileElements();
	public static FTPElements ftpElements = new FTPElements();
	public static JMSElements jmsElements = new JMSElements();
	public static JdbcElements jdbcElements = new JdbcElements();
	public static GlobalElements globalElements = new GlobalElements();
//	public static RestActivities restActivites = new RestActivities();
	public static RestElements restElements = new RestElements();
	public static ArrayList<String> namespaces = new ArrayList<>(Arrays.asList("ns", "tns", "cmn","xs"));
	public static List<String> xsdDataTypes = new ArrayList<>(Arrays.asList(
            "string",
            "stringList",
            "boolean",
            "byte",
            "double",
            "float",
            "int",
            "long",
            "short",
            "date",
            "integer",
            "decimal",
            "dateTime"
        ));
	
	private static ArrayList<String> wmNames = new ArrayList<String>
	(Arrays.asList(	"INVOKE",
					"MAP",
					"BRANCH",
					"EXIT",
					"LOOP",
					"REPEAT",
					"SEQUENCE"));
	private static ArrayList<String> wmGroupNames = new ArrayList<String>
	(Arrays.asList(	"BRANCH",
					"LOOP",
					"REPEAT",
					"SEQUENCE"));
	
	
	private static File migrationDir = null;
	private static File srcPrjDir = null;
	private static File trgPrjDir = null;
	private static File refDir = null;
	private static File mule = null;
	private static ArrayList<File> services = null;
	private static ArrayList<File> ndfs = null;
	private static ArrayList<File> refNdfs = null;
	public static ArrayList<File> refPackages = new ArrayList<>();
	public static ArrayList<String> connectionNames = new ArrayList<>();
	public static ArrayList<String> serviceNames = new ArrayList<>();
	public static ArrayList<String> docTypeNames = new ArrayList<>();
	public static List<KeyValuePair> builtInServices = new ArrayList<>();
	public static Map<String,Integer> pubActList = new HashMap<>();
	public static Map<String,ArrayList<String>> connAndAdpList = new HashMap<>();
	
	
	private static Properties properties = new Properties();
	
	public static File template = new File("C:\\WmMigration\\template.xml");
	public static String localhost = "DESKTOP-0UFM68U:5555";
	
	
	  public static Document getTemplateDoc() throws SAXException, IOException,
	  ParserConfigurationException { File template = new
	  File("C:\\WmMigration\\template.xml"); Document tDoc =
	  getDocBuilder().parse(template); return tDoc; }
	 
	
	// Setter for migrationDir
    public static void setMigrationDir(File directory) {
        migrationDir = directory;
    }

    // Getter for migrationDir
    public static File getMigrationDir() {
        return migrationDir;
    }
    
    public static void setRefDir(File directory) {
    	refDir = directory;
    }
    
    public static File getRefDir() {
    	return refDir;
    }

    // Getters
    public static Properties getProperties() {
        return properties;
    }

	
	// Getter for wmNodes
	public static ArrayList<String> getWmNodes() {
		return wmNames;
	}
	
	// Setter for srcPrjDir
	public static void setSrcPrjDir(File directory) {
		srcPrjDir = directory;
	}
	
	// Getter for srcPrjDir
	public static File getSrcPrjDir() {
		return srcPrjDir;
	}
	
	// Setter for trgPrjDir
	public static void setTrgPrjDir(File directory) {
		trgPrjDir = directory;
	}
		
	// Getter for trgPrjDir
	public static File getTrgPrjDir() {
		return trgPrjDir;
	}
	
	// Setter for services
	public static void setServices(ArrayList<File> serviceList) {
		services = serviceList;
	}
	
	// Getter for services
	public static ArrayList<File> getServices() {
		return services;
	}
	
	public static void setNdfs(ArrayList<File> ndfsList) {
		ndfs = ndfsList;
	}
	
	public static ArrayList<File> getNdfs() {
		return ndfs;
	}
	
	public static void setRefNdfs(ArrayList<File> ndfsList) {
		refNdfs = ndfsList;
	}
	
	public static ArrayList<File> getRefNdfs() {
		return refNdfs;
	}
 
	// Setter for mule
    public static void setMule(File muleFile) {
        mule = muleFile;
    }

    // Getter for mule
    public static File getMule() {
        return mule;
    }
    
 // Setter method to modify the ArrayList
    public static void setWmGroupNames(ArrayList<String> newGroupNames) {
        wmGroupNames = newGroupNames;
    }

    // Getter method to retrieve the ArrayList
    public static ArrayList<String> getWmGroupNames() {
        return wmGroupNames;
    }
	
	public static DocumentBuilder getDocBuilder() throws ParserConfigurationException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    DocumentBuilder builder = factory.newDocumentBuilder();
	    return builder;
	}
	
	public static String generateRandom(int n) {
		int leftLimit = 97; // letter 'A'
		int rightLimit = 122; // letter 'Z'
		int targetStringLength = n;
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for (int i = 0; i < targetStringLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt);
		}
		return buffer.toString();
	}
	
	public static String getWebUrlFetchedContent(String webUrl) {
		StringBuilder content = new StringBuilder();
        try {
            URL url = new URL(webUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    content.append(line+"\n");
                }
                reader.close();
            } else {
                System.out.println("Failed to fetch content. Response Code: " + responseCode);
            }
            connection.disconnect();
        } catch (IOException e) {}
        return content.toString();
	}
	
	public static void getFiles(File[] listFiles, int i, ArrayList<File> processes, String string) {
		if (i == listFiles.length) {
			return;
		}
		if (listFiles[i].isFile()) {
			if (listFiles[i].getName().endsWith(string)) {
				processes.add(listFiles[i]);
			}
		} else if (listFiles[i].isDirectory()) {
			getFiles(listFiles[i].listFiles(), 0, processes, string);
		}
		getFiles(listFiles, i + 1, processes, string);
	}
	
	public static String readFileToString(File file) throws IOException {
	    byte[] bytes = Files.readAllBytes(file.toPath());
	    return new String(bytes, StandardCharsets.UTF_8);
	}
	
	  public static void log(String message) {
			File file = new File("C:\\SHIP\\shiplog.text");

			try {
				if (!file.exists()) {
					file.createNewFile();
				}

				FileWriter fileWriter = new FileWriter(file.getAbsoluteFile(), true);
				BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				Date date = new Date();

				bufferedWriter.write(dateFormat.format(date) + ": EIDCardReader : " + message + "\r\n");
				bufferedWriter.close();
			} catch (Exception e) {
				log("ERROR ==> Method (log)" + e.getMessage());
			}
		}
	
}

class KeyValuePair {
    private String key;
    private String value;

    public KeyValuePair(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }
    
  
}

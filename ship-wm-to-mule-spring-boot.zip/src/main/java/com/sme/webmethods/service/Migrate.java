package com.sme.webmethods.service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.wm.data.IDataTreeCursor;
import com.wm.data.ISMemDataImpl;
						
@Component
public class Migrate {
	
	@Autowired
	private JdbcConnection jdbcCon;
	
	//@Autowired
	//private FileOperations fileOps;
	
	static int seqId = 1;
	static int groupId = 1;
	static int subCount = 1;
	public void migrateSource() throws ParserConfigurationException, SAXException, IOException, SQLException {
		
		jdbcCon.insertProject();
		System.out.println("insert into DB1");
		for(File service : Commons.getServices()) {
			insertServiceOperation(service);
		}
		for(File ndfFile : Commons.getNdfs()) {
			
			Document ndfDoc = Commons.getDocBuilder().parse(ndfFile);
			Commons.fileOps.removeBlankLines(ndfDoc);
			ArrayList<Node> node = new ArrayList<>();
			Commons.fileOps.getNodeWithAttribute(ndfDoc.getChildNodes(), 0, node, "value", "name", "node_type");
			for(Node n : node) {
				if(n.getTextContent().contentEquals("restResource")) {
					String serviceName = ndfFile.getParentFile().getAbsolutePath().replace( FileOperations.getSourcePrjDir()+"\\ns\\", "");
					String resourceName = null;
					String input = null;
					String output = null;
					String inputSchema = null;
					String outputSchema = null;
					for(int i = 0 ; i<ndfDoc.getFirstChild().getChildNodes().getLength(); i++) {
						if( ndfDoc.getFirstChild().getChildNodes().item(i).getNodeName().contentEquals("value")
							&&	ndfDoc.getFirstChild().getChildNodes().item(i).getAttributes().getNamedItem("name").getNodeValue().contentEquals("resourceName")) {
							resourceName = ndfDoc.getFirstChild().getChildNodes().item(i).getTextContent();
						}
						if( ndfDoc.getFirstChild().getChildNodes().item(i).getNodeName().contentEquals("value")
								&&	ndfDoc.getFirstChild().getChildNodes().item(i).getAttributes().getNamedItem("name").getNodeValue().contentEquals("assocdoctypename")) {
								File docType = new File(FileOperations.getSourcePrjDir()+"\\ns\\"+ndfDoc.getFirstChild().getChildNodes().item(i).getTextContent().replace(".", "\\").replace(":", "\\")+"\\node.ndf");
								if(docType.exists()) {
									Document docTypeDoc = Commons.getDocBuilder().parse(docType);
									Commons.fileOps.removeBlankLines(docTypeDoc);
									Node recordNode = docTypeDoc.getFirstChild().getFirstChild();
									for(int j = 0; j < recordNode.getChildNodes().getLength(); j++) {
										if( recordNode.getChildNodes().item(j).getNodeName().contentEquals("array")) {
											try {
												if(recordNode.getChildNodes().item(j).getAttributes().getNamedItem("name").getNodeValue().contentEquals("rec_fields")
												&& recordNode.getChildNodes().item(j).getAttributes().getNamedItem("type").getNodeValue().contentEquals("record")) {
													Element root = docTypeDoc.createElement("xsd:element");
													root.setAttribute("name", docType.getParentFile().getName());
													input = docType.getParentFile().getName();
													Element complexType = docTypeDoc.createElement("xsd:complexType");
													Element sequence = docTypeDoc.createElement("xsd:sequence");
													for(int k = 0 ; k<recordNode.getChildNodes().item(j).getChildNodes().getLength(); k++) {

														Element element = docTypeDoc.createElement("xsd:element");
														ArrayList<Node> values = new ArrayList<>();
														Commons.fileOps.getNodeWithAttribute(recordNode.getChildNodes().item(j).getChildNodes().item(k).getChildNodes(), 0, values, "value", "name", "field_name");
														Commons.fileOps.getNodeWithAttribute(recordNode.getChildNodes().item(j).getChildNodes().item(k).getChildNodes(), 0, values, "value", "name", "field_type");
														element.setAttribute("name", values.get(0).getTextContent());
														for(int a =0; a<recordNode.getChildNodes().item(j).getChildNodes().item(k).getChildNodes().getLength(); a++) {
															if(recordNode.getChildNodes().item(j).getChildNodes().item(k).getChildNodes().item(a).getAttributes().getNamedItem("name").getNodeValue().contentEquals("rec_fields")
															&& recordNode.getChildNodes().item(j).getChildNodes().item(k).getChildNodes().item(a).getAttributes().getNamedItem("type").getNodeValue().contentEquals("record")) {
																ArrayList<Node> attributes = new ArrayList<>();
																getHierarchy(element, recordNode.getChildNodes().item(j).getChildNodes().item(k).getChildNodes().item(a), docTypeDoc, attributes);
																for(Node attr : attributes) {
																	element.getFirstChild().appendChild(attr);
																}
															}
														}
														if(!element.hasChildNodes()) {
															element.setAttribute("type", "xsd:" + (!values.get(1).getTextContent().contentEquals("object")? values.get(1).getTextContent():"integer"));
														}
														sequence.appendChild(element);
													}
													complexType.appendChild(sequence);
													root.appendChild(complexType);
													inputSchema = Commons.fileOps.nodeToString(root);
												}
											}catch(Exception e) {}
										}
									}
								}	
						}
					}
					for(int i = 0 ; i<ndfDoc.getFirstChild().getChildNodes().getLength(); i++) {
						if( ndfDoc.getFirstChild().getChildNodes().item(i).getNodeName().contentEquals("record")
							&&	ndfDoc.getFirstChild().getChildNodes().item(i).getAttributes().getNamedItem("name").getNodeValue().contentEquals("restResource")) {
							ArrayList<Node> records = new ArrayList<>();
							Commons.fileOps.getNode(ndfDoc.getFirstChild().getChildNodes().item(i).getChildNodes(), 0, records, "record");
							
							for(Node record : records) {
								String urlTemplate = null;
								String base = "localhost:5555";
								String method = null;
								for(int j = 0; j<record.getChildNodes().getLength(); j++) {
									if(record.getChildNodes().item(j).getAttributes().getNamedItem("name").getNodeValue().contentEquals("urlTemplate")) {
										urlTemplate = record.getChildNodes().item(j).getTextContent();
									}
									if(record.getChildNodes().item(j).getAttributes().getNamedItem("name").getNodeValue().contentEquals("httpMethods")) {
										method = record.getChildNodes().item(j).getFirstChild().getTextContent();
									}
								}
								
								output = "output";
								outputSchema = "<xsd:element name=\"output\" type=\"xsd:string\"/>";
								
								jdbcCon.insertRestService(serviceName, resourceName, urlTemplate, base, method, input, output, inputSchema, outputSchema);
							}
						}
					}
				}
				
				if(n.getTextContent().contentEquals("webServiceDescriptor")) {
					System.out.println(ndfFile.getAbsolutePath());
					String soapServiceName = ndfFile.getParentFile().getAbsolutePath().replace(FileOperations.getSourcePrjDir().getAbsolutePath()+"\\ns\\", "");
					String ndfFileContent = Commons.fileOps.readFileToString(ndfFile.getAbsolutePath());
					jdbcCon.insertConfig(soapServiceName+".webServiceDescriptor", ndfFileContent);
					
					String wsdlStr = "";
					String wsdlUrl = "";
					
					ArrayList<Node> webNodes = new ArrayList<>();
					Commons.fileOps.getNodeWithAttribute(ndfDoc.getChildNodes(), 0, webNodes, "value", "name", "WSDLURL");
						// webNOde is 0 as we have no wsdlURl   
					if(webNodes.size()==0) {
						Commons.fileOps.getNodeWithAttribute(ndfDoc.getChildNodes(), 0, webNodes, "value", "name", "externalWSDL");
						if(webNodes.size()!=0) {
							wsdlStr = webNodes.get(0).getTextContent();
						}
					}else {
						if(webNodes.size()!=0) {
							wsdlStr = webNodes.get(0).getTextContent();
							wsdlStr = Commons.getWebUrlFetchedContent(wsdlUrl);
						}
						
					}
					
					if(wsdlUrl.length()!=0) {
					if(wsdlStr.length()==0) {
						System.out.println(wsdlUrl+"           urllll");
						System.out.println(wsdlStr.length());
						String trgNamespace = wsdlUrl.substring(wsdlUrl.indexOf("//")+2);
						trgNamespace = trgNamespace.substring(0,trgNamespace.indexOf("/"));
						wsdlUrl = wsdlUrl.replace(trgNamespace, Commons.localhost);
						wsdlStr = Commons.getWebUrlFetchedContent(wsdlUrl);
					}
					if(wsdlStr.length()==0) {
						ArrayList<Node> trgNsNode = new ArrayList<>();
						Commons.fileOps.getNodeWithAttribute(ndfDoc.getChildNodes(), 0, trgNsNode, "value", "name", "targetNamespace");
						String trgNs = trgNsNode.get(0).getTextContent();
						trgNs = trgNs.substring(trgNs.lastIndexOf("/")+1).replace(".", "_").replace(":", "_");
						trgNs = "Default_"+trgNs+".wsdl";
						File wsdlFile = new File(FileOperations.getSourcePrjDir()+"\\wsdls\\"+trgNs);
						if(wsdlFile.exists()) {
							wsdlStr = Commons.readFileToString(ndfFile);
						}
					}
					
					jdbcCon.insertConfig(soapServiceName+".wsdl", wsdlStr);
					
					}
				}
				if(n.getTextContent().contentEquals("webMethods/trigger")) {

					String umServiceName = ndfFile.getParentFile().getAbsolutePath().replace(FileOperations.getSourcePrjDir().getAbsolutePath()+"\\ns\\", "");
					String ndfFileContent = Commons.fileOps.readFileToString(ndfFile.getAbsolutePath());
					jdbcCon.insertConfig(umServiceName+".trigger", ndfFileContent);
					ArrayList<Node> triggerServices = new ArrayList<>();
					Commons.fileOps.getNodeWithAttribute(ndfDoc.getChildNodes(), 0, triggerServices, "value", "name", "serviceName");
					for(Node trig : triggerServices) {
						for(File refPackage : Commons.refPackages) {
		    				File referencedFile = new File(refPackage.getAbsolutePath()+"\\ns\\"+trig.getTextContent().replace(".", "\\").replace(":", "\\")+"\\flow.xml");
		    				if(referencedFile.exists()) {
		    					Document refDoc = Commons.getDocBuilder().parse(referencedFile);
								Commons.fileOps.removeBlankLines(refDoc);
		    					insertRow(trig.getTextContent().replace(".", "\\").replace(":", "\\"),refDoc.getFirstChild());
		    				}
		    			}
					}
				}
				
			}
			
			try{
				if(ndfDoc.getFirstChild().getFirstChild().getNodeName().contentEquals("record")) {
					String docName = ndfFile.getParentFile().getAbsolutePath().replace(FileOperations.getSourcePrjDir().getAbsolutePath()+"\\ns\\", "").replace("\\", "-");
					String ndfFileContent = Commons.fileOps.readFileToString(ndfFile.getAbsolutePath());
					
					jdbcCon.insertConfig(docName+".docType", ndfFileContent);
					
				}
			}catch(Exception e) {}
			
			
		}
  
	}

	public void insertServiceOperation(File service) throws SAXException, IOException, ParserConfigurationException, SQLException {
//		seqId = 1;
//		groupId = 1;
		
	    Document serviceDocument = Commons.getDocBuilder().parse(new File(service.getAbsolutePath()+"\\flow.xml"));
	    Commons.fileOps.removeBlankLines(serviceDocument);
	   
	    Node srcFlow = serviceDocument.getFirstChild();
	    String serviceName = service.getAbsolutePath().substring(service.getAbsolutePath().indexOf("\\ns\\")+4);
	    System.out.println();
	    System.out.println("==============================================================");
	    System.out.println(serviceName);
	    System.out.println("==============================================================");
	    
	    insertRow(serviceName,srcFlow);
	    
	    Document serviceNdf = Commons.getDocBuilder().parse(new File(service.getAbsolutePath()+"\\node.ndf"));
	    Commons.fileOps.removeBlankLines(serviceNdf);
	    ArrayList<Node> recRef = new ArrayList<>();
	    Commons.fileOps.getNodeWithAttribute(serviceNdf.getChildNodes(), 0, recRef, "value", "name", "rec_ref");
	    for(Node rec : recRef) {
	    	String docName = rec.getTextContent();
	    	if(!Commons.docTypeNames.contains(docName)) {
	    		File referencedFile = new File(FileOperations.getSourcePrjDir()+"\\ns\\"+docName.replace(".", "\\").replace(":", "\\"));
		    	if(referencedFile.exists()) {
		    		 String nodeNdfPath = referencedFile.getAbsolutePath() + "\\node.ndf";
		    		 File nodeNdfFile = new File(nodeNdfPath);
		    		    if (nodeNdfFile.exists()) {
				    		String docContent = Commons.fileOps.readFileToString(referencedFile.getAbsolutePath()+"\\node.ndf");
				    		jdbcCon.insertConfig(docName+".docType", docContent);
		    		    }
		    	}else {
		    		if(docName.contains(".")) {
		    			for(File refPackage : Commons.refPackages) {
		    				referencedFile = new File(refPackage.getAbsolutePath()+"\\ns\\"+docName.replace(".", "\\").replace(":", "\\"));
		    				if(referencedFile.exists()) {
		    					
		    					File refFlow = new File(referencedFile.getAbsolutePath()+"\\flow.xml");
		    					if(refFlow.exists()) {
		    						insertServiceOperation(refFlow);
		    					}else {
		    						String docContent = Commons.fileOps.readFileToString(referencedFile.getAbsolutePath()+"\\node.ndf");
		    						jdbcCon.insertConfig(docName+".docType", docContent);
		    					}
		    				}
		    			}
		    		}
		    	}
	    		Commons.docTypeNames.add(docName);
	    	}
	    }
	}

	public void insertRow(String serviceName, Node srcFlow) throws SQLException, IOException, SAXException, ParserConfigurationException {
		for(int i = 0; i<srcFlow.getChildNodes().getLength(); i++) {
			if(Commons.getWmNodes().contains(srcFlow.getChildNodes().item(i).getNodeName())) {
				String acName = null;
				Node acNode = srcFlow.getChildNodes().item(i);
		    	try{
		    		acName = acNode.getAttributes().getNamedItem("SERVICE").getNodeValue();
		    	}catch(Exception e){
		    		acName =acNode.getNodeName();
		    	}
		    	
		    	for(int j=0; j<acNode.getChildNodes().getLength(); j++) {
		    		if(acNode.getChildNodes().item(j).getNodeName().contentEquals("MAP")) {
		    			Node mapNode = acNode.getChildNodes().item(j);
		    			for(int k = 0 ;k < mapNode.getChildNodes().getLength(); k++) {
		    				if(mapNode.getChildNodes().item(k).getNodeName().contentEquals("MAPSET")) {
		    					ArrayList<Node> nodes = new ArrayList<>();
		    					Commons.fileOps.getNodeWithAttribute(mapNode.getChildNodes().item(k).getChildNodes(), 0, nodes, "value", "name", "xml");
		    					Commons.fileOps.getNodeWithAttribute(mapNode.getChildNodes().item(k).getChildNodes(), 0, nodes, "value", "name", "field_name");
		    					if(nodes.size()==2) {
		    						jdbcCon.insertHardCodedValues(serviceName,acName,seqId,nodes.get(1).getTextContent(),nodes.get(0).getTextContent());
		    					}
		    				}
		    			}
		    		}
		    	}
		    	
		    	Commons.dbInsert.insertService(serviceName,seqId++,acName,acNode);
		    	if(acName.startsWith("pub.")) {
		    		addToPubActList(acName);
		    	}
		    	
		    	File referencedFile = new File(FileOperations.getSourcePrjDir()+"\\ns\\"+acName.replace(".", "\\").replace(":", "\\"));
		    	if(referencedFile.exists()) {
		    		referencedFileActivity(referencedFile,serviceName,acName);
		    	}
		    	else {
		    		if(acName.contains(".")) {
		    			for(File refPackage : Commons.refPackages) {
		    				referencedFile = new File(refPackage.getAbsolutePath()+"\\ns\\"+acName.replace(".", "\\").replace(":", "\\"));
		    				if(referencedFile.exists()) {
		    					referencedFileActivity(referencedFile,serviceName,acName);
		    				}
		    			}
		    		}
    			}
		    	if(Commons.getWmGroupNames().contains(acNode.getNodeName())){
		    		insertGroup(serviceName,acName, acNode, seqId-1);
		    	}
			}
	    }
	}
	
	public void insertGroup(String serviceName, String groupName, Node srcFlow, int goupId) throws SQLException, IOException, SAXException, ParserConfigurationException {
		for(int i = 0; i<srcFlow.getChildNodes().getLength(); i++) {
			if(Commons.getWmNodes().contains(srcFlow.getChildNodes().item(i).getNodeName())) {
				String acName = null;
				Node acNode = srcFlow.getChildNodes().item(i);
		    	try{
		    		acName = acNode.getAttributes().getNamedItem("SERVICE").getNodeValue();
		    	}catch(Exception e){
		    		acName =acNode.getNodeName();
		    	}
		    	String condition = null;
		    	try{
		    		condition = acNode.getAttributes().getNamedItem("NAME").getNodeValue();
		    	}catch(Exception e) {}
		    	
		    	for(int j=0; j<acNode.getChildNodes().getLength(); j++) {
		    		if(acNode.getChildNodes().item(j).getNodeName().contentEquals("MAP")) {
		    			Node mapNode = acNode.getChildNodes().item(j);
		    			for(int k = 0 ;k < mapNode.getChildNodes().getLength(); k++) {
		    				if(mapNode.getChildNodes().item(k).getNodeName().contentEquals("MAPSET")) {
		    					if(mapNode.getChildNodes().item(k).getNodeName().contentEquals("MAPSET")) {
			    					ArrayList<Node> nodes = new ArrayList<>();
			    					Commons.fileOps.getNodeWithAttribute(mapNode.getChildNodes().item(k).getChildNodes(), 0, nodes, "value", "name", "xml");
			    					Commons.fileOps.getNodeWithAttribute(mapNode.getChildNodes().item(k).getChildNodes(), 0, nodes, "value", "name", "field_name");
			    					if(nodes.size()==2) {
			    					 jdbcCon.insertHardCodedValues(serviceName,acName,seqId,nodes.get(1).getTextContent(),nodes.get(0).getTextContent());
			    					}
		    					}
		    				}
		    			}
		    		}
		    	}
		    	
		    	Commons.dbInsert.insertServiceGroup(groupName, serviceName, seqId++, goupId, acName, acNode,condition);
		    	if(acName.startsWith("pub.")) {
		    		addToPubActList(acName);
		    	}
		    	
		    	File referencedFile = new File(FileOperations.getSourcePrjDir()+"\\ns\\"+acName.replace(".", "\\").replace(":", "\\"));
		    	if(referencedFile.exists()) {
		    		referencedFileActivity(referencedFile,serviceName,acName);
//		    		File referencedFileConfig = new File(referencedFile.getAbsolutePath()+"\\node.ndf");
//		    		String configStr = Commons.fileOps.readFileToString(referencedFileConfig.getAbsolutePath());
//		    		Node configNode = Commons.getDocBuilder().parse(new InputSource(new StringReader(configStr))).getDocumentElement();
//		    		ArrayList<Node> node = new ArrayList<>();
//		    		Commons.fileOps.getNodeWithAttribute(configNode.getChildNodes(), 0, node, "value", "name", "IRTNODE_PROPERTY");
//		    		try{
//		    			
//		    			String encodedData = node.get(0).getTextContent();
//		    			String decryptedData = Commons.fileOps.decryptEncodedWmData(encodedData).toString();
//		    			jdbcCon.insertConfig(acName,decryptedData);
//		    			String connectionName = decryptedData.substring(decryptedData.indexOf("connectionName"));
//		    			connectionName = connectionName.substring(connectionName.indexOf("=")+1,connectionName.indexOf(","));
//		    			Commons.builtInServices.add(new KeyValuePair(serviceName, connectionName+"::"+acName));
//		    			if(!Commons.serviceNames.contains(acName)) {
//			    			if(!Commons.connectionNames.contains(connectionName)) {
//			    				File connectionFile = new File(FileOperations.getSourcePrjDir()+"\\ns\\"+connectionName.replace(".", "\\").replace(":", "\\")+"\\node.ndf");
//			    				String connectionConfigStr = Commons.fileOps.readFileToString(connectionFile.getAbsolutePath());
//					    		Node connectionConfigNode = Commons.getDocBuilder().parse(new InputSource(new StringReader(connectionConfigStr))).getDocumentElement();
//					    		
//					    		ArrayList<Node> node1 = new ArrayList<>();
//					    		Commons.fileOps.getNodeWithAttribute(connectionConfigNode.getChildNodes(), 0, node1, "value", "name", "IRTNODE_PROPERTY");
//					    		try{
//					    			String encodedConnectionData = node1.get(0).getTextContent();
//					    			String decryptedConnectionData = Commons.fileOps.decryptEncodedWmData(encodedConnectionData).toString();
//					    			IDataTreeCursor dataCursor = Commons.fileOps.decryptEncodedWmData(encodedConnectionData).getTreeCursor();
//					    			if (dataCursor.first("connectionProperties")) {
//					    	            ISMemDataImpl data1 = (ISMemDataImpl)dataCursor.getValue();
//					    	            decryptedConnectionData = data1.toString();
//					    	            jdbcCon.insertConfig(connectionName,decryptedConnectionData);
//					    			}
//					    		}catch(Exception e) {
//					    			e.printStackTrace();
//					    		}
//			    				Commons.connectionNames.add(connectionName);
//			    			}
//		    				
//		    				Commons.serviceNames.add(acName);
//		    			}
//		    			
//		    			
//		    		}catch(Exception e) {
//		    			e.printStackTrace();
//		    		}
		    	}
			 
	    		for(File refPackage : Commons.refPackages) {
    				referencedFile = new File(refPackage.getAbsolutePath()+"\\ns\\"+acName.replace(".", "\\").replace(":", "\\"));
    				if(referencedFile.exists()) {
    					referencedFileActivity(referencedFile,serviceName,acName);
    				}
		 
    			}
		    	if(Commons.getWmGroupNames().contains(acNode.getNodeName())){
		    		insertGroup(serviceName,acName, acNode, seqId-1);
		    	}
			}
		}
	}
	
	public void addToPubActList(String acName) throws SQLException {
		ResultSet wmRefRs = jdbcCon.getMulesoftForWm(acName);
		int flag = 0;
		while(wmRefRs.next()) {
			flag = 1;
		}
		wmRefRs.close();
		if(flag == 0) {
			if (Commons.pubActList.containsKey(acName)) {
                Commons.pubActList.put(acName, Commons.pubActList.get(acName) + 1);
            } else {
                Commons.pubActList.put(acName, 1);
            }
		}
	}
	
	
	public void addToConnectionList(String connectionStr) throws SQLException {
		String connectionName = connectionStr.substring(0,connectionStr.indexOf("::"));
		String adpService = connectionStr.substring(connectionStr.indexOf("::")+2);
		if (Commons.connAndAdpList.containsKey(connectionName)) {
			ArrayList<String> newEle = Commons.connAndAdpList.get(connectionName);
			if(!newEle.contains(adpService)) {
				newEle.add(adpService);
	            Commons.connAndAdpList.put(connectionName, newEle);
			}
        } else {
        	ArrayList<String> firstEle = new ArrayList<>();
        	firstEle.add(adpService);
            Commons.connAndAdpList.put(connectionName, firstEle);
        }
	}
	
	public void referencedFileActivity(File referencedFile, String serviceName, String acName) throws IOException, SAXException, ParserConfigurationException, SQLException {
		File refFile = new File(referencedFile.getAbsoluteFile()+"\\"+"flow.xml");
		File referencedFileNdfConfig = new File(referencedFile.getAbsolutePath()+"\\node.ndf");
		
		if(refFile.exists()){
			Document refServiceDocument = Commons.getDocBuilder().parse(refFile);
		    Commons.fileOps.removeBlankLines(refServiceDocument);
		   
		    Node refSrcFlow = refServiceDocument.getFirstChild();
		    String refServiceName = referencedFile.getAbsolutePath().substring(referencedFile.getAbsolutePath().indexOf("\\ns\\")+4);
			insertRow(refServiceName, refSrcFlow);
	  
		}else if(referencedFileNdfConfig.exists()) {
				
				String configStr = Commons.fileOps.readFileToString(referencedFileNdfConfig.getAbsolutePath());
				Node configNode = Commons.getDocBuilder().parse(new InputSource(new StringReader(configStr))).getDocumentElement();
				ArrayList<Node> node = new ArrayList<>();
				Commons.fileOps.getNodeWithAttribute(configNode.getChildNodes(), 0, node, "value", "name", "IRTNODE_PROPERTY");
				if(node.size()>0) {
					try{
						if(!Commons.serviceNames.contains(acName)) {
							String encodedData = node.get(0).getTextContent();
							String decryptedData = Commons.fileOps.decryptEncodedWmData(encodedData).toString();
							jdbcCon.insertConfig(acName,decryptedData);
							String connectionName = decryptedData.substring(decryptedData.indexOf("connectionName"));
							connectionName = connectionName.substring(connectionName.indexOf("=")+1,connectionName.indexOf(","));
							Commons.builtInServices.add(new KeyValuePair(serviceName, connectionName+"::"+acName));
			    			if(!Commons.connectionNames.contains(connectionName)) {
			    				File connectionFile = new File(FileOperations.getSourcePrjDir()+"\\ns\\"+connectionName.replace(".", "\\").replace(":", "\\")+"\\node.ndf");
			    				if(connectionFile.exists()) {
			    					connectionFileActivity(connectionFile, connectionName);
			    				}else{
			    					for(File refPackage : Commons.refPackages) {
			    						connectionFile = new File(refPackage.getAbsolutePath()+"\\ns\\"+connectionName.replace(".", "\\").replace(":", "\\")+"\\node.ndf");
			    						if(connectionFile.exists()) {
			    							connectionFileActivity(connectionFile, connectionName);
			    						}
			    					}
			    				}
			    				Commons.connectionNames.add(connectionName);
			    			}
							
							Commons.serviceNames.add(acName);
						}
				}catch(Exception e) {
					e.printStackTrace();
	  
				}
	
	
	
	
			}
			
		}
	}

	public void connectionFileActivity(File connectionFile, String connectionName) throws IOException, SAXException, ParserConfigurationException {
		String connectionConfigStr = Commons.fileOps.readFileToString(connectionFile.getAbsolutePath());
		Node connectionConfigNode = Commons.getDocBuilder().parse(new InputSource(new StringReader(connectionConfigStr))).getDocumentElement();
		
		ArrayList<Node> node1 = new ArrayList<>();
		Commons.fileOps.getNodeWithAttribute(connectionConfigNode.getChildNodes(), 0, node1, "value", "name", "IRTNODE_PROPERTY");
		try{
			String encodedConnectionData = node1.get(0).getTextContent();
			String decryptedConnectionData = Commons.fileOps.decryptEncodedWmData(encodedConnectionData).toString();
			IDataTreeCursor dataCursor = Commons.fileOps.decryptEncodedWmData(encodedConnectionData).getTreeCursor();
			if (dataCursor.first("connectionProperties")) {
	            ISMemDataImpl data1 = (ISMemDataImpl)dataCursor.getValue();
	            decryptedConnectionData = data1.toString();
	            jdbcCon.insertConfig(connectionName,decryptedConnectionData);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	

	public void migrateTarget() throws SQLException, SAXException, IOException, ParserConfigurationException {
		System.out.println();
		System.out.println("====================================================================================================");
		System.out.println("Retrieval from MySql and Migrate to MuleSoft");
		System.out.println("====================================================================================================");
		ArrayList<String> serviceNames = new ArrayList<>();
		for(File service : Commons.getServices()) {
			serviceNames.add(service.getAbsolutePath().substring(service.getAbsolutePath().indexOf("\\ns\\")+4));
										 
		}
				 
		for(String serviceName : serviceNames) {
			retrieveServiceOperations(serviceName);
		}
		
		
	    while(jdbcCon.getRestService().next()) {
		   Commons.restElements.addApikitRouterActivity();
		   Commons.restElements.generateRaml();
		   break;
	   }  
	 
	 
		// ----- Soap Provider 					
	 
		ResultSet rs1 = jdbcCon.getConfigFilesWithLike("webServiceDescriptor");
		while (rs1.next()) {
			String configName = rs1.getString(1).toString();
			String configContent = rs1.getString(2).toString();
			Node webNode = Commons.getDocBuilder().parse(new InputSource(new StringReader(configContent))).getDocumentElement();
			
			ArrayList<Node> node = new ArrayList<>();
			Commons.fileOps.getNodeWithAttribute(webNode.getChildNodes(), 0, node, "Boolean", "name", "inbound");
			if(node.size()>0) {
				if(node.get(0).getTextContent().contentEquals("true")) {
					Commons.actOps.soapRouterActivity(configName,webNode);
				}
		}
//			if(node.get(0).getTextContent().contentEquals("false")) {
//				Commons.actOps.soapReqReplyActivity(configName, webNode);
//			}
		}
		rs1.close();
		ResultSet rs2 = jdbcCon.getConfigFilesWithLike("wsdl");
	    while(rs2.next()) {
	    	String configName = rs2.getString(1).toString();
			String configContent = rs2.getString(2).toString();
	    	
			Commons.fileOps.WriteStringToFile(FileOperations.getTargetPrjDir().getAbsolutePath()+"\\src\\main\\resources\\api\\"+configName.replace("\\", "-"), configContent);
	    }
	    rs2.close();
	    
	    ResultSet rs3 = jdbcCon.getConfigFilesWithLike("docType");
		while (rs3.next()) {
			String docName = rs3.getString(1);
			String rootName = docName.substring(docName.lastIndexOf("-")+1,docName.lastIndexOf("."));
			if(rootName.contains(":")) {
				rootName = rootName.substring(rootName.lastIndexOf(":")+1);
			}
			String docType = rs3.getString(2);
			Document docTypeDoc = Commons.getDocBuilder().parse(new InputSource(new StringReader(docType)));
			Commons.fileOps.removeBlankLines(docTypeDoc);
			Node recordNode = docTypeDoc.getFirstChild().getFirstChild();
			for(int j = 0; j < recordNode.getChildNodes().getLength(); j++) {
				if( recordNode.getChildNodes().item(j).getNodeName().contentEquals("array")) {
					try {
						Element schema = docTypeDoc.createElement("xs:schema");
						schema.setAttribute("xmlns:xs", "http://www.w3.org/2001/XMLSchema");
						Element root = docTypeDoc.createElement("xs:element");
						root.setAttribute("name", rootName);
						Element complexType = docTypeDoc.createElement("xsd:complexType");
						Element sequence = docTypeDoc.createElement("xsd:sequence");
						if(recordNode.getChildNodes().item(j).getAttributes().getNamedItem("name").getNodeValue().contentEquals("rec_fields")
						&& recordNode.getChildNodes().item(j).getAttributes().getNamedItem("type").getNodeValue().contentEquals("record")) {
							for(int k = 0 ; k<recordNode.getChildNodes().item(j).getChildNodes().getLength(); k++) {
								Element element = docTypeDoc.createElement("xsd:element");
								ArrayList<Node> values = new ArrayList<>();
								Commons.fileOps.getNodeWithAttribute(recordNode.getChildNodes().item(j).getChildNodes().item(k).getChildNodes(), 0, values, "value", "name", "field_name");
								Commons.fileOps.getNodeWithAttribute(recordNode.getChildNodes().item(j).getChildNodes().item(k).getChildNodes(), 0, values, "value", "name", "field_type");
								
								Commons.fileOps.getNodeWithAttribute(recordNode.getChildNodes().item(j).getChildNodes().item(k).getChildNodes(), 0, values, "value", "name", "wrapper_type");
								for(int i=0; i<recordNode.getChildNodes().item(j).getChildNodes().item(k).getChildNodes().getLength(); i++) {
									if(recordNode.getChildNodes().item(j).getChildNodes().item(k).getChildNodes().item(i).getAttributes().getNamedItem("name").getNodeValue().contentEquals("field_content_type")) {
										Commons.fileOps.getNodeWithAttribute(recordNode.getChildNodes().item(j).getChildNodes().item(k).getChildNodes().item(i).getChildNodes(), 0, values, "value", "name", "ncName");
									}
								}
								String fType = null;
								try {
									fType = values.get(1).getTextContent();
								}catch(Exception e) {}
								
								String name = values.get(0).getTextContent();
								if(name.contains(":")) {
									if(Commons.namespaces.contains(name.substring(0,name.indexOf(":")))) {
										name = name.substring(name.indexOf(":")+1);
									}else {
										name = name.replace(":", "_");
									}
								}
								name.replace("*", "");
								element.setAttribute("name", name);
								if(fType.contentEquals("recref")) {
									
									Node record = recordNode.getChildNodes().item(j).getChildNodes().item(k);
									
									for(int i=0; i<record.getChildNodes().getLength(); i++) {
										if(record.getChildNodes().item(i).getAttributes().getNamedItem("name").getNodeValue().contentEquals("rec_ref")) {
											File refFile = new File(FileOperations.getSourcePrjDir()+"\\ns\\"+record.getChildNodes().item(i).getTextContent().replace(".", "\\").replace(":", "\\")+"\\node.ndf");
											if(refFile.exists()) {
												Document refDoc = Commons.getDocBuilder().parse(refFile);
												Commons.fileOps.removeBlankLines(refDoc);
												for(int j1 = 0; j1<refDoc.getFirstChild().getFirstChild().getChildNodes().getLength(); j1++) {
												if(refDoc.getFirstChild().getFirstChild().getChildNodes().item(j1).getAttributes().getNamedItem("name").getNodeValue().contentEquals("rec_fields")
												&&	refDoc.getFirstChild().getFirstChild().getChildNodes().item(j1).getAttributes().getNamedItem("type").getNodeValue().contentEquals("record")) {
													ArrayList<Node> attributes = new ArrayList<>();
													getHierarchy(element, refDoc.getFirstChild().getFirstChild().getChildNodes().item(j1), docTypeDoc, attributes);
													for(Node attr : attributes) {
														element.getFirstChild().appendChild(attr);
													}
												}
											}
											}else {
												for(File ref : Commons.refPackages) {
													refFile = new File(ref+"\\ns\\"+record.getChildNodes().item(i).getTextContent().replace(".", "\\").replace(":", "\\")+"\\node.ndf");
													if(refFile.exists()) {
														Document refDoc = Commons.getDocBuilder().parse(refFile);
														Commons.fileOps.removeBlankLines(refDoc);
														for(int j1 = 0; j1<refDoc.getFirstChild().getFirstChild().getChildNodes().getLength(); j1++) {
															if(refDoc.getFirstChild().getFirstChild().getChildNodes().item(j1).getAttributes().getNamedItem("name").getNodeValue().contentEquals("rec_fields")
															&&	refDoc.getFirstChild().getFirstChild().getChildNodes().item(j1).getAttributes().getNamedItem("type").getNodeValue().contentEquals("record")) {
																ArrayList<Node> attributes = new ArrayList<>();
																getHierarchy(element, refDoc.getFirstChild().getFirstChild().getChildNodes().item(j1), docTypeDoc, attributes);
																for(Node attr : attributes) {
																	element.getFirstChild().appendChild(attr);
																}
															}
														}
													}
												}
											}
										}
									}
								}
								
								try {
									if(values.get(2).getTextContent().contains(".")) {
										fType = values.get(2).getTextContent().substring(values.get(2).getTextContent().lastIndexOf(".")+1).toLowerCase();
									}else{
										fType = values.get(2).getTextContent();
									}
								}catch(Exception e) {}
								
								if(values.get(0).getTextContent().startsWith("@")) {
									continue;
								}
								for(int i =0; i<recordNode.getChildNodes().item(j).getChildNodes().item(k).getChildNodes().getLength(); i++) {
									if(recordNode.getChildNodes().item(j).getChildNodes().item(k).getChildNodes().item(i).getAttributes().getNamedItem("name").getNodeValue().contentEquals("rec_fields")
									&& recordNode.getChildNodes().item(j).getChildNodes().item(k).getChildNodes().item(i).getAttributes().getNamedItem("type").getNodeValue().contentEquals("record")) {
										ArrayList<Node> attributes = new ArrayList<>();
										getHierarchy(element, recordNode.getChildNodes().item(j).getChildNodes().item(k).getChildNodes().item(i), docTypeDoc, attributes);
										for(Node attr : attributes) {
											element.getFirstChild().appendChild(attr);
										}
									}
								}
								
								switch(fType) {
								case "character":
									fType = "string";
									break;
								case "integer":
									fType = "int";
									break;
								case "biginteger":
									fType = "integer";
									break;
								case "bigdecimal":
									fType = "decimal";
									break;
								case "object":
									fType = "string";
									break;
								case "recref":
									fType = "string";
									break;
								case "record":
									fType = "string";
									break;
								}
								if(!Commons.xsdDataTypes.contains(fType)) {
									fType = "string";
								}
								if(!element.hasChildNodes()) {
									element.setAttribute("type", "xsd:" + fType);
								}
								sequence.appendChild(element);
							}
							complexType.appendChild(sequence);
							root.appendChild(complexType);
							schema.appendChild(root);
							
//							String xsd = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
//					        		+ "<xsd:schema xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">\r\n";
//							
//							for(int i = 0; i< root.getChildNodes().getLength(); i++) {
//								xsd += Commons.fileOps.nodeToString(root.getChildNodes().item(i))+"\r\n";
//							}
//							
//							xsd += "</xsd:schema>";
							
							try (BufferedWriter writer = new BufferedWriter(new FileWriter(Commons.getTrgPrjDir()+"\\src\\main\\resources\\docTypes\\"+docName.replace(".", "-").replace(":", "-")+".xsd"))) {
					            writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"+Commons.fileOps.nodeToString(schema).replace("xsd:", "xs:"));  
					        } catch (IOException e) {
					            e.printStackTrace();
					        }
							
				            File xmlFile = Commons.restElements.convertXsdToXml(Commons.getTrgPrjDir()+"\\src\\main\\resources\\docTypes\\"+docName.replace(".", "-").replace(":", "-")+".xsd", rootName);
				            Commons.restElements.convertXmlToJson(xmlFile,"\\jsonFiles\\",".json");
									   
									  
									 
			  
						}
					}catch(Exception e) {}
				}
			}
		}
		rs3.close();
		
	//  JMS MQ
			ResultSet rs4 = jdbcCon.getConfigFilesWithLike("trigger");
			while (rs4.next()) {
				String configName = rs4.getString(1).toString();
				String configContent = rs4.getString(2).toString();
				Node triggerNode = Commons.getDocBuilder().parse(new InputSource(new StringReader(configContent))).getDocumentElement();
				Commons.fileOps.removeBlankNodes(triggerNode);
					
				ArrayList<Node> triggerNodeType = new ArrayList<>();
				Commons.fileOps.getNodeWithAttribute(triggerNode.getChildNodes(), 0, triggerNodeType, "value", "name", "trigger_type");
				
				// ---- Universal Messaging with IBM mq			
				if(triggerNodeType.get(0).getTextContent().contains("broker-trigger")){
				ArrayList<Node> conditionsNode = new ArrayList<>();
				Commons.fileOps.getNodeWithAttribute(triggerNode.getChildNodes(), 0, conditionsNode, "array", "name", "conditions");
				ArrayList<Node> recordsNode = new ArrayList<>();
					Commons.fileOps.getNodeWithAttribute(conditionsNode.get(0).getChildNodes(), 0, recordsNode, "record", "name", "data");
					int countOfMess = 0;
					
					// --record each one
					String serviceName = null;
					for(int k = 0; k< recordsNode.size(); k++) {
						ArrayList<String> messNames = new ArrayList<>();
						ArrayList<Node> messageNode = new ArrayList<>();
						ArrayList<Node> joinTypeNode = new ArrayList<>();
						Commons.fileOps.getNodeWithAttribute(recordsNode.get(k).getChildNodes(), 0, joinTypeNode, "number", "name", "joinType");
						String joinType = null;
						if(joinTypeNode.size()>0) {
							joinType = joinTypeNode.get(0).getTextContent();
						}
						
						Commons.fileOps.getNodeWithAttribute(recordsNode.get(k).getChildNodes(), 0, messageNode, "record", "javaclass", "com.wm.util.Values");
					String contnName = null;
								 
					ArrayList<Node> valuesNode = new ArrayList<>();
					Commons.fileOps.getNodeWithAttribute(recordsNode.get(k).getChildNodes(), 0, valuesNode, "value", "name", "serviceName");
					Commons.fileOps.getNodeWithAttribute(recordsNode.get(k).getChildNodes(), 0, valuesNode, "value", "name", "conditionName");
					if(valuesNode.get(0).getAttributes().getNamedItem("name").getNodeValue().contentEquals("serviceName")) {
						serviceName = valuesNode.get(0).getTextContent();
					}
					if(valuesNode.get(1).getAttributes().getNamedItem("name").getNodeValue().contentEquals("conditionName")) {
						contnName = valuesNode.get(1).getTextContent();
					}
					
					 Document serviceDoc = Commons.getDocBuilder().parse(Commons.template);

					
					for(int j=0; j<messageNode.size(); j++) {
						countOfMess++;	
						if(messageNode.get(j).getFirstChild().getAttributes().getNamedItem("name").getTextContent().contentEquals("messageType")) {
							messNames.add(messageNode.get(j).getFirstChild().getTextContent());
						}
					
						if(messNames.size()>0) {
	   
																																																																
																					   
	   

																										 
																			
										  
								
																										  

																																																													   

																																										

  

																				   
																					   
			 
				  
																																				  
							 Element flow = serviceDoc.createElement("flow");
				    		 flow.setAttribute("name", serviceName+"_"+messageNode.get(j).getTextContent()+"_sub");
				    		 flow.setAttribute("doc:id", Commons.generateRandom(8)+"-eadc-40b9-98cc-268d14076da0");

				        	Element onNewMessage = Commons.jmsElements.jmsMQOnNewMessageActivity(messageNode.get(j).getTextContent(),serviceName, contnName, serviceDoc);
				        	Element flowRef = Commons.actOps.flowRefActivity(serviceName, serviceDoc);
				        	
				        	serviceDoc.getFirstChild().insertBefore(flow, serviceDoc.getFirstChild().getChildNodes().item(0));

				        	flow.appendChild(onNewMessage);
				        	flow.appendChild(flowRef);
				        	}
						} // for j
					Commons.fileOps.writeFile(serviceDoc,new File(Commons.getTrgPrjDir()+"\\src\\main\\mule"+"\\"+"Consume_"+serviceName.replace(" ", "_").replace(".", "-").replace(":", "-")+".xml")); 	
					
				}	// for k each record
			}		//--- if broker Trigger closes
			
			// if amq
				if(triggerNodeType.get(0).getTextContent().contains("mqtt-trigger")){
					String serviceName = null;
					String topicName = null;
					ArrayList<Node> mqTTNode = new ArrayList<>();
					Commons.fileOps.getNodeWithAttribute(triggerNode.getChildNodes(), 0, mqTTNode, "value", "name", "serviceName");
					Commons.fileOps.getNodeWithAttribute(triggerNode.getChildNodes(), 0, mqTTNode, "value", "name", "topic");
					for(int i=0; i<mqTTNode.size();i++) {
						if(mqTTNode.get(i).getAttributes().getNamedItem("name").getTextContent().contains("serviceName")) {
							serviceName = mqTTNode.get(i).getTextContent();
						}
						if(mqTTNode.get(i).getAttributes().getNamedItem("name").getTextContent().contains("topic")) {
							topicName = mqTTNode.get(i).getTextContent();
						}
					}
																
					 Document servDoc = Commons.getDocBuilder().parse(Commons.template);
					 
					 Element flow = servDoc.createElement("flow");
		    		 flow.setAttribute("name", serviceName.replace(":", "-")+"_sub");
		    		 flow.setAttribute("doc:id", Commons.generateRandom(8)+"-eadc-40b9-98cc-268d14076da0");

		        	Element onNewMessage = Commons.jmsElements.addJMSOnNewMessageActivity(topicName,serviceName, servDoc);
		        	Element flowRef = Commons.actOps.flowRefActivity(serviceName, servDoc);
		        	
		        	servDoc.getFirstChild().insertBefore(flow, servDoc.getFirstChild().getChildNodes().item(0));
		        	flow.appendChild(onNewMessage);
		        	flow.appendChild(flowRef);
		        	
		        	Commons.fileOps.writeFile(servDoc,new File(Commons.getTrgPrjDir()+"\\src\\main\\mule"+"\\"+"Consume_"+serviceName.replace(" ", "_").replace(".", "-").replace(":", "-")+".xml")); 	
		  		
				}
			
			}
			rs4.close();  
	}
	

	public void retrieveServiceOperations(String serviceName) throws SAXException, IOException, ParserConfigurationException, SQLException {
		System.out.println();
		System.out.println("====================================================================================================");
		System.out.println(serviceName);
		System.out.println("====================================================================================================");
		
		Document tDoc = Commons.getDocBuilder().parse(Commons.template);
		Element flow = tDoc.createElement("flow");
	    flow.setAttribute("name", serviceName.replace("\\", "-").replace(" ", "_"));
	    flow.setAttribute("doc:id", Commons.generateRandom(8)+"-eadc-40b9-98cc-268d14076da0");
	    // cache logic
	   
	    ArrayList<File> ndfFilesCache  = Commons.getNdfs();
	    ndfFilesCache.addAll(Commons.getRefNdfs());
	    File cacheFile = null;
	    for(File ndfFile : ndfFilesCache){
	    	if(ndfFile.getParentFile().getAbsolutePath().substring(ndfFile.getAbsolutePath().indexOf("\\ns\\")+4).contains(serviceName)){
	    		cacheFile = ndfFile;
	    		break;
	    	}
	    }
	    
	    String cacheContent = new String(Files.readAllBytes(cacheFile.toPath()), StandardCharsets.UTF_8);
        
        Node cacheNode = Commons.getDocBuilder().parse(new InputSource(new StringReader(cacheContent))).getDocumentElement();
        ArrayList<Node> checkCacheNode = new ArrayList<>();
		Commons.fileOps.getNodeWithAttribute(cacheNode.getChildNodes(), 0, checkCacheNode, "value", "name", "caching");
		Commons.fileOps.getNodeWithAttribute(cacheNode.getChildNodes(), 0, checkCacheNode, "value", "name", "cache_ttl");
		
		if(checkCacheNode.get(0).getTextContent().contentEquals("yes")) {
			String cache_time = checkCacheNode.get(1).getTextContent();
			Element cache = Commons.actOps.cacheElement(tDoc,serviceName.replace("\\", "-")+"_cache", cache_time);
			
			ResultSet serviceRs = jdbcCon.getService(serviceName);
			while(serviceRs.next()) {
				String acName = serviceRs.getString(4);
				String acXslt = serviceRs.getString(6);
				int seqId = serviceRs.getInt(2);
				Node acNode = Commons.getDocBuilder().parse(new InputSource(new StringReader(acXslt))).getDocumentElement();
				addActivityToFlow(serviceName,acName,acNode,tDoc,cache,seqId);
				if(acName.startsWith("pub.")) {
		    		Commons.builtInServices.add(new KeyValuePair(serviceName, acName));
		    	}
			}    		    	
	    	flow.appendChild(cache);
	    	tDoc.getFirstChild().appendChild(flow);
		}
		else {
			ResultSet serviceRs = jdbcCon.getService(serviceName);
			while(serviceRs.next()) {
				String acName = serviceRs.getString(4);
				String acXslt = serviceRs.getString(6);
				int seqId = serviceRs.getInt(2);
				Node acNode = Commons.getDocBuilder().parse(new InputSource(new StringReader(acXslt))).getDocumentElement();
				addActivityToFlow(serviceName,acName,acNode,tDoc,flow,seqId);
				if(acName.startsWith("pub.")) {
		    		Commons.builtInServices.add(new KeyValuePair(serviceName, acName));
		    	}
			}
			tDoc.getFirstChild().appendChild(flow);
		}
		
		if(serviceName.contains("\\")) {
			File trg = new File(FileOperations.getMule().getAbsolutePath()+"\\"+serviceName.substring(0,serviceName.lastIndexOf("\\")).replace(" ","_"));
			Path path = Paths.get(trg.getAbsolutePath());
			Files.createDirectories(path);
		}
	    Commons.fileOps.writeFile(tDoc, new File(FileOperations.getMule().getAbsolutePath()+"\\"+serviceName.replace(" ", "_")+".xml"));
	}

	public void getHierarchy(Element elementParent, Node recordParent, Document docTypeDoc, ArrayList<Node> attributes) throws SAXException, IOException, ParserConfigurationException {
		Element complexType = docTypeDoc.createElement("xsd:complexType");
		Element sequence = docTypeDoc.createElement("xsd:sequence");
		for(int k = 0 ; k<recordParent.getChildNodes().getLength(); k++) {
			Node record = recordParent.getChildNodes().item(k);
			Element element = docTypeDoc.createElement("xsd:element");
			
			ArrayList<Node> values = new ArrayList<>();
			Commons.fileOps.getNodeWithAttribute(record.getChildNodes(), 0, values, "value", "name", "field_name");
			Commons.fileOps.getNodeWithAttribute(record.getChildNodes(), 0, values, "value", "name", "field_type");
			
			Commons.fileOps.getNodeWithAttribute(record.getChildNodes(), 0, values, "value", "name", "wrapper_type");
			for(int i=0; i<record.getChildNodes().getLength(); i++) {
				if(record.getChildNodes().item(i).getAttributes().getNamedItem("name").getNodeValue().contentEquals("field_content_type")) {
					Commons.fileOps.getNodeWithAttribute(record.getChildNodes().item(i).getChildNodes(), 0, values, "value", "name", "ncName");
				}
			}
			String fType = null;
			try {
				fType = values.get(1).getTextContent();
			}catch(Exception e) {}
			
			if(fType.contentEquals("recref")) {
				for(int i=0; i<record.getChildNodes().getLength(); i++) {
					if(record.getChildNodes().item(i).getAttributes().getNamedItem("name").getNodeValue().contentEquals("rec_ref")) {
						File refFile = new File(FileOperations.getSourcePrjDir()+"\\ns\\"+record.getChildNodes().item(i).getTextContent().replace(".", "\\").replace(":", "\\")+"\\node.ndf");
						if(refFile.exists()) {
							Document refDoc = Commons.getDocBuilder().parse(refFile);
							Commons.fileOps.removeBlankLines(refDoc);
							for(int j = 0; j<refDoc.getFirstChild().getFirstChild().getChildNodes().getLength(); j++) {
							if(refDoc.getFirstChild().getFirstChild().getChildNodes().item(j).getAttributes().getNamedItem("name").getNodeValue().contentEquals("rec_fields")
							&&	refDoc.getFirstChild().getFirstChild().getChildNodes().item(j).getAttributes().getNamedItem("type").getNodeValue().contentEquals("record")) {
								ArrayList<Node> innerAttributes = new ArrayList<>();
								getHierarchy(element, refDoc.getFirstChild().getFirstChild().getChildNodes().item(j), docTypeDoc, innerAttributes);
								for(Node attr : innerAttributes) {
									element.getFirstChild().appendChild(attr);
								}
							}
						}
						}else {
							for(File ref : Commons.refPackages) {
								refFile = new File(ref+"\\ns\\"+record.getChildNodes().item(i).getTextContent().replace(".", "\\").replace(":", "\\")+"\\node.ndf");
								if(refFile.exists()) {
									Document refDoc = Commons.getDocBuilder().parse(refFile);
									Commons.fileOps.removeBlankLines(refDoc);
									for(int j = 0; j<refDoc.getFirstChild().getFirstChild().getChildNodes().getLength(); j++) {
										if(refDoc.getFirstChild().getFirstChild().getChildNodes().item(j).getAttributes().getNamedItem("name").getNodeValue().contentEquals("rec_fields")
										&&	refDoc.getFirstChild().getFirstChild().getChildNodes().item(j).getAttributes().getNamedItem("type").getNodeValue().contentEquals("record")) {
											ArrayList<Node> innerAttributes = new ArrayList<>();
											getHierarchy(element, refDoc.getFirstChild().getFirstChild().getChildNodes().item(j), docTypeDoc, innerAttributes);
											for(Node attr : innerAttributes) {
												element.getFirstChild().appendChild(attr);
											}
										}
									}
								}
							}
						}
					}
				}
				if(!element.hasChildNodes()) {
					continue;
				}
			}
			
			try {
				if(values.get(2).getTextContent().contains(".")) {
					fType = values.get(2).getTextContent().substring(values.get(2).getTextContent().lastIndexOf(".")+1).toLowerCase();
				}else{
					fType = values.get(2).getTextContent();
				}
			}catch(Exception e) {}
			
			String name = values.get(0).getTextContent();
			if(name.contains(":")) {
				if(Commons.namespaces.contains(name.substring(0,name.indexOf(":")))) {
					name = name.substring(name.indexOf(":")+1);
				}else {
					name = name.replace(":", "_");
				}
			}
			
			switch(fType) {
			case "character":
				fType = "string";
				break;
			case "integer":
				fType = "int";
				break;
			case "biginteger":
				fType = "integer";
				break;
			case "bigdecimal":
				fType = "decimal";
				break;
			case "object":
				fType = "string";
				break;
			case "recref":
				fType = "string";
				break;
			case "record":
				fType = "string";
				break;
			}
			
			if(name.startsWith("*")) {
				name = name.replace("*", "");
				element.setAttribute("minOccurs","0");
			}
			
			
			element.setAttribute("name", name);
			if(values.get(0).getTextContent().startsWith("@")) {
				name = name.replace("@", "");
				Element attribute = docTypeDoc.createElement("xsd:attribute");
				attribute.setAttribute("name", name);
				attribute.setAttribute("type", "xsd:" + fType);
				attributes.add(attribute);
										   
				continue;
			}
			for(int i = 0; i<record.getChildNodes().getLength(); i++) {
				if(record.getChildNodes().item(i).getAttributes().getNamedItem("name").getNodeValue().contentEquals("rec_fields")
				&&	record.getChildNodes().item(i).getAttributes().getNamedItem("type").getNodeValue().contentEquals("record")) {
					ArrayList<Node> innerAttributes = new ArrayList<>();
					getHierarchy(element, record.getChildNodes().item(i), docTypeDoc, innerAttributes);
					for(Node attr : innerAttributes) {
						element.getFirstChild().appendChild(attr);
					}
				}
			}
			if(!Commons.xsdDataTypes.contains(fType)) {
				fType = "string";
			}
			if(!element.hasChildNodes()) {
				element.setAttribute("type", "xsd:" + fType);
			}
			sequence.appendChild(element);
		}
		if(sequence.hasChildNodes()) {
			complexType.appendChild(sequence);
			elementParent.appendChild(complexType);
		}
	}

	public void addActivityToFlow(String serviceName, String acName, Node acNode, Document tDoc, Element flow, int seqId) throws SQLException, SAXException, IOException, ParserConfigurationException {
		System.out.println(acName+"----"+seqId);
		if(acName.contentEquals("SEQUENCE")) {
//			if(acNode.getChildNodes().getLength()>10) {
//				String serviceNameSub = serviceName+"_Sub_"+subCount;
//				Document tDocSub = Commons.getTemplateDoc();
//				Element flowSub = tDocSub.createElement("flow");
//				flowSub.setAttribute("name", serviceNameSub.replace("\\", "-").replace(" ", "_"));
//				flowSub.setAttribute("doc:id", Commons.generateRandom(8)+"-eadc-40b9-98cc-268d14076da0");
//			    ResultSet groupRs = jdbcCon.getServiceFromGroup(serviceName,seqId);
//				while(groupRs.next()) {
//					String gacName = groupRs.getString(5);
//					String gacXslt = groupRs.getString(7);
//					int gacSeqId = groupRs.getInt(3);
//					if(gacName.contains("BRANCH")&& gacSeqId==47) {
//						System.out.println("HEre----eeeeeeeeeee");
//					}
//					
//					Node gacNode = Commons.getDocBuilder().parse(new InputSource(new StringReader(gacXslt))).getDocumentElement();
//					addActivityToFlow(serviceNameSub, gacName, gacNode, tDocSub, flowSub, gacSeqId);
//				}
//			    tDocSub.getFirstChild().appendChild(flowSub);
//				if(serviceNameSub.contains("\\")) {
//					File trg = new File(Commons.getMule().getAbsolutePath()+"\\"+serviceNameSub.substring(0,serviceNameSub.lastIndexOf("\\")).replace(" ","_"));
//					Path path = Paths.get(trg.getAbsolutePath());
//					Files.createDirectories(path);
//				}
//				
//				Commons.fileOps.writeFile(tDocSub, new File(Commons.getMule().getAbsolutePath()+"\\"+serviceNameSub.replace(" ", "_")+".xml"));
//			    flow.appendChild(Commons.actOps.flowRefActivity(serviceNameSub.replace("\\", "-").replace(" ", "_"), tDoc));
//			    subCount++;
//			}
//			else {
				Element tryActivity = tDoc.createElement("try");
				tryActivity.setAttribute("doc:name", acName);
				ResultSet groupRs = jdbcCon.getServiceFromGroup(serviceName,seqId);
				while(groupRs.next()) {
					String gacName = groupRs.getString(5);
					String gacXslt = groupRs.getString(7);
					int gacSeqId = groupRs.getInt(3);
					Node gacNode = Commons.getDocBuilder().parse(new InputSource(new StringReader(gacXslt))).getDocumentElement();
				
					if(gacName.contains("BRANCH")&& gacSeqId==47) {
						System.out.println("HEreeeeeeeeeeee");
					}
					addActivityToFlow(serviceName, gacName, gacNode, tDoc, tryActivity, gacSeqId);
					if(acName.startsWith("pub.")) {
						Commons.builtInServices.add(new KeyValuePair(serviceName, acName));
					}
				}
				if(tryActivity.getChildNodes().getLength()==0) {	
					tryActivity.appendChild(Commons.actOps.loggerActivity(acName, acNode, tDoc, flow, acName));
				}
				flow.appendChild(tryActivity);
//			}
								 
		}
		else if(acName.contentEquals("LOOP")) {
			
			Element payLoadActivity = tDoc.createElement("set-payload");
			payLoadActivity.setAttribute("doc:name", "Set Payload");
			payLoadActivity.setAttribute("name", "set_payload");
			payLoadActivity.setAttribute("doc:id", Commons.generateRandom(8)+"-eadc-40b9-98cc-268d14076da0");
			payLoadActivity.setAttribute("value", "#[payload]");
			
			
			Element forEachActivity = tDoc.createElement("foreach");
			forEachActivity.setAttribute("doc:name", acName);
			forEachActivity.setAttribute("name", acName);
			forEachActivity.setAttribute("doc:id", Commons.generateRandom(8)+"-eadc-40b9-98cc-268d14076da0");
			forEachActivity.setAttribute("collection", "#[payload]");
			ResultSet groupRs = jdbcCon.getServiceFromGroup(serviceName,seqId);
			while(groupRs.next()) {
				String gacName = groupRs.getString(5);
				String gacXslt = groupRs.getString(7);
				int gacSeqId = groupRs.getInt(3);
				Node gacNode = Commons.getDocBuilder().parse(new InputSource(new StringReader(gacXslt))).getDocumentElement();
				addActivityToFlow(serviceName, gacName, gacNode, tDoc, forEachActivity, gacSeqId);
			}
			flow.appendChild(payLoadActivity);
			flow.appendChild(forEachActivity);
		}
		else if(acName.contentEquals("BRANCH")) {
			ArrayList<Element> whens = new ArrayList<>();
			Element otherwise = tDoc.createElement("otherwise");
			Element choiceActivity = tDoc.createElement("choice");
			choiceActivity.setAttribute("doc:name", acName);
			ResultSet groupRs = jdbcCon.getServiceFromGroup(serviceName,seqId);
			ArrayList<Integer> addedSeqIds = new ArrayList<>();
			
			
			while(groupRs.next()) {
				int gacSeqId = groupRs.getInt(3);
				String gacName = groupRs.getString(5);
				String gacXslt = groupRs.getString(7);
				String condition = groupRs.getString(10);
				
				Node gacNode = Commons.getDocBuilder().parse(new InputSource(new StringReader(gacXslt))).getDocumentElement();
				try {
					String prNam = groupRs.getString(2);
				
					ResultSet parentRs = jdbcCon.getServiceFromGroupWithSq(serviceName,groupRs.getInt(4));
					while(parentRs.next()) {
						Node pacNode = Commons.getDocBuilder().parse(new InputSource(new StringReader(parentRs.getString(7)))).getDocumentElement();
					
							condition = "% "+pacNode.getAttributes().getNamedItem("SWITCH").getNodeValue()+"% = "+condition;
						
					}
					parentRs = jdbcCon.getServiceFromFlowWithSq(serviceName,groupRs.getInt(4));
					while(parentRs.next()) {
						Node pacNode = Commons.getDocBuilder().parse(new InputSource(new StringReader(parentRs.getString(6)))).getDocumentElement();
					
						condition = "%"+pacNode.getAttributes().getNamedItem("SWITCH").getNodeValue()+"% = "+condition;
						
					}
				}
				catch(Exception e) {}
				// Included condtn!=null , have to cross check
				
				if(condition!= null  && condition.contains("$default")) {
					addActivityToFlow(serviceName, gacName, gacNode, tDoc, otherwise, gacSeqId);
				}else {
					Element when = tDoc.createElement("when");
					when.setAttribute("expression", condition);
					addActivityToFlow(serviceName, gacName, gacNode, tDoc, when, gacSeqId);
					whens.add(when);
				}
			
				
			
		}
			for(Element whenEle : whens) {
				choiceActivity.appendChild(whenEle);
			}
			if(otherwise.hasChildNodes()) {
				choiceActivity.appendChild(otherwise);
			}
			flow.appendChild(choiceActivity);
		}
		
		else if(acName.contentEquals("MAP")) {
			flow.appendChild(Commons.actOps.transformActivity(acName, acNode, tDoc, flow, acName));
			
		}
		else{
			flow.appendChild(Commons.actOps.addMulesoftActivity(acName,acNode,tDoc,flow,acName));
		}
	}
}
package com.sme.webmethods.service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.io.FileUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.wm.data.IData;
import com.wm.util.Base64;
import com.wm.util.coder.IDataBinCoder;

@Component
public class FileOperations {
	@Value("${working.directory}")
	private String workingDir;

	public File getSrc() {
		return src;
	}

	public void setSrc(File src) {
		this.src = src;
	}

	public File getTrg() {
		return trg;
	}

	public void setTrg(File trg) {
		this.trg = trg;
	}

	public String getSrcPath() {
		return srcPath;
	}

	public void setSrcPath(String srcPath) {
		this.srcPath = srcPath;
	}

	public String getTrgPath() {
		return trgPath;
	}

	public void setTrgPath(String trgPath) {
		this.trgPath = trgPath;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public File getMigrationDir() {
		return migrationDir;
	}

	public void setMigrationDir(File migDir) {
		migrationDir = migDir;
	}

	public File getRef() {
		return ref;
	}

	public void setRef(File ref) {
		this.ref = ref;
	}

	public String getRefPath() {
		return refPath;
	}

	public void setRefPath(String refPath) {
		this.refPath = refPath;
	}

	private File src;
	private File trg;
	private File ref;
	private String srcPath;
	private String trgPath;
	private String refPath;
	private String projectName;
	private static File migrationDir;

	public static File getSourcePrjDir() {
		return sourcePrjDir;
	}

	public static void setSourcePrjDir(File srcPrjDir) {
		sourcePrjDir = srcPrjDir;
	}

	public static File getTargetPrjDir() {
		return targetPrjDir;
	}

	public static void setTargetPrjDir(File trgPrjDir) {
		targetPrjDir = trgPrjDir;
	}

	public static File getRefDir() {
		return refDir;
	}

	public static void setRefDir(File refDirectory) {
		refDir = refDirectory;
	}

	public static File getMule() {
		return mule;
	}

	public static void setMule(File muleDir) {
		mule = muleDir;
	}

	private static File sourcePrjDir;
	private static File targetPrjDir;
	private static File refDir;
	private static File mule;

	public String getWorkingDir() {
		return workingDir;
	}

	public void setWorkingDir(String workingDir) {
		this.workingDir = workingDir;
	}

	public void setSourceFiles() throws FileNotFoundException, IOException, InterruptedException {
		System.out.println("Working Directory is" + workingDir);
		try {
			String srcPath = getWorkingDir() + File.separator + File.separator + "src";
			String trgPath = getWorkingDir() + File.separator + File.separator + "trg";
			String refPath = getWorkingDir() + File.separator + File.separator + "ref";
			setSrcPath(srcPath);
			setSrc(new File(srcPath));
			setSrcPath(trgPath);
			setTrg(new File(trgPath));
			setRefPath(refPath);
			setRef(new File(refPath));
			if (getSrc().mkdirs()) {
				System.out.println("Directory Created for src " + getSrc().getAbsolutePath());
			}
			if (getTrg().mkdirs()) {
				System.out.println("Directory Created for trg " + getTrg().getAbsolutePath());
			}
			if (getRef().mkdirs()) {
				System.out.println("Directory Created for ref " + getRef().getAbsolutePath());
			}
			setSourcePrjDir(new File(getSrc().getAbsolutePath()).listFiles()[0]);
			setMigrationDir(new File(getWorkingDir()));

			System.out.println("After src migration path get: " + getSourcePrjDir());
			System.out.println("After src migration path get 1: " + getSourcePrjDir().getName());

			String trgPrjDir = getTrg().getAbsolutePath() + File.separator + getSourcePrjDir().getName();
			setTargetPrjDir(new File(trgPrjDir));
			if (getTargetPrjDir().mkdirs()) {
				System.out.println("trg project directory creation " + getTargetPrjDir().getAbsolutePath());
			} else {
				System.out.println("Unable to create directory for " + getTargetPrjDir().getAbsolutePath());
			}
			Commons.log("ref migration path set");
			System.out.println("my doubt: " + getSourcePrjDir().getParent());
			System.out.println("trg migration path get: " + getTargetPrjDir());

			setRefDir(new File(getRef().getAbsolutePath()));
			Commons.log("ref migration path set end");
			System.out.println("ref migration path get: " + getRefDir());
		} catch (Exception e) {
			Commons.log(e.getMessage());
		}
		try {

			for (File refFile : getRefDir().listFiles()) {
				Commons.refPackages.add(refFile);
			}
			Commons.log("FileOperations-64");
			ArrayList<File> services = new ArrayList<File>();
			getAllServices(getSourcePrjDir(), 0, services);
			Commons.setServices(services);
			ArrayList<File> ndfs = new ArrayList<File>();
			ArrayList<File> refNdfs = new ArrayList<File>();
			getAllNdfFiles(getSourcePrjDir().listFiles(), 0, ndfs, ".ndf");
			getRefNdfFiles(getRefDir().listFiles(), 0, refNdfs, ".ndf");
			Commons.setNdfs(ndfs);
			Commons.setRefNdfs(refNdfs);

			generateMuleProject(getSourcePrjDir().getName());

			setMule(new File(getTargetPrjDir().getAbsolutePath() + File.separator + "src" + File.separator + "main"
					+ File.separator + "mule"));
			getMule().mkdirs();
			File java = new File(getTargetPrjDir().getAbsolutePath() + File.separator + "src" + File.separator + "main"
					+ File.separator + "java");
			java.mkdirs();
			File docTypes = new File(getTargetPrjDir().getAbsolutePath() + File.separator + "src" + File.separator
					+ "main" + File.separator + "resources" + File.separator + "docTypes");
			docTypes.mkdirs();
			File jsons = new File(getTargetPrjDir().getAbsolutePath() + File.separator + "src" + File.separator + "main"
					+ File.separator + "resources" + File.separator + "jsonFiles");
			jsons.mkdirs();
			File xmls = new File(getTargetPrjDir().getAbsolutePath() + File.separator + "src" + File.separator + "main"
					+ File.separator + "resources" + File.separator + "xmls");
			xmls.mkdirs();
			File api = new File(getTargetPrjDir().getAbsolutePath() + File.separator + "src" + File.separator + "main"
					+ File.separator + "resources" + File.separator + "api");
			api.mkdirs();
			File types = new File(getTargetPrjDir().getAbsolutePath() + File.separator + "src" + File.separator + "main"
					+ File.separator + "resources" + File.separator + "types");
			types.mkdirs();
			File examples = new File(getTargetPrjDir().getAbsolutePath() + File.separator + "src" + File.separator
					+ "main" + File.separator + "resources" + File.separator + "examples");
			examples.mkdirs();
			replacePom();
			System.out.println("End of Source files method");
		} catch (Exception e) {
			System.out.println("Exception is" + e.getMessage());
			Commons.log(e.getMessage());
		}
	}
	/*
	 * public void setSourceFiles() throws FileNotFoundException, IOException,
	 * InterruptedException { try (FileInputStream fileInputStream = new
	 * FileInputStream("C:\\SHIP\\application.properties")) {
	 * Commons.log("load Properties start");
	 * Commons.getProperties().load(fileInputStream);
	 * Commons.log("load Properties end"); Commons.log("migration path set");
	 * Commons.log(Commons.getProperties().getProperty("migration.path"));
	 * Commons.setMigrationDir(new
	 * File(Commons.getProperties().getProperty("migration.path")));
	 * Commons.log("src migration path set");
	 * System.out.println("migration path get: "+ Commons.getMigrationDir());
	 * Commons.setSrcPrjDir(new
	 * File(Commons.getProperties().getProperty("migration.path.src")).listFiles()[0
	 * ]); Commons.log("trg migration path set");
	 * System.out.println("After src migration path get: "+ Commons.getSrcPrjDir());
	 * Commons.setTrgPrjDir(new
	 * File(Commons.getProperties().getProperty("migration.path.trg")+"\\"+Commons.
	 * getSrcPrjDir().getName())); Commons.log("ref migration path set");
	 * System.out.println("my doubt: " + Commons.getSrcPrjDir().getParent());
	 * System.out.println("trg migration path get: "+ Commons.getTrgPrjDir());
	 * Commons.setRefDir(new
	 * File(Commons.getProperties().getProperty("migration.path.ref")));
	 * Commons.log("ref migration path set end");
	 * System.out.println("ref migration path get: "+ Commons.getRefDir()); }catch
	 * (Exception e) { Commons.log(e.getMessage()); } try {
	 * 
	 * for(File refFile : Commons.getRefDir().listFiles()) {
	 * Commons.refPackages.add(refFile); } Commons.log("FileOperations-64");
	 * ArrayList<File> services = new ArrayList<File>();
	 * getAllServices(Commons.getSrcPrjDir(),0,services);
	 * Commons.setServices(services); ArrayList<File> ndfs = new ArrayList<File>();
	 * ArrayList<File> refNdfs = new ArrayList<File>();
	 * getAllNdfFiles(Commons.getSrcPrjDir().listFiles(),0,ndfs,".ndf");
	 * getRefNdfFiles(Commons.getRefDir().listFiles(),0,refNdfs,".ndf");
	 * Commons.setNdfs(ndfs); Commons.setRefNdfs(refNdfs);
	 * 
	 * generateMuleProject(Commons.getSrcPrjDir().getName());
	 * 
	 * Commons.setMule(new
	 * File(Commons.getTrgPrjDir().getAbsolutePath()+"\\src\\main\\mule"));
	 * Commons.getMule().mkdir(); File java = new
	 * File(Commons.getTrgPrjDir().getAbsolutePath()+"\\src\\main\\java");
	 * java.mkdir(); File docTypes = new
	 * File(Commons.getTrgPrjDir().getAbsolutePath()+
	 * "\\src\\main\\resources\\docTypes"); docTypes.mkdir(); File jsons = new
	 * File(Commons.getTrgPrjDir().getAbsolutePath()+
	 * "\\src\\main\\resources\\jsonFiles"); jsons.mkdir(); File xmls = new
	 * File(Commons.getTrgPrjDir().getAbsolutePath()+"\\src\\main\\resources\\xmls")
	 * ; xmls.mkdir(); File api = new
	 * File(Commons.getTrgPrjDir().getAbsolutePath()+"\\src\\main\\resources\\api");
	 * api.mkdir(); File types = new File(Commons.getTrgPrjDir().getAbsolutePath()+
	 * "\\src\\main\\resources\\api\\types"); types.mkdir(); File examples = new
	 * File(Commons.getTrgPrjDir().getAbsolutePath()+
	 * "\\src\\main\\resources\\api\\examples"); examples.mkdir(); replacePom();
	 * }catch (Exception e) { Commons.log(e.getMessage()); } }
	 */

	public void replacePom() throws IOException {
		try {
			//String src = getMigrationDir().getAbsolutePath() + "//pom.xml";
			String trg = getTargetPrjDir().getAbsolutePath() + "//pom.xml";
			ClassLoader classLoader = getClass().getClassLoader();
			 try (InputStream fis = classLoader.getResourceAsStream("pom.xml")) {
		            byte[] srcBytes = fis.readAllBytes();
		            Files.write(Path.of(trg), srcBytes, StandardOpenOption.TRUNCATE_EXISTING);
			replaceProjectName(trg, "TemplateProject", getSourcePrjDir().getName());
		} 
		}catch (Exception e) {
			Commons.log(e.getMessage());
		}
	}

	public void getAllNdfFiles(File[] listFiles, int i, ArrayList<File> ndfs, String string) {
		if (i == listFiles.length) {
			return;
		}
		if (listFiles[i].isFile()) {
			if (listFiles[i].getName().endsWith(string)) {
				ndfs.add(listFiles[i]);
			}
		} else if (listFiles[i].isDirectory()) {
			getAllNdfFiles(listFiles[i].listFiles(), 0, ndfs, string);
		}
		getAllNdfFiles(listFiles, i + 1, ndfs, string);
	}

	public void getRefNdfFiles(File[] listFiles, int i, ArrayList<File> ndfs, String string) {
		if (i == listFiles.length) {
			return;
		}
		if (listFiles[i].isFile()) {
			if (listFiles[i].getName().endsWith(string)) {
				ndfs.add(listFiles[i]);
			}
		} else if (listFiles[i].isDirectory()) {
			getAllNdfFiles(listFiles[i].listFiles(), 0, ndfs, string);
		}
		getAllNdfFiles(listFiles, i + 1, ndfs, string);
	}

	public void generateMuleProject(String projectName) throws IOException, InterruptedException {

		/*
		 * String filePath = getMigrationDir().getAbsolutePath() + "\\Mulecmd.bat";
		 * System.out.println("File path is " + filePath);
		 * System.out.println("Project name is " + projectName);
		 * replaceProjectName(filePath, "TemplateProject", projectName); ProcessBuilder
		 * processBuilder = new ProcessBuilder("cmd.exe", "/c", filePath);
		 * System.out.println("check point"); Process process = processBuilder.start();
		 * int exitCode = process.waitFor(); if (exitCode == 0) {
		 * System.out.println("Mule project created successfully."); } else {
		 * System.out.println("Mule project not getting created."); }
		 * replaceProjectName(filePath, projectName, "TemplateProject");
		 */
        String muleCmd = "mvn archetype:generate -B " +
                "-DarchetypeGroupId=com.sageit " +
                "-DarchetypeArtifactId=new-project-archetype " +
                "-DarchetypeVersion=1.0.0-SNAPSHOT " +
                "-DgroupId=com.sageit " +
                "-DartifactId=" + projectName + " " +
                "-Dversion=1.0.0";

        boolean isWindows = System.getProperty("os.name")
                .toLowerCase().startsWith("windows");

        String[] command = new String[2];
        command[0] = isWindows ? "cmd.exe" : "/bin/sh";
        command[1] = isWindows ? "/c" : "-c";


        ProcessBuilder processBuilder = new ProcessBuilder(command[0], command[1], "cd "
                + getTrg().getAbsolutePath() + " && " + muleCmd);
        processBuilder.redirectOutput(ProcessBuilder.Redirect.INHERIT);
        processBuilder.redirectErrorStream(true);
        Process process = processBuilder.start();
        int exitCode = process.waitFor();
        if (exitCode == 0) {
        	System.out.println("Mule project created successfully.");
            //logger.info("Mule project created successfully.");
        } else {
        	System.out.println("Mule project not getting created.");
           // logger.error("Mule project not getting created.");
            throw new RuntimeException("Mule project not getting created.");
        }
	}

	public void replaceProjectName(String filePath, String oldStr, String newStr) {
		try {
			// Read the file content
			byte[] fileContent = Files.readAllBytes(Path.of(filePath));
			String content = new String(fileContent);
			String modifiedContent = content.replace(oldStr, newStr);
			Files.write(Path.of(filePath), modifiedContent.getBytes(), StandardOpenOption.TRUNCATE_EXISTING);
            System.out.println("Replace Project Successful");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void getAllServices(File file, int i, ArrayList<File> services) {
		if (i == file.listFiles().length) {
			return;
		}
		if (file.listFiles()[i].isFile()) {
			if (file.listFiles()[i].getName().contentEquals("flow.xml")) {
				services.add(file);
			}
		} else if (file.listFiles()[i].isDirectory()) {
			getAllServices(file.listFiles()[i], 0, services);
		}
		getAllServices(file, i + 1, services);
	}

	public String readFileToString(String filePath) throws IOException {
		Path path = Paths.get(filePath);
		byte[] bytes = Files.readAllBytes(path);
		return new String(bytes, StandardCharsets.UTF_8);
	}

	public void getNodeWithAttribute(NodeList nodeList, int i, ArrayList<Node> nlist, String nodeName, String attrName,
			String attrValue) {
		if (i == nodeList.getLength()) {
			return;
		}
		if (nodeList.item(i).getNodeName().contentEquals(nodeName)) {
			try {
				if (nodeList.item(i).getAttributes().getNamedItem(attrName).getNodeValue().contentEquals(attrValue)) {
					nlist.add(nodeList.item(i));
				}
			} catch (Exception e) {
			}
		}
		if (nodeList.item(i).hasChildNodes()) {
			getNodeWithAttribute(nodeList.item(i).getChildNodes(), 0, nlist, nodeName, attrName, attrValue);
		}
		getNodeWithAttribute(nodeList, i + 1, nlist, nodeName, attrName, attrValue);
	}

	public void getNode(NodeList nodeList, int i, ArrayList<Node> nlist, String nName) {
		if (i == nodeList.getLength()) {
			return;
		}
		if (nodeList.item(i).getNodeName().contentEquals(nName)) {
			nlist.add(nodeList.item(i));
		}
		if (nodeList.item(i).hasChildNodes()) {
			getNode(nodeList.item(i).getChildNodes(), 0, nlist, nName);
		}
		getNode(nodeList, i + 1, nlist, nName);
	}

	public IData decryptEncodedWmData(String encodedData) {
		ByteArrayInputStream bis = null;
		try {
			IDataBinCoder coder = new IDataBinCoder();
			bis = new ByteArrayInputStream(Base64.decode(encodedData.getBytes("UTF8")));
			return coder.decode(bis);
		} catch (Throwable throwable) {
		} finally {
			if (bis != null) {
				try {
					bis.close();
				} catch (Throwable throwable) {
				}
				bis = null;
			}
		}
		return null;
	}

	public void removeBlankLines(Document doc) {
		try {
			XPath xp = XPathFactory.newInstance().newXPath();
			NodeList nl = (NodeList) xp.evaluate("//text()[normalize-space(.)='']", doc, XPathConstants.NODESET);

			for (int i = 0; i < nl.getLength(); ++i) {
				Node node = nl.item(i);
				node.getParentNode().removeChild(node);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void removeBlankNodes(Node node) {
		try {
			XPath xp = XPathFactory.newInstance().newXPath();
			NodeList nl = (NodeList) xp.evaluate(".//text()[normalize-space(.)='']", node, XPathConstants.NODESET);

			for (int i = 0; i < nl.getLength(); ++i) {
				Node textNode = nl.item(i);
				textNode.getParentNode().removeChild(textNode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String nodeToString(Node node) {
		StringWriter sw = new StringWriter();
		try {
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(new DOMSource(node), new StreamResult(sw));

		} catch (TransformerException te) {
			System.out.println("nodeToString Transformer Exception");
		}
		return sw.toString();
	}

	public void writeFile(Document doc, File file) {
		try {
			doc.getDocumentElement().normalize();
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			doc.setXmlStandalone(true);
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(file.getAbsolutePath()));
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(source, result);
			System.out.println("File updation : " + file.getName() + " file updated successfully at "
					+ file.getParentFile().getAbsolutePath());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void WriteStringToFile(String filePath, String content) {
		try {
			FileWriter writer = new FileWriter(filePath);
			writer.write(content);
			writer.close();
		} catch (IOException e) {
			System.out.println("An error occurred: " + e.getMessage());
			e.printStackTrace();
		}
	}

	public String convertXmlToJson(String filePath) throws SAXException, IOException, ParserConfigurationException {
		File file = new File(filePath);
		Document doc = Commons.getDocBuilder().parse(file);

		String TEST_XML_STRING = Commons.fileOps.nodeToString(doc.getDocumentElement());

		try {
			JSONObject xmlJSONObj = XML.toJSONObject(TEST_XML_STRING);
			String jsonPrettyPrintString = xmlJSONObj.toString(4);
			return jsonPrettyPrintString;
		} catch (JSONException je) {
			System.out.println(je.toString());
		}
		return "";
	}

	public void removeSource() {
		try {
			String srcPath = "C:\\WmMigration\\src";
			FileUtils.cleanDirectory(new File(srcPath));
		} catch (Exception e) {
			Commons.log(e.getMessage());
		}
	}

}

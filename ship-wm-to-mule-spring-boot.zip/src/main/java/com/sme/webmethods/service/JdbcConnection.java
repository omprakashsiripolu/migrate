package com.sme.webmethods.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
//import java.util.Properties;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.Map.Entry;
@Repository
@Component
public class JdbcConnection {
	public static Connection connection = null;
	public static int exec_id = 1;
	 @Value("${database.hostname1}")
	    private String hostName;
	 
	 @Value("${database.portnum1}")
	 private String portNum;
	 
	 @Value("${database.service.name1}")
	 private String serviceName;
	 
	 @Value("${database.username1}")
	 private String userName;
	 
	 @Value("${database.password1}")
	 private String password;
	 

	 
	public void setConnection(){
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			//Properties prop = Commons.getProperties();
			
			//String url = "jdbc:mysql://"+prop.getProperty("database.hostname")+":"+prop.getProperty("database.portnum")+"/"+prop.getProperty("database.service.name")+"?serverTimezone=UTC";
			String url = "jdbc:mysql://"+getHostName()+":"+getPortNum()+"/"+getServiceName()+"?serverTimezone=UTC";
			//String username = prop.getProperty("database.username");
			//password = prop.getProperty("database.password");
			System.out.println("DB details are "+getUserName());
			System.out.println("Connection url "+ url );
			connection = DriverManager.getConnection(url, getUserName(), getPassword());
			if (connection != null) {
				System.out.println("====================================================================================================");
				System.out.println("Connected with MySql JDBC connection");
				System.out.println("====================================================================================================");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getPortNum() {
		return portNum;
	}
	public void setPortNum(String portNum) {
		this.portNum = portNum;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void insertToFlow(String serviceName, int seqId, String acName, String acXslt) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("INSERT INTO FLOW (PROCESSES_NAME,SEQID,ACTIVITY_NAME,ACTIVITY_XSLT) VALUES (?,?,?,?)");
		statement.setString(1, serviceName);
		statement.setInt(2, seqId);
		statement.setString(3, acName);
		statement.setString(4, acXslt);
		statement.execute();
		System.out.println("Row Inserted to flow : "+acName);
	}
	public void insertToGroup(String groupName,String serviceName, int seqId, int groupId, String acName, String acXslt, String condition) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("INSERT INTO GROUPACTIVITIES (GROUP_NAME,PROCESSES_NAME,SEQID,LVL,ACTIVITY_NAME,ACTIVITY_XSLT,XPATH) VALUES (?,?,?,?,?,?,?)");
		statement.setString(1, groupName);
		statement.setString(2, serviceName);
		statement.setInt(3, seqId);
		statement.setInt(4, groupId);
		statement.setString(5, acName);
		statement.setString(6, acXslt);
		statement.setString(7, condition);
		statement.execute();
		System.out.println("Row Inserted to group : "+acName);
	}
	
	public void insertProject() throws SQLException {
		PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO PROJECT VALUES (?)");
		preparedStatement.setString(1,FileOperations.getSourcePrjDir().getName());
		preparedStatement.execute();
	}
	
	public ArrayList<String> getServiceNames() throws SQLException {
		ArrayList<String> serviceNames = new ArrayList<>();
		PreparedStatement statement = connection.prepareStatement("SELECT DISTINCT(PROCESSES_NAME) FROM FLOW ");
		ResultSet rs = statement.executeQuery();
		while(rs.next()) {
			serviceNames.add(rs.getString(1));
		}
		rs.close();
		PreparedStatement statement1 = connection.prepareStatement("SELECT DISTINCT(PROCESSES_NAME) FROM GROUPACTIVITIES ");
		ResultSet rs1 = statement1.executeQuery();
		while(rs1.next()) {
			serviceNames.add(rs1.getString(1));
		}
		rs1.close();
		return serviceNames;
	}
 
	public ResultSet getServicesFromFlow() throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT DISTINCT PROCESSES_NAME FROM FLOW");
		return statement.executeQuery();
	}
	public ResultSet getServiceFromFlowWithSq(String serviceName, int seqId) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM FLOW WHERE PROCESSES_NAME = ? AND SEQID = ?");
		statement.setString(1, serviceName);
		statement.setInt(2, seqId);
		return statement.executeQuery();
	}
	public ResultSet getServiceFromGroupWithSq(String serviceName, int seqId) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM GROUPACTIVITIES WHERE PROCESSES_NAME = ? AND SEQID = ?");
		statement.setString(1, serviceName);
		statement.setInt(2, seqId);
		return statement.executeQuery();
	}
	public ResultSet getService(String serviceName) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM FLOW WHERE PROCESSES_NAME = ? ORDER BY SEQID;");
		statement.setString(1, serviceName);
		return statement.executeQuery();
	}
	public ResultSet getServiceFromGroup(String serviceName, int seqId) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM GROUPACTIVITIES WHERE PROCESSES_NAME = ? AND LVL = ? ORDER BY SEQID;");
		statement.setString(1, serviceName);
		statement.setInt(2, seqId);
		return statement.executeQuery();
	}
	public void insertConfig(String configName, String configContent) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("INSERT INTO CONFIGFILES VALUES (?,?)");
		statement.setString(1, configName);
		statement.setString(2, configContent);
		statement.execute();
	}
	public ResultSet getServiceFromConfigFiles(String acName) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM CONFIGFILES WHERE NAME = ?");
		statement.setString(1, acName);
		return statement.executeQuery()	;
	}
	
	public ResultSet getServiceFromFlow(String acName) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM FLOW WHERE PROCESSES_NAME = ?");
		statement.setString(1, acName);
		return statement.executeQuery()	;
	}
	
	public void insertRestService(String serviceName, String resourceName, String urlTemplate, String base, String method, String input, String inputSchema, String output, String outputSchema) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("INSERT INTO RESTSERVICE VALUES (?,?,?,?,?,?,?,?,?)");
		statement.setString(1, serviceName);
		statement.setString(2, resourceName);
		statement.setString(3, urlTemplate);
		statement.setString(4, base);
		statement.setString(5, method);
		statement.setString(6, input);
		statement.setString(7, inputSchema);
		statement.setString(8, output);
		statement.setString(9, outputSchema);
		statement.execute();

	}
	public ResultSet getRestResultSet() throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM RESTSERVICE ORDER BY PATH");
        return  statement.executeQuery();
	}
	
	public ResultSet getRestService() throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM RESTSERVICE");
		//statement.setString(1, serviceName);
		
		return statement.executeQuery();

	}
	
	public ResultSet getMulesoftForWm(String acName) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM WMREFERENCES WHERE WEBMETHODS = ?");
		statement.setString(1, acName);
		return statement.executeQuery()	;
	}
	
	public ResultSet getConfigFile(String name) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM CONFIGFILES WHERE NAME = ?");
		statement.setString(1, name);
		return statement.executeQuery();

	}
	
	public ResultSet getConfigFilesWithLike(String endStr) throws SQLException {
		PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM CONFIGFILES WHERE NAME LIKE '%."+endStr+"' ");
		return preparedStatement.executeQuery();
	}
	
	public void archive() throws SQLException {
		PreparedStatement preparedStatementarch = connection.prepareStatement("SELECT MAX(EXEC_ID) FROM ARC_FLOW");
		ResultSet rs = preparedStatementarch.executeQuery();
		while(rs.next()) {
			exec_id = rs.getInt(1)+1;
		}
		rs.close();
		
		PreparedStatement flowps = connection.prepareStatement("SELECT * FROM FLOW");
		ResultSet flow = flowps.executeQuery();
		while(flow.next()) {
			PreparedStatement preparedStatement1 = connection.prepareStatement("INSERT INTO ARC_FLOW VALUES (?,?,?,?,?,?,?,?,?,?,?)");
			preparedStatement1.setString(1, flow.getString(1));
			preparedStatement1.setInt(2, flow.getInt(2));
			preparedStatement1.setInt(3, flow.getInt(3));
			preparedStatement1.setString(4, flow.getString(4));
			preparedStatement1.setString(5, flow.getString(5));
			preparedStatement1.setString(6, flow.getString(6));
			preparedStatement1.setString(7, flow.getString(7));
			preparedStatement1.setString(8, flow.getString(8));
			preparedStatement1.setString(9, flow.getString(9));
			preparedStatement1.setInt(10,flow.getInt(10));
			preparedStatement1.setInt(11,exec_id);
			preparedStatement1.execute();
		}
		flow.close();
		
		PreparedStatement transitionps = connection.prepareStatement("SELECT * FROM TRANSITIONS");
		ResultSet transition = transitionps.executeQuery();
		while(transition.next()) {
			PreparedStatement preparedStatement1 = connection.prepareStatement("INSERT INTO ARC_TRANSITIONS VALUES (?,?,?,?,?,?)");
			preparedStatement1.setString(1, transition.getString(1));
			preparedStatement1.setInt(2, transition.getInt(2));
			preparedStatement1.setInt(3, transition.getInt(3));
			preparedStatement1.setString(4, transition.getString(4));
			preparedStatement1.setString(5, transition.getString(5));
			preparedStatement1.setInt(6,exec_id);
			preparedStatement1.execute();
		}
		transition.close();
		
		PreparedStatement globalvariablesps = connection.prepareStatement("SELECT * FROM GLOBALVARIABLES");
		ResultSet globalvariables = globalvariablesps.executeQuery();
		while(globalvariables.next()) {
			PreparedStatement preparedStatement1 = connection.prepareStatement("INSERT INTO ARC_GLOBALVARIABLES VALUES (?,?,?)");
			preparedStatement1.setString(1, globalvariables.getString(1));
			preparedStatement1.setString(2, globalvariables.getString(2));
			preparedStatement1.setInt(3,exec_id);
			preparedStatement1.execute();
		}
		globalvariables.close();
		
		PreparedStatement configfilesps = connection.prepareStatement("SELECT * FROM CONFIGFILES");
		ResultSet configfiles = configfilesps.executeQuery();
		while(configfiles.next()) {
			PreparedStatement preparedStatement1 = connection.prepareStatement("INSERT INTO ARC_CONFIGFILES VALUES (?,?,?)");
			preparedStatement1.setString(1, configfiles.getString(1));
			preparedStatement1.setString(2, configfiles.getString(2));
			preparedStatement1.setInt(3,exec_id);
			preparedStatement1.execute();
		}
		configfiles.close();
		
		PreparedStatement groupactivitesps = connection.prepareStatement("SELECT * FROM GROUPACTIVITIES");
		ResultSet groupactivites = groupactivitesps.executeQuery();
		while(groupactivites.next()) {
			PreparedStatement preparedStatement1 = connection.prepareStatement("INSERT INTO ARC_GROUPACTIVITIES VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
			preparedStatement1.setString(1, groupactivites.getString(1));
			preparedStatement1.setString(2, groupactivites.getString(2));
			preparedStatement1.setInt(3, groupactivites.getInt(3));
			preparedStatement1.setInt(4, groupactivites.getInt(4));
			preparedStatement1.setString(5, groupactivites.getString(5));
			preparedStatement1.setString(6, groupactivites.getString(6));
			preparedStatement1.setString(7, groupactivites.getString(7));
			preparedStatement1.setString(8, groupactivites.getString(8));
			preparedStatement1.setString(9, groupactivites.getString(9));
			preparedStatement1.setString(10, groupactivites.getString(10));
			preparedStatement1.setInt(11,groupactivites.getInt(11));
			preparedStatement1.setInt(12,exec_id);
			preparedStatement1.execute();
		}
		groupactivites.close();
		
		PreparedStatement restserviceps = connection.prepareStatement("SELECT * FROM RESTSERVICE");
		ResultSet restservice = restserviceps.executeQuery();
		while(restservice.next()) {
			PreparedStatement preparedStatement1 = connection.prepareStatement("INSERT INTO ARC_RESTSERVICE VALUES (?,?,?,?,?,?,?,?,?,?)");
			preparedStatement1.setString(1, restservice.getString(1));
			preparedStatement1.setString(2, restservice.getString(2));
			preparedStatement1.setString(3, restservice.getString(3));
			preparedStatement1.setString(4, restservice.getString(4));
			preparedStatement1.setString(5, restservice.getString(5));
			preparedStatement1.setString(6, restservice.getString(6));
			preparedStatement1.setString(7, restservice.getString(7));
			preparedStatement1.setString(8, restservice.getString(8));
			preparedStatement1.setString(9, restservice.getString(9));
			preparedStatement1.setInt(10,exec_id);
			preparedStatement1.execute();
		}
		restservice.close();
		
		PreparedStatement sharedconnectionsps = connection.prepareStatement("SELECT * FROM SHAREDCONNECTIONS");
		ResultSet sharedconnections = sharedconnectionsps.executeQuery();
		while(sharedconnections.next()) {
			PreparedStatement preparedStatement1 = connection.prepareStatement("INSERT INTO ARC_SHAREDCONNECTIONS VALUES (?,?,?)");
			preparedStatement1.setString(1, sharedconnections.getString(1));
			preparedStatement1.setString(2, sharedconnections.getString(2));
			preparedStatement1.setInt(3,exec_id);
			preparedStatement1.execute();
		}
		sharedconnections.close();
		
		PreparedStatement xsltodwps = connection.prepareStatement("SELECT * FROM XSLTTODW");
		ResultSet xsltodw = xsltodwps.executeQuery();
		while(xsltodw.next()) {
			PreparedStatement preparedStatement1 = connection.prepareStatement("INSERT INTO ARC_XSLTTODW VALUES (?,?,?)");
			preparedStatement1.setString(1, xsltodw.getString(1));
			preparedStatement1.setString(2, xsltodw.getString(2));
			preparedStatement1.setInt(3,exec_id);
			preparedStatement1.execute();
		}
		xsltodw.close();
		
		Timestamp currentDateTime = new Timestamp(System.currentTimeMillis());
		PreparedStatement projectps = connection.prepareStatement("SELECT * FROM PROJECT");
		ResultSet project = projectps.executeQuery();
		while(project.next()) {
			PreparedStatement preparedStatement1 = connection.prepareStatement("INSERT INTO ARC_PROJECTS VALUES (?,?,?)");
			preparedStatement1.setString(1, project.getString(1));
			preparedStatement1.setInt(2, exec_id);
			preparedStatement1.setTimestamp(3, currentDateTime);
			preparedStatement1.execute();
		}
		project.close();
		
		System.out.println("ARCHIVING COMPLETE...");
	}
	
	public void truncateData() throws SQLException {
        truncateTable("FLOW");
        truncateTable("TRANSITIONS");
        truncateTable("SHAREDCONNECTIONS");
        truncateTable("GLOBALVARIABLES");
        truncateTable("GROUPACTIVITIES");
        truncateTable("CONFIGFILES");
        truncateTable("XSLTTODW");
        truncateTable("RESTSERVICE");
        truncateTable("PROJECT");
        truncateTable("ANALYSIS");
        truncateTable("HARDCODEDVALUES");
        truncateTable("ADAPTERSERVICES");
    }
	
	public void truncateTable(String tableName) throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement("TRUNCATE TABLE "+tableName);
        preparedStatement.execute();
    }
	public void insertAnalysis() throws SQLException {
		Map<String, List<String>> keyValueMap = new HashMap<>();
        for (KeyValuePair kvp : Commons.builtInServices) {
            String key = kvp.getKey();
            String value = kvp.getValue();

            keyValueMap.computeIfAbsent(key, k -> new ArrayList<>()).add(value);
        }

		 for (Entry<String, List<String>> entry : keyValueMap.entrySet()) {
	            String key = entry.getKey();
	            List<String> values = entry.getValue();
	            String builtins = null;
	            int b = 0;
	            String connections = null;
	            int c = 0;
	            String adapterservices = null;
	            int a = 0;
	            for(String value : values) {
	            	if(value.contains("::")) {
	            		Commons.migrate.addToConnectionList(value);
	            		
	            		if(connections==null) {
	            			connections = value.substring(0,value.indexOf("::"));
	            			c++;
	            		}else {
	            			if(!connections.contains(value.substring(0,value.indexOf("::")))){
	            				connections += ","+value.substring(0,value.indexOf("::"));
		            			c++;
	            			}
	            		}
	            		if(adapterservices==null) {
	            			adapterservices = value.substring(value.indexOf("::")+2);
	            			a++;
	            		}else {
	            			adapterservices += ","+value.substring(value.indexOf("::")+2);
	            			a++;
	            		}
	            	}else {
	            		if(builtins==null) {
	            			builtins = value;
	            			b++;
	            		}else {
	            			builtins += ","+value;
	            			b++;
	            		}
	            	}
	            }
	            PreparedStatement statement = connection.prepareStatement("INSERT INTO ANALYSIS VALUES (?,?,?,?,?,?,?,?)");
	            statement.setString(1, FileOperations.getSourcePrjDir().getName());
	    		statement.setString(2, key);
	    		statement.setString(3, builtins);
	    		statement.setString(4, connections);
	    		statement.setString(5, adapterservices);
	    		statement.setInt(6, b);
	    		statement.setInt(7, c);
	    		statement.setInt(8, a);
	    		statement.execute();
	            
	     }
	}
	public void insertHardCodedValues(String serviceName, String acName, int seqId, String label,
			String value) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("INSERT INTO HARDCODEDVALUES VALUES (?,?,?,?,?)");
        statement.setString(1, serviceName);
		statement.setString(2, acName);
		statement.setInt(3, seqId);
		statement.setString(4, label);
		statement.setString(5, value);
		statement.execute();
	}
	public void insertAdapterServices() throws SQLException {
		for (Map.Entry<String, ArrayList<String>> entry : Commons.connAndAdpList.entrySet()) {
            String connectionKey = entry.getKey();
            ArrayList<String> adapters = entry.getValue();
            for (String adapter : adapters) {
            	PreparedStatement statement = connection.prepareStatement("INSERT INTO ADAPTERSERVICES VALUES (?,?)");
	            statement.setString(1, connectionKey);
	    		statement.setString(2, adapter);
	    		statement.execute();
            }
        }
	}
 
}

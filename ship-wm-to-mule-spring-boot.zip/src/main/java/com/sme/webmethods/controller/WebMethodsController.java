package com.sme.webmethods.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Paths;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.sme.webmethods.service.Commons;
import com.sme.webmethods.service.FileOperations;
import com.sme.webmethods.service.JdbcConnection;
import com.sme.webmethods.service.Migrate;


@Controller
public class WebMethodsController{

@Autowired
	private FileOperations fileOper;
@Autowired
private JdbcConnection jdbcConn;

@Autowired
private Migrate mig;

@PostMapping("/webmethods/test")
public ResponseEntity<?> PostWebMethods() {
    try {
    	fileOper.setSourceFiles();
    	//ResponseEntity.okCommons.log("setConnection");
    	System.out.println("start of connection");
    	jdbcConn.setConnection();
		//Commons.jdbcConnection.setConnection();
		System.out.println("connection successful");
		Commons.log("truncateData");
		//Commons.jdbcConnection.truncateData();
		jdbcConn.truncateData();
		System.out.println("truncate successful");
		Commons.log("migrateSource");
		//Commons.migrate.migrateSource();
		mig.migrateSource();
		System.out.println("migrate successful");
		Commons.log("insertAnalysis");
		//Commons.jdbcConnection.insertAnalysis();
		jdbcConn.insertAnalysis();
		System.out.println("Insert Analysis");
		jdbcConn.insertAdapterServices();
		//Commons.jdbcConnection.insertAdapterServices();
		System.out.println("Insert Adapter successful");
		Commons.log("archive");
		jdbcConn.archive();
		//Commons.jdbcConnection.archive();
		System.out.println("Connection archive successful");
		Commons.log("migrateTarget");
		mig.migrateTarget();
		//Commons.migrate.migrateTarget();
		System.out.println("migrate target successful");
	//	Commons.fileOps.removeSource();
		Commons.log("end");
		System.out.println("All executed with out errors");
		System.out.println(Commons.pubActList);
		System.out.println(Commons.connAndAdpList);
		
		
        return ResponseEntity.ok("Folders created");

    } catch (Exception e) {
    	e.printStackTrace();
    	System.out.println("Exception is "+ e.getMessage());
        return ResponseEntity.internalServerError().body("Error message");
    }
}
}

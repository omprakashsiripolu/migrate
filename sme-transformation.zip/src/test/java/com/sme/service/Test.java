package com.sme.service;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Random;
import java.util.UUID;

public class Test {
    public static void main(String[] args) throws IOException {

    }


}

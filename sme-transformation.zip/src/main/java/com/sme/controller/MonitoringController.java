package com.sme.controller;


import com.sme.dao.entity.Projects;
import com.sme.http.response.ErrorResponseBody;
import com.sme.http.response.ProjectDetailInformation;
import com.sme.http.response.ProjectInformation;
import com.sme.service.IMonitor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@Controller
public class MonitoringController {

    private static final Logger logger = LoggerFactory.getLogger(MonitoringController.class);

    @Autowired
    IMonitor monitorService;

    @GetMapping("/projects")
    public ResponseEntity<?> getAllProjectDetails(@RequestParam(required = false) Boolean summary) {
        try {
            boolean summaryInclude = summary != null && summary;
            List<Projects> projectsList = monitorService.findAllProjects();
            List<ProjectInformation> projectInformationList = new ArrayList<>();
            projectsList.forEach((projects -> {
                projectInformationList.add(new ProjectInformation(projects, summaryInclude));
            }));

            return ResponseEntity.ok().body(projectInformationList);

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return ResponseEntity.internalServerError().body(new ErrorResponseBody(e.getMessage()));
        }
    }

    @GetMapping("/projects/{execId}")
    public ResponseEntity<?> getProjectDetails(@PathVariable int execId) {
        try {
            Projects project = monitorService.findProjectByExecutionId(execId);
            if (project == null) {
                return ResponseEntity.notFound().build();
            }
            ProjectDetailInformation projectDetailInformation = new ProjectDetailInformation(project);
            return ResponseEntity.ok().body(projectDetailInformation);

        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(new ErrorResponseBody(e.getMessage()));
        }
    }

    @GetMapping("/projects/{executionId}/download/{fileToDownload}")
    public ResponseEntity<?> downloadSourceZipFile(@PathVariable int executionId, @PathVariable String fileToDownload) throws IOException {
        // Get the zip file from the database.
        Projects project = monitorService.findProjectByExecutionId(executionId);
        if (project == null) {
            return ResponseEntity.notFound().build();
        }

        String filename = project.getName();
        byte[] zipFileBytes = new byte[0];


        switch (fileToDownload) {
            case "source":
                filename = URLEncoder.encode(project.getName(), StandardCharsets.UTF_8) + "-source.zip";
                zipFileBytes = project.getSourceProject();
                break;
            case "target":
                filename = URLEncoder.encode(project.getName(), StandardCharsets.UTF_8) + "-target.zip";
                zipFileBytes = project.getTargetProject();
                break;
            case "xsltToDwl":
                filename = URLEncoder.encode(project.getName(), StandardCharsets.UTF_8) + "-xsltToDwl.zip";
                zipFileBytes = project.getXsltToDwlExcel();
                break;
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

        headers.setContentDisposition(ContentDisposition.attachment().filename(filename).build());
        return ResponseEntity.ok().headers(headers).body(zipFileBytes);
    }

}

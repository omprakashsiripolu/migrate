package com.sme.controller;

import com.sme.dao.entity.ProjectStatus;
import com.sme.dao.entity.Projects;
import com.sme.http.response.BaseResponse;
import com.sme.http.response.ErrorResponseBody;
import com.sme.http.response.ProjectInformation;
import com.sme.http.response.SimpleResponseBody;
import com.sme.service.IAccelerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import reactor.core.publisher.Flux;

import java.util.concurrent.CompletableFuture;

import javax.xml.parsers.ParserConfigurationException;

@Controller
public class AcceleratorController {

    private final static Logger logger = LoggerFactory.getLogger(AcceleratorController.class);

    private IAccelerator accelerator;

    @Autowired
    public void setAccelerator(IAccelerator accelerator) {
        this.accelerator = accelerator;
    }

    @PostMapping("/upload")
    public ResponseEntity<BaseResponse> handleFileUpload(@RequestParam("file") MultipartFile file) {
        try {
            Projects projects = accelerator.saveProjectFile(file);
            return ResponseEntity.ok(new ProjectInformation(projects.getExecId(), projects.getName(),
                    projects.getDescription(), projects.getDatetime()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(new ErrorResponseBody(e.getMessage()));
        }
    }

    @DeleteMapping("/projects/{executionId}")
    public ResponseEntity<?> deleteProjectBasedOnExecutionId(@PathVariable int executionId) {
        try {
            Projects projects = accelerator.checkStatus(executionId);
            if (projects == null) {
                return ResponseEntity.notFound().build();
            }

            accelerator.deleteProject(projects);
            return ResponseEntity.ok(new SimpleResponseBody("Project deleted from the server"));

        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(new ErrorResponseBody(e.getMessage()));
        }
    }

    @GetMapping("/projects/{executionId}/analyze")
    public ResponseEntity<BaseResponse> analyze(@PathVariable int executionId,
                                                @RequestParam(required = false) String force) {
        try {
            Projects projects = accelerator.checkStatus(executionId);
            if (projects == null) {
                return ResponseEntity.notFound().build();
            }

            if (projects.getAnalyzeEnd() != null && force == null) {
                if (projects.getAnalyzeEnd() != null
                        && projects.getStatus().equals(ProjectStatus.ANALYZE_ERROR.toString())) {
                    return ResponseEntity.ok(new SimpleResponseBody("Project previously analyzed " +
                            "and analysis raised an error at " + projects.getAnalyzeEnd().toString()
                            + ". Error is " + projects.getError() +
                            ". Use force=true to trigger analysis again."));
                }
                return ResponseEntity.ok(new SimpleResponseBody("Project is already analyzed " +
                        "and analysis completed at " + projects.getAnalyzeEnd().toString()
                        + ". You can run analysis again using force=true query param"));
            }
            if (projects.getAnalyzeEnd() != null && force != null) {
                boolean forceFlag = Boolean.parseBoolean(force);
                if (!forceFlag) {
                    return ResponseEntity.ok(new SimpleResponseBody("Project is already analyzed " +
                            "and analysis completed at " + projects.getAnalyzeEnd().toString()
                            + ". You can run analysis again using force=true query param"));
                }
            }

            if (accelerator.checkExecutionInProgress(executionId)) {
                return ResponseEntity.ok(new SimpleResponseBody("Project is already under process for - "
                        + executionId + ". Wait few minutes till execution is complete."));
            }

            CompletableFuture
                    .runAsync(() -> accelerator.analyze(executionId))
                    .handle((unused, throwable) -> {
                        logger.error("Error in background process for analyze() " + throwable.getMessage());
                        return throwable;
                    });
            return ResponseEntity.ok(new SimpleResponseBody("Project analysis started for - " + executionId));
        } catch (Exception e) {
            logger.error("Error while analyzing " + e.getMessage());
            return ResponseEntity.internalServerError().body(new ErrorResponseBody(e.getMessage()));
        }
    }

    @GetMapping("/projects/{executionId}/migrate")
    public ResponseEntity<BaseResponse> migrate(@PathVariable int executionId,
                                                @RequestParam(required = false) String force,
                                                @RequestParam(required = false) Boolean analyze) {
        try {
            Projects projects = accelerator.checkStatus(executionId);
            if (projects == null) {
                return ResponseEntity.notFound().build();
            }

            if (projects.getMigrationEnd() != null && force == null) {
                if (projects.getMigrationEnd() != null
                        && projects.getStatus().equals(ProjectStatus.MIGRATION_ERROR.toString())) {
                    return ResponseEntity.ok(new SimpleResponseBody("Project previously migrated " +
                            "and migration raised an error at " + projects.getMigrationEnd().toString()
                            + ". Error is " + projects.getError() +
                            ". Use force=true to trigger migration again."));
                }
                return ResponseEntity.ok(new SimpleResponseBody("Project is already migrated " +
                        "and migration completed at " + projects.getMigrationEnd().toString()
                        + ". You can run migration again using force=true query param"));
            }
            if (projects.getMigrationEnd() != null && force != null) {
                boolean forceFlag = Boolean.parseBoolean(force);
                if (!forceFlag) {
                    return ResponseEntity.ok(new SimpleResponseBody("Project is already migrated " +
                            "and migration completed at " + projects.getMigrationEnd().toString()
                            + ". You can run migration again using force=true query param"));
                }
            }

            if (accelerator.checkExecutionInProgress(executionId)) {
                return ResponseEntity.ok(new SimpleResponseBody("Project is already under process for - "
                        + executionId + ". Wait few minutes till execution is complete."));
            }

            CompletableFuture
                    .runAsync(() -> {
                        // run analyze as well if request param is set to true
                        if (analyze != null && analyze) {
                            accelerator.analyze(executionId);
                        }
                        try {
							accelerator.migrate(executionId);
						} catch (ParserConfigurationException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
                    })
                    .handle((unused, throwable) -> {
                        logger.error("Error in background process for migrate() " + throwable.getMessage());
                        return throwable;
                    });
            return ResponseEntity.ok(new SimpleResponseBody("Project migration started for - " + executionId));
        } catch (Exception e) {
            logger.error("Error while migrating " + e.getMessage());
            return ResponseEntity.internalServerError().body(new ErrorResponseBody(e.getMessage()));
        }
    }

    @GetMapping(path = "/projects/{executionId}/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<ServerSentEvent<String>> stream(@PathVariable int executionId,
                                                @RequestParam(required = false) String force) {
        try {
            Projects projects = accelerator.checkStatus(executionId);
            if (projects == null) {
                return Flux.just(ServerSentEvent.builder("Project not found").build());
            }

            if (projects.getMigrationEnd() != null && force == null) {
                if (projects.getMigrationEnd() != null
                        && projects.getStatus().equals(ProjectStatus.MIGRATION_ERROR.toString())) {
                    return Flux.just(ServerSentEvent.builder("Project previously migrated " +
                            "and migration raised an error at " + projects.getMigrationEnd().toString()
                            + ". Error is " + projects.getError() +
                            ". Use force=true to trigger migration again.").build());
                }
                return Flux.just(ServerSentEvent.builder("Project is already migrated " +
                        "and migration completed at " + projects.getMigrationEnd().toString()
                        + ". You can run migration again using force=true query param").build());
            }
            if (projects.getMigrationEnd() != null && force != null) {
                boolean forceFlag = Boolean.parseBoolean(force);
                if (!forceFlag) {
                    return Flux.just(ServerSentEvent.builder("Project is already migrated " +
                            "and migration completed at " + projects.getMigrationEnd().toString()
                            + ". You can run migration again using force=true query param").build());
                }
            }

            if (accelerator.checkExecutionInProgress(executionId)) {
                return Flux.just(ServerSentEvent.builder("Project is already under process for - "
                        + executionId + ". Wait few minutes till execution is complete.").build());
            }

            return accelerator.streamMigration(executionId)
                    .map((s) -> ServerSentEvent.builder(s).build());
        } catch (Exception e) {
            logger.error("Error while migrating " + e.getMessage());
            return Flux.just(ServerSentEvent.builder("error:" + e.getMessage()).build());
        }
    }
}

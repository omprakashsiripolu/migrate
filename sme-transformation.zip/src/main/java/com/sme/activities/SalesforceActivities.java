package com.sme.activities;

import java.util.ArrayList;

import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.sme.service.Accelerator;
@Component
public class SalesforceActivities {

	public Element sfActivitiesConfig(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,
			String mulesoftActivity) {
		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:salesforce") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:salesforce", "http://www.mulesoft.org/schema/mule/salesforce");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/salesforce http://www.mulesoft.org/schema/mule/salesforce/current/mule-salesforce.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
		
		Element activity = tDoc.createElement(mulesoftActivity);

		node.removeAll(node);
		ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
		ac.getNode(acNode.getChildNodes(), 0, node, "salesforceSharedConfig");
		String configName ="";
		for (Node n : node) {
			if (n.getNodeName().contentEquals("pd:description")) {
				activity.setAttribute("doc:description", n.getTextContent());
			}
			if (n.getNodeName().contentEquals("salesforceSharedConfig")) {
				configName = n.getTextContent();
				configName = configName.substring(1,configName.lastIndexOf(".sharedsalesforce"));
				activity.setAttribute("config-ref", configName.replace(" ", "_"));
			}
		}
		activity.setAttribute("doc:name", acName);
		activity.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
		if(!mulesoftActivity.contains("salesforce:new-object-listener")){
		activity.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
		}
	
		return activity;
	}
	
	public Element sfCreateAll(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,String mulesoftActivity) {
		Element sfCreateAll = sfActivitiesConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);
		sfCreateAll.setAttribute("type", "\'\"\"\'");
		return sfCreateAll;
	}
	
	public Element sfQueryAll(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,String mulesoftActivity) {
		Element sfQueryAll = sfActivitiesConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);
		Element sfQueryStmt = tDoc.createElement("salesforce:salesforce-query");
		sfQueryAll.appendChild(sfQueryStmt);
		return sfQueryAll;
	}
	
	public Element sfQuery(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,String mulesoftActivity) {
		Element sfQuery = sfActivitiesConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);
		Element sfQueryStmt = tDoc.createElement("salesforce:salesforce-query");
		//sfQueryStmt.setAttribute("","");
		sfQuery.appendChild(sfQueryStmt);
		return sfQuery;
	}
	
	public Element sfDeleteAll(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,String mulesoftActivity) {
		Element sfDeleteAll = sfActivitiesConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);
		return sfDeleteAll;
	}
	
	public Element sfRetriveAll(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,String mulesoftActivity) {
		Element sfRetriveAll = sfActivitiesConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);
		sfRetriveAll.setAttribute("type", "\'\"\"\'");
		return sfRetriveAll;
	}
	
	public Element sfUpsert(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,String mulesoftActivity) {
		Element sfUpsert = sfActivitiesConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);
		sfUpsert.setAttribute("objectType", "\"\"");
		sfUpsert.setAttribute("externalIdFieldName", "\"\"");
		return sfUpsert;
	}
	
	public Element sfOutMsgLsnr(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,String mulesoftActivity) {
		Element sfOutMsgLsnr = sfActivitiesConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);
		Element strategy = tDoc.createElement("scheduling-strategy");
		Element frequency = tDoc.createElement("fixed-frequency");
		sfOutMsgLsnr.setAttribute("objectType", "\"\"");
		frequency.setAttribute("frequency", "100");
		frequency.setAttribute("timeUnit", "DAYS");
		strategy.appendChild(frequency);
		sfOutMsgLsnr.appendChild(strategy);

		return sfOutMsgLsnr;
	}
	
	public Element sfUpdateAll(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,String mulesoftActivity) {
		Element sfUpdateAll = sfActivitiesConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);
		sfUpdateAll.setAttribute("type", "\"\"");
		return sfUpdateAll;
	}
}

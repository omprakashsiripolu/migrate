package com.sme.activities;

import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.sme.dao.SharedConnections;
import com.sme.service.Accelerator;
import com.sme.util.ActivityOps;

@Component
public class RestActivities {

    @Autowired
    private SharedConnections shared;

    public void deleteMethod(Accelerator ac, Document tDoc, String flowName, String acName, String methodName,
                             String resourcePath, int apikitConfigCount) {

        Element deleteFlow = tDoc.createElement("flow");
        deleteFlow.setAttribute("name",
                "delete:\\" + resourcePath + ":application\\json:" + "Router" + apikitConfigCount);

        if (methodName.contentEquals("DELETE")) {

            Element flowRef = tDoc.createElement("flow-ref");
            flowRef.setAttribute("doc:name", flowName);
            flowRef.setAttribute("doc:id", ac.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
            flowRef.setAttribute("name", flowName);

            deleteFlow.appendChild(flowRef);
        }

        tDoc.getFirstChild().appendChild(deleteFlow);

    }

    public void putMethod(Accelerator ac, Document tDoc, String flowName, String acName, String methodName,
                          String resourcePath, int apikitConfigCount) {

        Element putFlow = tDoc.createElement("flow");
        putFlow.setAttribute("name", "put:\\" + resourcePath + ":application\\json:" + "Router" + apikitConfigCount);

        if (methodName.contentEquals("PUT")) {

            Element flowRef = tDoc.createElement("flow-ref");
            flowRef.setAttribute("doc:name", flowName);
            flowRef.setAttribute("doc:id", ac.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
            flowRef.setAttribute("name", flowName);

            putFlow.appendChild(flowRef);
        }

        tDoc.getFirstChild().appendChild(putFlow);

    }

    public void getMethod(Accelerator ac, Document tDoc, String flowName, String acName, String methodName,
                          String resourcePath, int apikitConfigCount) {

        Element getFlow = tDoc.createElement("flow");
        getFlow.setAttribute("name", "get:\\" + resourcePath + ":Router" + apikitConfigCount);

        if (methodName.contentEquals("GET")) {

            Element flowRef = tDoc.createElement("flow-ref");
            flowRef.setAttribute("doc:name", flowName);
            flowRef.setAttribute("doc:id", ac.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
            flowRef.setAttribute("name", flowName);

            getFlow.appendChild(flowRef);
        }

        tDoc.getFirstChild().appendChild(getFlow);

    }

    public void postMethod(Accelerator ac, Document tDoc, String flowName, String acName, String methodName,
                           String resourcePath, int apikitConfigCount) {

        Element postFlow = tDoc.createElement("flow");
        postFlow.setAttribute("name", "post:\\" + resourcePath + ":application\\json:" + "Router" + apikitConfigCount);

        if (methodName.contentEquals("POST")) {

            Element flowRef = tDoc.createElement("flow-ref");
            flowRef.setAttribute("doc:name", flowName);
            flowRef.setAttribute("doc:id", ac.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
            flowRef.setAttribute("name", flowName);

            postFlow.appendChild(flowRef);
        }

        tDoc.getFirstChild().appendChild(postFlow);

    }

    public int apikitConfigCount = 0;

    public Element addApikitRouterActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ActivityOps activityOps)
            throws ParserConfigurationException, SAXException, IOException {

        ArrayList<String> methods = new ArrayList<>();
        ArrayList<String> flows = new ArrayList<>();

        Element apikitRouter = tDoc.createElement("apikit:router");

        apikitRouter.setAttribute("doc:name", acName);
        apikitRouter.setAttribute("doc:id", ac.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
        apikitRouter.setAttribute("config-ref", "Router" + ++apikitConfigCount);

        ArrayList<Node> resourcesNode = new ArrayList<>();
        ac.getNodeLike(acNode.getChildNodes(), 0, resourcesNode, ":resources");

        for (Node rsn : resourcesNode) {

            ArrayList<Node> resourceNode = new ArrayList<>();
            ac.getNodeLike(rsn.getChildNodes(), 0, resourceNode, ":resource");

            for (Node rs : resourceNode) {

                String resourcePath = "";

                if (rs.getNodeName().endsWith(":resource")) {
                    resourcePath = rs.getAttributes().getNamedItem("path").getNodeValue();
                    if (resourcePath.contains("/")) {
                        resourcePath = resourcePath.substring(1);
                    }
                }

                ArrayList<Node> methodsNode = new ArrayList<>();
                ac.getNodeLike(rs.getChildNodes(), 0, methodsNode, ":method");
                ac.getNode(rs.getChildNodes(), 0, methodsNode, "Binding");

                for (Node m : methodsNode) {

                    if (m.getNodeName().endsWith(":method")) {
                        String method = m.getAttributes().getNamedItem("name").getNodeValue();
                        methods.add(method);
                    }
                    if (m.getNodeName().contentEquals("Binding")) {
                        String flow = m.getAttributes().getNamedItem("process").getNodeValue();
                        flow = flow.substring(flow.lastIndexOf('/') + 1, flow.lastIndexOf('.'));
                        flows.add(flow);
                    }
                }

                for (int i = 0; i < methods.size(); i++) {

                    String methodName = methods.get(i);
                    String flowName = flows.get(i);

                    if (methodName.contentEquals("DELETE")) {
                        deleteMethod(ac, tDoc, flowName, acName, methodName, resourcePath, apikitConfigCount);
                    }
                    if (methodName.contentEquals("PUT")) {
                        putMethod(ac, tDoc, flowName, acName, methodName, resourcePath, apikitConfigCount);
                    }
                    if (methodName.contentEquals("GET")) {
                        getMethod(ac, tDoc, flowName, acName, methodName, resourcePath, apikitConfigCount);
                    }
                    if (methodName.contentEquals("POST")) {
                        postMethod(ac, tDoc, flowName, acName, methodName, resourcePath, apikitConfigCount);
                    }
                }

            }
        }

        shared.apikitConfigTag(ac, tDoc, acNode, this,activityOps);

        return apikitRouter;
    }

    public int restHttpRequestCount = 0;

    public Element addRestHttpRequestActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ActivityOps activityOps)
            throws ParserConfigurationException, SAXException, IOException {

        Element httpRequest = tDoc.createElement("http:request");
        String enableProtocolUI = "";

        httpRequest.setAttribute("doc:name", acName);
        httpRequest.setAttribute("doc:id", ac.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
        httpRequest.setAttribute("config-ref", "Rest_HTTP_Request_configuration" + ++restHttpRequestCount);
        httpRequest.setAttribute("target", acName.toLowerCase().replace(" ", "_"));

        ArrayList<Node> node = new ArrayList<>();
        ac.getNode(acNode.getChildNodes(), 0, node, "enableProtocolUI");
        ac.getNode(acNode.getChildNodes(), 0, node, "restMethodUI");
        ac.getNode(acNode.getChildNodes(), 0, node, "restURI");
        ac.getNode(acNode.getChildNodes(), 0, node, "WADLPaths");
        for (Node n : node) {

            if (n.getNodeName().contentEquals("restMethodUI")) {
                String value = n.getTextContent();
                httpRequest.setAttribute("method", value.substring(0, value.length()));
            }

            if (n.getNodeName().contentEquals("restURI") && enableProtocolUI.contentEquals("None")) {
                httpRequest.setAttribute("url", n.getTextContent().substring(n.getTextContent().lastIndexOf("//") + 2));
            }
            if (n.getNodeName().contentEquals("WADLPaths") && enableProtocolUI.contentEquals("WADL")) {
                httpRequest.setAttribute("path", "/" + n.getTextContent());
            }
            if (n.getNodeName().contentEquals("enableProtocolUI")) {
                if (n.getTextContent().contentEquals("None")) {
                    enableProtocolUI = "None";
                }
                if (n.getTextContent().contentEquals("WADL")) {
                    enableProtocolUI = "WADL";
                }
                if (n.getTextContent().contentEquals("Swagger")) {
                    enableProtocolUI = "Swagger";
                }
            }
        }

        shared.addRestHttpRequestConfigTag(ac, tDoc, acNode, this,activityOps);

        return httpRequest;

    }

}

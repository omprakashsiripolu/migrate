package com.sme.activities;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.sme.dao.JDBCConnection;
import com.sme.dao.SharedConnections;
import com.sme.service.Accelerator;
import com.sme.util.ActivityOps;

@Component
public class GeneralActivities {
    private static final Logger logger = LoggerFactory.getLogger(GeneralActivities.class);
    //	static JDBCConnection jdbcConnection = new JDBCConnection();
    @Autowired
    private SharedConnections sharedConnections;
//	static JDBCConnection jdbc = new JDBCConnection();

    @Autowired
    private JDBCConnection jdbc;
    
    public Element addSchedulerActivity(Accelerator ac, Document tDoc, Node acNode, String acName,
                                        ArrayList<Node> node) {

        String frequencyRunOnce = "true";
        String frequencyRange = "";
        Element scheduler = tDoc.createElement("scheduler");
        Element strategy = tDoc.createElement("scheduling-strategy");
        Element frequency = tDoc.createElement("fixed-frequency");
        scheduler.setAttribute("doc:name", acName);
        scheduler.setAttribute("doc:id", ac.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "TimeInterval");
        ac.getNode(acNode.getChildNodes(), 0, node, "FrequencyIndex");
        ac.getNode(acNode.getChildNodes(), 0, node, "Frequency");
        for (Node n : node) {
            if (n.getNodeName().contentEquals("TimeInterval")) {
                frequencyRange = n.getTextContent();
            }
            if (n.getNodeName().contentEquals("Frequency")) {
                if (n.getTextContent().contentEquals("false")) {
                    frequencyRunOnce = n.getTextContent();
                }
            }
            if (n.getNodeName().contentEquals("FrequencyIndex") && frequencyRunOnce.contentEquals("false")) {
                frequency.setAttribute("frequency", frequencyRange);
                frequency.setAttribute("timeUnit", n.getTextContent().toUpperCase() + "S");
            }
            if (n.getNodeName().contentEquals("FrequencyIndex") && frequencyRunOnce.contentEquals("true")) {
                frequency.setAttribute("frequency", "100");
                frequency.setAttribute("timeUnit", "DAYS");
            }

        }
        strategy.appendChild(frequency);
        scheduler.appendChild(strategy);

        return scheduler;
    }

    public Element addLoggerActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,String activityDWL) {

        Element logger = tDoc.createElement("logger");
        logger.setAttribute("level", "INFO");
        logger.setAttribute("doc:name", acName);
        logger.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        logger.setAttribute("message",  "#["+activityDWL+"]");
        
       
//		String map = node.get(0).getAttributes().getNamedItem("select").getNodeValue();
//		map = map.substring(map.indexOf("$")+1,map.indexOf("/"));
//		map = "\""+map+"\"";
//		map = "#[vars." + map + "]";
//		logger.setAttribute("message", map);

        return logger;
    }

    public Node addacActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node) {

        Element acAct = tDoc.createElement("muleac");
        acAct.setAttribute("doc:name", "Read");
        acAct.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        node.removeAll(node);

        return acAct;
    }

    public Element setVariableActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,String activityDWL)
            throws SQLException, SAXException, IOException, ParserConfigurationException {

        String resourceName = "";
        Element muleSetVariable = tDoc.createElement("os:store");
        Element valueOfSetVar = tDoc.createElement("os:value");

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "variableConfig");
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:inputBindings");
        String value = null;
        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                muleSetVariable.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("variableConfig")) {
                resourceName = n.getTextContent().substring(n.getTextContent().lastIndexOf("/") + 1).replace(" ", "_");
                muleSetVariable.setAttribute("objectStore", resourceName.substring(0, resourceName.lastIndexOf(".")));
            }
            if (n.getNodeName().contentEquals("pd:inputBindings")) {
                // value =
                // n.getFirstChild().getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
            }

        }
        // sharedConnections.addObjectStoreConfigTag(ac,tDoc,resourceName);

        // retrieving Variable key and value from DB
        String sharedXslt = null;
        List<com.sme.dao.entity.SharedConnections> sharedConnectionsList = jdbc.getSharedConfig(resourceName);
        if (!sharedConnectionsList.isEmpty()) {
            sharedXslt = new String(sharedConnectionsList.get(sharedConnectionsList.size() - 1).getSharedConfig(),
                    StandardCharsets.UTF_8);
        }
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Node sharedNode = docBuilder.parse(new InputSource(new StringReader(sharedXslt))).getDocumentElement();

        node.removeAll(node);
        ac.getNode(sharedNode.getChildNodes(), 0, node, "xsdString");
        ac.getNode(sharedNode.getChildNodes(), 0, node, "initialValueRef");
        // String keyValue = node.get(1).getTextContent();

        for (Node n : node) {
            if (n.getNodeName().contentEquals("xsdString")) {
                // muleSetVariable.setAttribute("key",n.getFirstChild().getAttributes().getNamedItem("name").getNodeValue());
                muleSetVariable.setAttribute("key", " ");
                valueOfSetVar.setTextContent( "#["+activityDWL+"]");
                // if(n.getFirstChild().getAttributes().getNamedItem("type").getNodeValue().contentEquals("xsd:string"))
                // {

                // }
            }
        }
        // valueOfSetVar.setTextContent("");

        muleSetVariable.setAttribute("doc:name", acName);
        muleSetVariable.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        muleSetVariable.appendChild(valueOfSetVar);
        return muleSetVariable;

    }

    public Element getVariableActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node)
            throws SQLException, SAXException, IOException, ParserConfigurationException {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:os") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:os", "http://www.mulesoft.org/schema/mule/os");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/os  http://www.mulesoft.org/schema/mule/os/current/mule-os.xsd";
            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }
        String resourceName = "";

        Element muleGetVariable = tDoc.createElement("os:retrieve");
        Element valueOfSetVar = tDoc.createElement("os:default-value");

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "variableConfig");
        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                muleGetVariable.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("variableConfig")) {
                resourceName = n.getTextContent().substring(n.getTextContent().lastIndexOf("/") + 1).replace(" ", "_");
                muleGetVariable.setAttribute("objectStore", resourceName.substring(0, resourceName.lastIndexOf(".")));

            }
        }

        // sharedConnections.addObjectStoreConfigTag(ac,tDoc,resourceName);

        // retrieving Variable key and value from DB
        String sharedXslt = null;
        List<com.sme.dao.entity.SharedConnections> sharedConnectionsList = jdbc.getSharedConfig(resourceName);
        if (!sharedConnectionsList.isEmpty()) {
            sharedXslt = new String(sharedConnectionsList.get(sharedConnectionsList.size() - 1).getSharedConfig(),
                    StandardCharsets.UTF_8);
        }
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

        Node sharedNode = docBuilder.parse(new InputSource(new StringReader(sharedXslt))).getDocumentElement();

        node.removeAll(node);
        ac.getNode(sharedNode.getChildNodes(), 0, node, "xsdString");
        for (Node n : node) {
            if (n.getNodeName().contentEquals("xsdString")) {
                // muleSetVariable.setAttribute("key",n.getFirstChild().getAttributes().getNamedItem("name").getNodeValue());
                muleGetVariable.setAttribute("key", " ");
            }
        }
        muleGetVariable.setAttribute("doc:name", acName);
        muleGetVariable.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        muleGetVariable.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
        muleGetVariable.appendChild(valueOfSetVar);
        return muleGetVariable;
    }

    public Element soapReqReplyActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,
                                        String mulesoftActivity, ActivityOps activityOps , String activityDWL) throws SQLException, ParserConfigurationException, SAXException, IOException {
        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:wsc") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:wsc", "http://www.mulesoft.org/schema/mule/wsc");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/wsc http://www.mulesoft.org/schema/mule/wsc/current/mule-wsc.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }
        Element soapReqReply = tDoc.createElement(mulesoftActivity);
        Element message = tDoc.createElement("wsc:body");
        Element body = tDoc.createElement("wsc:message");
        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "operation");

        ac.getNode(acNode.getChildNodes(), 0, node, "soapAction");
        ac.getNode(acNode.getChildNodes(), 0, node, "service");
        soapReqReply.setAttribute("doc:name", acName);
        soapReqReply.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        soapReqReply.setAttribute("target", acName.toLowerCase().replace(" ", "_"));

        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                soapReqReply.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("operation")) {
                soapReqReply.setAttribute("operation", n.getTextContent());
            }
        }
        String wsdlName1 = sharedConnections.addWebServiceConfigTag(ac, acName, tDoc, acNode, node,activityOps);
        soapReqReply.setAttribute("config-ref", wsdlName1);
        body.setTextContent( "#["+activityDWL+"]");
        message.appendChild(body);
        soapReqReply.appendChild(message);
        return soapReqReply;

    }

    public Element serviceAgentActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,
                                        String mulesoftActivity, String wsdlName, ActivityOps activityOps)
            throws SQLException, ParserConfigurationException, SAXException, IOException {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:apikit-soap") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:apikit-soap", "http://www.mulesoft.org/schema/mule/apikit-soap");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/apikit-soap http://www.mulesoft.org/schema/mule/apikit-soap/current/mule-apikit-soap.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }
        Element serviceAgentAct = tDoc.createElement(mulesoftActivity);

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "description");
        serviceAgentAct.setAttribute("doc:name", acName);
        serviceAgentAct.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        serviceAgentAct.setAttribute("target", acName.toLowerCase().replace(" ", "_"));

        for (Node n : node) {
            if (n.getNodeName().contentEquals("description")) {
                serviceAgentAct.setAttribute("doc:description", n.getTextContent());
            }
        }

        String wsdlName1 = sharedConnections.addAPIKITforSoapConfigTag(ac, tDoc, acNode, node,activityOps);
        serviceAgentAct.setAttribute("config-ref", wsdlName1);
        return serviceAgentAct;

    }

    public Element flowRefActivity(Accelerator accelerator, Document tDoc, Node acNode, String acName,
                                   ArrayList<Node> node, String mulesoftActivity ) {
        Element flowRef = tDoc.createElement("flow-ref");
        flowRef.setAttribute("doc:name", acName);
        node.removeAll(node);
        accelerator.getNode(acNode.getChildNodes(), 0, node, "processName");
        String refName = node.get(0).getTextContent();
        refName = refName.substring(1);
        flowRef.setAttribute("name", refName.substring(refName.indexOf("/") + 1, refName.lastIndexOf("."))
                .replaceAll("/", "-").replaceAll(" ", "_"));
        flowRef.setAttribute("doc:id", accelerator.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        return flowRef;
    }

    public Element assignActivity(Accelerator accelerator, Document tDoc, Node acNode, String acName,
                                  ArrayList<Node> node, String mulesoftActivity , String activityDWL) {

        Element assignAct = tDoc.createElement(mulesoftActivity);
        node.removeAll(node);

        accelerator.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        accelerator.getNode(acNode.getChildNodes(), 0, node, "variableName");
        accelerator.getNode(acNode.getChildNodes(), 0, node, "pd:inputBindings");
        assignAct.setAttribute("doc:name", acName);
        assignAct.setAttribute("doc:id", accelerator.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                assignAct.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("variableName")) {
                assignAct.setAttribute("variableName", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("pd:inputBindings")) {

                if (n.getFirstChild().getFirstChild().getNodeName().contentEquals("xsl:value-of")) {
                    // assignAct.setAttribute("value",
                    // n.getFirstChild().getFirstChild().getAttributes().getNamedItem("select").getNodeValue());
                    assignAct.setAttribute("value", "#["+activityDWL+"]");
                } else {
                    assignAct.setAttribute("value",  "#["+activityDWL+"]");
                }
            }
        }
        return assignAct;

    }

// Closing 
}

package com.sme.activities;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.sme.dao.SharedConnections;
import com.sme.service.Accelerator;
import com.sme.util.ActivityOps;

@Component
public class MailActivities {

    static final int emailPop3ConfigCount = 0;
    @Autowired
    private SharedConnections shared;

    public Element addOnNewEmail(Accelerator ac, Document templateDoc, Node acNode, String activityName, ActivityOps activityOps)
            throws SQLException, ParserConfigurationException, SAXException, IOException {

        String host = null, userName = null;
        boolean useSsl = false;

        Element emailListener = templateDoc.createElement("email:listener-pop3");
        emailListener.setAttribute("doc:name", activityName);
        emailListener.setAttribute("doc:id", ac.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
        emailListener.setAttribute("config-ref", "Email_POP3_" + emailPop3ConfigCount);

        ArrayList<Node> node = new ArrayList<>();
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "pollinginterval");
        ac.getNode(acNode.getChildNodes(), 0, node, "deletemail");
        ac.getNode(acNode.getChildNodes(), 0, node, "host");
        ac.getNode(acNode.getChildNodes(), 0, node, "username");
//		ac.getNode(acNode.getChildNodes(), 0, node, "password");
        ac.getNode(acNode.getChildNodes(), 0, node, "useSsl");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                emailListener.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("pollinginterval")) {

                Element schedulingStrategy = templateDoc.createElement("scheduling-strategy");
                Element fixedFrequency = templateDoc.createElement("fixed-frequency");

                fixedFrequency.setAttribute("frequency", n.getTextContent());
                fixedFrequency.setAttribute("timeUnit", "SECONDS");

                emailListener.appendChild(schedulingStrategy);
                schedulingStrategy.appendChild(fixedFrequency);

            }
            if (n.getNodeName().contentEquals("deletemail")) {
                emailListener.setAttribute("deleteAfterRetrieve", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("host")) {
                host = n.getTextContent();
            }
            if (n.getNodeName().contentEquals("username")) {
                userName = n.getTextContent();
            }
            if (n.getNodeName().contentEquals("useSsl") && n.getTextContent().contentEquals("true")) {
                useSsl = true;
            }
        }

        shared.addEmailPop3ConfigTag(ac, templateDoc, emailPop3ConfigCount, host, userName, useSsl,activityOps);

        return emailListener;
    }

    static final int emailSmtpConfigCount = 0;

    public Element addEmailSend(Accelerator ac, Document templateDoc, Node acNode, String activityName, ActivityOps activityOps)
            throws SQLException, ParserConfigurationException, SAXException, IOException {

        String emailBodyContentType = null;
        String host = null, userName = null;
        boolean useSsl = false;

        Element emailSend = templateDoc.createElement("email:send");
        emailSend.setAttribute("doc:name", activityName);
        emailSend.setAttribute("doc:id", ac.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
        emailSend.setAttribute("config-ref", "Email_SMTP" + emailSmtpConfigCount);

        ArrayList<Node> node = new ArrayList<>();
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "from");
        ac.getNode(acNode.getChildNodes(), 0, node, "to");
        ac.getNode(acNode.getChildNodes(), 0, node, "subject");
        ac.getNode(acNode.getChildNodes(), 0, node, "cc");
        ac.getNode(acNode.getChildNodes(), 0, node, "bcc");
        ac.getNode(acNode.getChildNodes(), 0, node, "replyTo");
        ac.getNode(acNode.getChildNodes(), 0, node, "Content-Type");
        ac.getNode(acNode.getChildNodes(), 0, node, "bodyText");
        ac.getNode(acNode.getChildNodes(), 0, node, "host");
        ac.getNode(acNode.getChildNodes(), 0, node, "useSsl");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                emailSend.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("from")) {
                String value = n.getFirstChild().getAttributes().getNamedItem("select").getTextContent();
                emailSend.setAttribute("fromAddress", value);
            }
            if (n.getNodeName().contentEquals("subject")) {
                String value = n.getFirstChild().getAttributes().getNamedItem("select").getTextContent();
                emailSend.setAttribute("subject", value);
            }
            if (n.getNodeName().contentEquals("to")) {

                Element emailToAddresses = templateDoc.createElement("email:to-addresses");
                Element emailToAddress = templateDoc.createElement("email:to-address");

                String value = n.getFirstChild().getAttributes().getNamedItem("select").getTextContent();

                emailToAddress.setAttribute("value", value);

                emailSend.appendChild(emailToAddresses);
                emailToAddresses.appendChild(emailToAddress);

            }
            if (n.getNodeName().contentEquals("cc")) {

                Element emailCcAddresses = templateDoc.createElement("email:cc-addresses");
                Element emailCcAddress = templateDoc.createElement("email:cc-address");

                String value = n.getFirstChild().getAttributes().getNamedItem("select").getTextContent();

                emailCcAddress.setAttribute("value", value);

                emailSend.appendChild(emailCcAddresses);
                emailCcAddresses.appendChild(emailCcAddress);

            }
            if (n.getNodeName().contentEquals("bcc")) {

                Element emailBccAddresses = templateDoc.createElement("email:bcc-addresses");
                Element emailBccAddress = templateDoc.createElement("email:bcc-address");

                String value = n.getFirstChild().getAttributes().getNamedItem("select").getTextContent();

                emailBccAddress.setAttribute("value", value);

                emailSend.appendChild(emailBccAddresses);
                emailBccAddresses.appendChild(emailBccAddress);

            }
            if (n.getNodeName().contentEquals("replyTo")) {

                Element emailTeplyToAddresses = templateDoc.createElement("email:reply-to-addresses");
                Element emailTeplyToAddress = templateDoc.createElement("email:reply-to-address");

                String value = n.getFirstChild().getAttributes().getNamedItem("select").getTextContent();

                emailTeplyToAddress.setAttribute("value", value);

                emailSend.appendChild(emailTeplyToAddresses);
                emailTeplyToAddresses.appendChild(emailTeplyToAddress);

            }
            if (n.getNodeName().contentEquals("Content-Type")) {
                emailBodyContentType = n.getFirstChild().getAttributes().getNamedItem("select").getTextContent();
            }
            if (n.getNodeName().contentEquals("bodyText")) {

                Element emailBody = templateDoc.createElement("email:body");
                Element emailContent = templateDoc.createElement("email:content");

                emailBody.setAttribute("contentType", emailBodyContentType);

                String value = n.getFirstChild().getAttributes().getNamedItem("select").getTextContent();

                emailContent.setTextContent(value);

                emailSend.appendChild(emailBody);
                emailBody.appendChild(emailContent);

            }
            if (n.getNodeName().contentEquals("host")) {
                host = n.getTextContent();
            }
            if (n.getNodeName().contentEquals("useSsl") && n.getTextContent().contentEquals("true")) {
                useSsl = true;
            }
        }
        shared.addEmailSMTPConfigTag(ac, templateDoc, emailSmtpConfigCount, host, userName, useSsl,activityOps);

        return emailSend;
    }

}

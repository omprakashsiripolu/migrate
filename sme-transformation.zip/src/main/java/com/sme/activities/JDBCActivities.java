package com.sme.activities;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.sme.service.Accelerator;
import com.sme.util.ActivityOps;

@Component
public class JDBCActivities {

    public Element setJDBCActivtyConfig(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,
                                        String mulesoftActivity) {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:db") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:db", "http://www.mulesoft.org/schema/mule/db");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }
        Element activity = tDoc.createElement(mulesoftActivity);

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "timeout");
        ac.getNode(acNode.getChildNodes(), 0, node, "maxRows");
        ac.getNode(acNode.getChildNodes(), 0, node, "statement");
        ac.getNode(acNode.getChildNodes(), 0, node, "jdbcSharedConfig");
        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                activity.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("timeout")) {
                activity.setAttribute("queryTimeout", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("maxRows")) {
                activity.setAttribute("maxRows", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("jdbcSharedConfig")) {
                String resourceName = n.getTextContent();
                resourceName = resourceName.substring(resourceName.lastIndexOf("/") + 1, resourceName.indexOf("."))
                        .replaceAll(" ", "_");
                activity.setAttribute("config-ref", resourceName);
            }
        }
        activity.setAttribute("doc:name", acName);
        activity.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        activity.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
        Element dbInputParameters;
        //

        if (mulesoftActivity.contentEquals("db:stored-procedure") || mulesoftActivity.contentEquals("db:update")
                || mulesoftActivity.contentEquals("db:insert") || mulesoftActivity.contentEquals("db:delete")
                || mulesoftActivity.contentEquals("db:select") || mulesoftActivity.contentEquals("db:bulk-insert")
                || mulesoftActivity.contentEquals("db:bulk-update")
                || mulesoftActivity.contentEquals("db:bulk-delete")) {

            Element dbSql = tDoc.createElement("db:sql");
            if (mulesoftActivity.contentEquals("db:bulk-insert") || mulesoftActivity.contentEquals("db:bulk-update")
                    || mulesoftActivity.contentEquals("db:bulk-delete")) {
                dbInputParameters = tDoc.createElement("db:bulk-input-parameters");
            } else {
                dbInputParameters = tDoc.createElement("db:input-parameters");
            }
            node.removeAll(node);
            ac.getNode(acNode.getChildNodes(), 0, node, "Prepared_Param_DataType");
            ac.getNode(acNode.getChildNodes(), 0, node, "statement");
            ac.getNode(acNode.getChildNodes(), 0, node, "jdbcQueryActivityInput");
            ac.getNode(acNode.getChildNodes(), 0, node, "jdbcUpdateActivityInput");
            ac.getNode(acNode.getChildNodes(), 0, node, "xsl:value-of");
            ac.getNode(acNode.getChildNodes(), 0, node, "parameterTypes");
            ac.getNode(acNode.getChildNodes(), 0, node, "ProcedureName");
            // ----------------check from here
            ArrayList<String> parameterNames = new ArrayList<>();
            ArrayList<String> parameterNms = new ArrayList<>();
            for (Node n : node) {
                if (n.getNodeName().contentEquals("Prepared_Param_DataType")) {
                    for (int i = 0; i < n.getChildNodes().getLength(); i++) {
                        parameterNames.add(n.getChildNodes().item(i).getFirstChild().getTextContent());
                    }
                }
                if (n.getNodeName().contentEquals("statement")) {
                    String queryStatement = n.getTextContent();
                    if (queryStatement.contains("?")) {
                        for (String parameterName : parameterNames) {
                            queryStatement = queryStatement.replaceFirst("\\?", ":" + parameterName);
                        }
                    }
                    dbSql.setTextContent(queryStatement);
                }

                if (n.getNodeName().contentEquals("parameterTypes")) {
                    for (int i = 0; i < n.getChildNodes().getLength(); i++) {
                        parameterNms.add(n.getChildNodes().item(i).getFirstChild().getTextContent());
                    }
                }
                if (n.getNodeName().contentEquals("ProcedureName")) {
                    String queryCallProcedure = n.getTextContent();
                    queryCallProcedure = "{call " + queryCallProcedure + "(";
                    for (String parameterName : parameterNms) {
                        queryCallProcedure += ":" + parameterName + ",";
                    }
                    queryCallProcedure = queryCallProcedure.substring(0, queryCallProcedure.length() - 1) + ")}";
                    dbSql.setTextContent(queryCallProcedure);
                }

                // trial

                if (n.getNodeName().contentEquals("jdbcQueryActivityInput")
                        || n.getNodeName().contentEquals("jdbcUpdateActivityInput")) {

                    // for-each starts
                    NodeList nodeListInp;
                    Node firstChild = n.getFirstChild();
                    if (firstChild != null) {
                        if (firstChild.getNodeName().contentEquals("xsl:for-each")) {
                            ArrayList<Node> inputNames = new ArrayList<>();
                            Node secondChild = firstChild.getFirstChild();
                            if (secondChild != null && secondChild.getNodeName().contentEquals("Record")) {
                                nodeListInp = secondChild.getChildNodes();
                                for (int i = 0; i < nodeListInp.getLength(); i++) {
                                    Node nodeInp = nodeListInp.item(i);
                                    inputNames.add(nodeInp);
                                }

                            }
                            ArrayList<String> inputParameters = new ArrayList<>();
                            String appendInputParam = "";
                            ArrayList<Node> node1 = new ArrayList<>();

                            String targetVarEnd = "";

                            for (int i = 0; i < inputNames.size(); i++) {
                                node1.removeAll(node1);
                                ac.getNode(inputNames.get(i).getChildNodes(), 0, node1, "xsl:value-of");
                                if (!node1.isEmpty() && node1.get(0).getNodeName().equals("xsl:value-of")) {
                                    for (Node n1 : node1) {
                                        String tempVariable = n1.getAttributes().getNamedItem("select").getNodeValue();
                                        String targetVarName = n1.getAttributes().getNamedItem("select").getNodeValue();
                                        // if select contains $ and /
                                        if (targetVarName.contains("_globalVariables") && targetVarName.contains("/")) {
                                            targetVarName = targetVarName.substring(
                                                    targetVarName.indexOf("GlobalVariables/") + 16,
                                                    targetVarName.length());
                                            targetVarName = "p(" + "'" + targetVarName + "'" + ")";
                                            inputParameters.add(":" + targetVarName);
                                        } else if (targetVarName.contains("$") && targetVarName.contains("/")) {
                                            targetVarName = targetVarName.substring(targetVarName.indexOf("$") + 1,
                                                    targetVarName.indexOf("/"));
                                            targetVarEnd = tempVariable.substring(tempVariable.lastIndexOf("/") + 1,
                                                    tempVariable.length());
                                            inputParameters.add("\": vars." + targetVarName + "." + targetVarEnd);
                                        } else {
                                            targetVarEnd = tempVariable.substring(tempVariable.lastIndexOf("/") + 1,
                                                    tempVariable.length());
                                            inputParameters.add("\": vars." + targetVarEnd);
                                        }
                                        // appending both key and value
                                        if (inputNames.size() > 0) {
                                            appendInputParam += "\"" + inputNames.get(i).getNodeName() + "\""
                                                    + inputParameters.get(i) + ",";

                                        } else {
                                            String inName = n.getFirstChild().getNodeName();
                                            appendInputParam += inputParameters.get(i) + "\"";
                                            appendInputParam = appendInputParam.replace("null", inName);
                                        }
                                    }
                                }
                            }

                            if (appendInputParam != null) {
                                dbInputParameters.setTextContent(
                                        "{" + appendInputParam.substring(0, appendInputParam.length() - 1) + "}");
                            }

                        }

                        // for-each ends
                        else {

                            // normal mapping
                            ArrayList<String> inputParameters = new ArrayList<>();
                            String appendInputParam = "";
                            ArrayList<Node> params = new ArrayList<>();
                            NodeList nodeList = n.getChildNodes();
                            ArrayList<Node> node1 = new ArrayList<>();
                            for (int i = 0; i < nodeList.getLength(); i++) {
                                Node node2 = nodeList.item(i);
                                params.add(node2);
                            }
                            String targetVarEnd = "";

                            for (int i = 0; i < params.size(); i++) {
                                node1.removeAll(node1);
                                ac.getNode(params.get(i).getChildNodes(), 0, node1, "xsl:value-of");
                                if (!node1.isEmpty() && node1.get(0).getNodeName().equals("xsl:value-of")) {
                                    for (Node n1 : node1) {

                                        String tempVariable = n1.getAttributes().getNamedItem("select").getNodeValue();

                                        String targetVarName = n1.getAttributes().getNamedItem("select").getNodeValue();
                                        if (targetVarName.contains("_globalVariables") && targetVarName.contains("/")) {
                                            targetVarName = targetVarName.substring(
                                                    targetVarName.indexOf("GlobalVariables/") + 16,
                                                    targetVarName.length());
                                            targetVarName = "p(" + "'" + targetVarName + "'" + ")";
                                            inputParameters.add(":" + targetVarName);
                                        } else if (targetVarName.contains("$") && targetVarName.contains("/")) {
                                            targetVarName = targetVarName.substring(targetVarName.indexOf("$") + 1,
                                                    targetVarName.lastIndexOf("/"));
                                            targetVarEnd = tempVariable.substring(tempVariable.lastIndexOf("/") + 1,
                                                    tempVariable.length());
                                            inputParameters.add("\": vars." + targetVarName + "." + targetVarEnd);
                                        } else {
                                            targetVarEnd = tempVariable.substring(tempVariable.lastIndexOf("/") + 1,
                                                    tempVariable.length());
                                            inputParameters.add("\": vars." + targetVarEnd);

                                        }
                                        // appending both key and value
                                        if (parameterNames.size() > 0) {
                                            appendInputParam += "\"" + parameterNames.get(i) + inputParameters.get(i)
                                                    + ",";
                                        } else {
                                            String inName = n.getFirstChild().getNodeName();
                                            inName = "\"" + inName + "\"";
                                            appendInputParam += inputParameters.get(i);
                                            appendInputParam = appendInputParam.replace("null", inName);

                                        }
                                    }
                                }

                            }

                            if (appendInputParam != null) {
                                dbInputParameters.setTextContent("#[" + "{"
                                        + appendInputParam.substring(0, appendInputParam.length() - 1) + "}" + "]");
                            }
                        }

                        // normal mapping ends
                    }
                }

                //

//					ArrayList<Node> node1 =  new ArrayList<>();
//					for(int i = 0; i<params.getLength();i++) {	
//						ac.getNode(acNode.getChildNodes(), 0, node1, "xsl:value-of");
//						if(node1.get(0).getNodeName().contentEquals("xsl:value-of")){
//							for(Node n1: node1) {
//								String tempVariable = n1.getAttributes().getNamedItem("select").getNodeValue();	
//								String targetVarName = n1.getAttributes().getNamedItem("select").getNodeValue();
//								if (targetVarName.contains("$")&&targetVarName.contains("/")) {
//									targetVarName = targetVarName.substring(targetVarName.indexOf("$")+1,targetVarName.indexOf("/"));
//								}
//								String targetVarEnd = tempVariable.substring(tempVariable.lastIndexOf("/")+1,tempVariable.length());
//								inputParameters.add("\": vars."+targetVarName+"."+targetVarEnd);
//								}
//							}
//						appendInputParam += parameterNames.get(i)+inputParameters.get(i)+",";
//					}
//					dbInputParameters.setTextContent("{\""+appendInputParam.substring(0,appendInputParam.length()-1)+"}");
//				}		
//				
                // trial

                if (mulesoftActivity.contentEquals("db:bulk-insert") || mulesoftActivity.contentEquals("db:bulk-update")
                        || mulesoftActivity.contentEquals("db:bulk-delete")) {
                    activity.appendChild(dbInputParameters);
                    activity.appendChild(dbSql);

                } else {
                    activity.appendChild(dbSql);
                    activity.appendChild(dbInputParameters);
                }

            }
        }
        return activity;

    }

    public Element jdbcUpdateActivity(Accelerator ac, Document tDoc, Node acNode, String acName, int seqId, ArrayList < Node > node,
    		   String mulesoftActivity, ActivityOps activityOps,double constant_manualTime,double constant_AfterMgrtnTime) {
    		   node.removeAll(node);
    		   ac.getNode(acNode.getChildNodes(), 0, node, "statement");
    		   ac.getNode(acNode.getChildNodes(), 0, node, "batchUpdate");
    		   // check insert or delete
    		   int manEff = 1;
    		   
    		   if (node.size() == 2) {
    		     if ((node.get(0).getTextContent().toUpperCase().contains("INSERT") &&
    		         node.get(1).getTextContent().contentEquals("false"))) {
    		       manEff = activityOps.calManualEfrt(ac, acNode);
    		       activityOps.addToDo(ac, "db:insert", acName, seqId,constant_manualTime+manEff, constant_AfterMgrtnTime, "activity");
    		       return jdbcInsertActivity(ac, tDoc, acNode, acName, node, "db:insert");
    		     } else if ((node.get(0).getTextContent().toUpperCase().contains("DELETE") &&
    		         node.get(1).getTextContent().contentEquals("false"))) {
    		       manEff = activityOps.calManualEfrt(ac, acNode);
    		       activityOps.addToDo(ac, "db:delete", acName, seqId, constant_manualTime+manEff, constant_AfterMgrtnTime, "activity");
    		       return jdbcDeleteActivity(ac, tDoc, acNode, acName, node, "db:delete");
    		     } else if ((node.get(0).getTextContent().toUpperCase().contains("UPDATE") &&
    		         node.get(1).getTextContent().contentEquals("false"))) {
    		       manEff = activityOps.calManualEfrt(ac, acNode);
    		       activityOps.addToDo(ac, "db:update", acName, seqId, constant_manualTime+manEff, constant_AfterMgrtnTime, "activity");
    		       return jdbcMuleUpdateActivity(ac, tDoc, acNode, acName, node, "db:update");
    		     } else if (node.get(0).getTextContent().toUpperCase().contains("INSERT") &&
    		       node.get(1).getTextContent().contentEquals("true")) {
    		       manEff = activityOps.calManualEfrt(ac, acNode);
    		       activityOps.addToDo(ac, "db:bulk-insert", acName, seqId, constant_manualTime+manEff, constant_AfterMgrtnTime, "activity");
    		       return jdbcBulkInsertActivity(ac, tDoc, acNode, acName, node, "db:bulk-insert");
    		     } else if (node.get(0).getTextContent().toUpperCase().contains("UPDATE") &&
    		       node.get(1).getTextContent().contentEquals("true")) {
    		       manEff = activityOps.calManualEfrt(ac, acNode);
    		       activityOps.addToDo(ac, "db:bulk-update", acName, seqId, constant_manualTime+manEff, constant_AfterMgrtnTime, "activity");
    		       return jdbcBulkUpdateActivity(ac, tDoc, acNode, acName, node, "db:bulk-update");
    		     } else if (node.get(0).getTextContent().toUpperCase().contains("DELETE") &&
    		       node.get(1).getTextContent().contentEquals("true")) {
    		       manEff = activityOps.calManualEfrt(ac, acNode);
    		       activityOps.addToDo(ac, "db:bulk-delete", acName, seqId, constant_manualTime+manEff, constant_AfterMgrtnTime, "activity");
    		       return jdbcBulkDeleteActivity(ac, tDoc, acNode, acName, node, "db:bulk-delete");
    		     }
    		   }
    		   if (node.size() == 1) {
    		     if ((node.get(0).getTextContent().toUpperCase().contains("INSERT"))) {
    		       manEff = activityOps.calManualEfrt(ac, acNode);
    		       activityOps.addToDo(ac, "db:insert", acName, seqId, constant_manualTime+manEff, constant_AfterMgrtnTime, "activity");
    		       return jdbcInsertActivity(ac, tDoc, acNode, acName, node, "db:insert");
    		     } else if ((node.get(0).getTextContent().toUpperCase().contains("DELETE"))) {
    		       manEff = activityOps.calManualEfrt(ac, acNode);
    		       activityOps.addToDo(ac, "db:delete", acName, seqId, constant_manualTime+manEff, constant_AfterMgrtnTime, "activity");
    		       return jdbcDeleteActivity(ac, tDoc, acNode, acName, node, "db:delete");
    		     } else if ((node.get(0).getTextContent().toUpperCase().contains("UPDATE"))) {
    		       manEff = activityOps.calManualEfrt(ac, acNode);
    		       activityOps.addToDo(ac, "db:update", acName, seqId, constant_manualTime+manEff, constant_AfterMgrtnTime, "activity");
    		       return jdbcMuleUpdateActivity(ac, tDoc, acNode, acName, node, "db:update");
    		     }
    		   }
    		   return null;

    		 }    public Element jdbcQueryActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,
                                     String mulesoftActivity) {

        Element jdbcQuery = setJDBCActivtyConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);

        return jdbcQuery;
    }

    public Element sqlDirectActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,
                                     String mulesoftActivity) {

        Element sqlDirect = setJDBCActivtyConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);
        Element dbSql = tDoc.createElement("db:sql");

        ac.getNode(acNode.getChildNodes(), 0, node, "statement");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("statement")) {

                dbSql.setTextContent(n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue().substring(
                        1, n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue().length() - 1));
            }
        }
        sqlDirect.appendChild(dbSql);
        return sqlDirect;
    }

    public Element jdbcMuleUpdateActivity(Accelerator ac, Document tDoc, Node acNode, String acName,
                                          ArrayList<Node> node, String mulesoftActivity) {

        Element jdbcUpdate = setJDBCActivtyConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);

        return jdbcUpdate;

    }

    public Element jdbcInsertActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,
                                      String mulesoftActivity) {

        Element jdbcInsert = setJDBCActivtyConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);

        return jdbcInsert;
    }

    public Element jdbcDeleteActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,
                                      String mulesoftActivity) {

        Element jdbcDelete = setJDBCActivtyConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);

        return jdbcDelete;
    }

    public Element jdbcBulkInsertActivity(Accelerator ac, Document tDoc, Node acNode, String acName,
                                          ArrayList<Node> node, String mulesoftActivity) {

        Element jdbcBulkInsert = setJDBCActivtyConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);

        return jdbcBulkInsert;
    }

    public Element jdbcBulkDeleteActivity(Accelerator ac, Document tDoc, Node acNode, String acName,
                                          ArrayList<Node> node, String mulesoftActivity) {

        Element jdbcBulkDelete = setJDBCActivtyConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);

        return jdbcBulkDelete;
    }

    public Element jdbcBulkUpdateActivity(Accelerator ac, Document tDoc, Node acNode, String acName,
                                          ArrayList<Node> node, String mulesoftActivity) {

        Element jdbcBulkUpdate = setJDBCActivtyConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);

        return jdbcBulkUpdate;
    }
    // JDBC call procedure pending*********************

    public Element jdbcCallProcdureActivity(Accelerator ac, Document tDoc, Node acNode, String acName,
                                            ArrayList<Node> node, String mulesoftActivity) {
        Element jdbcCallPro = setJDBCActivtyConfig(ac, tDoc, acNode, acName, node, mulesoftActivity);

        return jdbcCallPro;
    }

}

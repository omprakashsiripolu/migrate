package com.sme.activities;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.sme.service.Accelerator;
@Component
public class ADBAdapterActivities {


	public Element addJMSOnNewMessageActivity(Accelerator ac, Document templateDoc, Node acNode, String activityName) {

		Element jmsListener = templateDoc.createElement("jms:listener");
		Element jmsConsumerType = templateDoc.createElement("jms:consumer-type");
		Element consumerTypeTag = null;

		jmsListener.setAttribute("doc:id", ac.generateRandom(8) + "ba44-4f56-9c63-d1d76a5d22ca");
		jmsListener.setAttribute("doc:name", activityName);

		ArrayList<Node> node = new ArrayList<>();
		ac.getNode(acNode.getChildNodes(), 0, node, "ae.aepalette.sharedProperties.adapterService");
		ac.getNode(acNode.getChildNodes(), 0, node, "ae.aepalette.sharedProperties.transportChoice");
		ac.getNode(acNode.getChildNodes(), 0, node, "ae.aepalette.sharedProperties.jmsTopicSessionTopic");

		for (Node n : node) {
			if (n.getNodeName().contentEquals("ae.aepalette.sharedProperties.adapterService")) {
				String resourceName = n.getTextContent().substring(n.getTextContent().lastIndexOf('/') + 1);
				;
				resourceName = resourceName.substring(0, resourceName.indexOf("."));
				resourceName = resourceName.replaceAll(" ", "_");
				jmsListener.setAttribute("config-ref", resourceName);
			}
			if (n.getNodeName().contentEquals("ae.aepalette.sharedProperties.transportChoice")) {
				if (n.getTextContent().contentEquals("default")) {
					consumerTypeTag = templateDoc.createElement("jms:topic-consumer");
				}
				if (n.getTextContent().contentEquals("jmsTopic")) {
					consumerTypeTag = templateDoc.createElement("jms:topic-consumer");
				}
				if (n.getTextContent().contentEquals("jmsQueue")) {
					consumerTypeTag = templateDoc.createElement("jms:queue-consumer");
				}
			}
			if (n.getNodeName().contentEquals("ae.aepalette.sharedProperties.jmsTopicSessionTopic")) {
				jmsListener.setAttribute("destination", n.getTextContent());
			}

		}

		jmsConsumerType.appendChild(consumerTypeTag);
		jmsListener.appendChild(jmsConsumerType);

		return jmsListener;
	}
}
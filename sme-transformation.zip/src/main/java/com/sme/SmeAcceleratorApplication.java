package com.sme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmeAcceleratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmeAcceleratorApplication.class, args);
    }

}
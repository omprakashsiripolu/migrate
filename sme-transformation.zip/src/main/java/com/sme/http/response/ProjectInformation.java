package com.sme.http.response;

import com.sme.dao.entity.Projects;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

public class ProjectInformation extends BaseResponse implements Serializable {

    private int execId;

    private String name;

    private String description;

    private Date uploadedDate;

    private String status;

    private Date analyzeStart;

    private Date analyzeEnd;

    private Date migrationStart;

    private Date migrationEnd;

    private String error;

    private int configFilesCount;

    private int flowsCount;

    private int globalVariablesCount;

    private int groupActivitiesCount;

    private int restServicesCount;

    private int sharedConnectionsCount;

    private int transitionsCount;

    private int xsltCount;

    private boolean sourceZipExists;

    private boolean targetZipExists;

    private boolean xsltToDwlZipExists;

    public ProjectInformation(int execId, String name, String description, Date uploadedDate) {
        this.execId = execId;
        this.name = name;
        this.description = description;
        this.uploadedDate = uploadedDate;
        this.sourceZipExists = true;
    }

    public ProjectInformation(Projects projects, boolean summary) {
        this.execId = projects.getExecId();
        this.name = projects.getName();
        this.description = projects.getDescription();
        this.uploadedDate = projects.getDatetime();
        this.status = projects.getStatus();
        this.analyzeStart = projects.getAnalyzeStart();
        this.analyzeEnd = projects.getAnalyzeEnd();
        this.migrationStart = projects.getMigrationStart();
        this.migrationEnd = projects.getMigrationEnd();
        this.error = projects.getError();
        if (summary) {
            this.configFilesCount = projects.getConfigFilesList().size();
            this.flowsCount = projects.getFlowList().size();
            this.globalVariablesCount = projects.getGlobalVariablesList().size();
            this.groupActivitiesCount = projects.getGroupActivitiesList().size();
            this.restServicesCount = projects.getRestServiceList().size();
            this.sharedConnectionsCount = projects.getSharedConnectionsList().size();
            this.transitionsCount = projects.getTransitionsList().size();
            this.xsltCount = projects.getXsltToDwList().size();
        }
        this.sourceZipExists = projects.getSourceProject() != null;
        this.targetZipExists = projects.getTargetProject() != null;
        this.xsltToDwlZipExists = projects.getXsltToDwlExcel() != null;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getConfigFilesCount() {
        return configFilesCount;
    }

    public void setConfigFilesCount(int configFilesCount) {
        this.configFilesCount = configFilesCount;
    }

    public int getFlowsCount() {
        return flowsCount;
    }

    public void setFlowsCount(int flowsCount) {
        this.flowsCount = flowsCount;
    }

    public int getGlobalVariablesCount() {
        return globalVariablesCount;
    }

    public void setGlobalVariablesCount(int globalVariablesCount) {
        this.globalVariablesCount = globalVariablesCount;
    }

    public int getGroupActivitiesCount() {
        return groupActivitiesCount;
    }

    public void setGroupActivitiesCount(int groupActivitiesCount) {
        this.groupActivitiesCount = groupActivitiesCount;
    }

    public int getRestServicesCount() {
        return restServicesCount;
    }

    public void setRestServicesCount(int restServicesCount) {
        this.restServicesCount = restServicesCount;
    }

    public int getSharedConnectionsCount() {
        return sharedConnectionsCount;
    }

    public void setSharedConnectionsCount(int sharedConnectionsCount) {
        this.sharedConnectionsCount = sharedConnectionsCount;
    }

    public int getTransitionsCount() {
        return transitionsCount;
    }

    public void setTransitionsCount(int transitionsCount) {
        this.transitionsCount = transitionsCount;
    }

    public int getXsltCount() {
        return xsltCount;
    }

    public void setXsltCount(int xsltCount) {
        this.xsltCount = xsltCount;
    }

    public Date getUploadedDate() {
        return uploadedDate;
    }

    public void setUploadedDate(Date uploadedDate) {
        this.uploadedDate = uploadedDate;
    }

    public Date getAnalyzeStart() {
        return analyzeStart;
    }

    public void setAnalyzeStart(Date analyzeStart) {
        this.analyzeStart = analyzeStart;
    }

    public Date getAnalyzeEnd() {
        return analyzeEnd;
    }

    public void setAnalyzeEnd(Date analyzeEnd) {
        this.analyzeEnd = analyzeEnd;
    }

    public Date getMigrationStart() {
        return migrationStart;
    }

    public void setMigrationStart(Date migrationStart) {
        this.migrationStart = migrationStart;
    }

    public Date getMigrationEnd() {
        return migrationEnd;
    }

    public void setMigrationEnd(Date migrationEnd) {
        this.migrationEnd = migrationEnd;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public boolean isSourceZipExists() {
        return sourceZipExists;
    }

    public void setSourceZipExists(boolean sourceZipExists) {
        this.sourceZipExists = sourceZipExists;
    }

    public boolean isTargetZipExists() {
        return targetZipExists;
    }

    public void setTargetZipExists(boolean targetZipExists) {
        this.targetZipExists = targetZipExists;
    }

    public boolean isXsltToDwlZipExists() {
        return xsltToDwlZipExists;
    }

    public void setXsltToDwlZipExists(boolean xsltToDwlZipExists) {
        this.xsltToDwlZipExists = xsltToDwlZipExists;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProjectInformation that = (ProjectInformation) o;
        return execId == that.execId && configFilesCount == that.configFilesCount && flowsCount == that.flowsCount && globalVariablesCount == that.globalVariablesCount && groupActivitiesCount == that.groupActivitiesCount && restServicesCount == that.restServicesCount && sharedConnectionsCount == that.sharedConnectionsCount && transitionsCount == that.transitionsCount && xsltCount == that.xsltCount && sourceZipExists == that.sourceZipExists && targetZipExists == that.targetZipExists && xsltToDwlZipExists == that.xsltToDwlZipExists && Objects.equals(name, that.name) && Objects.equals(description, that.description) && Objects.equals(uploadedDate, that.uploadedDate) && Objects.equals(status, that.status) && Objects.equals(analyzeStart, that.analyzeStart) && Objects.equals(analyzeEnd, that.analyzeEnd) && Objects.equals(migrationStart, that.migrationStart) && Objects.equals(migrationEnd, that.migrationEnd) && Objects.equals(error, that.error);
    }

    @Override
    public int hashCode() {
        return Objects.hash(execId, name, description, uploadedDate, status, analyzeStart, analyzeEnd, migrationStart, migrationEnd, error, configFilesCount, flowsCount, globalVariablesCount, groupActivitiesCount, restServicesCount, sharedConnectionsCount, transitionsCount, xsltCount, sourceZipExists, targetZipExists, xsltToDwlZipExists);
    }
}

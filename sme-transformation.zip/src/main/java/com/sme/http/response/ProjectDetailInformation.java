package com.sme.http.response;

import com.sme.dao.entity.*;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class ProjectDetailInformation extends BaseResponse implements Serializable {

    private int executionId;

    private String name;

    private String description;

    private Date uploadedDate;

    private String status;

    private Date analyzeStart;

    private Date analyzeEnd;

    private Date migrationStart;

    private Date migrationEnd;

    private String error;

    private List<ConfigFiles> configFiles;

    private List<Flow> flows;
    
    private List<UnmigratedActivities> unmigratedActivities;

	private List<GlobalVariables> globalVariables;

    private List<GroupActivities> groupActivities;

    private List<RestService> restServices;

    private List<SharedConnections> sharedConnections;

    private List<Transitions> transitions;

    private List<XsltToDw> xsltToDw;
    

    public ProjectDetailInformation(Projects projects) {
        this.executionId = projects.getExecId();
        this.name = projects.getName();
        this.description = projects.getDescription();
        this.uploadedDate = projects.getDatetime();
        this.status = projects.getStatus();
        this.analyzeStart = projects.getAnalyzeStart();
        this.analyzeEnd = projects.getAnalyzeEnd();
        this.migrationStart = projects.getMigrationStart();
        this.migrationEnd = projects.getMigrationEnd();
        this.error = projects.getError();
        this.configFiles = projects.getConfigFilesList();
        this.flows = projects.getFlowList();
        this.unmigratedActivities = projects.getUnmigratedActivitiesList();
        this.globalVariables = projects.getGlobalVariablesList();
        this.groupActivities = projects.getGroupActivitiesList();
        this.restServices = projects.getRestServiceList();
        this.sharedConnections = projects.getSharedConnectionsList();
        this.transitions = projects.getTransitionsList();
        this.xsltToDw = projects.getXsltToDwList();
    }

    public int getExecutionId() {
        return executionId;
    }

    public void setExecutionId(int executionId) {
        this.executionId = executionId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getAnalyzeStart() {
        return analyzeStart;
    }

    public void setAnalyzeStart(Date analyzeStart) {
        this.analyzeStart = analyzeStart;
    }

    public Date getAnalyzeEnd() {
        return analyzeEnd;
    }

    public void setAnalyzeEnd(Date analyzeEnd) {
        this.analyzeEnd = analyzeEnd;
    }

    public Date getMigrationStart() {
        return migrationStart;
    }

    public void setMigrationStart(Date migrationStart) {
        this.migrationStart = migrationStart;
    }

    public Date getMigrationEnd() {
        return migrationEnd;
    }

    public void setMigrationEnd(Date migrationEnd) {
        this.migrationEnd = migrationEnd;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public List<ConfigFiles> getConfigFiles() {
        return configFiles;
    }

    public void setConfigFiles(List<ConfigFiles> configFiles) {
        this.configFiles = configFiles;
    }

    public List<Flow> getFlows() {
        return flows;
    }

    public void setFlows(List<Flow> flows) {
        this.flows = flows;
    }
    
    public List<UnmigratedActivities> getUnmigratedActivities() {
		return unmigratedActivities;
	}

	public void setUnmigratedActivities(List<UnmigratedActivities> unmigratedActivities) {
		this.unmigratedActivities = unmigratedActivities;
	}

    public List<GlobalVariables> getGlobalVariables() {
        return globalVariables;
    }

    public void setGlobalVariables(List<GlobalVariables> globalVariables) {
        this.globalVariables = globalVariables;
    }

    public List<GroupActivities> getGroupActivities() {
        return groupActivities;
    }

    public void setGroupActivities(List<GroupActivities> groupActivities) {
        this.groupActivities = groupActivities;
    }

    public List<RestService> getRestServices() {
        return restServices;
    }

    public void setRestServices(List<RestService> restServices) {
        this.restServices = restServices;
    }

    public List<SharedConnections> getSharedConnections() {
        return sharedConnections;
    }

    public void setSharedConnections(List<SharedConnections> sharedConnections) {
        this.sharedConnections = sharedConnections;
    }

    public List<Transitions> getTransitions() {
        return transitions;
    }

    public void setTransitions(List<Transitions> transitions) {
        this.transitions = transitions;
    }

    public List<XsltToDw> getXsltToDw() {
        return xsltToDw;
    }

    public void setXsltToDw(List<XsltToDw> xsltToDw) {
        this.xsltToDw = xsltToDw;
    }

    public Date getUploadedDate() {
        return uploadedDate;
    }

    public void setUploadedDate(Date uploadedDate) {
        this.uploadedDate = uploadedDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProjectDetailInformation that = (ProjectDetailInformation) o;
        return executionId == that.executionId && Objects.equals(name, that.name)
                && Objects.equals(description, that.description) && Objects.equals(uploadedDate, that.uploadedDate)
                && Objects.equals(status, that.status) && Objects.equals(analyzeStart, that.analyzeStart)
                && Objects.equals(analyzeEnd, that.analyzeEnd) && Objects.equals(migrationStart, that.migrationStart)
                && Objects.equals(migrationEnd, that.migrationEnd) && Objects.equals(error, that.error)
                && Objects.equals(configFiles, that.configFiles) && Objects.equals(flows, that.flows)
                && Objects.equals(unmigratedActivities, that.unmigratedActivities) && Objects.equals(globalVariables, that.globalVariables)
                && Objects.equals(groupActivities, that.groupActivities)
                && Objects.equals(restServices, that.restServices)
                && Objects.equals(sharedConnections, that.sharedConnections)
                && Objects.equals(transitions, that.transitions) && Objects.equals(xsltToDw, that.xsltToDw);
    }

    @Override
    public int hashCode() {
        return Objects.hash(executionId, name, description, uploadedDate, status, analyzeStart,
                analyzeEnd, migrationStart, migrationEnd, error, configFiles, flows, unmigratedActivities,
                globalVariables, groupActivities, restServices, sharedConnections, transitions, xsltToDw);
    }
}

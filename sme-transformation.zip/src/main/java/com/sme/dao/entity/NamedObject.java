package com.sme.dao.entity;

import java.util.List;

public class NamedObject {
    public final List<Flow> flows;
    public final List<GroupActivities> groupActivities;

    public NamedObject(List<Flow> flows, List<GroupActivities> groupActivities) {
        this.flows = flows;
        this.groupActivities = groupActivities;
    }
}

package com.sme.dao.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "ARC_TRANSITIONS")
@IdClass(TransitionsCompositeKey.class)
public class Transitions {

    @Column(name = "PROCESSES_NAME")
    private String processesName;
    @Id
    @Column(name = "SEQID")
    private int seqId;

    @Id
    @Column(name = "PARENTID")
    private int parentId;

    @Column(name = "CONDITIONTYPE")
    private String conditionType;

    @Column(name = "XPATH")
    private String xPath;

    @Id
    @Column(name = "EXEC_ID")
    private int execId;

    public Transitions() {
    }

    public Transitions(String processesName, int seqId, int parentId, String conditionType, String xPath, int execId) {
        this.processesName = processesName;
        this.seqId = seqId;
        this.parentId = parentId;
        this.conditionType = conditionType;
        this.xPath = xPath;
        this.execId = execId;
    }

    public String getProcessesName() {
        return processesName;
    }

    public void setProcessesName(String processesName) {
        this.processesName = processesName;
    }

    public int getSeqId() {
        return seqId;
    }

    public void setSeqId(int seqId) {
        this.seqId = seqId;
    }

    public int getParentId() {
        return parentId;
    }

    public void setParentId(int parentId) {
        this.parentId = parentId;
    }

    public String getConditionType() {
        return conditionType;
    }

    public void setConditionType(String conditionType) {
        this.conditionType = conditionType;
    }

    public String getxPath() {
        return xPath;
    }

    public void setxPath(String xPath) {
        this.xPath = xPath;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Transitions that = (Transitions) o;
        return seqId == that.seqId && parentId == that.parentId && execId == that.execId && Objects.equals(processesName, that.processesName) && Objects.equals(conditionType, that.conditionType) && Objects.equals(xPath, that.xPath);
    }

    @Override
    public int hashCode() {
        return Objects.hash(processesName, seqId, parentId, conditionType, xPath, execId);
    }
}

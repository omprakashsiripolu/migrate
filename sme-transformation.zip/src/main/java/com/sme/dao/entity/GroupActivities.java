package com.sme.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Arrays;
import java.util.Objects;

@Entity
@Table(name = "ARC_GROUPACTIVITIES")
@IdClass(GroupActivitiesCompositeKey.class)
@NamedQueries({
        @NamedQuery(name = "findAllByProcessesNameAndExecIdAndParentIdLikeAndGroupName",
                query = "SELECT f FROM GroupActivities f WHERE " +
                        "f.execId = :execId AND " +
                        "f.processesName = :processesName AND " +
                        "f.parentId LIKE :parentId AND " +
                        "f.groupName = :groupName"),
        @NamedQuery(name = "findAllByProcessesNameAndExecIdAndParentIdAndParentIdLikeAndGroupName",
                query = "SELECT f FROM GroupActivities f WHERE " +
                        "f.execId = :execId AND " +
                        "f.processesName = :processesName AND " +
                        "(f.parentId = :parentId OR f.parentId LIKE :similar) AND " +
                        "f.groupName = :groupName")
})
public class GroupActivities {

    @Id
    @Column(name = "group_name")
    private String groupName;

    @Column(name = "processes_name")
    private String processesName;


    @Id
    private int seqId;

    private int lvl;

    @Column(name = "ACTIVITY_NAME")
    private String activityName;

    @Column(name = "ACTIVITY_TYPE")
    private String activityType;

    @Lob
    @JsonIgnore
    @Column(name = "ACTIVITY_XSLT")
    private byte[] activityXslt;

    private String parentId;

    private String conditionType;

    private String xpath;

    private int parentCount;

    @Column(name = "EXEC_ID")
    @Id
    private int execId;
    
    public GroupActivities() {
    }

    public GroupActivities(String groupName, String processesName,
                           int seqId, int lvl, String activityName,
                           String activityType, byte[] activityXslt,
                           String parentId, String conditionType,
                           String xpath, int parentCount, int execId) {
        this.groupName = groupName;
        this.processesName = processesName;
        this.seqId = seqId;
        this.lvl = lvl;
        this.activityName = activityName;
        this.activityType = activityType;
        this.activityXslt = activityXslt;
        this.parentId = parentId;
        this.conditionType = conditionType;
        this.xpath = xpath;
        this.parentCount = parentCount;
        this.execId = execId;
    
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GroupActivities that = (GroupActivities) o;
        return seqId == that.seqId && lvl == that.lvl && parentCount == that.parentCount && execId == that.execId && Objects.equals(groupName, that.groupName) && Objects.equals(processesName, that.processesName) && Objects.equals(activityName, that.activityName) && Objects.equals(activityType, that.activityType) && Arrays.equals(activityXslt, that.activityXslt) && Objects.equals(parentId, that.parentId) && Objects.equals(conditionType, that.conditionType) && Objects.equals(xpath, that.xpath);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(groupName, processesName, seqId, lvl, activityName, activityType, parentId, conditionType, xpath, parentCount, execId);
        result = 31 * result + Arrays.hashCode(activityXslt);
        return result;
    }


    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getProcessesName() {
        return processesName;
    }

    public void setProcessesName(String processesName) {
        this.processesName = processesName;
    }

    public int getSeqId() {
        return seqId;
    }

    public void setSeqId(int seqId) {
        this.seqId = seqId;
    }

    public int getLvl() {
        return lvl;
    }

    public void setLvl(int lvl) {
        this.lvl = lvl;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public byte[] getActivityXslt() {
        return activityXslt;
    }

    public void setActivityXslt(byte[] activityXslt) {
        this.activityXslt = activityXslt;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getConditionType() {
        return conditionType;
    }

    public void setConditionType(String conditionType) {
        this.conditionType = conditionType;
    }

    public String getXpath() {
        return xpath;
    }

    public void setXpath(String xpath) {
        this.xpath = xpath;
    }

    public int getParentCount() {
        return parentCount;
    }

    public void setParentCount(int parentCount) {
        this.parentCount = parentCount;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }
}

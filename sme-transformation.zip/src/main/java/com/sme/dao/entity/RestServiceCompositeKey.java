package com.sme.dao.entity;

import java.io.Serializable;
import java.util.Objects;

public class RestServiceCompositeKey implements Serializable {
    private String processesName;

    private String resourceName;

    private int execId;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RestServiceCompositeKey that = (RestServiceCompositeKey) o;
        return execId == that.execId && Objects.equals(processesName, that.processesName) && Objects.equals(resourceName, that.resourceName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(processesName, resourceName, execId);
    }

    public String getProcessesName() {
        return processesName;
    }

    public void setProcessesName(String processesName) {
        this.processesName = processesName;
    }

    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }

    public RestServiceCompositeKey(String processesName, String resourceName, int execId) {
        this.processesName = processesName;
        this.resourceName = resourceName;
        this.execId = execId;
    }

    public RestServiceCompositeKey() {
    }
}

package com.sme.dao.entity;

import java.io.Serializable;
import java.util.Objects;

public class GroupActivitiesCompositeKey implements Serializable {

    private String groupName;

    private int seqId;

    private int execId;

    public GroupActivitiesCompositeKey() {
    }

    public GroupActivitiesCompositeKey(String groupName, int seqId, int execId) {
        this.groupName = groupName;
        this.seqId = seqId;
        this.execId = execId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public int getSeqId() {
        return seqId;
    }

    public void setSeqId(int seqId) {
        this.seqId = seqId;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GroupActivitiesCompositeKey that = (GroupActivitiesCompositeKey) o;
        return seqId == that.seqId && execId == that.execId && Objects.equals(groupName, that.groupName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(groupName, seqId, execId);
    }
}

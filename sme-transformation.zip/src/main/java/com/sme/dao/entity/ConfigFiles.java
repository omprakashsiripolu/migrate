package com.sme.dao.entity;


import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;

@Entity
@Table(name = "ARC_CONFIGFILES")
@IdClass(ConfigFilesCompositeKey.class)
@NamedQuery(name = "findByNameLikeAndExecId",
        query = "select c from ConfigFiles c where c.name like :name and c.execId = :execId")
public class ConfigFiles {

    @Id
    private String name;

    @Lob
    @JsonIgnore
    private byte[] config;

    @Id
    @Column(name = "exec_id")
    private int execId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte[] getConfig() {
        return config;
    }

    public void setConfig(byte[] config) {
        this.config = config;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }

    public ConfigFiles(String name, byte[] config, int execId) {
        this.name = name;
        this.config = config;
        this.execId = execId;
    }

    protected ConfigFiles() {
    }
}

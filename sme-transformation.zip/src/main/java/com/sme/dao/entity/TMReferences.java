package com.sme.dao.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.util.Objects;

@Entity
@Table(name = "TMREFERENCES")
@IdClass(TMReferencesCompositeKey.class)
public class TMReferences {

    @Id
    private String tibco;

    @Id
    private String mulesoft;

    private Double manualTime;

    private Double afterMigrationTime;

    public TMReferences() {
    }

    public TMReferences(String tibco, String mulesoft, Double manualTime, Double afterMigrationTime) {
        this.tibco = tibco;
        this.mulesoft = mulesoft;
        this.manualTime = manualTime;
        this.afterMigrationTime = afterMigrationTime;
    }

    public String getTibco() {
        return tibco;
    }

    public void setTibco(String tibco) {
        this.tibco = tibco;
    }

    public String getMulesoft() {
        return mulesoft;
    }

    public void setMulesoft(String mulesoft) {
        this.mulesoft = mulesoft;
    }

    public Double getManualTime() {
        return manualTime;
    }

    public void setManualTime(Double manualTime) {
        this.manualTime = manualTime;
    }

    public Double getAfterMigrationTime() {
        return afterMigrationTime;
    }

    public void setAfterMigrationTime(Double afterMigrationTime) {
        this.afterMigrationTime = afterMigrationTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TMReferences that = (TMReferences) o;
        return Objects.equals(tibco, that.tibco) &&
               Objects.equals(mulesoft, that.mulesoft) &&
               Objects.equals(manualTime, that.manualTime) &&
               Objects.equals(afterMigrationTime, that.afterMigrationTime);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tibco, mulesoft, manualTime, afterMigrationTime);
    }
}

package com.sme.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Arrays;
import java.util.Objects;

@Entity
@Table(name = "ARC_XSLTTODW")
@IdClass(XsltToDwCompositeKey.class)
public class XsltToDw {

    @Id
    @Column(name = "ACTIVITY_NAME")
    private String activityName;

    @Lob
    @JsonIgnore
    private byte[] xslt;

    @Id
    @Column(name = "EXEC_ID")
    private int execId;
    
    @Id
    @Column (name = "Seq_Id")
    private Integer seqId;
    
    @Column(name = "DWL")  
    private String dwl;  

    public XsltToDw() {
    }

    public XsltToDw(String activityName, byte[] xslt, int execId , int seqId , String dwl) {
        this.activityName = activityName;
        this.xslt = xslt;
        this.execId = execId;
        this.seqId = seqId;
        this.dwl = dwl;
        
    }


    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public byte[] getXslt() {
        return xslt;
    }

    public void setXslt(byte[] xslt) {
        this.xslt = xslt;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }
    public int getSeqId () {
    	return seqId;
    }
    public void setSeqId(int seqId) {
    	this.seqId = seqId;
    }
    public String getDwl() {
    	return dwl;
    }
    public void setDwl(String dwl) {
    	this.dwl = dwl;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        XsltToDw xsltToDw = (XsltToDw) o;
        return execId == xsltToDw.execId && Objects.equals(activityName, xsltToDw.activityName) && Arrays.equals(xslt, xsltToDw.xslt);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(activityName, execId);
        result = 31 * result + Arrays.hashCode(xslt);
        return result;
    }
}

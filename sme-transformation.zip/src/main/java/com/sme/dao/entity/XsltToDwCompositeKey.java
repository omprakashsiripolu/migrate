package com.sme.dao.entity;


import java.io.Serializable;
import java.util.Objects;

public class XsltToDwCompositeKey implements Serializable {

    private String activityName;

    private int execId;

    public XsltToDwCompositeKey() {
    }

    public XsltToDwCompositeKey(String activityName, int execId) {
        this.activityName = activityName;
        this.execId = execId;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        XsltToDwCompositeKey that = (XsltToDwCompositeKey) o;
        return execId == that.execId && Objects.equals(activityName, that.activityName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(activityName, execId);
    }
}

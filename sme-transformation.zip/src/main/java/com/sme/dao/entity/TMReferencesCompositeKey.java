package com.sme.dao.entity;

import java.io.Serializable;
import java.util.Objects;

public class TMReferencesCompositeKey implements Serializable {

    private String tibco;

    private String mulesoft;

    public TMReferencesCompositeKey() {
    }

    public TMReferencesCompositeKey(String tibco, String mulesoft) {
        this.tibco = tibco;
        this.mulesoft = mulesoft;
    }

    public String getTibco() {
        return tibco;
    }

    public void setTibco(String tibco) {
        this.tibco = tibco;
    }

    public String getMulesoft() {
        return mulesoft;
    }

    public void setMulesoft(String mulesoft) {
        this.mulesoft = mulesoft;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TMReferencesCompositeKey that = (TMReferencesCompositeKey) o;
        return Objects.equals(tibco, that.tibco) && Objects.equals(mulesoft, that.mulesoft);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tibco, mulesoft);
    }
}

package com.sme.dao.entity;

public enum ProjectStatus {
    ANALYZE_START("Analyze in progress"),
    ANALYZE_END("Analyze complete"),
    ANALYZE_ERROR("Analyze error"),
    MIGRATION_START("Migration in progress"),
    MIGRATION_END("Migration complete"),
    MIGRATION_ERROR("Migration error");

    private final String text;

    ProjectStatus(String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return text;
    }
}

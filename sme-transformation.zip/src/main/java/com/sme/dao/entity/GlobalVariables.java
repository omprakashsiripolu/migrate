package com.sme.dao.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "ARC_GLOBALVARIABLES")
@IdClass(GlobalVariablesCompositeKey.class)
public class GlobalVariables {

    @Id
    @Column(name = "key_s")
    private String keyS;

    @Column(name = "value_s")
    private String valueS;

    @Id
    @Column(name = "exec_id")
    private int execId;

    public String getKeyS() {
        return keyS;
    }

    public void setKeyS(String keyS) {
        this.keyS = keyS;
    }

    public String getValueS() {
        return valueS;
    }

    public void setValueS(String valueS) {
        this.valueS = valueS;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }

    protected GlobalVariables() {
    }

    public GlobalVariables(String keyS, String valueS, int execId) {
        this.keyS = keyS;
        this.valueS = valueS;
        this.execId = execId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GlobalVariables that = (GlobalVariables) o;
        return execId == that.execId && Objects.equals(keyS, that.keyS) && Objects.equals(valueS, that.valueS);
    }

    @Override
    public int hashCode() {
        return Objects.hash(keyS, valueS, execId);
    }
}

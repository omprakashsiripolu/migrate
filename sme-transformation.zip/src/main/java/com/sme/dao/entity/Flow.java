package com.sme.dao.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

//import antlr.collections.List;
import java.util.List;

@Entity
@Table(name = "ARC_FLOW")
@IdClass(FlowCompositeKey.class)
@NamedQueries({
        @NamedQuery(name = "findAllByProcessesNameAndExecIdAndParentIdLike",
                query = "SELECT f FROM Flow f WHERE " +
                        "f.execId = :execId AND " +
                        "f.processesName = :processesName AND " +
                        "f.parentId LIKE :parentId"),
        @NamedQuery(name = "findAllByProcessesNameAndExecIdAndParentIdAndParentIdLike",
                query = "SELECT f FROM Flow f WHERE " +
                        "f.execId = :execId AND " +
                        "f.processesName = :processesName AND " +
                        "(f.parentId = :parentId OR f.parentId LIKE :similar)")
})
public class Flow {

    @Column(name = "PROCESSES_NAME")
    private String processesName;

    @Id
    private int seqId;

    private int lvl;

    @Column(name = "ACTIVITY_NAME")
    private String activityName;

    @Column(name = "ACTIVITY_TYPE")
    private String activityType;

    @Lob
    @JsonIgnore
    @Column(name = "ACTIVITY_XSLT")
    private byte[] activityXslt;


    private String parentId;
  
    private String conditionType;

    private String xpath;

    private int parentCount;
    
    private int manual_efforts_required;

    @Column(name = "EXEC_ID")
    @Id
    private int execId;

    public Flow() {
    }

    public Flow(String processesName, int seqId, int lvl,
            String activityName, String activityType,
            byte[] activityXslt,String parentId,
            String conditionType, String xpath, int parentCount, int execId) {
    this.processesName = processesName;
    this.seqId = seqId;
    this.lvl = lvl;
    this.activityName = activityName;
    this.activityType = activityType;
    this.activityXslt = activityXslt;
    this.parentId = parentId;
    this.conditionType = conditionType;
    this.xpath = xpath;
    this.parentCount = parentCount;
    this.execId = execId;
   
}
    public String getProcessesName() {
        return processesName;
    }

    public void setProcessesName(String processesName) {
        this.processesName = processesName;
    }

    public int getSeqId() {
        return seqId;
    }

    public void setSeqId(int seqId) {
        this.seqId = seqId;
    }

    public int getLvl() {
        return lvl;
    }

    public void setLvl(int lvl) {
        this.lvl = lvl;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public byte[] getActivityXslt() {
        return activityXslt;
    }

    public void setActivityXslt(byte[] activityXslt) {
        this.activityXslt = activityXslt;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getConditionType() {
        return conditionType;
    }

    public void setConditionType(String conditionType) {
        this.conditionType = conditionType;
    }

    public String getXpath() {
        return xpath;
    }

    public void setXpath(String xpath) {
        this.xpath = xpath;
    }

    public int getParentCount() {
        return parentCount;
    }

    public void setParentCount(int parentCount) {
        this.parentCount = parentCount;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }

	public int getManual_efforts_required() {
		return manual_efforts_required;
	}

	public void setManual_efforts_required(int manual_efforts_required) {
		this.manual_efforts_required = manual_efforts_required;
	}

	
	
	
	
}

package com.sme.dao.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "arc_migrationstats")
public class MigrationStats {
    
	   @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "Sno")
	    private int sno;
	
	@Column(name = "Exec_Id")
	private int execId;
	
	@Column(name = "seqid")
	private int seqId;

	@Column(name = "Type")
    private String type;
    
    @Column(name = "Input_Type")
    private String inputType;
    
    @Column(name = "Name")
    private String nameOfAct;
    
    @Column(name = "Filename")
    private String fileName;
    
    @Column(name = "Manual_Effort")
    private double manualEffort;
    
    @Column(name = "After_Migration")
    private double afterMigration;
    
    @Column(name = "Time_Saved")
    private double timeSaved;
    
    public MigrationStats() {

    }

      public MigrationStats(int sno ,int execId,int seqId, String type, String inputType, String nameOfAct, String fileName,  double manualEffort , double afterMigration, double timeSaved) {
    	this.sno = sno;
    	this.execId = execId;
    	this.seqId = seqId;
        this.type = type;
        this.inputType = inputType;
        this.nameOfAct = nameOfAct;
        this.fileName = fileName;
        this.manualEffort = manualEffort;
        this.afterMigration = afterMigration;
        this.timeSaved = timeSaved;
    }
      
      public int getSno() {
    	    return sno;
    	}

    	public void setSno(int sno) {
    	    this.sno = sno;
    	}
    	

        public int getSeqId() {
    		return seqId;
    	}

    	public void setSeqId(int seqId) {
    		this.seqId = seqId;
    	}

      
      
      public String getType() {
          return type;
      }

      public void setType(String type) {
          this.type = type;
      }
      
      public int getExecIdAnalysis() {
          return execId;
      }

      public void setExecIdAnalysis(int execId) {
          this.execId = execId;
      }
      
      public String getInputType() {
          return inputType;
      }

      public void setInputType(String inputType) {
          this.inputType = inputType;
      }
      
      public String getNameOfAct() {
          return nameOfAct;
      }

      public void setNameOfAct(String nameOfAct) {
          this.nameOfAct = nameOfAct;
      }
      
      public String getFileName() {
          return fileName;
      }

      public void setFileName(String fileName) {
          this.fileName = fileName;
      }
      
      
      public double getManualEffort() {
          return manualEffort;
      }
      
      public void setManualEffort(double manualEffort) {
          this.manualEffort = manualEffort;
      }
      
      public double getAfterMigration() {
          return afterMigration;
      }
      
      public void setAfterMigration(double afterMigration) {
          this.afterMigration = afterMigration;
      }
      
      public double getSavedTime() {
          return timeSaved;
      }

      public void setSavedTime(double timeSaved) {
          this.timeSaved = timeSaved;
      }
      
}


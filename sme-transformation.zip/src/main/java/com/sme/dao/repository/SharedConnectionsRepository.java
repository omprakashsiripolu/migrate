package com.sme.dao.repository;

import com.sme.dao.entity.SharedConnections;
import com.sme.dao.entity.SharedConnectionsCompositeKey;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface SharedConnectionsRepository extends CrudRepository<SharedConnections, SharedConnectionsCompositeKey> {
    List<SharedConnections> findAllBySharedNameAndExecId(String resourceName, int execId);

    List<SharedConnections> findAllByExecIdAndSharedNameLike(int execId, String s);

    List<SharedConnections> findAllByExecId(int execId);
}

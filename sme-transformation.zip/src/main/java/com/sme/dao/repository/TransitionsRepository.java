package com.sme.dao.repository;

import com.sme.dao.entity.Transitions;
import com.sme.dao.entity.TransitionsCompositeKey;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface TransitionsRepository extends CrudRepository<Transitions, TransitionsCompositeKey> {
    List<Transitions> findAllByExecIdAndProcessesNameAndSeqIdAndParentId(int execId, String processesName, int seqId, String parentId);
}

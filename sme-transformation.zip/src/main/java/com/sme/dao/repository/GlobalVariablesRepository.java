package com.sme.dao.repository;

import com.sme.dao.entity.GlobalVariables;
import com.sme.dao.entity.GlobalVariablesCompositeKey;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GlobalVariablesRepository extends CrudRepository<GlobalVariables, GlobalVariablesCompositeKey> {
    List<GlobalVariables> findAllByKeyS(String keyS);
    List<GlobalVariables> findAllByExecId(int execId);
}

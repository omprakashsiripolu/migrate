package com.sme.dao.repository;

import com.sme.dao.entity.RestService;
import com.sme.dao.entity.RestServiceCompositeKey;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface RestServiceRepository extends CrudRepository<RestService, RestServiceCompositeKey> {
    List<RestService> findAllByExecId(int execId);
}

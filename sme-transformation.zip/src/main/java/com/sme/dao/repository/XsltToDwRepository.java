package com.sme.dao.repository;

import com.sme.dao.entity.XsltToDw;
import com.sme.dao.entity.XsltToDwCompositeKey;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface XsltToDwRepository extends CrudRepository<XsltToDw, XsltToDwCompositeKey> {
	List<XsltToDw> findAllByExecId(int execId);
}

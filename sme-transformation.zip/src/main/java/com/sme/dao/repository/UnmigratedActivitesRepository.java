package com.sme.dao.repository;

import org.springframework.data.repository.CrudRepository;

import com.sme.dao.entity.UnmigratedActivities;
import com.sme.dao.entity.UnmigratedActivitiesCompositeKey;

public interface UnmigratedActivitesRepository extends CrudRepository <UnmigratedActivities, UnmigratedActivitiesCompositeKey>{

}

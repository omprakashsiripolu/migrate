package com.sme.dao;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import com.sme.dao.entity.ConfigFiles;
import com.sme.dao.entity.GlobalVariables;
import com.sme.dao.entity.TMReferences;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.sme.activities.RestActivities;
import com.sme.service.Accelerator;
import com.sme.util.ActivityOps;
import com.sme.util.FlowOps;
import com.sme.util.RetrieveOps;

@Component
public class SharedConnections {
    private static final Logger logger = LoggerFactory.getLogger(SharedConnections.class);

    @Autowired
    private RetrieveOps retrieveOps;
    ArrayList<String> nonSharedConnections = new ArrayList<>();

    @Autowired
    JDBCConnection jdbc;


    
    double constant_manualTime =0.0;
    double constant_AfterMgrtnTime =0.0;
	String mulesoftActivity="";
    public void addJdbcConfigTag(Accelerator accelerator, Document tDoc, String resourceName, String sharedXslt, ActivityOps activityOps)
            throws SQLException, ParserConfigurationException, SAXException, IOException {

        resourceName = resourceName.substring(resourceName.lastIndexOf("/") + 1, resourceName.indexOf("."))
                .replaceAll(" ", "_");

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:db") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:db", "http://www.mulesoft.org/schema/mule/db");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);

            // create driver depencency in pom.xml
        }

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

        Node sharedNode = docBuilder.parse(new InputSource(new StringReader(sharedXslt))).getDocumentElement();

        Element config = tDoc.createElement("db:config");
        config.setAttribute("name", resourceName);
        config.setAttribute("doc:name", resourceName);
        config.setAttribute("doc:id", accelerator.generateRandom(8) + "-cc1e-44ea-8a3d-d56cb1a380a5");

        Element connection = tDoc.createElement("db:oracle-connection");
        ArrayList<Node> node = new ArrayList<>();
        accelerator.getNode(sharedNode.getChildNodes(), 0, node, "location");
        accelerator.getNode(sharedNode.getChildNodes(), 0, node, "user");
        accelerator.getNode(sharedNode.getChildNodes(), 0, node, "password");

        String host = null;
        String port = null;
        String instance = null;

        String driver = node.get(0).getTextContent().substring(node.get(0).getTextContent().indexOf("@") + 1);
        if (driver.contains("%%")) {
            List<GlobalVariables> globalVariables = jdbc.getGlobalVariable(driver.substring(2, driver.length() - 2));
            logger.info("JDBC driver: " + driver);
            if (!globalVariables.isEmpty())
                driver = globalVariables.get(globalVariables.size() - 1).getValueS();
        }
        if (driver.contains("sqlserver")) {
            driver = driver.substring(driver.indexOf("//") + 1);
            host = driver.substring(0, driver.indexOf(":"));
            port = driver.substring(driver.indexOf(":") + 1, driver.lastIndexOf(";"));
            instance = driver.substring(driver.lastIndexOf("=") + 1);
        } else if (driver.contains("mysql")) {
            driver = driver.substring(driver.indexOf("//") + 1);
            host = driver.substring(0, driver.indexOf(":"));
            port = driver.substring(driver.indexOf(":") + 1, driver.lastIndexOf("/"));
            instance = driver.substring(driver.lastIndexOf("/") + 1);
        } else {
            host = driver.substring(0, driver.indexOf(":"));
            port = driver.substring(driver.indexOf(":") + 1, driver.lastIndexOf(":"));
            instance = driver.substring(driver.lastIndexOf(":") + 1);
        }

        String user = node.get(1).getTextContent();
        String password = node.get(2).getTextContent();
//		logger.info("JDBC User: "+user);
//		logger.info("JDBC Password: "+password);

        connection.setAttribute("host", host);
        connection.setAttribute("user", user);
        connection.setAttribute("password", password);
        connection.setAttribute("instance", instance);
        connection.setAttribute("port", port);
        mulesoftActivity = "Database Configuration";
    	List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
        for (TMReferences tm : constantTimeList) {
       	 constant_manualTime = tm.getManualTime();
       	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
        }

        activityOps.addToDo(accelerator, "Jdbc Connection", resourceName, -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
        
        config.appendChild(connection);
        tDoc.getFirstChild().insertBefore(config, tDoc.getElementsByTagName("flow").item(0));
    }

    public void addJmsConfigTag(Accelerator accelerator, Document tDoc, String resourceName, String sharedXslt, ActivityOps activityOps)
            throws SQLException, ParserConfigurationException, SAXException, IOException {

        resourceName = resourceName.substring(resourceName.lastIndexOf("/") + 1, resourceName.indexOf("."))
                .replaceAll(" ", "_");
        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:jms") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:jms", "http://www.mulesoft.org/schema/mule/jms");
            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/jms http://www.mulesoft.org/schema/mule/jms/current/mule-jms.xsd";
            mule.setAttribute("xsi:schemaLocation", schemaLocation);
            // create driver depencency in pom.xml
        }
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Node sharedNode = docBuilder.parse(new InputSource(new StringReader(sharedXslt))).getDocumentElement();
        boolean useJNDI = false;
        Element jmsconfig = tDoc.createElement("jms:config");
        Element jmsGenericConnection = tDoc.createElement("jms:generic-connection");
        Element jmsConnectionFactory = tDoc.createElement("jms:connection-factory");
        Element jmsJndiConnectionFactory = tDoc.createElement("jms:jndi-connection-factory");
        Element jmsNameResolverBuilder = tDoc.createElement("jms:name-resolver-builder");

        jmsconfig.setAttribute("name", resourceName);
        jmsconfig.setAttribute("doc:name", resourceName);
        jmsconfig.setAttribute("doc:id", accelerator.generateRandom(8) + "-91ee-4acd-b62e-9317139d9ff7");
        jmsGenericConnection.setAttribute("specification", "JMS_2_0");
        jmsJndiConnectionFactory.setAttribute("connectionFactoryJndiName", "ConnectionFactory");

        ArrayList<Node> node = new ArrayList<>();
        accelerator.getNode(sharedNode.getChildNodes(), 0, node, "UseJNDI");
        accelerator.getNode(sharedNode.getChildNodes(), 0, node, "NamingInitialContextFactory");
        accelerator.getNode(sharedNode.getChildNodes(), 0, node, "NamingURL");
        accelerator.getNode(sharedNode.getChildNodes(), 0, node, "username");
        accelerator.getNode(sharedNode.getChildNodes(), 0, node, "password");
        accelerator.getNode(sharedNode.getChildNodes(), 0, node, "clientID");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("UseJNDI") && n.getTextContent().contentEquals("true")) {
                useJNDI = true;
            }
            if (useJNDI) {
                if (n.getNodeName().contentEquals("NamingInitialContextFactory")) {
                    jmsNameResolverBuilder.setAttribute("jndiInitialContextFactory", n.getTextContent());
                }
                if (n.getNodeName().contentEquals("NamingURL")) {
                    jmsNameResolverBuilder.setAttribute("jndiProviderUrl", n.getTextContent());
                }
            }
            if (n.getNodeName().contentEquals("username")) {
                jmsGenericConnection.setAttribute("username", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("password")) {
                jmsGenericConnection.setAttribute("password", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("clientID")) {
                jmsGenericConnection.setAttribute("clientId", n.getTextContent());
            }
        }
        mulesoftActivity = "JMS Configuration";
        List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
        for (TMReferences tm : constantTimeList) {
       	 constant_manualTime = tm.getManualTime();
       	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
        }

        
        activityOps.addToDo(accelerator, "JMS Connection", resourceName, -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
        
        jmsJndiConnectionFactory.appendChild(jmsNameResolverBuilder);
        jmsConnectionFactory.appendChild(jmsJndiConnectionFactory);
        jmsGenericConnection.appendChild(jmsConnectionFactory);
        jmsconfig.appendChild(jmsGenericConnection);
        tDoc.getFirstChild().insertBefore(jmsconfig, tDoc.getElementsByTagName("flow").item(0));
    }

    
    public void addFileConfigTag(Accelerator accelerator, Document tDoc, String resourceName, FlowOps flowOps, ActivityOps activityOps)
            throws ParserConfigurationException, SAXException, IOException {

        File globalElements = new File(
                accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                        + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml");

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);

            // create driver depencency in pom.xml
        }

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

        Document tDocGlobal = docBuilder.parse(
                new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                        + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));
        accelerator.removeBlankLines(tDocGlobal);

        if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
            Element mule = (Element) tDocGlobal.getFirstChild();
            mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);

            // create driver depencency in pom.xml
        }

        if (!nonSharedConnections.contains("File_config1")) {
            Element config = tDocGlobal.createElement("file:config");
            config.setAttribute("name", "File_config1");
            config.setAttribute("doc:name", "File config");
            config.setAttribute("doc:id", accelerator.generateRandom(8) + "-cc1e-44ea-8a3d-d56cb1a380a5");

            tDocGlobal.getFirstChild().insertBefore(config, tDocGlobal.getElementsByTagName("flow").item(0));
            String firstReplacement = "${";
            String lastReplacement = "}";
            retrieveOps.replaceAttributeValues(tDocGlobal.getDocumentElement(), firstReplacement, lastReplacement);
            accelerator.writeFile(tDocGlobal,
                    new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                            + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));
            nonSharedConnections.add("File_config1");

            mulesoftActivity = "File Configuration";
            List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
            for (TMReferences tm : constantTimeList) {
           	 constant_manualTime = tm.getManualTime();
           	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
            }
            activityOps.addToDo(accelerator, "File Connection", "File_config1", -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
            
            
            flowOps.conTypes.add("File configuration");
            flowOps.conNames.add("File config");
            flowOps.fileNames.add(globalElements.getAbsolutePath());
        }
    }

    public void addHttpListenerConfigTag(Accelerator accelerator, Document tDoc, String resourceName, String sharedXslt, ActivityOps activityOps)
            throws SQLException, ParserConfigurationException, SAXException, IOException {

        String host = "0.0.0.0", port = "8080";

        resourceName = resourceName.substring(resourceName.lastIndexOf("/") + 1, resourceName.indexOf("."))
                .replaceAll(" ", "_");

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:http") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:http", "http://www.mulesoft.org/schema/mule/http");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Node sharedNode = docBuilder.parse(new InputSource(new StringReader(sharedXslt))).getDocumentElement();

        Element httpListenerConfig = tDoc.createElement("http:listener-config");
        Element httplistenerconnection = tDoc.createElement("http:listener-connection");

        httpListenerConfig.setAttribute("doc:name", resourceName);
        httpListenerConfig.setAttribute("doc:id", accelerator.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
        httpListenerConfig.setAttribute("name", resourceName);

        ArrayList<Node> node = new ArrayList<>();
        accelerator.getNode(sharedNode.getChildNodes(), 0, node, "Host");
        accelerator.getNode(sharedNode.getChildNodes(), 0, node, "Port");

        for (int i = 0; i < node.size(); i++) {

            if (node.get(i).getNodeName().contentEquals("Host")) {
                host = node.get(i).getTextContent();
            }
            if (node.get(i).getNodeName().contentEquals("Port")) {
                port = node.get(i).getTextContent();
            }
        }

        httplistenerconnection.setAttribute("host", host);
        httplistenerconnection.setAttribute("port", port);

        mulesoftActivity = "HTTP Listener Configuration";
        List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
        for (TMReferences tm : constantTimeList) {
       	 constant_manualTime = tm.getManualTime();
       	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
        }
        activityOps.addToDo(accelerator, "HTTP Listener Connection", resourceName, -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
        
        
        httpListenerConfig.appendChild(httplistenerconnection);

        tDoc.getFirstChild().insertBefore(httpListenerConfig, tDoc.getElementsByTagName("flow").item(0));
    }

    public void addHttpRequestConfigTag(Accelerator accelerator, Document tDoc, String host, String port,
                                        int httpRequestCount, FlowOps flowOps, ActivityOps activityOps) throws SQLException, ParserConfigurationException, SAXException, IOException {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:http") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:http", "http://www.mulesoft.org/schema/mule/http");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

        Document tDocGlobal = docBuilder.parse(
                new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                        + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));
        accelerator.removeBlankLines(tDocGlobal);

        if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:http") == null) {
            Element mule = (Element) tDocGlobal.getFirstChild();
            mule.setAttribute("xmlns:http", "http://www.mulesoft.org/schema/mule/http");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        if (!nonSharedConnections.contains("HTTP_Request_configuration" + httpRequestCount)) {

            File globalElements = new File(
                    accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                            + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml");

            Element httpRequestConfig = tDocGlobal.createElement("http:request-config");
            Element httpRequestConnection = tDocGlobal.createElement("http:request-connection");

            httpRequestConfig.setAttribute("doc:name", "HTTP Request configuration");
            httpRequestConfig.setAttribute("doc:id", accelerator.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
            httpRequestConfig.setAttribute("name", "HTTP_Request_configuration" + httpRequestCount);

            httpRequestConnection.setAttribute("host", host);
            httpRequestConnection.setAttribute("port", port);

            
            httpRequestConfig.appendChild(httpRequestConnection);

            tDocGlobal.getFirstChild().insertBefore(httpRequestConfig, tDocGlobal.getElementsByTagName("flow").item(0));
            String firstReplacement = "${";
            String lastReplacement = "}";
            retrieveOps.replaceAttributeValues(tDocGlobal.getDocumentElement(), firstReplacement, lastReplacement);
            accelerator.writeFile(tDocGlobal,
                    new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                            + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));

            nonSharedConnections.add("HTTP_Request_configuration" + httpRequestCount);


            mulesoftActivity = "HTTP Request Configuration";
            List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
            for (TMReferences tm : constantTimeList) {
           	 constant_manualTime = tm.getManualTime();
           	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
            }
            activityOps.addToDo(accelerator, "HTTP Request Connection", "HTTP_Request_configuration" + httpRequestCount, -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
            
            
            flowOps.conTypes.add("HTTP Request configuration");
            flowOps.conNames.add("HTTP Request configuration" + httpRequestCount);
            flowOps.fileNames.add(globalElements.getAbsolutePath());
        }
    }

    public void addFtpConfigTag(Accelerator accelerator, Document tDoc, String resourceName, String sharedXslt, ActivityOps activityOps)
            throws SQLException {

        try {

            resourceName = resourceName.substring(resourceName.lastIndexOf("/") + 1, resourceName.indexOf("."))
                    .replaceAll(" ", "_");

            if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:ftp") == null) {
                Element mule = (Element) tDoc.getFirstChild();
                mule.setAttribute("xmlns:ftp", "http://www.mulesoft.org/schema/mule/ftp");

                String schemaLocation = mule.getAttribute("xsi:schemaLocation");
                schemaLocation += " http://www.mulesoft.org/schema/mule/ftp http://www.mulesoft.org/schema/mule/ftp/current/mule-ftp.xsd";

                mule.setAttribute("xsi:schemaLocation", schemaLocation);
            }

            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

            Node sharedNode = docBuilder.parse(new InputSource(new StringReader(sharedXslt))).getDocumentElement();

            Element ftpConfig = tDoc.createElement("ftp:config");
            Element ftpConnection = tDoc.createElement("ftp:connection");

            ftpConfig.setAttribute("doc:name", resourceName);
            ftpConfig.setAttribute("name", resourceName);
            ftpConfig.setAttribute("doc:id", accelerator.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");

            ArrayList<Node> node = new ArrayList<>();
            accelerator.getNode(sharedNode.getChildNodes(), 0, node, "Host");
            accelerator.getNode(sharedNode.getChildNodes(), 0, node, "Port");
            accelerator.getNode(sharedNode.getChildNodes(), 0, node, "UserName");
            accelerator.getNode(sharedNode.getChildNodes(), 0, node, "Timeout");
            accelerator.getNode(sharedNode.getChildNodes(), 0, node, "Password");
            accelerator.getNode(sharedNode.getChildNodes(), 0, node, "Encoding");
            accelerator.getNode(sharedNode.getChildNodes(), 0, node, "Mode");

            for (int i = 0; i < node.size(); i++) {
                if (node.get(i).getNodeName().contentEquals("Host")) {
                    ftpConnection.setAttribute("host", node.get(i).getTextContent());
                }
                if (node.get(i).getNodeName().contentEquals("Port")) {
                    ftpConnection.setAttribute("port", node.get(i).getTextContent());
                }
                if (node.get(i).getNodeName().contentEquals("UserName")) {
                    ftpConnection.setAttribute("username", node.get(i).getTextContent());
                }
                if (node.get(i).getNodeName().contentEquals("Timeout")) {
                    ftpConnection.setAttribute("connectionTimeout", node.get(i).getTextContent());
                }
                if (node.get(i).getNodeName().contentEquals("Password")) {
                    ftpConnection.setAttribute("password", node.get(i).getTextContent());
                }
                if (node.get(i).getNodeName().contentEquals("Encoding")) {
                    ftpConnection.setAttribute("controlEncoding", node.get(i).getTextContent());
                }
                if (node.get(i).getNodeName().contentEquals("Mode")) {
                    if (node.get(i).getTextContent().contentEquals("Passive")) {
                        ftpConnection.setAttribute("passive", "true");
                    } else {
                        ftpConnection.setAttribute("passive", "false");
                    }
                }
            }
            
            
            mulesoftActivity = "FTP Configuration";
            List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
            for (TMReferences tm : constantTimeList) {
           	 constant_manualTime = tm.getManualTime();
           	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
            }
            activityOps.addToDo(accelerator, "FTP Connection", resourceName, -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
            
            

            ftpConfig.appendChild(ftpConnection);

            tDoc.getFirstChild().insertBefore(ftpConfig, tDoc.getElementsByTagName("flow").item(0));
        } catch (SAXException | IOException e) {
            // TODO Auto-generated catch block
            logger.error("An error occurred: " + e.getMessage());
        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            logger.error("An error occurred: " + e.getMessage());
        }

    }

    public void addObjectStoreConfigTag(Accelerator accelerator, Document tDoc, String resourceName, String sharedXslt, ActivityOps activityOps)
            throws SQLException, ParserConfigurationException, SAXException, IOException {

        resourceName = resourceName.substring(resourceName.lastIndexOf("/") + 1, resourceName.indexOf("."))
                .replaceAll(" ", "_");

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:os") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:os", "http://www.mulesoft.org/schema/mule/os");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/os  http://www.mulesoft.org/schema/mule/os/current/mule-os.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

        Node sharedNode = docBuilder.parse(new InputSource(new StringReader(sharedXslt))).getDocumentElement();

        Element storeConfig = tDoc.createElement("os:object-store");
        storeConfig.setAttribute("name", resourceName);

        storeConfig.setAttribute("doc:name", resourceName);
        storeConfig.setAttribute("doc:id", accelerator.generateRandom(8) + "-cc1e-44ea-8a3d-d56cb1a380a5");

        ArrayList<Node> node = new ArrayList<>();
        accelerator.getNode(sharedNode.getChildNodes(), 0, node, "persistent");
        accelerator.getNode(sharedNode.getChildNodes(), 0, node, "initialValue");
        accelerator.getNode(sharedNode.getChildNodes(), 0, node, "initialValueRef");
        for (Node n : node) {

            if (n.getNodeName().contentEquals("persistent")) {
                storeConfig.setAttribute("persistent", n.getTextContent().equals("true") ? "true" : "false");

            }
        }
        
        mulesoftActivity = "ObjectStore Configuration";
        List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
        for (TMReferences tm : constantTimeList) {
       	 constant_manualTime = tm.getManualTime();
       	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
        }
        activityOps.addToDo(accelerator, "ObjectStore Connection", resourceName, -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
        
        
        tDoc.getFirstChild().insertBefore(storeConfig, tDoc.getElementsByTagName("flow").item(0));

    }

    public String addWebServiceConfigTag(Accelerator accelerator, String acName, Document tDoc, Node acNode,
                                         ArrayList<Node> node, ActivityOps activityOps) throws SQLException, ParserConfigurationException, SAXException, IOException {
        String wsdlName = null;
        String wsdlLocation = null;
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Document tDocGlobal = docBuilder.parse(
                new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                        + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));
        accelerator.removeBlankLines(tDocGlobal);
        if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:wsc") == null) {
            Element mule = (Element) tDocGlobal.getFirstChild();
            mule.setAttribute("xmlns:wsc", "http://www.mulesoft.org/schema/mule/wsc");
            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/wsc http://www.mulesoft.org/schema/mule/wsc/current/mule-wsc.xsd";
            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        Element webServiceConfig = tDocGlobal.createElement("wsc:config");
        Element webServiceConnConfig = tDocGlobal.createElement("wsc:connection");
        Element webServiceSecurityConfig = tDocGlobal.createElement("wsc:web-service-security");

        webServiceConfig.setAttribute("doc:name", "Web Service Consumer Config");
        webServiceConfig.setAttribute("doc:id", accelerator.generateRandom(8) + "-cc1e-44ea-8a3d-d56cb1a380a5");
        node.removeAll(node);
        accelerator.getNode(acNode.getChildNodes(), 0, node, "service");
        accelerator.getNode(acNode.getChildNodes(), 0, node, "servicePort");
        accelerator.getNode(acNode.getChildNodes(), 0, node, "endpointURL");
        accelerator.getNode(acNode.getChildNodes(), 0, node, "soapAction");
        accelerator.getNode(acNode.getChildNodes(), 0, node, "wsdlNamespaceRoot");
        String serviceName = "";
        String wsdlNameRoot = "";
        byte[] processFileContent = new byte[0];
        for (int i = 0; i < node.size(); i++) {
            if (node.get(i).getNodeName().contentEquals("soapAction")) {
                serviceName = node.get(i).getTextContent();
            }
            if (node.get(i).getNodeName().contentEquals("service")) {
                webServiceConnConfig.setAttribute("service", node.get(i).getTextContent());
            }
            if (node.get(i).getNodeName().contentEquals("servicePort")) {
                webServiceConnConfig.setAttribute("port", node.get(i).getTextContent());
            }
            if (node.get(i).getNodeName().contentEquals("endpointURL")) {
                webServiceConnConfig.setAttribute("address", node.get(i).getTextContent());
            }
        }
        if (serviceName.contains(".serviceagent")) {
            serviceName = serviceName.substring(0, serviceName.indexOf(".serviceagent") + 13);
            serviceName = serviceName.substring(serviceName.lastIndexOf("/") + 1);

            List<com.sme.dao.entity.SharedConnections> sharedConnections = jdbc.getSharedConfig(serviceName);
            String agentConfig = null;
            if (!sharedConnections.isEmpty()) {
                agentConfig = new String(sharedConnections.get(sharedConnections.size() - 1).getSharedConfig(),
                        StandardCharsets.UTF_8);
            }
            if (agentConfig != null) {
                ByteArrayInputStream input = new ByteArrayInputStream(agentConfig.getBytes("UTF-8"));
                Document agentDoc = docBuilder.parse(input);
                accelerator.removeBlankLines(agentDoc);

                ArrayList<Node> node1 = new ArrayList<>();

                accelerator.getNode(agentDoc.getChildNodes(), 0, node1, "wsdlDetail");
                wsdlName = node1.get(0).getAttributes().getNamedItem("location").getNodeValue();
                wsdlName = wsdlName.substring(wsdlName.lastIndexOf("/") + 1);

                sharedConnections = jdbc.getSharedConfig(wsdlName);

                for (com.sme.dao.entity.SharedConnections rs : sharedConnections) {
                    String wsdl_config = new String(rs.getSharedConfig(), StandardCharsets.UTF_8);
                    Files.writeString(
                            new File(accelerator.getTrgProjectDir()
                                    + File.separator + "src" + File.separator
                                    + "main" + File.separator + "resources" + File.separator + "api"
                                    + File.separator + wsdlName).toPath(),
                            wsdl_config);
                    webServiceConnConfig.setAttribute("wsdlLocation", wsdlName);
//					logger.info("File Updation : "+wsdlName);
                }

                webServiceConfig.setAttribute("name", wsdlName.substring(0, wsdlName.indexOf(".")));

            } else {
                for (int i = 0; i < node.size(); i++) {
                    if (node.get(i).getNodeName().contentEquals("soapAction")) {
                        webServiceConnConfig.setAttribute("wsdlLocation", node.get(i).getTextContent());
                    }
                    webServiceConfig.setAttribute("name", acName + "_config");
                }
            }
        } else {

            serviceName = serviceName.substring(serviceName.lastIndexOf("/") + 1);

            for (Node n : node) {
                if (n.getNodeName().contentEquals("wsdlNamespaceRoot")) {
                    wsdlNameRoot = n.getTextContent();
                    wsdlNameRoot = wsdlNameRoot.substring(0, wsdlNameRoot.lastIndexOf("/"));
                }
            }

            // trial start

            List<ConfigFiles> configFilesList = jdbc.getConfigsProcess(retrieveOps.getProcessName());
            if (!configFilesList.isEmpty()) {
                processFileContent = configFilesList.get(0).getConfig();
            }
            ByteArrayInputStream input = new ByteArrayInputStream(processFileContent);
            Document processDoc = docBuilder.parse(input);
            accelerator.removeBlankLines(processDoc);
            ArrayList<Node> node1 = new ArrayList<>();
            accelerator.getNode(processDoc.getChildNodes(), 0, node1, "wsdl:import");
            for (Node n1 : node1) {
                if (n1.getNodeName().contentEquals("wsdl:import")) {
                    if (n1.getAttributes().getNamedItem("namespace").getNodeValue().contentEquals(wsdlNameRoot)
                            || n1.getAttributes().getNamedItem("namespace").getNodeValue().contains("http")) {
                        wsdlLocation = n1.getAttributes().getNamedItem("location").getNodeValue();
                        wsdlLocation = wsdlLocation.substring(wsdlLocation.lastIndexOf("/") + 1, wsdlLocation.length());
                    }
                }
            }
            webServiceConfig.setAttribute("wsdlLocation", wsdlLocation);

            webServiceConfig.setAttribute("name", wsdlLocation.substring(0, wsdlLocation.lastIndexOf(".")));
            // trail end

//				for(int i=0; i<node.size(); i++) {
//				if(node.get(i).getNodeName().contentEquals("soapAction")) {
//					webServiceConnConfig.setAttribute("wsdlLocation", node.get(i).getTextContent());
//				}
//				webServiceConfig.setAttribute("name",acName+"_config");
//				}
        }

        mulesoftActivity = "Soap web Consume Configuration";
        List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
        for (TMReferences tm : constantTimeList) {
       	 constant_manualTime = tm.getManualTime();
       	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
        }
        activityOps.addToDo(accelerator, "Soap web Consume Connection", acName + "_config", -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
        
        
        
        webServiceConfig.appendChild(webServiceConnConfig);
        webServiceConnConfig.appendChild(webServiceSecurityConfig);

        if (!retrieveOps.sharedConfigs.contains(wsdlName)) {
            tDocGlobal.getFirstChild().insertBefore(webServiceConfig, tDocGlobal.getElementsByTagName("flow").item(0));
            retrieveOps.sharedConfigs.add(wsdlName);
        }
        tDocGlobal.getFirstChild().insertBefore(webServiceConfig, tDocGlobal.getElementsByTagName("flow").item(0));
        String firstReplacement = "${";
        String lastReplacement = "}";
        retrieveOps.replaceAttributeValues(tDocGlobal.getDocumentElement(), firstReplacement, lastReplacement);
        accelerator.writeFile(tDocGlobal,
                new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                        + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));

        if (wsdlName != null) {
            return wsdlName.substring(0, wsdlName.lastIndexOf("."));
        } else if (wsdlLocation != null) {
            return wsdlLocation.substring(0, wsdlLocation.lastIndexOf("."));
        } else {
            return acName + "_config";
        }

    }

    public String addAPIKITforSoapConfigTag(Accelerator accelerator, Document tDoc, Node acNode, ArrayList<Node> node, ActivityOps activityOps)
            throws SQLException, ParserConfigurationException, SAXException, IOException {

        String wsdlName = null;

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Document tDocGlobal = docBuilder.parse(
                new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                        + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));
        accelerator.removeBlankLines(tDocGlobal);

        Element apiKitSoapConfig = tDocGlobal.createElement("apikit-soap:config");

        if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:apikit-soap") == null) {
            Element mule = (Element) tDocGlobal.getFirstChild();
            mule.setAttribute("xmlns:apikit-soap", "http://www.mulesoft.org/schema/mule/apikit-soap");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/apikit-soap http://www.mulesoft.org/schema/mule/apikit-soap/current/mule-apikit-soap.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        apiKitSoapConfig.setAttribute("doc:name", "APIKit for SOAP Configuration");
        apiKitSoapConfig.setAttribute("doc:id", accelerator.generateRandom(8) + "-cc1e-44ea-8a3d-d56cb1a380a5");
        apiKitSoapConfig.setAttribute("soapVersion", "SOAP11");

        node.removeAll(node);
        accelerator.getNode(acNode.getChildNodes(), 0, node, "service");
        accelerator.getNode(acNode.getChildNodes(), 0, node, "servicePort");
        accelerator.getNode(acNode.getChildNodes(), 0, node, "endpointURL");
        accelerator.getNode(acNode.getChildNodes(), 0, node, "wsdlNamespaceRoot");
        accelerator.getNode(acNode.getChildNodes(), 0, node, "soapAction");

        String serviceName = "";
        String wsdlNameRoot = "";
        String agentConfig = "";
        byte[] processFileContent = new byte[0];
        for (Node n : node) {
            if (n.getNodeName().contentEquals("soapAction")) {
                serviceName = n.getTextContent();
            }
        }

        if (serviceName.contains(".serviceagent")) {

            serviceName = serviceName.substring(0, serviceName.indexOf(".serviceagent") + 13);
            serviceName = serviceName.substring(serviceName.lastIndexOf("/") + 1);

            List<com.sme.dao.entity.SharedConnections> sharedConnections = jdbc.getSharedConfig(serviceName);
            if (!sharedConnections.isEmpty()) {
                agentConfig = new String(sharedConnections.get(sharedConnections.size() - 1).getSharedConfig(),
                        StandardCharsets.UTF_8);
            }
            ByteArrayInputStream input = new ByteArrayInputStream(agentConfig.getBytes("UTF-8"));
            Document agentDoc = docBuilder.parse(input);
            accelerator.removeBlankLines(agentDoc);

            ArrayList<Node> node1 = new ArrayList<>();

            accelerator.getNode(agentDoc.getChildNodes(), 0, node1, "wsdlDetail");
            wsdlName = node1.get(0).getAttributes().getNamedItem("location").getNodeValue();
            wsdlName = wsdlName.substring(wsdlName.lastIndexOf("/") + 1);
            apiKitSoapConfig.setAttribute("wsdlLocation", wsdlName);
            if (!retrieveOps.sharedConfigs.contains(wsdlName)) {
                tDocGlobal.getFirstChild().insertBefore(apiKitSoapConfig,
                        tDocGlobal.getElementsByTagName("flow").item(0));
                retrieveOps.sharedConfigs.add(wsdlName);
            }
            apiKitSoapConfig.setAttribute("name", wsdlName.substring(0, wsdlName.lastIndexOf(".")));
            tDocGlobal.getFirstChild().insertBefore(apiKitSoapConfig, tDocGlobal.getElementsByTagName("flow").item(0));
            
            mulesoftActivity = "Soap APIKIT router Configuration";
            List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
            for (TMReferences tm : constantTimeList) {
           	 constant_manualTime = tm.getManualTime();
           	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
            }
            activityOps.addToDo(accelerator, "Soap APIKIT router Connection", wsdlName.substring(0, wsdlName.lastIndexOf(".")) + "_config", -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
            

            
            String firstReplacement = "${";
            String lastReplacement = "}";
            retrieveOps.replaceAttributeValues(tDocGlobal.getDocumentElement(), firstReplacement, lastReplacement);
            accelerator.writeFile(tDocGlobal,
                    new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                            + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));
            return wsdlName.substring(0, wsdlName.lastIndexOf("."));
        } else {

            serviceName = serviceName.substring(serviceName.lastIndexOf("/") + 1);

            for (Node n : node) {
                if (n.getNodeName().contentEquals("wsdlNamespaceRoot")) {
                    wsdlNameRoot = n.getTextContent();
                    wsdlNameRoot = wsdlNameRoot.substring(0, wsdlNameRoot.lastIndexOf("/"));
                }
            }
            // trial start
            String wsdlLocation = "";
            List<ConfigFiles> configFilesList = jdbc.getConfigsProcess(retrieveOps.getProcessName());
            if (!configFilesList.isEmpty()) {
                processFileContent = configFilesList.get(0).getConfig();
            }

            ByteArrayInputStream input = new ByteArrayInputStream(processFileContent);
            Document processDoc = docBuilder.parse(input);
            accelerator.removeBlankLines(processDoc);
            ArrayList<Node> node1 = new ArrayList<>();
            accelerator.getNode(processDoc.getChildNodes(), 0, node1, "wsdl:import");
            for (Node n1 : node1) {
                if (n1.getNodeName().contentEquals("wsdl:import")) {
                    if (n1.getAttributes().getNamedItem("namespace").getNodeValue().contentEquals(wsdlNameRoot)) {
                        wsdlLocation = n1.getAttributes().getNamedItem("location").getNodeValue();
                        wsdlLocation = wsdlLocation.substring(wsdlLocation.lastIndexOf("/") + 1, wsdlLocation.length());
                    }
                }
            }
            apiKitSoapConfig.setAttribute("wsdlLocation", wsdlLocation);

            apiKitSoapConfig.setAttribute("name", wsdlLocation.substring(0, wsdlLocation.lastIndexOf(".")));

            // trail end

//			
//			ResultSet rs1 = Accelerator.jdbc.getWsdls();
//			
//			while(rs1.next()) {
//				
//				agentConfigName = rs1.getString("SHARED_NAME");
//				agentConfig = rs1.getString("SHARED_CONFIG");
//				ByteArrayInputStream input = new ByteArrayInputStream(agentConfig.getBytes("UTF-8")); 
//				Document agentDoc = docBuilder.parse(input); 
//				accelerator.removeBlankLines(agentDoc);
//				ArrayList<Node> node1 = new ArrayList<>();
//				accelerator.getNode(agentDoc.getChildNodes(), 0, node1, "wsdl:definitions");
//				accelerator.getNode(agentDoc.getChildNodes(), 0, node1, "definitions");
//				for(Node n1 : node1) {
//					if(n1.getNodeName().contentEquals("wsdl:definitions") || n1.getNodeName().contentEquals("definitions")) {
//						String wsdlNameSpace = n1.getAttributes().getNamedItem("xmlns:tns").getNodeValue();
//						if(wsdlNameSpace.contentEquals(wsdlNameRoot)) {
//							apiKitSoapConfig.setAttribute("wsdlLocation", agentConfigName);
//							if(!RetrieveOps.sharedConfigs.contains(agentConfigName)) {
//								tDocGlobal.getFirstChild().insertBefore(apiKitSoapConfig,tDocGlobal.getElementsByTagName("flow").item(0));
//								RetrieveOps.sharedConfigs.add(agentConfigName);
//							}
//							apiKitSoapConfig.setAttribute("name",agentConfigName.substring(0,agentConfigName.lastIndexOf(".")));
//						}
//					}
//				}
//			 }
//			rs1.close();
//		
            
            
            mulesoftActivity = "Soap APIKIT router Configuration";
            List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
            for (TMReferences tm : constantTimeList) {
           	 constant_manualTime = tm.getManualTime();
           	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
            }
            activityOps.addToDo(accelerator, "Soap APIKIT router Connection", wsdlLocation.substring(0, wsdlLocation.lastIndexOf(".")) + "_config", -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
            

            tDocGlobal.getFirstChild().insertBefore(apiKitSoapConfig, tDocGlobal.getElementsByTagName("flow").item(0));
            String firstReplacement = "${";
            String lastReplacement = "}";
            retrieveOps.replaceAttributeValues(tDocGlobal.getDocumentElement(), firstReplacement, lastReplacement);
            accelerator.writeFile(tDocGlobal,
                    new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                            + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));

            // return agentConfigName.substring(0,agentConfigName.lastIndexOf("."));
            return wsdlLocation.substring(0, wsdlLocation.lastIndexOf("."));

        }

    }

    public void apikitConfigTag(Accelerator accelerator, Document tDoc, Node acNode, RestActivities restActivities, ActivityOps activityOps)
            throws ParserConfigurationException, SAXException, IOException {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:apikit") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:apikit", "http://www.mulesoft.org/schema/mule/mule-apikit");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/mule-apikit http://www.mulesoft.org/schema/mule/mule-apikit/current/mule-apikit.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

        Document tDocGlobal = docBuilder.parse(
                new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                        + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));
        accelerator.removeBlankLines(tDocGlobal);

        if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:apikit") == null) {
            Element mule = (Element) tDocGlobal.getFirstChild();
            mule.setAttribute("xmlns:apikit", "http://www.mulesoft.org/schema/mule/mule-apikit");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/mule-apikit http://www.mulesoft.org/schema/mule/mule-apikit/current/mule-apikit.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        if (!nonSharedConnections.contains("Router" + restActivities.apikitConfigCount)) {

            Element apikitConfig = tDocGlobal.createElement("apikit:config");

            apikitConfig.setAttribute("doc:id", accelerator.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
            apikitConfig.setAttribute("name", "Router" + restActivities.apikitConfigCount);
            apikitConfig.setAttribute("doc:name", "Router");
            apikitConfig.setAttribute("api", "api\\api.raml");
            apikitConfig.setAttribute("outboundHeadersMapName", "outboundHeadersMapName");
            apikitConfig.setAttribute("httpStatusVarName", "httpStatus");

            mulesoftActivity = "Rest APIKIT router Configuration";
            List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
            for (TMReferences tm : constantTimeList) {
           	 constant_manualTime = tm.getManualTime();
           	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
            }
            activityOps.addToDo(accelerator, "Rest APIKIT router Connection", "Router" + restActivities.apikitConfigCount, -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
            
            
            
            tDocGlobal.getFirstChild().insertBefore(apikitConfig, tDocGlobal.getElementsByTagName("flow").item(0));
            String firstReplacement = "${";
            String lastReplacement = "}";
            retrieveOps.replaceAttributeValues(tDocGlobal.getDocumentElement(), firstReplacement, lastReplacement);
            accelerator.writeFile(tDocGlobal,
                    new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                            + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));
            nonSharedConnections.add("Router" + restActivities.apikitConfigCount);
        }
    }

    public void addRestHttpRequestConfigTag(Accelerator accelerator, Document tDoc, Node acNode, RestActivities restActivities, ActivityOps activityOps)
            throws ParserConfigurationException, SAXException, IOException {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:http") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:http", "http://www.mulesoft.org/schema/mule/http");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

        Document tDocGlobal = docBuilder.parse(
                new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                        + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));
        accelerator.removeBlankLines(tDocGlobal);

        if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:http") == null) {
            Element mule = (Element) tDocGlobal.getFirstChild();
            mule.setAttribute("xmlns:http", "http://www.mulesoft.org/schema/mule/http");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        if (!nonSharedConnections.contains("Rest_HTTP_Request_configuration" + restActivities.restHttpRequestCount)) {

            Element httpRequestConfig = tDocGlobal.createElement("http:request-config");
            Element httpRequestConnection = tDocGlobal.createElement("http:request-connection");

            String enableProtocolUI = "";

            httpRequestConfig.setAttribute("doc:name", "HTTP Request configuration");
            httpRequestConfig.setAttribute("doc:id", accelerator.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
            httpRequestConfig.setAttribute("name",
                    "Rest_HTTP_Request_configuration" + restActivities.restHttpRequestCount);

            ArrayList<Node> node = new ArrayList<>();
            accelerator.getNode(acNode.getChildNodes(), 0, node, "enableProtocolUI");
            accelerator.getNode(acNode.getChildNodes(), 0, node, "restURI");

            for (Node n : node) {
                if (n.getNodeName().contentEquals("enableProtocolUI")) {
                    if (n.getTextContent().contentEquals("None")) {
                        enableProtocolUI = "None";
                    }
                    if (n.getTextContent().contentEquals("WADL")) {
                        enableProtocolUI = "WADL";
                    }
                    if (n.getTextContent().contentEquals("Swagger")) {
                        enableProtocolUI = "Swagger";
                    }
                }
                if (n.getNodeName().contentEquals("restURI")) {

                    if (enableProtocolUI.contentEquals("None")) {
                        String url = n.getTextContent();
                        int startIndex = url.indexOf("//") + 2;
                        int endIndex = url.indexOf("/", startIndex);
                        String value = url.substring(startIndex, endIndex);
                        int colonIndex = value.indexOf(":");
                        httpRequestConnection.setAttribute("host", value.substring(0, colonIndex));
                        httpRequestConnection.setAttribute("port", value.substring(colonIndex + 1));
                    }

                    if (enableProtocolUI.contentEquals("WADL")) {
                        String url = n.getTextContent();
                        int startIndex = url.indexOf("//") + 2;
                        int endIndex = url.indexOf("/", startIndex);
                        String value = url.substring(startIndex, endIndex);
                        httpRequestConnection.setAttribute("host", value);
                        httpRequestConnection.setAttribute("port", "8080");
                        httpRequestConfig.setAttribute("basePath", url.substring(url.lastIndexOf("/")));
                    }
                    if (enableProtocolUI.contentEquals("Swagger")) {
                        httpRequestConnection.setAttribute("host", "localhost");
                        httpRequestConnection.setAttribute("port", "8080");
                    }

                }
            }
            
            mulesoftActivity = "Rest HTTP Request Configuration";
            List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
            for (TMReferences tm : constantTimeList) {
           	 constant_manualTime = tm.getManualTime();
           	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
            }
            activityOps.addToDo(accelerator, "Rest HTTP Request Connection", "Rest_HTTP_Request_configuration" + restActivities.restHttpRequestCount, -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
            

            httpRequestConfig.appendChild(httpRequestConnection);

            tDocGlobal.getFirstChild().insertBefore(httpRequestConfig, tDocGlobal.getElementsByTagName("flow").item(0));
            String firstReplacement = "${";
            String lastReplacement = "}";
            retrieveOps.replaceAttributeValues(tDocGlobal.getDocumentElement(), firstReplacement, lastReplacement);
            accelerator.writeFile(tDocGlobal,
                    new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                            + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));
            nonSharedConnections.add("Rest_HTTP_Request_configuration" + restActivities.restHttpRequestCount);
        }
    }

    public void addEmailPop3ConfigTag(Accelerator accelerator, Document tDoc, int emailPop3ConfigCount, String host,
                                      String userName, boolean useSsl, ActivityOps activityOps)
            throws SQLException, ParserConfigurationException, SAXException, IOException {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:email") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:email", "http://www.mulesoft.org/schema/mule/email");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/email http://www.mulesoft.org/schema/mule/email/current/mule-email.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

        Document tDocGlobal = docBuilder.parse(
                new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                        + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));
        accelerator.removeBlankLines(tDocGlobal);

        if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:email") == null) {
            Element mule = (Element) tDocGlobal.getFirstChild();
            mule.setAttribute("xmlns:email", "http://www.mulesoft.org/schema/mule/email");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/email http://www.mulesoft.org/schema/mule/email/current/mule-email.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        if (!nonSharedConnections.contains("Email_POP3_" + emailPop3ConfigCount)) {

            if (useSsl) {

                Element emailPop3Config = tDocGlobal.createElement("email:pop3-config");
                Element emailPop3sConnection = tDocGlobal.createElement("email:pop3s-connection");
                Element tlsContext = tDocGlobal.createElement("tls:context");

                emailPop3Config.setAttribute("doc:name", "Email POP3");
                emailPop3Config.setAttribute("doc:id", accelerator.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
                emailPop3Config.setAttribute("name", "Email_POP3_" + emailPop3ConfigCount);

                emailPop3sConnection.setAttribute("host", host);
                emailPop3sConnection.setAttribute("user", userName);
                emailPop3sConnection.setAttribute("password", userName);

                mulesoftActivity = "Email Configuration";
                List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
                for (TMReferences tm : constantTimeList) {
               	 constant_manualTime = tm.getManualTime();
               	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
                }
                activityOps.addToDo(accelerator, "Email Connection", "Email_POP3_" + emailPop3ConfigCount, -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
                
                
                emailPop3sConnection.appendChild(tlsContext);
                emailPop3Config.appendChild(emailPop3sConnection);

                tDocGlobal.getFirstChild().insertBefore(emailPop3Config,
                        tDocGlobal.getElementsByTagName("flow").item(0));
                String firstReplacement = "${";
                String lastReplacement = "}";
                retrieveOps.replaceAttributeValues(tDocGlobal.getDocumentElement(), firstReplacement, lastReplacement);
                accelerator.writeFile(tDocGlobal, new File(
                        accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                                + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));

                nonSharedConnections.add("Email_POP3_" + emailPop3ConfigCount);
            } else {

                Element emailPop3Config = tDocGlobal.createElement("email:pop3-config");
                Element emailPop3Connection = tDocGlobal.createElement("email:pop3-connection");

                emailPop3Config.setAttribute("doc:name", "Email POP3");
                emailPop3Config.setAttribute("doc:id", accelerator.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
                emailPop3Config.setAttribute("name", "Email_POP3_" + emailPop3ConfigCount);

                emailPop3Connection.setAttribute("host", host);
                emailPop3Connection.setAttribute("user", userName);
                emailPop3Connection.setAttribute("password", userName);

                mulesoftActivity = "Email Configuration";
                List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
                for (TMReferences tm : constantTimeList) {
               	 constant_manualTime = tm.getManualTime();
               	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
                }
                activityOps.addToDo(accelerator, "Email Connection", "Email_POP3_" + emailPop3ConfigCount, -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
                
                emailPop3Config.appendChild(emailPop3Connection);

                tDocGlobal.getFirstChild().insertBefore(emailPop3Config,
                        tDocGlobal.getElementsByTagName("flow").item(0));
                String firstReplacement = "${";
                String lastReplacement = "}";
                retrieveOps.replaceAttributeValues(tDocGlobal.getDocumentElement(), firstReplacement, lastReplacement);
                accelerator.writeFile(tDocGlobal, new File(
                        accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                                + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));

                nonSharedConnections.add("Email_POP3_" + emailPop3ConfigCount);
            }
        }
    }

    public void addEmailSMTPConfigTag(Accelerator accelerator, Document tDoc, int emailSmtpConfigCount, String host,
                                      String userName, boolean useSsl, ActivityOps activityOps)
            throws SQLException, ParserConfigurationException, SAXException, IOException {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:email") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:email", "http://www.mulesoft.org/schema/mule/email");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/email http://www.mulesoft.org/schema/mule/email/current/mule-email.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

        Document tDocGlobal = docBuilder.parse(
                new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                        + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));
        accelerator.removeBlankLines(tDocGlobal);

        if (tDocGlobal.getFirstChild().getAttributes().getNamedItem("xmlns:email") == null) {
            Element mule = (Element) tDocGlobal.getFirstChild();
            mule.setAttribute("xmlns:email", "http://www.mulesoft.org/schema/mule/email");

            if (useSsl) {
                mule.setAttribute("xmlns:tls", "http://www.mulesoft.org/schema/mule/tls");
            }

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/email http://www.mulesoft.org/schema/mule/email/current/mule-email.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        if (!nonSharedConnections.contains("Email_SMTP" + emailSmtpConfigCount)) {

            if (useSsl) {

                Element emailSmtpConfig = tDocGlobal.createElement("email:smtp-config");
                Element emailSmtpsConnection = tDocGlobal.createElement("email:smtps-connection");
                Element tlsContext = tDocGlobal.createElement("tls:context");
//				Element tlsTrustStore = tDocGlobal.createElement("tls:trust-store");
//				Element tlsKeyStore = tDocGlobal.createElement("tls:key-store");

                emailSmtpConfig.setAttribute("doc:name", "Email SMTP");
                emailSmtpConfig.setAttribute("doc:id", accelerator.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
                emailSmtpConfig.setAttribute("name", "Email_SMTP" + emailSmtpConfigCount);

                emailSmtpsConnection.setAttribute("host", host);
                emailSmtpsConnection.setAttribute("user", userName);
                emailSmtpsConnection.setAttribute("password", userName);

//				tlsContext.appendChild(tlsTrustStore);
//				tlsContext.appendChild(tlsKeyStore);
                
                mulesoftActivity = "Email SMTP Configuration";
                List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
                for (TMReferences tm : constantTimeList) {
               	 constant_manualTime = tm.getManualTime();
               	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
                }
                activityOps.addToDo(accelerator, "Email SMTP Connection", "Email_SMTP" + emailSmtpConfigCount, -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
                
                
                emailSmtpsConnection.appendChild(tlsContext);
                emailSmtpConfig.appendChild(emailSmtpsConnection);

                tDocGlobal.getFirstChild().insertBefore(emailSmtpConfig,
                        tDocGlobal.getElementsByTagName("flow").item(0));
                String firstReplacement = "${";
                String lastReplacement = "}";
                retrieveOps.replaceAttributeValues(tDocGlobal.getDocumentElement(), firstReplacement, lastReplacement);
                accelerator.writeFile(tDocGlobal, new File(
                        accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                                + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));

                nonSharedConnections.add("Email_SMTP" + emailSmtpConfigCount);
            } else {

                Element emailSmtpConfig = tDocGlobal.createElement("email:smtp-config");
                Element emailSmtpConnection = tDocGlobal.createElement("email:smtp-connection");

                emailSmtpConfig.setAttribute("doc:name", "Email SMTP");
                emailSmtpConfig.setAttribute("doc:id", accelerator.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
                emailSmtpConfig.setAttribute("name", "Email_SMTP" + emailSmtpConfigCount);

                emailSmtpConnection.setAttribute("host", host);
                emailSmtpConnection.setAttribute("user", userName);
                emailSmtpConnection.setAttribute("password", userName);

                mulesoftActivity = "Email SMTP Configuration";
                List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
                for (TMReferences tm : constantTimeList) {
               	 constant_manualTime = tm.getManualTime();
               	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
                }
                activityOps.addToDo(accelerator, "Email SMTP Connection", "Email_SMTP" + emailSmtpConfigCount, -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
                
                
                emailSmtpConfig.appendChild(emailSmtpConnection);

                tDocGlobal.getFirstChild().insertBefore(emailSmtpConfig,
                        tDocGlobal.getElementsByTagName("flow").item(0));
                String firstReplacement = "${";
                String lastReplacement = "}";
                retrieveOps.replaceAttributeValues(tDocGlobal.getDocumentElement(), firstReplacement, lastReplacement);
                accelerator.writeFile(tDocGlobal, new File(
                        accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                                + "main" + File.separator + "mule" + File.separator + "GlobalElements.xml"));

                nonSharedConnections.add("Email_SMTP" + emailSmtpConfigCount);
            }
        }
    }
    

	// salesforce connection configuration
	public void salesforceConfigTag(Accelerator accelerator, Document tDoc, String resourceName, String sharedXslt, ActivityOps activityOps) throws SQLException, ParserConfigurationException, SAXException, IOException {
	resourceName = resourceName.substring(0,resourceName.lastIndexOf(".sharedsalesforce"));
	resourceName= resourceName.replace(" ", "_");
		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:salesforce") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:salesforce", "http://www.mulesoft.org/schema/mule/salesforce");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/salesforce http://www.mulesoft.org/schema/mule/salesforce/current/mule-salesforce.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
		
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

		Node sharedNode = docBuilder.parse(new InputSource(new StringReader(sharedXslt))).getDocumentElement();

		Element sfConn = tDoc.createElement("salesforce:sfdc-config");
		Element sfBasicConn = tDoc.createElement("salesforce:basic-connection");
		sfConn.setAttribute("name", resourceName);
		sfConn.setAttribute("doc:name", "Salesforce Config");
		sfConn.setAttribute("doc:id", accelerator.generateRandom(8) + "-cc1e-44ea-8a3d-d56cb1a380a5");

		ArrayList<Node> node = new ArrayList<>();
		accelerator.getNode(sharedNode.getChildNodes(), 0, node, "UserName");
		accelerator.getNode(sharedNode.getChildNodes(), 0, node, "Password");
		accelerator.getNode(sharedNode.getChildNodes(), 0, node, "ServerURL");

		for (Node n : node) {
			if (n.getNodeName().contentEquals("UserName")) {
				sfBasicConn.setAttribute("username", n.getTextContent());
			}
			if (n.getNodeName().contentEquals("Password")) {
				sfBasicConn.setAttribute("password", n.getTextContent());
			}
			if (n.getNodeName().contentEquals("ServerURL")) {
				sfBasicConn.setAttribute("url", n.getTextContent());
			}
		}
		
		 mulesoftActivity = "Salesforce Configuration";
         List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
         for (TMReferences tm : constantTimeList) {
        	 constant_manualTime = tm.getManualTime();
        	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
         }
         activityOps.addToDo(accelerator, "Salesforce Connection", resourceName, -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
         
         
		
		sfConn.appendChild(sfBasicConn);
		tDoc.getFirstChild().insertBefore(sfConn, tDoc.getElementsByTagName("flow").item(0));
		
		
	}
    public void addAdbConfigTag(Accelerator accelerator, Document tDoc, String resourceName, String sharedXslt, ActivityOps activityOps)
			throws SQLException, ParserConfigurationException, SAXException, IOException {

		resourceName = resourceName.substring(resourceName.lastIndexOf("/") + 1, resourceName.indexOf("."))
				.replaceAll(" ", "_");
		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:jms") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:jms", "http://www.mulesoft.org/schema/mule/jms");
			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/jms http://www.mulesoft.org/schema/mule/jms/current/mule-jms.xsd";
			mule.setAttribute("xsi:schemaLocation", schemaLocation);
			// create driver depencency in pom.xml
		}
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Node sharedNode = docBuilder.parse(new InputSource(new StringReader(sharedXslt))).getDocumentElement();
		Element jmsconfig = tDoc.createElement("jms:config");
		Element jmsGenericConnection = tDoc.createElement("jms:generic-connection");
		Element jmsConnectionFactory = tDoc.createElement("jms:connection-factory");
		Element jmsJndiConnectionFactory = tDoc.createElement("jms:jndi-connection-factory");
		Element jmsNameResolverBuilder = tDoc.createElement("jms:name-resolver-builder");

		jmsconfig.setAttribute("name", resourceName);
		jmsconfig.setAttribute("doc:name", resourceName);
		jmsconfig.setAttribute("doc:id", accelerator.generateRandom(8) + "-91ee-4acd-b62e-9317139d9ff7");
		jmsGenericConnection.setAttribute("specification", "JMS_2_0");
		jmsJndiConnectionFactory.setAttribute("connectionFactoryJndiName", "ConnectionFactory");

		ArrayList<Node> node = new ArrayList<>();
		accelerator.getNode(sharedNode.getChildNodes(), 0, node, "publisher");
		accelerator.getNode(sharedNode.getChildNodes(), 0, node, "jmsProducer");
		accelerator.getNode(sharedNode.getChildNodes(), 0, node, "jmsSession");

		String publisherName = "", sessionRef = "";

		for (Node n : node) {
			if (n.getNodeName().contentEquals("publisher")) {

				ArrayList<Node> publisherNode = new ArrayList<>();
				accelerator.getNode(sharedNode.getChildNodes(), 0, publisherNode, "name");

				for (Node n1 : publisherNode) {
					if (n1.getNodeName().contentEquals("name")) {
						publisherName = n1.getTextContent();
					}
				}
			}
			if (n.getNodeName().contentEquals("jmsProducer")) {
				if (n.getAttributes().getNamedItem("name").getTextContent().contentEquals(publisherName)) {
					ArrayList<Node> jmsProducer = new ArrayList<>();
					accelerator.getNode(sharedNode.getChildNodes(), 0, jmsProducer, "session");

					for (Node n1 : jmsProducer) {
						if (n1.getNodeName().contentEquals("session")) {
							sessionRef = n1.getTextContent();
							sessionRef = sessionRef.substring(sessionRef.indexOf("."));
						}
					}
				}
			}
			if (n.getNodeName().contentEquals("jmsSession")) {
				if (n.getAttributes().getNamedItem("name").getTextContent().contentEquals(sessionRef)) {
					ArrayList<Node> jmsSession = new ArrayList<>();
					accelerator.getNode(sharedNode.getChildNodes(), 0, jmsSession, "providerUrl");
					accelerator.getNode(sharedNode.getChildNodes(), 0, jmsSession, "providerCtxFactory");
					jmsJndiConnectionFactory.appendChild(jmsNameResolverBuilder);
					for (Node n1 : jmsSession) {
						if (n1.getNodeName().contentEquals("providerUrl")) {
							jmsNameResolverBuilder.setAttribute("jndiProviderUrl", n.getTextContent());
						}
						if (n1.getNodeName().contentEquals("providerCtxFactory")) {
							jmsNameResolverBuilder.setAttribute("jndiInitialContextFactory", n.getTextContent());
						}
					}
				}
			}
		}

		 mulesoftActivity = "ADB Connection";
         List<TMReferences> constantTimeList = jdbc.getReferenceByMuleActivity(mulesoftActivity);
         for (TMReferences tm : constantTimeList) {
        	 constant_manualTime = tm.getManualTime();
        	 constant_AfterMgrtnTime = tm.getAfterMigrationTime();
         }
         activityOps.addToDo(accelerator, "ADB Connection", resourceName, -5,constant_manualTime, constant_AfterMgrtnTime,"Connection");
         
         
		jmsConnectionFactory.appendChild(jmsJndiConnectionFactory);
		jmsGenericConnection.appendChild(jmsConnectionFactory);
		jmsconfig.appendChild(jmsGenericConnection);
		tDoc.getFirstChild().insertBefore(jmsconfig, tDoc.getElementsByTagName("flow").item(0));

	}


    public void addJdbcAttributes(Accelerator accelerator, Document tDoc, String textContent) {
        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:db") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:db", "http://www.mulesoft.org/schema/mule/db");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }
    }

    public void addJmsAttributes(Accelerator accelerator, Document tDoc, String textContent) {
        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:jms") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:jms", "http://www.mulesoft.org/schema/mule/jms");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/jms http://www.mulesoft.org/schema/mule/jms/current/mule-jms.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }
    }

    public void addHttpAttributes(Accelerator accelerator, Document tDoc, String textContent) {
        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:http") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:http", "http://www.mulesoft.org/schema/mule/http");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }
    }

    public void addFtpAttribute(Accelerator accelerator, Document tDoc, String textContent) {
        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:ftp") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:ftp", "http://www.mulesoft.org/schema/mule/ftp");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/ftp http://www.mulesoft.org/schema/mule/ftp/current/mule-ftp.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }
    }

    public void addObjectStoreAttribute(Accelerator accelerator, Document tDoc, String textContent) {
        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:os") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:os", "http://www.mulesoft.org/schema/mule/os");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/os  http://www.mulesoft.org/schema/mule/os/current/mule-os.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }
    }

    public void addAdbAttributes(Accelerator accelerator, Document tDoc, String textContent) {
		if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:jms") == null) {
			Element mule = (Element) tDoc.getFirstChild();
			mule.setAttribute("xmlns:jms", "http://www.mulesoft.org/schema/mule/jms");

			String schemaLocation = mule.getAttribute("xsi:schemaLocation");
			schemaLocation += " http://www.mulesoft.org/schema/mule/jms http://www.mulesoft.org/schema/mule/jms/current/mule-jms.xsd";

			mule.setAttribute("xsi:schemaLocation", schemaLocation);
		}
	}

}

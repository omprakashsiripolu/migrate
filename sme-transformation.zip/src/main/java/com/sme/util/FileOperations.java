package com.sme.util;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;

import com.sme.dao.entity.SharedConnections;
import org.apache.commons.io.FileUtils;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.sme.dao.InsertToDb;
import com.sme.dao.JDBCConnection;
import com.sme.service.Accelerator;
import com.tibco.security.AXSecurityException;

@Component
public class FileOperations {

    @Autowired
    JDBCConnection jdbc;

    private static final Logger logger = LoggerFactory.getLogger(FileOperations.class);

    @Autowired
    private XmlToYamlConverter yaml;

    @Autowired
    private InsertToDb insert;

    @Value("${mule.template-project.string}")
    private String templateProjectString;

    public void loadProperties(Accelerator accelerator, ArrayList<File> processes) throws IOException,
            ParserConfigurationException, SAXException, SQLException, InterruptedException, AXSecurityException {
        File srcProjectFile = accelerator.getSrcProjectDir();

        getFiles(srcProjectFile.listFiles(), 0, processes, ".process");

        yaml.setYamlData(srcProjectFile);
    }

    public void createMuleProjectAndDirs(Accelerator accelerator) throws IOException, InterruptedException {
        generateMuleProject(accelerator, accelerator.getProjectName());

        File trgProjectFile = accelerator.getTrgProjectDir();
        new File(trgProjectFile.getAbsolutePath() + File.separator + "src" + File.separator
                + "main" + File.separator + "mule").mkdirs();
        File java = new File(trgProjectFile.getAbsolutePath() + File.separator + "src"
                + File.separator + "main" + File.separator + "java");
        java.mkdirs();
        File api = new File(trgProjectFile.getAbsolutePath() + File.separator + "src" + File.separator + "main"
                + File.separator + "resources" + File.separator + "api");
        api.mkdirs();
        File types = new File(trgProjectFile.getAbsolutePath() + File.separator + "src"
                + File.separator + "main"
                + File.separator + "resources" + File.separator + "api" + File.separator + "types");
        types.mkdirs();
        File examples = new File(
                trgProjectFile.getAbsolutePath() + File.separator + "src" + File.separator + "main"
                        + File.separator + "resources" + File.separator + "api" + File.separator + "examples");
        examples.mkdirs();
        File config = new File(trgProjectFile.getAbsolutePath() + File.separator + "src"
                + File.separator + "main"
                + File.separator + "resources" + File.separator + "config");
        config.mkdirs();

        replacePom(accelerator);

    }

    public void replacePom(Accelerator accelerator) throws IOException {
        String trg = accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "pom.xml";
        ClassLoader classLoader = getClass().getClassLoader();
        try (InputStream fis = classLoader.getResourceAsStream("pom.xml")) {
            byte[] srcBytes = fis.readAllBytes();
            Files.write(Path.of(trg), srcBytes, StandardOpenOption.TRUNCATE_EXISTING);
            replaceProjectName(trg, templateProjectString, accelerator.getProjectName());
        } catch (Exception e) {
            logger.error("Unable to read classpath file - pom.xml" + e.getMessage());
        }

    }

    public void generateMuleProject(Accelerator accelerator, String projectName) throws IOException, InterruptedException {

        String muleCmd = "mvn archetype:generate -B " +
                "-DarchetypeGroupId=com.sageit " +
                "-DarchetypeArtifactId=new-project-archetype " +
                "-DarchetypeVersion=1.0.0-SNAPSHOT " +
                "-DgroupId=com.sageit " +
                "-DartifactId=" + projectName + " " +
                "-Dversion=1.0.0";

        boolean isWindows = System.getProperty("os.name")
                .toLowerCase().startsWith("windows");

        String[] command = new String[2];
        command[0] = isWindows ? "cmd.exe" : "/bin/sh";
        command[1] = isWindows ? "/c" : "-c";


        ProcessBuilder processBuilder = new ProcessBuilder(command[0], command[1], "cd "
                + accelerator.getTrg().getAbsolutePath() + " && " + muleCmd);
        processBuilder.redirectOutput(ProcessBuilder.Redirect.INHERIT);
        processBuilder.redirectErrorStream(true);
        Process process = processBuilder.start();
        int exitCode = process.waitFor();
        if (exitCode == 0) {
            logger.info("Mule project created successfully.");
        } else {
            logger.error("Mule project not getting created.");
            throw new RuntimeException("Mule project not getting created.");
        }
    }

    public void replaceProjectName(String filePath, String oldStr, String newStr) {
        try {
            // Read the file content
            byte[] fileContent = Files.readAllBytes(Path.of(filePath));
            String content = new String(fileContent);

            // Replace the old string with the new string
            String modifiedContent = content.replace(oldStr, newStr);

            // Write the modified content back to the file
            Files.write(Path.of(filePath), modifiedContent.getBytes(), StandardOpenOption.TRUNCATE_EXISTING);
            logger.info("String replaced successfully.");

        } catch (IOException e) {
            logger.error("An error occurred: " + e.getMessage());
        }
    }

    public void getFiles(File[] listFiles, int i, ArrayList<File> processes, String string) {
        if (listFiles == null) {
            return;
        }
        if (i == listFiles.length) {
            return;
        }
        if (listFiles[i].isFile()) {
            if (listFiles[i].getName().endsWith(string)) {
                processes.add(listFiles[i]);
            }
        } else if (listFiles[i].isDirectory()) {
            getFiles(listFiles[i].listFiles(), 0, processes, string);
        }
        getFiles(listFiles, i + 1, processes, string);
    }

    public void findServiceAgent(Accelerator accelerator, File srcProjectFile)
            throws ParserConfigurationException, SAXException, IOException,
            SQLException, TransformerConfigurationException, JSONException {
        ArrayList<File> serviceAgents = new ArrayList<>();
        getFiles(srcProjectFile.listFiles(), 0, serviceAgents, ".serviceagent");

        for (File serviceAgent : serviceAgents) {
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

            Document serviceAgentDoc = docBuilder.parse(serviceAgent);

            NodeList rows = serviceAgentDoc.getElementsByTagName("row");
            for (int i = 0; i < rows.getLength(); i++) {
                if (rows.item(i).getAttributes() != null) {
                    if (rows.item(i).getAttributes().getNamedItem("opImpl") != null) {
                        String fullStarterProcessStr = rows.item(i).getAttributes().getNamedItem("opImpl")
                                .getNodeValue();
                        File starterProcess = new File(srcProjectFile.getAbsolutePath() + fullStarterProcessStr);
                        String starterProcessStr = fullStarterProcessStr.substring(
                                fullStarterProcessStr.lastIndexOf('/') + 1, fullStarterProcessStr.lastIndexOf('.'));
                        starterProcessStr = starterProcessStr.replace(' ', '_');

                        Document prcDoc = docBuilder.parse(starterProcess);
                        accelerator.removeBlankLines(prcDoc);

                        insert.insertRows(accelerator, prcDoc, fullStarterProcessStr.substring(1), starterProcessStr, 1);
                    }
                }
            }
        }
    }

    public void insertWsdls(File srcProjectFile)
            throws ParserConfigurationException, SAXException, IOException, SQLException {
        ArrayList<File> wsdls = new ArrayList<>();
        getFiles(srcProjectFile.listFiles(), 0, wsdls, ".wsdl");

        for (File wsdl : wsdls) {
            jdbc.insertSharedResources(wsdl.getName(), Files.readString(wsdl.toPath()));
        }
    }

    public void insertJavaFiles(File srcProjectFile)
            throws ParserConfigurationException, SAXException, IOException, SQLException {
        ArrayList<File> javaFiles = new ArrayList<>();
        getFiles(srcProjectFile.listFiles(), 0, javaFiles, ".java");

        for (File javaFile : javaFiles) {
            jdbc.insertJavaFiles(javaFile.getName(), Files.readString(javaFile.toPath()));
        }
    }

    public void writeWsdls(Accelerator accelerator) throws SQLException, IOException {
        List<SharedConnections> sharedConnections = jdbc.getWsdls();
        for (SharedConnections sc : sharedConnections) {
            Files.writeString(
                    new File(accelerator.getTrgProjectDir().getAbsolutePath()
                            + File.separator + "src" + File.separator + "main"
                            + File.separator + "resources" + File.separator + "api"
                            + File.separator + sc.getSharedName()).toPath(),
                    new String(sc.getSharedConfig(), StandardCharsets.UTF_8));
        }
    }

    public void removeSource(String path) {
        try {
            FileUtils.cleanDirectory(new File(path));
        } catch (Exception e) {
            logger.error("An error occurred: " + e.getMessage());
        }
    }

    public void removeTarget(String path) {
        try {
            FileUtils.cleanDirectory(new File(path));
        } catch (Exception e) {
            logger.error("An error occurred: " + e.getMessage());
        }
    }

}

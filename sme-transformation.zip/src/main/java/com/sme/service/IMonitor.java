package com.sme.service;

import com.sme.dao.entity.Projects;

import java.util.List;

public interface IMonitor {

    List<Projects> findAllProjects();

    Projects findProjectByExecutionId(int execId);
}

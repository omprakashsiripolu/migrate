package com.sme.service;

import com.sme.dao.entity.Projects;
import com.sme.dao.repository.ProjectsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class Monitor implements IMonitor {

    @Autowired
    ProjectsRepository projectsRepository;

    @Override
    public List<Projects> findAllProjects() {
        Iterable<Projects> projectsIterable = projectsRepository.findAll();
        List<Projects> projectsList = new ArrayList<>();
        projectsIterable.forEach(projectsList::add);
        return projectsList;
    }

    @Override
    public Projects findProjectByExecutionId(int execId) {
        return projectsRepository.findById(execId).orElse(null);
    }
}

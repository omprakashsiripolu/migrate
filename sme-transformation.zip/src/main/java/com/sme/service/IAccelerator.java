package com.sme.service;

import com.sme.dao.entity.Projects;

import javax.xml.parsers.ParserConfigurationException;

import org.springframework.web.multipart.MultipartFile;
import reactor.core.publisher.Flux;

public interface IAccelerator {

    void analyze(int executionId);

    void migrate(int executionId) throws ParserConfigurationException;

    void convert(String... args) throws ParserConfigurationException;

    Projects saveProjectFile(MultipartFile file);

    Projects checkStatus(int executionId);

    boolean checkExecutionInProgress(int executionId);

    void deleteProject(Projects projects);

    Flux<String> streamMigration(int executionId);
}

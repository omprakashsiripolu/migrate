import xml.etree.ElementTree as ET
import os
import xml.dom.minidom
import uuid
import traceback
import shutil
from flask import Flask, request, send_file
import zipfile

flow_mapping = {}

DOC_TYPES = {}
PIPELINE_IN = []
PIPELINE_OUT = []
STEP_MODE = "payload"
CURR_MODE = "payload"
SERVICE_NAME = ""
VAR_MAP = {
    "MAP": [],
    "INVOKE": [],
    "payload": []
}
MULE_MAPS = {}
WM_MAPS = {}
WM_FLOWS_ROOT = ""
WM_DOCS_ROOT = ""
MULE_FLOWS_ROOT = ""
SEPARATOR = "\\" if os.name == 'nt' else "/"
def parse_mule_flow_tree(root, flow_path=""):
    global MULE_MAPS
    top_level_tags = ["SEQUENCE", "BRANCH", "LOOP"]
    for node in root:
        doc_name_attr = node.attrib.get("name")
        if doc_name_attr is None:
            doc_name_attr = node.attrib.get("{http://www.mulesoft.org/schema/mule/documentation}name")

        if doc_name_attr == "MAP":
            node_code = ET.tostring(node, encoding='unicode').replace("ns0", "ee").replace("ns1", "doc")

            if flow_path in MULE_MAPS:
                MULE_MAPS[flow_path].append(node_code)
            else:
                MULE_MAPS[flow_path] = [node_code]

      
        if doc_name_attr in top_level_tags:
            new_flow_path = flow_path + f"{doc_name_attr}->"
        else:
            new_flow_path = flow_path

      
        parse_mule_flow_tree(node, new_flow_path)

    return flow_path 


def parse_mule_flow(file):
    try:
        xml_tree = ""
        with open(file, "r") as f:
            xml_tree = f.read()
        root = ET.fromstring(xml_tree)
        flow_path = ""
        flow_path = parse_mule_flow_tree(root, flow_path)

        return flow_path
    except Exception as e:
        traceback.print_exc()
        print(e)
        return {}
    
xml_tree = ""


def replace_mule_flow_with_map(mule_file, doc_id, new_content):
    file_path =  mule_file
    replace_ee_transform_block(file_path, doc_id, new_content)


def replace_ee_transform_block(file_path, doc_id, new_content):
    with open(file_path, 'r') as file:
        content = file.read()

    # Create a pattern to find the correct <ee:transform> block
    pattern = r'(<ee:transform doc:id="' + re.escape(doc_id) + r'"[^>]*>.*?</ee:transform>)'

    # Replace the entire <ee:transform> block with new_content
    updated_content = re.sub(pattern, new_content, content, flags=re.DOTALL)

    with open(file_path, 'w') as file:
        file.write(updated_content)


def print_top_level_elements(xml_string):
    # parse the XML string into a DOM object
    dom = xml.dom.minidom.parseString(xml_string)
    # get the FLOW element
    flow = dom.getElementsByTagName("FLOW")[0]
    # get the child elements of the FLOW element
    # children = flow.childNodes
    # for child in children:
    #     if child.nodeType == child.ELEMENT_NODE:
    #         print(child.tagName)

def print_element(element, indent=0):
    # get the tag name of the element
    tag = element.tagName
    # get the attributes of the element as a string
    attributes = " ".join(
        [f"{attr.name}='{attr.value}'" for attr in element.attributes.values()]
    )
    # get the value of the element
    value = element.firstChild.nodeValue.strip() if element.firstChild else ""
    # print the text view of the element
    return f"{' ' * indent}{tag} {attributes} {value}\n" + "".join(
        [
            print_element(child, indent + 2)
            for child in element.childNodes
            if child.nodeType == child.ELEMENT_NODE
        ]
    )

def pretty_print_xml(xml_string, output_file):
    # parse the XML string into a DOM object
    xml_string = xml_string.strip()
    dom = xml.dom.minidom.parseString(xml_string)
    # get the root element of the DOM object
    root = dom.documentElement
    # recursively print the text view of each element
    tree = print_element(root)
    # write the tree to the output file
    with open(output_file, "w") as f:
        f.write(tree)
    # return the tree as a string
    return tree


def get_node_field_text(node, field_name):
    node_text = ""
    node_field = node.find(f'value[@name="{field_name}"]')
    if node_field is not None:
        node_text = node_field.text
    return node_text

def parse_transformer_fields(map, transformer_map_type):
    global DOC_TYPES
    target_fields = {}
    target_fields[transformer_map_type] = []
    record = map.find(".//Values/record")
    field_name = ""
    field_type = get_node_field_text(record, "field_type")
    if (field_type == "record"):
        field_name = get_node_field_text(record, "field_name")
        records = record.findall('array[@name="rec_fields"]/record')
        parse_records(
            records, target_fields[transformer_map_type], field_name
        )
    elif field_type == "recref":
       add_recref_field(record, target_fields[transformer_map_type])
    else:
        add_field(record, target_fields[transformer_map_type], field_name)

    return target_fields

def add_field(record, fields, record_name):
    field_name = get_node_field_text(record, "field_name")
    if not field_name.startswith("$") and (field_name not in fields):
        fields.append(field_name)
        if record_name not in DOC_TYPES:
            DOC_TYPES[record_name] = []
        DOC_TYPES[record_name].append(field_name)


def process_defult_value(input_str):
    keys = re.findall(r"%([^%]+)%", input_str)

    # For each key, replace '/' with '.' and format with 'payload.' prefix
    for key in keys:
        formatted_key = f"{STEP_MODE}." + key.replace("/", ".")
        input_str = input_str.replace(
            "%" + key + "%", "' ++ " + formatted_key + " ++ '"
        )

    # Remove extra spaces around ++ for cleaner formatting
    output_str = input_str
    # trim trailing ++ ' if exists
    if output_str.endswith(" ++ '"):
        output_str = output_str[:-4]

    if output_str.endswith(" ++"):
        output_str = output_str[:-3]

    if not output_str.startswith("payload"):
        output_str = "'" + output_str

    # if not last word after ++ is not a payload, then add ' at the end
    output_str_parts = output_str.split(" ++ ")
    last_part = output_str_parts[-1]
    if not last_part.startswith("payload"):
        output_str = output_str + "'"
    return output_str.replace("\n", "")


def parse_delete_fields(map_xml):
    deletes = []
    map_deletes = map_xml.findall("MAPDELETE")
    for map_delete in map_deletes:
        if map_delete is not None:
            delete_field = convert_field_to_dot_notation(map_delete.attrib["FIELD"])
            if delete_field.startswith("."):
                delete_field = delete_field[1:]
            if delete_field.endswith("."):
                delete_field = delete_field[:-1]

            deletes.append(delete_field)
    return deletes


def parse_mapset_field(field):
  
    if ':' in field:
        after_colon = field.split(':')[-1]
       
        return after_colon.strip('/').split(';')[0]
    
    # If the format does not match any of the above cases, return "Unknown format"
    return field.split(';')[0].strip('/')

def parse_map_set_fields(map_xml):
    mapsets = map_xml.findall("MAPSET")
    mappings = []
    for map_mode_input_target in mapsets:
        default_value = ""
        if map_mode_input_target is not None:
            data_node = map_mode_input_target.find("DATA")
            if data_node is not None:
                if data_node.find("Values") is not None:
                    if data_node.find("Values").find("value") is not None:
                        default_value = data_node.find("Values").find("value").text
            if default_value is None:
                default_value = ""
            # print(default_value)

            default_value = process_defult_value(default_value)
            mapped_field = map_mode_input_target.attrib["FIELD"]
           

            mapped_field = convert_field_to_dot_notation(mapped_field)
           
            if mapped_field is not None:
                mappings.append(
                    {
                        "field": mapped_field,
                        "value": default_value,
                        "type": "MAPSET",
                    }
                )
    return mappings

def convert_field_to_dot_notation1(field):
    # Remove leading and trailing slashes
    field = field.strip('/')

    # Split the field by '/' and then by ':' to get individual parts
    parts = field.split('/')
    dot_parts = [part.split(';')[0].replace(':', '.') for part in parts if part]

    # Join the parts with '.' to create the dot notation string
    dot_notation = '.'.join(dot_parts)
    
    return dot_notation

def convert_field_to_dot_notation2(field):
    # Remove leading slash
    field = field.lstrip('/')
    # Split by hierarchy levels
    hierarchy = field.split('/')
    # Initialize an empty list for dot notation parts
    dot_notation_parts = []

    for part in hierarchy:
        # Remove the type and occurrence information
        part = part.split(';')[0]
        # Replace the colon with a dot
        part = part.replace(':', '.')
        dot_notation_parts.append(part)

    # Join the parts with dots to form the full dot notation path
    dot_notation = '.'.join(dot_notation_parts)
    return dot_notation

def convert_field_to_dot_notation(field):
    # Remove leading slash and split the string by '/'
    field_paths = field.lstrip('/').split('/')
    
    # Initialize an empty list for the formatted field paths
    formatted_paths = []

    # Extract the field names, ignoring the metadata (type and occurrence info)
    for path in field_paths:
        # Only take the part before the semicolon
        path = path.split(';')[0]
        # Check if there is a colon indicating a namespace
        if ':' in path:
            # Split by colon to separate namespace and field name
            namespace, field_name = path.split(':')
            # Append only the field name to the formatted paths list
            formatted_paths.append(field_name)
        else:
            # If no colon, the field does not have a namespace, so take it as is
            formatted_paths.append(path)

    # Join the formatted field names with dots to form the full dot notation path
    dot_notation = '.'.join(formatted_paths)
    
    return dot_notation

def parse_map_copy_fields(map_xml, source_fields, target_fields):
    map_copies = map_xml.findall("MAPCOPY")
    mappings = []
    for map_copy in map_copies:
        if map_copy is not None:
            from_field = convert_field_to_dot_notation(map_copy.attrib["FROM"])
            if from_field.startswith("."):
                from_field = from_field[1:]
            if from_field.endswith("."):
                from_field = from_field[:-1]

            if from_field in DOC_TYPES:
                for field in DOC_TYPES[from_field]:
                    full_field = from_field + "." + field
                    if full_field not in source_fields["inputs"]:
                        source_fields["inputs"].append(full_field)
            elif from_field not in source_fields["inputs"]:
                source_fields["inputs"].append(from_field)

            to_field = convert_field_to_dot_notation(map_copy.attrib["TO"])

            if to_field not in target_fields["outputs"]:
                target_fields["outputs"].append(to_field)

            mappings.append({"from": from_field, "to": to_field, "type": "MAPCOPY"})
    return mappings


def parse_map_params(map_xml):
    # get map mode input
    map_fields = {}
    source_fields = {"inputs": []}
    target_fields = {"outputs": []}
    map_mode_input_target = map_xml.find("MAPTARGET")
    if map_mode_input_target is None:
        map_fields.update({"outputs": []})
    else:
        target_fields = parse_transformer_fields(map_mode_input_target, "outputs")
        map_fields.update(target_fields)

    map_mode_input_source = map_xml.find("MAPSOURCE")
    if map_mode_input_source is None:
        map_fields.update({"inputs": []})
    else:
        source_fields = parse_transformer_fields(map_mode_input_source, "inputs")
        map_fields.update(source_fields)

    deletes = []
    map_deletes = parse_delete_fields(map_xml)

    map_fields.update({"deletes": map_deletes})

    for field in deletes:
        if field in target_fields["outputs"]:
            target_fields["outputs"].remove(field)

    mappings = parse_map_set_fields(map_xml)
    
    map_copies = parse_map_copy_fields(map_xml, source_fields, target_fields)
    map_fields.update({"mappings": mappings + map_copies})
    
    return map_fields


def parse_invoke_node(invoke_node):
    invoke_fields = {}
    map_mode_input = invoke_node.find('MAP[@MODE="INPUT"]')
    fields = parse_map_params(map_mode_input)
    invoke_fields.update({"map_input": fields})

    map_mode_output = invoke_node.find('MAP[@MODE="OUTPUT"]')
    if map_mode_output is None:
        invoke_fields.update({"map_output": {}})
    else:
        fields = parse_map_params(map_mode_output)
        invoke_fields.update({"map_output": fields})

    return invoke_fields


def parse_map_invoke_node(invoke_node):
    invoke_fields = {}
    # get map mode input
    service = invoke_node.attrib["SERVICE"]
    invoke_fields.update({"service": service})
    map_mode_input = invoke_node.find('MAP[@MODE="INVOKEINPUT"]')
    fields = parse_map_params(map_mode_input)
    invoke_fields.update({"map_input": fields})

    map_mode_output = invoke_node.find('MAP[@MODE="INVOKEOUTPUT"]')
    if map_mode_output is None:
        invoke_fields.update({"map_output": {}})
    else:
        fields = parse_map_params(map_mode_output)
        invoke_fields.update({"map_output": fields})

    return invoke_fields


def parse_map_node(map_node):
    invoke_fields_list = []
    fields = parse_map_params(map_node)
   
    map_invoke_nodes = map_node.findall("MAPINVOKE")
    invoke_fields = {}
    if len(map_invoke_nodes) == 0:
        invoke_fields.update({"map_input": fields})
        invoke_fields.update(
            {
                "map_output": {
                    "inputs": [],
                    "outputs": fields["outputs"],
                    "mappings": fields["mappings"],
                    "deletes": fields["deletes"]
                }
            }
        )
        invoke_fields_list.append(invoke_fields)
        return invoke_fields_list
    else:
        map_invoke_fields_list = []
        for map_invoke_node in map_invoke_nodes:
            map_invoke_fields = parse_map_invoke_node(map_invoke_node)
            inputs = []
            if "inputs" in fields:
                inputs = fields["inputs"]
            if "inputs" in map_invoke_fields["map_input"]:
                map_invoke_fields["map_input"]["inputs"].extend(inputs)
            
            outputs = []
            if "outputs" in fields:
                outputs = fields["outputs"]
            if "outputs" in map_invoke_fields["map_input"]:
                map_invoke_fields["map_output"]["outputs"].extend(outputs)
            map_invoke_fields_list.append(map_invoke_fields)

        return map_invoke_fields_list

            
   
def deep_merge(dict1, dict2):
    """
    Merge two dictionaries, including nested dictionaries.
    Values from dict2 will overwrite values from dict1 if keys are the same.
    """
    for key in dict2:
        if key in dict1:
            if isinstance(dict1[key], dict) and isinstance(dict2[key], dict):
                deep_merge(dict1[key], dict2[key])
            else:
                # If dict2's value is not a dict, it overwrites dict1's value
                dict1[key] = dict2[key]
        else:
            # If key is not in dict1, add it to dict1
            dict1[key] = dict2[key]
    return dict1

def handle_special_chars(value):
    # val has hyqhen or slash or dot, then wrapt the value in double quotes
    if (value.find("-") > -1) or (value.find("/") > -1) or (value.find(".") > -1):
        value = f'"{value}"'
    
    return value

def dict_to_dataweave(dw_dict, indent=0):
    dw_code = ""
    for key, val in dw_dict.items():
        # Add indentation
        dw_code += " " * indent
        if isinstance(val, dict):
            # Recursively call the function for nested dictionaries
            # if key is array, then wrapt the value in square brackets and remove [] from the key
            if key.endswith(']'):
                key_arr = key.split('[')
                key = key_arr[0]
                dw_code += f'"{key}": [{{\n{dict_to_dataweave(val, indent + 2)}\n'
                dw_code += " " * indent + "}]"
               
            else:
                dw_code += f'"{key}": {{\n{dict_to_dataweave(val, indent + 2)}\n'
                dw_code += " " * indent + "}"
              
        else:
            
            if key.endswith(']'):
                key_arr = key.split('[')
                key = key_arr[0]
                dw_code += f'"{key}": [{val}'
                dw_code += "]"
                
            else:
                val = val
                dw_code += f'"{key}": {val}'
                # mapping_fields_data[key] = val
        dw_code += ",\n"
    return dw_code.rstrip(",\n")  # Remove the trailing comma and newline

def generate_mapping_code(field, value, mapped_fields, mapping_fields_data={}):
    global STEP_MODE, CURR_MODE, VAR_MAP, PIPELINE_IN, PIPELINE_OUT


    # Split the field into parts based on dot notation
    field_parts = field.split('.')

    # Start with an empty JSON structure
    json_structure = {}

    # Temporary variable to hold the reference to the nested dictionaries
    current_level = json_structure

    # Iterate over the parts and construct the nested JSON structure
    for part in field_parts[:-1]:  # Exclude the last part, which is the field name
        if part not in current_level:
            # Create a new dictionary at the current level with the part as the key
            current_level[part] = {}
        # Move the reference down to the nested dictionary
        current_level = current_level[part]

    # Set the value at the deepest level of the nested JSON structure
    current_level[field_parts[-1]] = value
    mapping_fields_data = deep_merge(mapping_fields_data, json_structure)

    # Convert the nested JSON structure to DataWeave code
    # This will create a string representation of the nested dictionaries with proper indentation
   

    mapping_code = dict_to_dataweave(json_structure, 2) + ",\n"
    if field not in mapped_fields:
        mapped_fields.append(field)
    
    if field not in PIPELINE_OUT:
        PIPELINE_OUT.append(field)

    if field not in VAR_MAP[CURR_MODE]:
        VAR_MAP[CURR_MODE].append(field)

    return mapping_code


def generate_final_mapping_code(key, value):
    indent=0
    mapping_code = " " * indent
    if isinstance(value, dict):
        if key.endswith(']'):
            key_arr = key.split('[')
            key = key_arr[0]
            mapping_code += f'"{key}": [{{\n{dict_to_dataweave(value, indent + 2)}\n'
            mapping_code += " " * indent + "}]"
        else:
            mapping_code += f'"{key}": {{\n{dict_to_dataweave(value, indent + 2)}\n'
            mapping_code += " " * indent + "}"
    else:
        if key.endswith(']'):
            key_arr = key.split('[')
            key = key_arr[0]

            mapping_code += f'"{key}": [{value}'
            mapping_code += "]"
            
        else:
            value = value
            mapping_code += f'"{key}": {value}'
                 
    mapping_code += ",\n"

    return mapping_code

def expand_delete_fields(deletes):
    expanded_deletes = []
    for field in deletes:
        if field in DOC_TYPES:
            for f in DOC_TYPES[field]:
                expanded_deletes.append(field + "." + f)
        else:
            expanded_deletes.append(field)
    return expanded_deletes

def generate_map_code(map_data):
    global PIPELINE_IN, PIPELINE_OUT, STEP_MODE, CURR_MODE, VAR_MAP
    invoke_template = """
<ee:transform doc:name="MAP" doc:id="0af093a1-f36b-4a65-9f3f-7a904ab46e8b" >
			<ee:message >
			</ee:message>
			<ee:variables>
				<ee:set-variable variableName="MAP" ><![CDATA[%dw 2.0
output application/json
---
	//payload mapping
]]></ee:set-variable>
			</ee:variables>
		</ee:transform>
    """
    invoke_template1 = """
<ee:transform doc:name="Transform Message">
    <ee:message >
        <ee:set-payload ><![CDATA[%dw 2.0
            output application/json
            ---
            {
                //payload mapping
            }]]></ee:set-payload>
    </ee:message>
</ee:transform>
    """
    PIPELINE_OUT = []
    PREV_VAR_MAP = VAR_MAP
    data = map_data["fields"][0]
    map_output = data["map_output"]
    map_input = data["map_input"]
    mapping_code = ""
    mapping_fields_data = {}
    out_code = ""
    if not map_output is {}:
        if "mappings" in map_output:
            input_mappings = map_output["mappings"]
            mapping_code = ""
            out_code = ""
            mapped_fields = []
            for mapping in input_mappings:
                if mapping["type"] == "MAPCOPY":
                   
                        prefix = get_prefix(mapping["to"], PREV_VAR_MAP)
                        
                        tmpcode = generate_mapping_code(mapping["to"], prefix + ".\"" + mapping["from"] + "\"", mapped_fields, mapping_fields_data)
                elif mapping["type"] == "MAPSET":
                   
                    tmpcode = generate_mapping_code(mapping["field"], mapping["value"], mapped_fields, mapping_fields_data)

    output_fields = map_output["outputs"]
    input_fields = map_input["inputs"]
    out_deletes = map_output["deletes"]
    deletes = expand_delete_fields(out_deletes)
    in_deletes = map_input["deletes"]
    in_deletes = expand_delete_fields(in_deletes)
    deletes.extend(in_deletes)

    flat_output_fields = []

    for field in output_fields:
        if (field not in mapped_fields) and (field not in deletes) and (field not in mapping_fields_data):
            flat_output_fields.append(field)
    
    for field in input_fields:
        if (field not in mapped_fields) and (field not in flat_output_fields) and (field not in deletes) and(field not in mapping_fields_data):
            flat_output_fields.append(field)

    for field in flat_output_fields:
        if field in DOC_TYPES:
            for f in DOC_TYPES[field]:
                if f not in mapped_fields:
                    f_arr_name = f.split("[")
                    if len(f_arr_name) > 1:
                        f = f_arr_name[0]
                    else:
                        f = f

                    if f not in deletes:
                        prefix = get_prefix(f, PREV_VAR_MAP)
                        mapping_code += f"{f}:{prefix}.{f},\n"
                        PIPELINE_OUT.append(f)
                        VAR_MAP[CURR_MODE].append(f)
        else:
            field_arr_name = field.split("[")
            if len(field_arr_name) > 1:
                field = field_arr_name[0]
            else:
                field = field
            prefix = get_prefix(field, PREV_VAR_MAP)
            tmpcode = generate_mapping_code(field, prefix + ".\"" + field + "\"", mapped_fields, mapping_fields_data)
            # mapping_code += f"{field}:{prefix}.{field},\n"

            # PIPELINE_OUT.append(field)
            # VAR_MAP[CURR_MODE].append(field)

    # mappingfielddata to string
    # mapping_code = json.dumps(mapping_fields_data, indent=4)
    for key, val in mapping_fields_data.items():
        # val = handle_special_chars(val)
        mapping_code += generate_final_mapping_code(key, val)

    if mapping_code != "":
        if mapping_code.endswith(",\n"):
            mapping_code = mapping_code[:-2] + "\n"
        mapping_code = ("{" + mapping_code + "}")
        # mapping_code = merge_duplicate_keys(mapping_code)
        # mapping_code = clean_json_like_string(mapping_code)

        out_code = invoke_template.replace("//payload mapping", mapping_code)
    else:
        out_code = invoke_template.replace("//payload mapping", "{}")
    return out_code


def generate_invoke_code(data):
    global PIPELINE_IN, PIPELINE_OUT, STEP_MODE, CURR_MODE, VAR_MAP, SERVICE_NAME
    invoke_template = """
<ee:transform doc:name="Transform Message" doc:id="0af093a1-f36b-4a65-9f3f-7a904ab46e8b" >
			<ee:message >
			</ee:message>
			<ee:variables>
				<ee:set-variable variableName="INVOKE" ><![CDATA[%dw 2.0
output application/json
// transformer call
---
{
	//payload mapping
}]]></ee:set-variable>
			</ee:variables>
		</ee:transform>
    """
    invoke_template1 = """
<ee:transform doc:name="Transform Message">
    <ee:message >
        <ee:set-payload ><![CDATA[%dw 2.0
            output application/json
            ---
            {
                //payload mapping
            }]]></ee:set-payload>
    </ee:message>
</ee:transform>
    """
    PIPELINE_OUT = []
    PREV_VAR_MAP = VAR_MAP
    service_name = ""
    if "service" in data:
        service_name = cleanup_service_name(data["service"])
        SERVICE_NAME = service_name
        invoke_template = invoke_template.replace("Transform Message", service_name)

    if not "map_input" in data:
        return f"<!-- No input information for {service_name} -->"
    map_input = data["map_input"]
    mapping_code = ""
    out_code = ""
    transformer_call = "call <transformer> with args:"
    if not map_input is {}:
        if "mappings" in map_input:
            input_mappings = map_input["mappings"]
            mapping_code = ""
            out_code = ""
            mapped_fields = []
            for mapping in input_mappings:
                if mapping["type"] == "MAPCOPY":
                    if mapping["to"] in DOC_TYPES:
                        for field in DOC_TYPES[mapping["to"]]:
                            prefix = get_prefix(field, PREV_VAR_MAP)
                            mapping_code += f"{field}:{prefix}.{field},\n"
                            mapped_fields.append(field)
                    else:
                        prefix = get_prefix(mapping["to"], PREV_VAR_MAP)
                        mapping_code += f"{mapping['to']}:{prefix}.{mapping['from']},\n"
                        mapped_fields.append(mapping["to"])

                elif mapping["type"] == "MAPSET":
                    mapping_code += f"{mapping['field']}:{mapping['value']},\n"
                    mapped_fields.append(mapping["field"])
                    transformer_call += f"{mapping['field']}='{mapping['value']}',"

    output_fields = map_input["outputs"]
    
    flat_output_fields = []

    for field in output_fields:
        if field not in mapped_fields:
            flat_output_fields.append(field)

   
    for field in flat_output_fields:
        if field in DOC_TYPES:
            for f in DOC_TYPES[field]:
                mapping_code += f"{f}:{STEP_MODE}.{f},\n"
        else:
            mapping_code += f"{field}:{STEP_MODE}.{field},\n"

    if "service" in data:
        invoke_service = data["service"].replace(":", ".")
        transformer_call = transformer_call.replace("<transformer>", invoke_service)
    else:
        transformer_call = ""

    mapping_code = ""
    result_var = "result"
    map_output = data["map_output"]
    if not map_output is {}:
        if "mappings" in map_output:
            output_mappings = map_output["mappings"]
            mapped_fields = []
            for mapping in output_mappings:
                
                if mapping["type"] == "MAPCOPY":
                    result_var = mapping["from"]
                    to_field = mapping["to"]
                    if to_field in DOC_TYPES:
                        for field in DOC_TYPES[to_field]:
                            mapping_code += f"{field}:{result_var}.{field},\n"
                            mapped_fields.append(field)
                            PIPELINE_OUT.append(field)
                            VAR_MAP[CURR_MODE].append(field)
                    else:
                        mapping_code += f"{mapping['to']}:{result_var},\n"
                        mapped_fields.append(mapping["to"])
                        PIPELINE_OUT.append(mapping["to"])
                        VAR_MAP[CURR_MODE].append(mapping["to"])
                elif mapping["type"] == "MAPSET":
                    mapping_code += f"{mapping['field']}:{mapping['value']},\n"
                    mapped_fields.append(mapping["field"])
                    PIPELINE_OUT.append(mapping["field"])
                    VAR_MAP[CURR_MODE].append(mapping["field"])
      
        if "outputs" in map_output:
            output_fields = map_output["outputs"]
            input_fields = map_input["inputs"]
            deletes = map_output["deletes"]
            expanded_deletes = []
            for field in deletes:
                if field in DOC_TYPES:
                    for f in DOC_TYPES[field]:
                        expanded_deletes.append(f)
                else:
                    expanded_deletes.append(field)
            
            deletes = expanded_deletes

            if not output_fields == {}:
                flat_output_fields = []

                for field in output_fields:
                    if field not in mapped_fields:
                        flat_output_fields.append(field)

                for field in input_fields:
                    if field not in mapped_fields and field not in flat_output_fields:
                        flat_output_fields.append(field)


                for field in flat_output_fields:
                    field_arr_name = field.split("[")
                    if len(field_arr_name) > 1:
                        field = field_arr_name[0]
                    else:
                        field = field

                    if field not in deletes:
                        if field in DOC_TYPES:
                            for f in DOC_TYPES[field]:
                                if f not in flat_output_fields and (f not in mapped_fields) and (f not in deletes):
                                    field_arr_name = f.split("[")
                                    if len(field_arr_name) > 1:
                                        f = field_arr_name[0]
                                    else:
                                        f = f
                                    prefix = get_prefix(f, PREV_VAR_MAP)
                                    mapping_code += f"{f}:{prefix}.{f},\n"
                                    PIPELINE_OUT.append(f)
                                    VAR_MAP[CURR_MODE].append(f)
                        else:
                            prefix = get_prefix(field, PREV_VAR_MAP)
                            mapping_code += f"{field}:{prefix}.{field},\n"
                            PIPELINE_OUT.append(field)
                            VAR_MAP[CURR_MODE].append(field)

            if result_var.endswith(']'):
                    result_var = result_var.split('[')[0]

            transformer_call = f"var {result_var} = \"" + transformer_call + "\"" + "\n"
            out_code = ""
            if mapping_code.endswith(",\n"):
                mapping_code = mapping_code[:-2] + "\n"
            
            out_code = invoke_template.replace("//payload mapping", "//this will be filled by ${service_name} call from other conversion")
            out_code = out_code.replace("variableName=\"INVOKE\"", f"variableName=\"{service_name}\"")

    return out_code


def cleanup_service_name(service_name):
    service_name = service_name.replace(":", "-")
    service_name = service_name.replace(".", "-")
    return service_name

def get_prefix(field, var_map):
    prefix = ""
    if field in var_map[STEP_MODE.replace("vars.", "")]:
        prefix = STEP_MODE
        if prefix == "vars.INVOKE":
            prefix = f"vars.\"{SERVICE_NAME}\""
    else:
        for key in var_map:
            if key == "payload":
                continue
            if field in var_map[key]:
                prefix = f"vars.{key}"
                if key == "INVOKE":
                    prefix = f"vars.\"{SERVICE_NAME}\""
                break
        
    # finally check if field is in payload
    if prefix == "":
        prefix = "payload"
    
    return prefix

import json
import re


def replace_ee_transform_block(file_path, doc_id, new_content):
    with open(file_path, 'r') as file:
        content = file.read()

    # Create a pattern to find the correct <ee:transform> block
    pattern = r'(<ee:transform doc:id="' + re.escape(doc_id) + r'"[^>]*>.*?</ee:transform>)'

    # Replace the entire <ee:transform> block with new_content
    updated_content = re.sub(pattern, new_content, content, flags=re.DOTALL)

    # new_file_path = file_path.replace('.xml', '_updated2.xml')

    with open(file_path, 'w') as file:
        file.write(updated_content)


def generate_map_invoke_code(map_invoke_data):
    global PIPELINE_IN, PIPELINE_OUT, STEP_MODE, CURR_MODE, VAR_MAP
    invoke_template = """
<ee:transform doc:name="MAP" doc:id="0af093a1-f36b-4a65-9f3f-7a904ab46e8b" >
			<ee:message >
			</ee:message>
			<ee:variables>
				<ee:set-variable variableName="MAP" ><![CDATA[%dw 2.0
output application/json
// transformer call
---
	//payload mapping
]]></ee:set-variable>
			</ee:variables>
		</ee:transform>
    """

    PIPELINE_OUT = []
    PREV_VAR_MAP = VAR_MAP
    service_name = "" 
    out_code = ""  
    mapping_codes = []
    transformer_calls = []
    full_out_code = ""
    service_names = []
    mapped_fields = []
    flat_output_fields = []
    expanded_deletes = []
    iter = 0
    mapping_fields_data = {}
    for data in map_invoke_data["fields"]:
        iter += 1
        if not "map_input" in data:
            return f"<!-- No input information for {service_name} -->"
    
        map_input = data["map_input"] 
        map_output = data["map_output"]

        transformer_call = "call <transformer> with args:"
        if "service" in data:
            service_name = data["service"]
            service_names.append(service_name)
            transformer_call = transformer_call.replace("<transformer>", service_name)
        if not map_input is {}:
            if "mappings" in map_input:
                input_mappings = map_input["mappings"]
                mapping_code = ""
                out_code = ""
                for mapping in input_mappings:
                    if mapping["type"] == "MAPCOPY":
                        prefix = get_prefix(mapping["from"], PREV_VAR_MAP)
                        
                        tmp_code = generate_mapping_code(mapping["to"], prefix + ".\"" + mapping["from"] + "\"", mapped_fields)
                        # transformer_call += f"{mapping['to']} = {prefix}.{mapping['from']},"
                        # mapped_fields.append(mapping["to"])
                    elif mapping["type"] == "MAPSET":
                        tmp_code = generate_mapping_code(mapping["field"], mapping["value"], mapped_fields)
                        # mapping_code += f"{mapping['field']}:{mapping['value']},\n"
                        # mapped_fields.append(mapping["field"])
                        transformer_call += f"{mapping['field']}='{mapping['value']}',"

        output_fields = map_input["outputs"]
    
        # deletes 
        in_deletes = map_input["deletes"]
        deletes = expand_delete_fields(in_deletes)
        result_var = "result"

        if not map_output is {}:
            if "mappings" in map_output:
                output_mappings = map_output["mappings"]
                for mapping in output_mappings:    
                    if mapping["type"] == "MAPCOPY":
                        result_var = mapping["from"]
                        result_var = result_var.replace(".", "_")
                        iter_result_var = result_var + "_" + str(iter)
                        if result_var.endswith(']'):
                            #replace array name with iterated array name
                            result_var = result_var.split('[')[0]
                            # result_var = result_var + "_" + str(iter)
                            # rebuild the array name and index
                            iter_result_var = result_var + "[" + mapping["from"].split('[')[1]
                
                        # if to_field in DOC_TYPES:
                        #     for field in DOC_TYPES[to_field]:
                        #         mapping_code += f"{field}:{result_var}.{field},\n"
                        #         mapped_fields.append(field)
                        #         PIPELINE_OUT.append(field)
                        #         VAR_MAP[CURR_MODE].append(field)
                        # else:
                        # mapping_code += f"{mapping['to']}:{result_var},\n"
                        # mapped_fields.append(mapping["to"])
                        # PIPELINE_OUT.append(mapping["to"])
                        # VAR_MAP[CURR_MODE].append(mapping["to"])
                        if mapping["to"] in flat_output_fields:
                            flat_output_fields.remove(mapping["to"])
                        if mapping["to"] not in mapped_fields:
                            tmp_code = generate_mapping_code(mapping["to"], iter_result_var, mapped_fields, mapping_fields_data)
                    elif mapping["type"] == "MAPSET":
                         if mapping["field"] in flat_output_fields:
                            flat_output_fields.remove(mapping["field"])
                         if mapping["field"] not in mapped_fields:
                            tmp_code = generate_mapping_code(mapping["field"], mapping["value"], mapped_fields, mapping_fields_data)

        
            if "outputs" in map_output:
                output_fields = map_output["outputs"]
                input_fields = map_input["inputs"]
                out_deletes = map_output["deletes"]
                out_deletes = expand_delete_fields(out_deletes)
                deletes.extend(out_deletes)
                expanded_deletes.extend(out_deletes)
                if not output_fields == {}:
                    for field in output_fields:
                        if (field not in mapped_fields) and (field not in flat_output_fields) and (field not in mapping_fields_data):
                            flat_output_fields.append(field)

                    for field in input_fields:
                        if field not in mapped_fields and field not in flat_output_fields and (field not in mapping_fields_data):
                            flat_output_fields.append(field)

                
                if result_var.endswith(']'):
                    result_var = result_var.split('[')[0]
                else:
                    result_var = result_var + "_" + str(iter)
                
                transformer_call = f"var {result_var} = \"" + transformer_call + "\"" + "\n"
                transformer_calls.append(transformer_call)
                mapping_codes.append(mapping_code)
    

    # mapping_code = ""
    # for code in mapping_codes:
    #     mapping_code += code

    # mappingfielddata to string
    mapping_code = ""
    for field in flat_output_fields:
        if field in mapping_fields_data:
            continue
        field_arr_name = field.split("[")
        if len(field_arr_name) > 1:
            field = field_arr_name[0]
        else:
            field = field

        if field not in deletes:
            if field in DOC_TYPES:
                for f in DOC_TYPES[field]:
                    if f not in flat_output_fields and (f not in mapped_fields) and (field not in mapping_fields_data):
                        full_field = field + "." + f
                        prefix = get_prefix(full_field, PREV_VAR_MAP)
                        full_field = "\"" + field + "\".\"" + f + "\""
                        tmp_code = generate_mapping_code(full_field, prefix + "." + full_field, mapped_fields, mapping_fields_data)        
            else:
                prefix = get_prefix(field, PREV_VAR_MAP)
                tmp_code = generate_mapping_code(field, prefix + ".\"" + field + "\"", mapped_fields, mapping_fields_data)
                          

    full_transformer_call = ""
    for call in transformer_calls:
        full_transformer_call += call
    out_code = invoke_template.replace("// transformer call", full_transformer_call)

    for key, val in mapping_fields_data.items():
        # val = handle_special_chars(val)
        mapping_code += generate_final_mapping_code(key, val)

    if mapping_code.endswith(",\n"):
        mapping_code = mapping_code[:-2] + "\n"

    mapping_code = ("{" + mapping_code + "}")

    # mapping_code = merge_duplicate_keys(mapping_code)
    full_out_code = out_code.replace("//payload mapping", mapping_code)
    
    if len(service_names) > 0:
        full_out_code = full_out_code.replace("Transform Message", "|".join(service_names))

    return full_out_code



def generate_flow_code(tag, data, id, seq):
    global STEP_MODE, CURR_MODE, VAR_MAP
    invoke_service = ""

    comment = f"""
      <logger level="INFO" doc:name="loop-{seq}" doc:id="{id}" message="comment step"/>
       <!-- <new_step/> -->
    """
    loop = f"""
        <logger level="INFO" doc:name="loop-{seq}" doc:id="{id}" message="loop step"/> 
         <!-- <new_step/> -->
    """
    branch = f"""
        <logger level="INFO" doc:name="branch-{seq}" doc:id="{id}" message="branch step"/>
         <!-- <new_step/> -->
    """
    sequence = f"""
        <logger level="INFO" doc:name="sequence-{seq}" doc:id="{id}" message="sequence step"/>
        <!-- <new_step/> -->
    """
    invoke = f"""
        <logger level="INFO" doc:name="{seq}" doc:id="{id}" message=\"{invoke_service}\"/>
         <!-- <new_step/> -->
    """
    map = f"""
        <logger level="INFO" doc:name="map{seq}" doc:id="{id}" message="map step"/>
         <!-- <new_step/> -->
    """
    step = ""
    if tag == "INVOKE":
        CURR_MODE = "INVOKE"
        step = generate_invoke_code(data)
        STEP_MODE = "vars.INVOKE"
    elif tag == "LOOP":
        step = loop
    elif tag == "BRANCH":
        step = branch
    elif tag == "SEQUENCE":
        step = sequence
    elif tag == "COMMENT":
        step = comment
    elif tag == "MAP":
        CURR_MODE = "MAP"
        step = generate_map_code(data)
        STEP_MODE = "vars.MAP"
    elif tag == "MAPINVOKE":
        CURR_MODE = "MAP"
        step = generate_map_invoke_code(data)
        STEP_MODE = "vars.MAP"
    else:
        step = ""

    return step


def parse_flow_tree(root, flow_data, flow_code, flow_path="", seq=0):
    valid_nodes = ["INVOKE", "MAP", "LOOP", "SEQUENCE", "BRANCH"]
    for node in root:
        if node.tag not in valid_nodes:
            continue
        map_node = node.find("MAP")
        invoke_fields = {}
        flow_code = ""
        if node.tag == "INVOKE" and map_node is not None:
            invoke_fields = parse_invoke_node(node)
            invoke_fields["service"] = node.attrib["SERVICE"]
            node_str = f"{node.tag} {node.attrib} {node.text}"
            invoke_fields["tag"] = node.tag
            flow_data.append({node_str: invoke_fields})
            id = node.attrib["ID"] if "ID" in node.attrib else ""

        elif node.tag == "MAP":
            invoke_fields_list = parse_map_node(node)
            map_invoke_node = node.find("MAPINVOKE")
            comment_node = node.find("COMMENT")
            comment = ""
            if comment_node is not None:
                comment = comment_node.text
            
            node_str = ""
            # if map_invoke_node is not None:
            #     invoke_fields["service"] = map_invoke_node.attrib["SERVICE"]
            #     node_str = f"{map_invoke_node.tag} {map_invoke_node.attrib} {map_invoke_node.text}"
            #     invoke_fields["tag"] = map_invoke_node.tag
            # else:
            node_str = f"{node.tag} {node.attrib} {node.text}"
            invoke_fields = {}
            invoke_fields["tag"] = node.tag
            if map_invoke_node is not None:
                 invoke_fields["tag"] = map_invoke_node.tag
            invoke_fields["fields"] = invoke_fields_list
            
            invoke_fields["path"] = flow_path
            invoke_fields["comment"] = comment
            flow_data.append({node_str: invoke_fields})
        else:
            updated_flow_path = flow_path + node.tag + "->"
            node_str = f"{node.tag} {node.attrib} {node.text}"
            invoke_fields["tag"] = node.tag
            flow_data.append({node_str: invoke_fields})
            flow_code += parse_flow_tree(node, flow_data, flow_code, updated_flow_path)
            seq += 1

    return flow_code

def parse_flow(flow_xml):
    try:
        root = ET.fromstring(flow_xml)
        flow_fields = []
        flow_code = ""
        flow_code = parse_flow_tree(root, flow_fields, flow_code)

        return flow_fields
    except Exception as e:
        traceback.print_exc()
        print(e)
        return {}

def add_recref_field(record, fields):
    field_name = get_node_field_text(record, "field_name")
    if not field_name.startswith("$") and (field_name not in fields) and (not field_name.startswith("pub.")):
        fields.append(field_name)
        if field_name not in DOC_TYPES:
            DOC_TYPES[field_name] = []

def parse_record_fields(record, fields, record_name=""):
    field_type = get_node_field_text(record, "field_type")
    if field_type == "record":
        record_name = get_node_field_text(record, "field_name")    
        records = record.findall('array[@name="rec_fields"]/record')
        parse_records(records, fields, record_name)
    elif field_type == "recref":
        add_recref_field(record, fields)
    else:
        add_field(record, fields, record_name)


def parse_records(records, fields, record_name=""):
    for i in range(len(records)):
        record = records[i]
        parse_record_fields(record, fields, record_name)

def parse_sig(svc_sig, sig_type):
    sig_root = svc_sig.find('record[@name="' + sig_type + '"]')
    sig_in_fields = sig_root.findall('array[@name="rec_fields"]/record')
    sig_fields = {}
    sig_fields[sig_type] = []
    parse_records(sig_in_fields, sig_fields[sig_type])
    return sig_fields

def parse_ndf(ndf_xml):
    root = ET.fromstring(ndf_xml)
    svc_sig = root.find('record[@name="svc_sig"]')
    fields = {}
    sig_in_fields = parse_sig(svc_sig, "sig_in")
    fields.update(sig_in_fields)
    sig_out_fields = parse_sig(svc_sig, "sig_out")
    fields.update(sig_out_fields)
    return fields



def extract_ee_transform_elements_raw(file_path):
    with open(file_path, 'r') as file:
        file_content = file.read()

    # Regular expression to match <ee:transform> elements with doc:name="MAP"
    ee_transform_regex = r'(<ee:transform[^>]*?doc:name="MAP"[^>]*?>.*?</ee:transform>)'
    ee_transforms = re.findall(ee_transform_regex, file_content, re.DOTALL)

    return ee_transforms


def read_flow(wm_flow_folder, mule_flow_file, flow_name, output_file):
    try:
    
        global DOC_TYPES, PIPELINE_IN, PIPELINE_OUT, VAR_MAP, SERVICE_NAME, MULE_MAPS
        flow_mapping = {}
        MULE_MAPS = {}
        STEP_MODE = "payload"
        CURR_MODE = "payload"
        SERVICE_NAME = ""
        VAR_MAP = {
            "MAP": [],
            "INVOKE": [],
            "payload": []
        }
        # read ndf file
        ndf_file = os.path.join(wm_flow_folder, "node.ndf")
        ndf_xml = ""
        with open(ndf_file, "r") as f:
            ndf_xml = f.read()
        pretty_print_xml(ndf_xml, os.path.join(wm_flow_folder, "nd_parsed.txt"))
        fields = {}
        ndf_fields = parse_ndf(ndf_xml)
        fields.update(ndf_fields)

        flow_file = os.path.join(wm_flow_folder, "flow.xml")
        flow_xml = ""
        with open(flow_file, "r") as f:
            flow_xml = f.read()
        pretty_print_xml(flow_xml, os.path.join(wm_flow_folder, "flow_parsed.txt"))
        flow_fields = parse_flow(flow_xml)
    
        mapping_file = os.path.join(wm_flow_folder, "final_mapping.json")
        with open(mapping_file, "w") as m:
            json.dump(flow_fields, m, indent=4)

        flow_code = ""
        step = 0
        PIPELINE_OUT.extend(fields["sig_in"])
        VAR_MAP["payload"] = fields["sig_in"]
        maps = {}
        iter = 0

        parse_mule_flow(mule_flow_file)

        #write MULE_MAPS to file
        with open("mule_flows/mule_maps.json", "w") as f:
            f.write(json.dumps(MULE_MAPS, indent=4))

        wm_path_counter = {} # for handline multiple maps at same level or multiple sequences/branches at same level
        
        for flow_field in flow_fields:
            step += 1

            
            for key in flow_field:
                if "map_input" in flow_field[key]:
                    # remove duplicates from PIPELINE_OUT
                    PIPELINE_OUT = list(set(PIPELINE_OUT))
                    # EXTEND flow_field[key]['map_input']["inputs"] with NEW FIELDS FROM PIPELINE OUT
                    flow_field[key]['map_input']["inputs"].extend(PIPELINE_OUT)
                    #remove duplicates
                    flow_field[key]['map_input']["inputs"] = list(set(flow_field[key]['map_input']["inputs"]))


                tag = flow_field[key]["tag"]

                # id = key.split(' ')[1]
                id = str(uuid.uuid4())
                tmp_code = generate_flow_code(tag, flow_field[key], id, step)
                if tag == "MAP" or tag == "MAPINVOKE":
                    map_path = flow_field[key]["path"]
                    maps[map_path] = tmp_code
                    if map_path in wm_path_counter:
                        wm_path_counter[map_path] += 1
                    else:
                        wm_path_counter[map_path] = 1

                    if map_path  in MULE_MAPS:
                        if len(MULE_MAPS[map_path]) > (wm_path_counter[map_path] - 1):
                            existing_map_payload = MULE_MAPS[map_path][wm_path_counter[map_path] - 1]
                            existing_map_payload = existing_map_payload.replace("xmlns:ee=\"http://www.mulesoft.org/schema/mule/ee/core\"","")
                            existing_map_payload = existing_map_payload.replace("xmlns:doc=\"http://www.mulesoft.org/schema/mule/documentation\"","")

                            doc_id = existing_map_payload.split("doc:id=\"")[1].split("\"")[0]

                            replace_mule_flow_with_map(mule_flow_file, doc_id, tmp_code)
                        iter += 1
                    else:
                        print("map_path: ", map_path)
                flow_code += tmp_code
                # remove duplicates from VAR_MAP CURR_MODE
                VAR_MAP[CURR_MODE] = list(set(VAR_MAP[CURR_MODE]))

        
        flow_code_template = f"""
        <?xml version="1.0" encoding="UTF-8"?>

        <mule xmlns:ee="http://www.mulesoft.org/schema/mule/ee/core" xmlns="http://www.mulesoft.org/schema/mule/core"
        xmlns:doc="http://www.mulesoft.org/schema/mule/documentation"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/current/mule.xsd
        http://www.mulesoft.org/schema/mule/ee/core http://www.mulesoft.org/schema/mule/ee/core/current/mule-ee.xsd">
        <flow name="{flow_name}" doc:id="b14f3d1d-cdd0-4ad0-864b-cc6b0b52a6a0" >
            <!-- <new_step/> -->
        </flow>
        </mule>

            """
        flow_code = flow_code_template.replace("<!-- <new_step/> -->", flow_code)

        # write flow code to file
        # flow_code = flow_code.strip()
        # with open(output_file, "w") as f:
        #     f.write(flow_code)

        with open("mule_flows/map.json", "w") as f:
            f.write(json.dumps(maps, indent=4))

    except Exception as e:
        traceback.print_exc()
        print(e)
        return {}

def parse_doctype_rec_fields(rec_fields):
    doctype_fields = []
    if rec_fields is None:
        return doctype_fields
    records = rec_fields.findall(".//record")
    for record in records:
        field_name = record.find(".//value[@name='field_name']")
        if field_name is not None:
            doctype_fields.append(field_name.text)
    return doctype_fields

def parse_doc_type(doc_type_file_name):
    doc_type_fields = {}
    doc_type_xml = open(doc_type_file_name).read()
    root = ET.fromstring(doc_type_xml)
    doc_type_record = root.find(".//record")
    if doc_type_record is None:
        return doc_type_fields
    node_nsName = doc_type_record.find(".//value[@name='node_nsName']")
    if node_nsName is None:
        return doc_type_fields

    rec_fields = doc_type_record.find(".//array[@name='rec_fields']")
    fields = parse_doctype_rec_fields(rec_fields)
    doc_type_fields[node_nsName.text] = fields
    return doc_type_fields

def read_doctypes(dir_name):
    doctypes = {}
    for root, dirs, files in os.walk(dir_name):
        for file in files:
            print("root=>",root,"file=>",file)
            if file.endswith(".ndf"):
                doctype_fields = parse_doc_type(os.path.join(root, file))
                doctypes.update(doctype_fields)
    return doctypes

def get_all_services(folder, services):
    print("get_all_services",folder, services)
    for item in os.listdir(folder):
        item_path = os.path.join(folder, item)
        print("item_path=>", item_path)
        if os.path.isfile(item_path):
            print("os.path.dirname(item_path)==>", os.path.dirname(item_path))
            if item == "flow.xml":
                services.append(os.path.dirname(item_path))
        elif os.path.isdir(item_path):
            print("item_path dir=>", item_path)
            get_all_services(item_path, services)

def get_all_files_in_directory(folder):
    file_paths = []

    for root, dirs, files in os.walk(folder):
        for file in files:
            file_path = os.path.join(root, file)
            file_paths.append(file_path)

    return file_paths

def run_batch():
    global DOC_TYPES
    read_config_ini()
    DOC_TYPES = read_doctypes(WM_DOCS_ROOT)

    services_list = []
    try:
        get_all_services(WM_DOCS_ROOT, services_list)
    except Exception as e:
        print(e)

    print("exit")
    for filePath in services_list:
        print("filePath=>", filePath)
        files = get_all_files_in_directory(filePath)
        root = filePath

        PIPELINE_IN = []
        PIPELINE_OUT = []
        VAR_MAP = {"payload": [], "MAP": [], "INVOKE": []}
        # split by file separator
        flow_name = root.split(SEPARATOR)[-1]
        print("flow_name=>", flow_name)
        mule_flow_file_name =  MULE_FLOWS_ROOT+SEPARATOR + PROJECT_NAME+ SEPARATOR+"src"+SEPARATOR+"main"+SEPARATOR+"mule"+SEPARATOR+root.split(SEPARATOR+"ns"+SEPARATOR, 1)[-1]+".xml"
        if not os.path.exists("tmp"):
            os.makedirs("tmp")
        mule_flow_file_name_updated = os.path.join("tmp", flow_name + "_updated.xml")

        # make a copy first
        shutil.copyfile(mule_flow_file_name, mule_flow_file_name_updated)
        print("file==>", root, mule_flow_file_name_updated, flow_name, mule_flow_file_name_updated)
        read_flow(root, mule_flow_file_name_updated, flow_name, mule_flow_file_name_updated)
        shutil.copyfile(mule_flow_file_name_updated, mule_flow_file_name.replace(".xml","_updated.xml"))


def read_config_ini():
    global WM_FLOWS_ROOT, MULE_FLOWS_ROOT, WM_DOCS_ROOT, PROJECT_NAME
    # import configparser
    # config = configparser.ConfigParser()
    # config.read('config.ini')
    # print(config['DEFAULT']['wm_flows_root'])
    # print(config['DEFAULT']['mule_flows_root'])
    # print(config['DEFAULT']['wm_docs_root'])
    # WM_FLOWS_ROOT = config['DEFAULT']['wm_flows_root']
    # MULE_FLOWS_ROOT = config['DEFAULT']['mule_flows_root']
    # WM_DOCS_ROOT = config['DEFAULT']['wm_docs_root']
    PROJECT_NAME = [folder for folder in os.listdir(WM_FLOWS_ROOT) if os.path.isdir(os.path.join(WM_FLOWS_ROOT, folder))][0]
    print("PROJECT_NAME =>",PROJECT_NAME)


# Create the Flask instance and pass the Flask
# constructor the path of the correct module
app = Flask(__name__)

# The URL 'localhost:5000/square' is mapped to
# view function 'invoke'
@app.before_request
def middleware():
    # request - flask.request
    print('endpoint: %s, url: %s, path: %s' % (
        request.endpoint,
        request.url,
        request.path))

@app.route('/test', methods=['GET'])
def health():
    return "Alive", 200

@app.route('/covert-wm-mule', methods=['POST'])
def process_zip():
    try:
        global WM_FLOWS_ROOT, MULE_FLOWS_ROOT, WM_DOCS_ROOT
        # Get the uploaded ZIP file from the request
        src_zip = request.files['src']
        trg_zip = request.files['trg']

        print("source=>", src_zip)
        print("target=>", trg_zip)

        # Create a temporary directory to extract the contents
        src = 'src'
        trg = 'trg'
        os.makedirs(src, exist_ok=True)
        os.makedirs(trg, exist_ok=True)

        # Extract the contents of the uploaded ZIP file
        with zipfile.ZipFile(src_zip, 'r') as zip_ref:
            zip_ref.extractall(src)
        print("source extracted directories==>", [x[0] for x in os.walk(src)])
        # Extract the contents of the uploaded ZIP file
        with zipfile.ZipFile(trg_zip, 'r') as zip_ref:
            zip_ref.extractall(trg)

        print("target extracted directories==>", [x[0] for x in os.walk(trg)])

        WM_FLOWS_ROOT = src
        MULE_FLOWS_ROOT = trg
        WM_DOCS_ROOT = src

        run_batch()

        # Create a new ZIP file with the processed contents
        processed_zip_path = 'processed.zip'
        if os.path.exists(processed_zip_path):
            os.remove(processed_zip_path)
        with zipfile.ZipFile(processed_zip_path, 'w') as processed_zip:
            for root, dirs, files in os.walk(trg):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, trg)
                    processed_zip.write(file_path, arcname=arcname)

        # Send the processed ZIP file as a response
        return send_file(processed_zip_path, as_attachment=True)

    except Exception as e:
        print(e)
        return f"exception accored while mapping, {e}", 500

    finally:
        # Cleanup: Remove the temporary directory and processed ZIP file
        if os.path.exists(src):
            shutil.rmtree(src)
        if os.path.exists(trg):
            shutil.rmtree(trg)




# Start with flask web app with debug as

# True only if this is the starting page
if(__name__ == "__main__"):
    app.run(debug=True)

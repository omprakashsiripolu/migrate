package com.sme.service;

//@SpringBootTest
class SmeAcceleratorApplicationTests {

	//@Test
	void contextLoads() {
	}

}

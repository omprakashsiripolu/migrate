CREATE TABLE `arc_configfiles` (
  `NAME` varchar(200) DEFAULT NULL,
  `CONFIG` longblob,
  `EXEC_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `arc_flow` (
  `PROCESSES_NAME` varchar(500) DEFAULT NULL,
  `SEQID` int DEFAULT NULL,
  `LVL` int DEFAULT NULL,
  `ACTIVITY_NAME` varchar(200) DEFAULT NULL,
  `ACTIVITY_TYPE` varchar(200) DEFAULT NULL,
  `ACTIVITY_XSLT` longblob,
  `PARENTID` varchar(500) DEFAULT NULL,
  `CONDITIONTYPE` varchar(50) DEFAULT NULL,
  `XPATH` varchar(2000) DEFAULT NULL,
  `PARENTCOUNT` int DEFAULT NULL,
  `EXEC_ID` int DEFAULT NULL,
  `seq_id` int NOT NULL,
  `condition_type` varchar(255) DEFAULT NULL,
  `parent_count` int NOT NULL,
  `parent_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `arc_globalvariables` (
  `KEY_S` varchar(100) DEFAULT NULL,
  `VALUE_S` varchar(500) DEFAULT NULL,
  `EXEC_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `arc_groupactivities` (
  `GROUP_NAME` varchar(50) DEFAULT NULL,
  `PROCESSES_NAME` varchar(500) DEFAULT NULL,
  `SEQID` int DEFAULT NULL,
  `LVL` int DEFAULT NULL,
  `ACTIVITY_NAME` varchar(200) DEFAULT NULL,
  `ACTIVITY_TYPE` varchar(200) DEFAULT NULL,
  `ACTIVITY_XSLT` longblob,
  `PARENTID` varchar(500) DEFAULT NULL,
  `CONDITIONTYPE` varchar(50) DEFAULT NULL,
  `XPATH` varchar(2000) DEFAULT NULL,
  `PARENTCOUNT` int DEFAULT NULL,
  `EXEC_ID` int DEFAULT NULL,
  `seq_id` int NOT NULL,
  `condition_type` varchar(255) DEFAULT NULL,
  `parent_count` int NOT NULL,
  `parent_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `arc_projects` (
  `EXEC_ID` int NOT NULL AUTO_INCREMENT,
  `NAME` varchar(200) NOT NULL,
  `DATETIME` timestamp NULL DEFAULT NULL,
  `DESCRIPTION` varchar(1000) DEFAULT NULL,
  `SOURCE_PROJECT` longblob,
  `TARGET_PROJECT` longblob,
  `XSLT_TO_DWL_EXCEL` longblob,
  `STATUS` varchar(45) DEFAULT NULL,
  `ANALYZE_START` timestamp NULL DEFAULT NULL,
  `ANALYZE_END` timestamp NULL DEFAULT NULL,
  `MIGRATION_START` timestamp NULL DEFAULT NULL,
  `MIGRATION_END` timestamp NULL DEFAULT NULL,
  `ERROR` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`EXEC_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=317 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `arc_restservice` (
  `PROCESSES_NAME` varchar(500) DEFAULT NULL,
  `RESOURCE_NAME` varchar(100) DEFAULT NULL,
  `PATH` varchar(200) DEFAULT NULL,
  `BASE` varchar(200) DEFAULT NULL,
  `METHOD_NAME` varchar(10) DEFAULT NULL,
  `INPUT` varchar(100) DEFAULT NULL,
  `OUTUT` varchar(100) DEFAULT NULL,
  `INP_SCHEMA` longblob,
  `OUT_SCHEMA` longblob,
  `EXEC_ID` int DEFAULT NULL,
  `output` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `arc_sharedconnections` (
  `SHARED_NAME` varchar(500) DEFAULT NULL,
  `SHARED_CONFIG` longblob,
  `EXEC_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `arc_transitions` (
  `PROCESSES_NAME` varchar(500) DEFAULT NULL,
  `SEQID` int DEFAULT NULL,
  `PARENTID` int DEFAULT NULL,
  `CONDITIONTYPE` varchar(50) DEFAULT NULL,
  `XPATH` varchar(2000) DEFAULT NULL,
  `EXEC_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `arc_xslttodw` (
  `ACTIVITY_NAME` varchar(200) DEFAULT NULL,
  `XSLT` longblob,
  `EXEC_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `tmreferences` (
  `tibco` varchar(200) DEFAULT NULL,
  `Mulesoft` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `password` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_6dotkott2kjsp8vw4d0m25fb7` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- load into users. Encode password using BCrypt encoder online

CREATE TABLE `arc_migrationstats` (
  `Sno` int NOT NULL AUTO_INCREMENT,
  `Exec_Id` int NOT NULL,
  `seqid` int NOT NULL,
  `Type` varchar(500) DEFAULT NULL,
  `Input_Type` varchar(255) DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Filename` varchar(500) DEFAULT NULL,
  `Manual_Effort` double NOT NULL,
  `After_Migration` int NOT NULL,
  `Time_Saved` double NOT NULL,
  PRIMARY KEY (`Sno`)
) ENGINE=InnoDB AUTO_INCREMENT=34430 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci

create table sme.arc_unmigratedActivities(
	Exec_id int,
	seqid int,
	activityname varchar(500), 
	processname varchar(500),
	description varchar(1000)
)ENGINE=InnoDB AUTO_INCREMENT=34430 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci

CREATE TRIGGER sme.movemanualefforts
AFTER INSERT ON sme.arc_migrationstats
FOR EACH ROW
BEGIN
    -- Update target_table1
    UPDATE sme.arc_flow
    SET manual_efforts_required = NEW.After_Migration
    WHERE seq_id = NEW.seqid and exec_id = NEW.exec_id;
 
    -- Update target_table2
    UPDATE sme.arc_groupactivities
    SET manual_efforts_required = NEW.After_Migration
    WHERE seq_id = NEW.seqid and exec_id = NEW.exec_id;
END //
 
DELIMITER ;

package com.sme.http.response;

public class BaseResponse {
}

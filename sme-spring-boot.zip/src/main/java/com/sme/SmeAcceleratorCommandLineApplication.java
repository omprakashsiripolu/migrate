package com.sme;

import com.sme.service.IAccelerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnNotWebApplication;
import org.springframework.stereotype.Component;

/**
 * This would be used when spring.main.web-application-type=NONE is set
 * Spring would decide to run as a command line program and exits JVM once complete
 */
@Component
@ConditionalOnNotWebApplication
public class SmeAcceleratorCommandLineApplication implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(SmeAcceleratorCommandLineApplication.class);

    private IAccelerator accelerator;

    @Autowired
    public void setAccelerator(IAccelerator accelerator) {
        this.accelerator = accelerator;
    }

    @Override
    public void run(String... args) throws Exception {
        try {
            accelerator.convert(args);
        } catch (Exception e) {
            logger.error("An error occurred: " + e.getMessage());
        }

    }
}

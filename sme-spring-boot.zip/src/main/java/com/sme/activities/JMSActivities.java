package com.sme.activities;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.sme.dao.entity.Flow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.sme.dao.JDBCConnection;
import com.sme.service.Accelerator;
import com.sme.util.RetrieveOps;

@Component
public class JMSActivities {

    @Autowired
    private JDBCConnection jdbc;

    public Element addJMSPublishActivity(Accelerator ac, Document tDoc, Node acNode, String acName,
                                         ArrayList<Node> node) {

        Element publish = tDoc.createElement("jms:publish");
        Element body = tDoc.createElement("jms:body");
        Element message = tDoc.createElement("jms:message");
        Element jmsReplyTo = tDoc.createElement("jms:reply-to");

        publish.setAttribute("doc:id", ac.generateRandom(8) + "ba44-4f56-9c63-d1d76a5d22ca");
        publish.setAttribute("doc:name", acName);

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:type");
        ac.getNode(acNode.getChildNodes(), 0, node, "destination");
        ac.getNode(acNode.getChildNodes(), 0, node, "ConnectionReference");
        ac.getNode(acNode.getChildNodes(), 0, node, "Body");
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "PermittedMessageType");
        ac.getNode(acNode.getChildNodes(), 0, node, "JMSReplyTo");
        ac.getNode(acNode.getChildNodes(), 0, node, "JMSDeliveryMode");
        ac.getNode(acNode.getChildNodes(), 0, node, "JMSPriority");
        ac.getNode(acNode.getChildNodes(), 0, node, "JMSExpiration");

        String activityType = null;

        for (Node n : node) {

            if (n.getNodeName().contentEquals("pd:type")) {
                activityType = n.getTextContent();
            }
            if (n.getNodeName().contentEquals("JMSDeliveryMode")) {
                if (n.getTextContent().contentEquals("PERSISTENT")) {
                    publish.setAttribute("persistentDelivery", "true");
                }
                if (n.getTextContent().contentEquals("NON_PERSISTENT")) {
                    publish.setAttribute("persistentDelivery", "false");
                }
            }
            if (activityType.contentEquals("com.tibco.plugin.jms.JMSQueueSendActivity")) {
                publish.setAttribute("destinationType", "QUEUE");
            }
            if (activityType.contentEquals("com.tibco.plugin.jms.JMSTopicPublishActivity")) {
                publish.setAttribute("destinationType", "TOPIC");
            }
            if (n.getNodeName().contentEquals("JMSReplyTo")
                    && activityType.contentEquals("com.tibco.plugin.jms.JMSQueueSendActivity")) {
                jmsReplyTo.setAttribute("destination", n.getTextContent());
                jmsReplyTo.setAttribute("destinationType", "QUEUE");
                message.appendChild(jmsReplyTo);
            }

            if (n.getNodeName().contentEquals("JMSReplyTo")
                    && activityType.contentEquals("com.tibco.plugin.jms.JMSTopicPublishActivity")) {
                jmsReplyTo.setAttribute("destination", n.getTextContent());
                jmsReplyTo.setAttribute("destinationType", "TOPIC");
                message.appendChild(jmsReplyTo);
            }
            if (n.getNodeName().contentEquals("destination")) {
                if (n.getTextContent() != null && !n.getTextContent().equals("")) {
                    publish.setAttribute("destination", n.getTextContent());
                } else {
                    publish.setAttribute("destination", "''");
                }
            }
            if (n.getNodeName().contentEquals("ConnectionReference")) {
                String resourceName = n.getTextContent().substring(n.getTextContent().lastIndexOf('/') + 1);
                ;
                resourceName = resourceName.replaceAll(" ", "_");
                publish.setAttribute("config-ref", resourceName.substring(0, resourceName.indexOf(".")));
            }
            if (n.getNodeName().contentEquals("Body")) {
                if (n.getFirstChild().getAttributes().getNamedItem("select") != null) {
                    body.setTextContent(n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue());
                }
            }
            if (n.getNodeName().contentEquals("pd:description")) {
                publish.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("PermittedMessageType")) {
                String value = n.getTextContent().toLowerCase();
                if (value.contentEquals("text")) {
                    value = "text/plain";
                    message.setAttribute("outboundContentType", value);
                } else {
                    message.setAttribute("outboundContentType", "application/" + value);
                }
            }
            if (n.getNodeName().contentEquals("JMSPriority")) {
                publish.setAttribute("priority", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("JMSExpiration")) {
                publish.setAttribute("timeToLive", n.getTextContent());
            }

        }

        message.appendChild(body);
        publish.appendChild(message);

        return publish;
    }

    public Element addJMSConsumeActivity(Accelerator ac, Document tDoc, Node acNode, String acName)
            throws SQLException, SAXException, IOException {

        Element consume = tDoc.createElement("jms:consume");
        Element consumerType = tDoc.createElement("jms:consumer-type");
        Element consumerTypeTag = null;
        consume.setAttribute("doc:id", ac.generateRandom(8) + "ba44-4f56-9c63-d1d76a5d22ca");
        consume.setAttribute("doc:name", acName);

        ArrayList<Node> node = new ArrayList<>();
        ac.getNode(acNode.getChildNodes(), 0, node, "destination");
        ac.getNode(acNode.getChildNodes(), 0, node, "ConnectionReference");
        ac.getNode(acNode.getChildNodes(), 0, node, "receiverTimeout");
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:type");
        ac.getNode(acNode.getChildNodes(), 0, node, "acknowledgeMode");
        ac.getNode(acNode.getChildNodes(), 0, node, "PermittedMessageType");
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "selector");
        ac.getNode(acNode.getChildNodes(), 0, node, "JMSDeliveryMode");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("ConnectionReference")) {
                String resourceName = n.getTextContent().substring(n.getTextContent().lastIndexOf('/') + 1);
                ;
                resourceName = resourceName.replaceAll(" ", "_");
                consume.setAttribute("config-ref", resourceName.substring(0, resourceName.indexOf(".")));
            }
            if (n.getNodeName().contentEquals("pd:type")
                    && n.getTextContent().contentEquals("com.tibco.plugin.jms.JMSQueueGetMessageActivity")) {
                consumerTypeTag = tDoc.createElement("jms:queue-consumer");
                consumerType.appendChild(consumerTypeTag);
            }
//			if(n.getNodeName().contentEquals("pd:type")  && n.getTextContent().contentEquals("com.tibco.plugin.jms.JMSQueueEventSource")) {
//				consumerTypeTag = tDoc.createElement("jms:queue-consumer");
//				consumerType.appendChild(consumerTypeTag);
//			}
//		
//			if(n.getNodeName().contentEquals("pd:type")  && n.getTextContent().contentEquals("com.tibco.plugin.jms.JMSTopicEventSource")) {
//				consumerTypeTag = tDoc.createElement("jms:topic-consumer");
//				consumerType.appendChild(consumerTypeTag);
//			}
            if (n.getNodeName().contentEquals("destination")) {
                consume.setAttribute("destination", n.getTextContent());
            }
//			if(n.getNodeName().contentEquals("JMSDeliveryMode")) {
//				if(n.getTextContent().contentEquals("PERSISTENT")) {
//					consume.setAttribute("persistentDelivery", "true");
//				}
//				if(n.getTextContent().contentEquals("NON_PERSISTENT")) {
//					consume.setAttribute("persistentDelivery", "false");
//				}	
//			}
            if (n.getNodeName().contentEquals("acknowledgeMode")) {
                if (n.getTextContent().contentEquals("1")) {
                    consume.setAttribute("ackMode", "IMMEDIATE");
                } else {
                    consume.setAttribute("ackMode", "MANUAL");
                }
            }
            if (n.getNodeName().contentEquals("PermittedMessageType")) {
                String value = n.getTextContent().toLowerCase();
                if (value.contentEquals("text")) {
                    value = "text/plain";
                    consume.setAttribute("contentType", value);
                } else {
                    consume.setAttribute("contentType", "application/" + value);
                }
            }
            if (n.getNodeName().contentEquals("pd:description")) {
                consume.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("selector")) {
                consume.setAttribute("selector", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("receiverTimeout")) {
                consume.setAttribute("maximumWait", n.getTextContent());
            }

        }

        consume.appendChild(consumerType);

        return consume;
    }

    public Element addJMSOnNewMessageActivity(Accelerator ac, Document tDoc, Node acNode, String acName, RetrieveOps retrieveOps)
            throws SQLException, SAXException, IOException {

        String queueRecXSLT = null;
        String jmsRepActXSLT = null;

        List<Flow> flows = jdbc.getActivitiesType(retrieveOps.getProcessName());

        for (Flow flow : flows) {
            if (flow.getActivityType().contentEquals("com.tibco.plugin.jms.JMSQueueEventSource")
                    || flow.getActivityType().contentEquals("com.tibco.plugin.jms.JMSTopicEventSource")) {
                queueRecXSLT = new String(flow.getActivityXslt(), StandardCharsets.UTF_8);
            }
            if (flow.getActivityType().contentEquals("com.tibco.plugin.jms.JMSReplyActivity")) {
                jmsRepActXSLT = new String(flow.getActivityXslt(), StandardCharsets.UTF_8);
            }
        }

        if (queueRecXSLT != null && jmsRepActXSLT != null) {

            Node queueRecNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(queueRecXSLT)))
                    .getDocumentElement();
            Node jmsRepActNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(jmsRepActXSLT)))
                    .getDocumentElement();

            Element jmsListener = tDoc.createElement("jms:listener");
            Element jmsConsumerType = tDoc.createElement("jms:consumer-type");
            Element jmsResponse = tDoc.createElement("jms:response");
            Element jmsBody = tDoc.createElement("jms:body");
            Element jmsReplyTo = tDoc.createElement("jms:reply-to");

            Element consumerTypeTag = null;

            jmsListener.setAttribute("doc:id", ac.generateRandom(8) + "ba44-4f56-9c63-d1d76a5d22ca");
            jmsListener.setAttribute("doc:name", acName);

            ArrayList<Node> tempNode = new ArrayList<>();
            ac.getNode(queueRecNode.getChildNodes(), 0, tempNode, "destination");
            ac.getNode(queueRecNode.getChildNodes(), 0, tempNode, "ConnectionReference");
            ac.getNode(queueRecNode.getChildNodes(), 0, tempNode, "pd:type");
            ac.getNode(queueRecNode.getChildNodes(), 0, tempNode, "acknowledgeMode");
            ac.getNode(queueRecNode.getChildNodes(), 0, tempNode, "PermittedMessageType");
            ac.getNode(queueRecNode.getChildNodes(), 0, tempNode, "pd:description");
            ac.getNode(queueRecNode.getChildNodes(), 0, tempNode, "selector");
            ac.getNode(queueRecNode.getChildNodes(), 0, tempNode, "receiverTimeout");

            ArrayList<Node> tempNode2 = new ArrayList<>();
            ac.getNode(jmsRepActNode.getChildNodes(), 0, tempNode2, "PermittedMessageType");
            ac.getNode(jmsRepActNode.getChildNodes(), 0, tempNode2, "JMSDeliveryMode");
            ac.getNode(jmsRepActNode.getChildNodes(), 0, tempNode2, "Body");

            for (Node n : tempNode) {
                if (n.getNodeName().contentEquals("ConnectionReference")) {
                    String resourceName = n.getTextContent().substring(n.getTextContent().lastIndexOf('/') + 1);
                    ;
                    resourceName = resourceName.replaceAll(" ", "_");
                    jmsListener.setAttribute("config-ref", resourceName.substring(0, resourceName.indexOf(".")));
                }
                if (n.getNodeName().contentEquals("destination")) {
                    jmsListener.setAttribute("destination", n.getTextContent());
                    jmsReplyTo.setAttribute("destination", n.getTextContent());
                }
                if (n.getNodeName().contentEquals("pd:type")
                        && n.getTextContent().contentEquals("com.tibco.plugin.jms.JMSQueueEventSource")) {
                    consumerTypeTag = tDoc.createElement("jms:queue-consumer");
                    jmsConsumerType.appendChild(consumerTypeTag);
                }

                if (n.getNodeName().contentEquals("pd:type")
                        && n.getTextContent().contentEquals("com.tibco.plugin.jms.JMSTopicEventSource")) {
                    consumerTypeTag = tDoc.createElement("jms:topic-consumer");
                    jmsConsumerType.appendChild(consumerTypeTag);
                }
                if (n.getNodeName().contentEquals("acknowledgeMode")) {
                    if (n.getTextContent().contentEquals("1")) {
                        jmsListener.setAttribute("ackMode", "AUTO");
                    }
                    if (n.getTextContent().contentEquals("3")) {
                        jmsListener.setAttribute("ackMode", "DUPS_OK");
                    }
                }
                if (n.getNodeName().contentEquals("PermittedMessageType")) {
                    String value = n.getTextContent().toLowerCase();
                    if (value.contentEquals("text")) {
                        value = "text/plain";
                        jmsListener.setAttribute("inboundContentType", value);
                    } else {
                        jmsListener.setAttribute("inboundContentType", "application/" + value);
                    }
                }
                if (n.getNodeName().contentEquals("pd:description")) {
                    jmsListener.setAttribute("doc:description", n.getTextContent());
                }
                if (n.getNodeName().contentEquals("selector")) {
                    jmsListener.setAttribute("selector", n.getTextContent());
                }
                if (n.getNodeName().contentEquals("receiverTimeout")) {
                    jmsListener.setAttribute("maximumWait", n.getTextContent());
                }
            }

            for (Node n2 : tempNode2) {
                if (n2.getNodeName().contentEquals("PermittedMessageType")) {
                    String value = n2.getTextContent().toLowerCase();
                    if (value.contentEquals("text")) {
                        value = "text/plain";
                        jmsResponse.setAttribute("outboundContentType", value);
                    } else {
                        jmsResponse.setAttribute("outboundContentType", "application/" + value);
                    }
                }
                if (n2.getNodeName().contentEquals("JMSDeliveryMode")) {
                    if (n2.getTextContent().contentEquals("PERSISTENT")) {
                        jmsResponse.setAttribute("persistentDelivery", "true");
                    }
                    if (n2.getTextContent().contentEquals("NON_PERSISTENT")) {
                        jmsResponse.setAttribute("persistentDelivery", "false");
                    }
                }
                if (n2.getNodeName().contentEquals("Body")) {
                    String value = n2.getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
                    jmsBody.setTextContent(value);
                }
            }

            jmsListener.appendChild(jmsConsumerType);
            jmsResponse.appendChild(jmsBody);
            jmsResponse.appendChild(jmsReplyTo);
            jmsListener.appendChild(jmsResponse);

            return jmsListener;
        } else {

            Element jmsListener = tDoc.createElement("jms:listener");
            Element jmsConsumerType = tDoc.createElement("jms:consumer-type");
            Element consumerTypeTag = null;

            jmsListener.setAttribute("doc:id", ac.generateRandom(8) + "ba44-4f56-9c63-d1d76a5d22ca");
            jmsListener.setAttribute("doc:name", acName);

            ArrayList<Node> node = new ArrayList<>();
            ac.getNode(acNode.getChildNodes(), 0, node, "pd:type");
            ac.getNode(acNode.getChildNodes(), 0, node, "destination");
            ac.getNode(acNode.getChildNodes(), 0, node, "ConnectionReference");
            ac.getNode(acNode.getChildNodes(), 0, node, "receiverTimeout");
            ac.getNode(acNode.getChildNodes(), 0, node, "acknowledgeMode");
            ac.getNode(acNode.getChildNodes(), 0, node, "PermittedMessageType");
            ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
            ac.getNode(acNode.getChildNodes(), 0, node, "selector");
            ac.getNode(acNode.getChildNodes(), 0, node, "JMSDeliveryMode");
            ac.getNode(acNode.getChildNodes(), 0, node, "durable");
            ac.getNode(acNode.getChildNodes(), 0, node, "subscriptionName");

            String activityType = "";

            for (Node n : node) {
                if (n.getNodeName().contentEquals("ConnectionReference")) {
                    String resourceName = n.getTextContent().substring(n.getTextContent().lastIndexOf('/') + 1);
                    ;
                    resourceName = resourceName.replaceAll(" ", "_");
                    jmsListener.setAttribute("config-ref", resourceName.substring(0, resourceName.indexOf(".")));
                }
                if (n.getNodeName().contentEquals("pd:type")) {
                    activityType = n.getTextContent();
                    if (activityType.contentEquals("com.tibco.plugin.jms.JMSQueueEventSource")) {
                        consumerTypeTag = tDoc.createElement("jms:queue-consumer");
                        jmsConsumerType.appendChild(consumerTypeTag);
                    }
                    if (activityType.contentEquals("com.tibco.plugin.jms.JMSTopicEventSource")) {
                        consumerTypeTag = tDoc.createElement("jms:topic-consumer");
                        jmsConsumerType.appendChild(consumerTypeTag);
                    }
//					if(activityType.contentEquals("com.tibco.plugin.jms.JMSQueueSignalInActivity")) {
//						consumerTypeTag = tDoc.createElement("jms:queue-consumer");
//						jmsConsumerType.appendChild(consumerTypeTag);
//					}
//				
//					if(activityType.contentEquals("com.tibco.plugin.jms.JMSTopicSignalInActivity")) {
//						consumerTypeTag = tDoc.createElement("jms:topic-consumer");
//						jmsConsumerType.appendChild(consumerTypeTag);
//					}
                }
                if (n.getNodeName().contentEquals("durable") && n.getTextContent().contentEquals("true")) {
                    consumerTypeTag.setAttribute("durable", n.getTextContent());
                }
                if (n.getNodeName().contentEquals("subscriptionName")) {
                    consumerTypeTag.setAttribute("subscriptionName", n.getTextContent());
                }
                if (n.getNodeName().contentEquals("destination")) {
                    jmsListener.setAttribute("destination", n.getTextContent());
                }
                if (n.getNodeName().contentEquals("JMSDeliveryMode")) {
                    if (activityType.contentEquals("com.tibco.plugin.jms.JMSTopicSignalInActivity")
                            || activityType.contentEquals("com.tibco.plugin.jms.JMSQueueSignalInActivity")) {
                        if (n.getTextContent().contentEquals("PERSISTENT")) {
                            jmsListener.setAttribute("persistentDelivery", "true");
                        }
                        if (n.getTextContent().contentEquals("NON_PERSISTENT")) {
                            jmsListener.setAttribute("persistentDelivery", "false");
                        }
                    }
                }
                if (n.getNodeName().contentEquals("acknowledgeMode")) {
                    if (n.getTextContent().contentEquals("1")) {
                        jmsListener.setAttribute("ackMode", "AUTO");
                    }
                    if (n.getTextContent().contentEquals("3")) {
                        jmsListener.setAttribute("ackMode", "DUPS_OK");
                    }
                }
                if (n.getNodeName().contentEquals("PermittedMessageType")) {
                    String value = n.getTextContent().toLowerCase();
                    if (value.contentEquals("text")) {
                        value = "text/plain";
                        jmsListener.setAttribute("inboundContentType", value);
                    } else {
                        jmsListener.setAttribute("inboundContentType", "application/" + value);
                    }
                }
                if (n.getNodeName().contentEquals("pd:description")) {
                    jmsListener.setAttribute("doc:description", n.getTextContent());
                }
                if (n.getNodeName().contentEquals("selector")) {
                    jmsListener.setAttribute("selector", n.getTextContent());
                }
                if (n.getNodeName().contentEquals("receiverTimeout")) {
                    jmsListener.setAttribute("maximumWait", n.getTextContent());
                }
            }

            jmsListener.appendChild(jmsConsumerType);

            return jmsListener;
        }

    }

    public Element addJMSPublishConsumeActivity(Accelerator ac, Document tDoc, Node acNode, String acName,
                                                ArrayList<Node> node) {

        Element publishConsume = tDoc.createElement("jms:publish-consume");
        Element jmsMessage = tDoc.createElement("jms:message");
        Element jmsBody = tDoc.createElement("jms:body");
        Element jmsPublishConfiguration = tDoc.createElement("jms:publish-configuration");
        Element jmsConsumeConfiguration = tDoc.createElement("jms:consume-configuration");
        Element jmsReplyTo = tDoc.createElement("jms:reply-to");

        publishConsume.setAttribute("doc:id", ac.generateRandom(8) + "ba44-4f56-9c63-d1d76a5d22ca");
        publishConsume.setAttribute("doc:name", acName);

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:type");
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "ConnectionReference");
        ac.getNode(acNode.getChildNodes(), 0, node, "PermittedMessageType");
        ac.getNode(acNode.getChildNodes(), 0, node, "replyToQueue");
        ac.getNode(acNode.getChildNodes(), 0, node, "destination");
        ac.getNode(acNode.getChildNodes(), 0, node, "Body");

        String activityType = "";
        boolean replyToQueue = false;

        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:type")) {
                activityType = n.getTextContent();
            }
            if (n.getNodeName().contentEquals("ConnectionReference")) {
                String resourceName = n.getTextContent().substring(n.getTextContent().lastIndexOf('/') + 1);
                ;
                resourceName = resourceName.replaceAll(" ", "_");
                publishConsume.setAttribute("config-ref", resourceName.substring(0, resourceName.indexOf(".")));
            }
            if (n.getNodeName().contentEquals("destination")) {
                if (!replyToQueue) {
                    jmsReplyTo.setAttribute("destination", n.getTextContent());
                    if (activityType.contentEquals("com.tibco.plugin.jms.JMSQueueRequestReplyActivity")) {
                        jmsReplyTo.setAttribute("destinationType", "QUEUE");
                    }
                    if (activityType.contentEquals("com.tibco.plugin.jms.JMSTopicRequestReplyActivity")) {
                        jmsReplyTo.setAttribute("destinationType", "TOPIC");
                    }
                }
                publishConsume.setAttribute("destination", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("pd:description")) {
                publishConsume.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("PermittedMessageType")) {
                String value = n.getTextContent().toLowerCase();
                if (value.contentEquals("text")) {
                    value = "text/plain";
                    jmsMessage.setAttribute("outboundContentType", value);
                } else {
                    jmsMessage.setAttribute("outboundContentType", "application/" + value);
                }
            }
            if (n.getNodeName().contentEquals("replyToQueue")) {
                replyToQueue = true;
                jmsReplyTo.setAttribute("destination",
                        n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue());
                if (activityType.contentEquals("com.tibco.plugin.jms.JMSQueueRequestReplyActivity")) {
                    jmsReplyTo.setAttribute("destinationType", "QUEUE");
                }
                if (activityType.contentEquals("com.tibco.plugin.jms.JMSTopicRequestReplyActivity")) {
                    jmsReplyTo.setAttribute("destinationType", "TOPIC");
                }
            }
            if (n.getNodeName().contentEquals("Body")) {
                jmsBody.setTextContent(n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue());
            }

        }

        publishConsume.appendChild(jmsMessage);
        jmsMessage.appendChild(jmsBody);
        jmsMessage.appendChild(jmsReplyTo);
        publishConsume.appendChild(jmsPublishConfiguration);
        publishConsume.appendChild(jmsConsumeConfiguration);

        return publishConsume;
    }

//	public Element addJMSAckActivity(Accelerator ac, Document tDoc, Node acNode, String acName,ArrayList<Node> node) {
//		
//		
//		
//		Element jmsAck = tDoc.createElement("jms:ack");
//		
//		jmsAck.setAttribute("doc:id", ac.generateRandom(8)+"ba44-4f56-9c63-d1d76a5d22ca");
//		jmsAck.setAttribute("doc:name", acName);
//		
//		return jmsAck;
//	}

}

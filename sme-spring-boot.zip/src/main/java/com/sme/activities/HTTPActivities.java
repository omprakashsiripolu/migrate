package com.sme.activities;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import com.sme.util.FlowOps;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.sme.dao.SharedConnections;
import com.sme.service.Accelerator;

@Component
public class HTTPActivities {

    @Autowired
    private SharedConnections shared;

    public Element addHttpListener(Accelerator ac, Document templateDoc, Node acNode, String activityName,
                                   ArrayList<Node> node) {

        Element listener = templateDoc.createElement("http:listener");
        listener.setAttribute("doc:name", activityName);
        listener.setAttribute("doc:id", ac.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
        listener.setAttribute("path", "*");

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "sharedChannel");
        ac.getNode(acNode.getChildNodes(), 0, node, "useHTTPAuthentication");

        for (Node n : node) {

            if (n.getNodeName().contentEquals("pd:description")) {
                listener.setAttribute("doc:description", n.getTextContent());
            }
//			if(n.getNodeName().contentEquals("useHTTPAuthentication")) {
//				if(n.getTextContent().contentEquals("true")) {
//					
//				}
//			}
            if (n.getNodeName().contentEquals("sharedChannel")) {
                String resourceName = n.getTextContent().substring(n.getTextContent().lastIndexOf('/') + 1);
                ;
                resourceName = resourceName.replaceAll(" ", "_");
                listener.setAttribute("config-ref", resourceName.substring(0, resourceName.indexOf(".")));
            }
        }

        return listener;
    }

    public Element addSetPayload(Accelerator ac, Document templateDoc, Node acNode, String activityName,
                                 ArrayList<Node> node) {

        Element setPayload = templateDoc.createElement("set-payload");
        setPayload.setAttribute("doc:name", activityName);
        setPayload.setAttribute("doc:id", ac.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "asciiContent");

        for (Node n : node) {

            if (n.getNodeName().contentEquals("pd:description")) {
                setPayload.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("asciiContent")) {
                String value = n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
                setPayload.setAttribute("value", value);
            }
        }

        return setPayload;
    }

    int httpRequestCount = 0;
    Map<String, ArrayList<String>> httpReqConf = new HashMap<>();

    public Element addHttpRequest(Accelerator ac, Document templateDoc, Node acNode, String activityName, FlowOps flowOps)
            throws SQLException, SAXException, IOException, ParserConfigurationException {

        String host = null, port = null;

        Element httpRequest = templateDoc.createElement("http:request");
        Element httpBody = templateDoc.createElement("http:body");

        ArrayList<Node> node = new ArrayList<>();
        ac.getNode(acNode.getChildNodes(), 0, node, "serverhost");
        ac.getNode(acNode.getChildNodes(), 0, node, "serverport");
        ac.getNode(acNode.getChildNodes(), 0, node, "Method");
        ac.getNode(acNode.getChildNodes(), 0, node, "PostData");

        for (int i = 0; i < node.size(); i++) {
            if (node.get(i).getNodeName().contentEquals("serverhost")) {
                host = node.get(i).getTextContent();
            }
            if (node.get(i).getNodeName().contentEquals("serverport")) {
                port = node.get(i).getTextContent();
            }

            if (node.get(i).getNodeName().contentEquals("Method")) {
                String value = node.get(i).getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
                httpRequest.setAttribute("method", value.substring(1, value.length() - 1));
            }
            if (node.get(i).getNodeName().contentEquals("PostData")) {
                String value = node.get(i).getFirstChild().getAttributes().getNamedItem("select").getTextContent();
                httpBody.setTextContent(value);
            }
        }

        if (httpReqConf.containsKey(host)) {
            ArrayList<String> values = httpReqConf.get(host);
            if (!values.contains(port)) {
                httpRequestCount++;
                while (values.size() < httpRequestCount) {
                    values.add(null);
                }
                values.add(httpRequestCount, port);
                shared.addHttpRequestConfigTag(ac, templateDoc, host, port, httpRequestCount, flowOps);
                httpRequest.setAttribute("config-ref", "HTTP_Request_configuration" + httpRequestCount);
            }
            if (values.contains(port)) {
                String targetValue = port;
                int index = values.indexOf(targetValue);
                httpRequest.setAttribute("config-ref", "HTTP_Request_configuration" + index);
            }
        } else {
            httpRequestCount++;
            ArrayList<String> values = new ArrayList<>();
            while (values.size() < httpRequestCount) {
                values.add(null);
            }
            values.add(httpRequestCount, port);
            httpReqConf.put(host, values);
            shared.addHttpRequestConfigTag(ac, templateDoc, host, port, httpRequestCount, flowOps);
            httpRequest.setAttribute("config-ref", "HTTP_Request_configuration" + httpRequestCount);
        }

        httpRequest.setAttribute("doc:name", activityName);
        httpRequest.setAttribute("doc:id", ac.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
        httpRequest.setAttribute("path", "/");

        return httpRequest;
    }
}
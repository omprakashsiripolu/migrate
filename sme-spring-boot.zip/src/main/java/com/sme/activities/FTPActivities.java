package com.sme.activities;

import java.util.ArrayList;

import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.sme.service.Accelerator;

@Component
public class FTPActivities {

    public Element addFtpDeleteActivity(Accelerator ac, Document tDoc, Node acNode, String activityName,
                                        ArrayList<Node> node) {

        Element ftpDelete = tDoc.createElement("ftp:delete");

        ftpDelete.setAttribute("doc:id", ac.generateRandom(8) + "-4f56-9c63-d1d76a5d22ca");
        ftpDelete.setAttribute("doc:name", activityName);

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "SharedUserData");
        ac.getNode(acNode.getChildNodes(), 0, node, "RemoteDirectory");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("SharedUserData")) {
                String resourceName = n.getTextContent().substring(n.getTextContent().lastIndexOf('/') + 1);
                ;
                resourceName = resourceName.replaceAll(" ", "_");
                ftpDelete.setAttribute("config-ref", resourceName.substring(0, resourceName.indexOf(".")));
            }
            if (n.getNodeName().contentEquals("RemoteDirectory")) {
                String remoteDir = n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
                ftpDelete.setAttribute("path", remoteDir.substring(1, remoteDir.length()));
            }
        }

        return ftpDelete;

    }

    public Element addFtpRenameActivity(Accelerator ac, Document tDoc, Node acNode, String activityName,
                                        ArrayList<Node> node) {

        Element ftpRename = tDoc.createElement("ftp:rename");

        ftpRename.setAttribute("doc:id", ac.generateRandom(8) + "-4f56-9c63-d1d76a5d22ca");
        ftpRename.setAttribute("doc:name", activityName);

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "SharedUserData");
        ac.getNode(acNode.getChildNodes(), 0, node, "OldRemoteDirectory");
        ac.getNode(acNode.getChildNodes(), 0, node, "OldRemoteFileName");
        ac.getNode(acNode.getChildNodes(), 0, node, "NewRemoteDirectory");
        ac.getNode(acNode.getChildNodes(), 0, node, "NewRemoteFileName");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("SharedUserData")) {
                String resourceName = n.getTextContent().substring(n.getTextContent().lastIndexOf('/') + 1);
                ;
                resourceName = resourceName.replaceAll(" ", "_");
                ftpRename.setAttribute("config-ref", resourceName.substring(0, resourceName.indexOf(".")));
            }
            if (n.getNodeName().contentEquals("NewRemoteDirectory")) {
                String newRemoteDir = n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
                ftpRename.setAttribute("path", newRemoteDir.substring(1, newRemoteDir.length()));
            }
            if (n.getNodeName().contentEquals("NewRemoteFileName")) {
                String newFileName = n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
                ftpRename.setAttribute("to", newFileName.substring(1, newFileName.length()));
            }
//			if(n.getNodeName().contentEquals("OldRemoteFileName")) {
//				String oldFileName = n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
//				ftpRename.setAttribute("method", value.substring(1, value.length()-1));
//			}
        }

        return ftpRename;

    }

    public Element addFtpListActivity(Accelerator ac, Document tDoc, Node acNode, String activityName,
                                      ArrayList<Node> node) {

        Element ftpList = tDoc.createElement("ftp:list");

        ftpList.setAttribute("doc:id", ac.generateRandom(8) + "-4f56-9c63-d1d76a5d22ca");
        ftpList.setAttribute("doc:name", activityName);
        ftpList.setAttribute("target", activityName.toLowerCase().replace(" ", "_"));

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "SharedUserData");
        ac.getNode(acNode.getChildNodes(), 0, node, "Directory");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("SharedUserData")) {
                String resourceName = n.getTextContent().substring(n.getTextContent().lastIndexOf('/') + 1);
                ;
                resourceName = resourceName.replaceAll(" ", "_");
                ftpList.setAttribute("config-ref", resourceName.substring(0, resourceName.indexOf(".")));
            }
            if (n.getNodeName().contentEquals("Directory")) {
                String remoteDir = n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
                ftpList.setAttribute("directoryPath", remoteDir.substring(1, remoteDir.length() - 1));
            }
        }

        return ftpList;

    }

    public Element addFtpCreateDirectoryActivity(Accelerator ac, Document tDoc, Node acNode, String activityName,
                                                 ArrayList<Node> node) {

        Element ftpCreateDirectory = tDoc.createElement("ftp:create-directory");

        ftpCreateDirectory.setAttribute("doc:id", ac.generateRandom(8) + "-4f56-9c63-d1d76a5d22ca");
        ftpCreateDirectory.setAttribute("doc:name", activityName);

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "SharedUserData");
        ac.getNode(acNode.getChildNodes(), 0, node, "RemoteDirName");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("SharedUserData")) {
                String resourceName = n.getTextContent().substring(n.getTextContent().lastIndexOf('/') + 1);
                ;
                resourceName = resourceName.replaceAll(" ", "_");
                ftpCreateDirectory.setAttribute("config-ref", resourceName.substring(0, resourceName.indexOf(".")));
            }
            if (n.getNodeName().contentEquals("RemoteDirName")) {
                String remoteDir = n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
                ftpCreateDirectory.setAttribute("directoryPath", remoteDir.substring(1, remoteDir.length()));
            }
        }

        return ftpCreateDirectory;

    }

    public Element addFtpReadActivity(Accelerator ac, Document tDoc, Node acNode, String activityName,
                                      ArrayList<Node> node) {

        Element ftpRead = tDoc.createElement("ftp:read");

        ftpRead.setAttribute("doc:id", ac.generateRandom(8) + "-4f56-9c63-d1d76a5d22ca");
        ftpRead.setAttribute("doc:name", activityName);
        ftpRead.setAttribute("target", activityName.toLowerCase().replace(" ", "_"));

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "SharedUserData");
        ac.getNode(acNode.getChildNodes(), 0, node, "RemoteFileName");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("SharedUserData")) {
                String resourceName = n.getTextContent().substring(n.getTextContent().lastIndexOf('/') + 1);
                ;
                resourceName = resourceName.replaceAll(" ", "_");
                ftpRead.setAttribute("config-ref", resourceName.substring(0, resourceName.indexOf(".")));
            }
            if (n.getNodeName().contentEquals("RemoteFileName")) {
                String remoteFileName = n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
                ftpRead.setAttribute("path", remoteFileName.substring(1, remoteFileName.length()));
            }
        }

        return ftpRead;

    }

//	public Element addFtpCopyActivity(Accelerator ac, Document tDoc,Node acNode, String activityName, ArrayList<Node> node){
//		
//		Element ftpCopy = tDoc.createElement("ftp:copy");
//		
//		ftpCopy.setAttribute("doc:id", ac.generateRandom(8)+"-4f56-9c63-d1d76a5d22ca");
//		ftpCopy.setAttribute("doc:name", activityName);
//		
//		node.removeAll(node);
//		ac.getNode(acNode.getChildNodes(), 0, node, "SharedUserData");
//		ac.getNode(acNode.getChildNodes(), 0, node, "RemoteFileName");
//		
//		for(Node n : node) {
//			if(n.getNodeName().contentEquals("SharedUserData")) {
//				String resourceName = n.getTextContent().substring(n.getTextContent().lastIndexOf('/')+1);;
//				resourceName = resourceName.replaceAll(" ", "_");
//				ftpCopy.setAttribute("config-ref", resourceName.substring(0, resourceName.indexOf(".")) );
//			}
//			if(n.getNodeName().contentEquals("RemoteFileName")) {
//				String fileName = n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
//				ftpCopy.setAttribute("sourcePath", fileName.substring(1, fileName.length()));
//				ftpCopy.setAttribute("targetPath",fileName.substring(1, fileName.length()));
//			}
//		}
//		
//		return ftpCopy;
//		
//	}

    public Element addFtpWriteActivity(Accelerator ac, Document tDoc, Node acNode, String activityName,
                                       ArrayList<Node> node) {

        Element ftpWrite = tDoc.createElement("ftp:write");
        Element ftpContent = tDoc.createElement("ftp:content");

        ftpWrite.setAttribute("doc:id", ac.generateRandom(8) + "-4f56-9c63-d1d76a5d22ca");
        ftpWrite.setAttribute("doc:name", activityName);

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "SharedUserData");
        ac.getNode(acNode.getChildNodes(), 0, node, "RemoteFileName");
        ac.getNode(acNode.getChildNodes(), 0, node, "useProcessData");
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "Data");
        ac.getNode(acNode.getChildNodes(), 0, node, "Append");
        ac.getNode(acNode.getChildNodes(), 0, node, "Overwrite");

        int ifUseProcessData = 0;

        for (Node n : node) {
            if (n.getNodeName().contentEquals("SharedUserData")) {
                String resourceName = n.getTextContent().substring(n.getTextContent().lastIndexOf('/') + 1);
                ;
                resourceName = resourceName.replaceAll(" ", "_");
                ftpWrite.setAttribute("config-ref", resourceName.substring(0, resourceName.indexOf(".")));
            }
            if (n.getNodeName().contentEquals("RemoteFileName")) {
                String fileName = n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
                ftpWrite.setAttribute("path", fileName.substring(1, fileName.length()));
            }
            if (n.getNodeName().contentEquals("pd:description")) {
                ftpWrite.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("useProcessData") && n.getTextContent().contentEquals("true")) {
                ifUseProcessData = 1;
            }
            if (ifUseProcessData == 1 && n.getNodeName().contentEquals("Data")) {
                String value = n.getFirstChild().getAttributes().getNamedItem("select").getTextContent();
                ftpContent.setTextContent(value);
                ftpWrite.appendChild(ftpContent);
            }
            if (n.getNodeName().contentEquals("Append") && n.getTextContent().contentEquals("true")) {
                ftpWrite.setAttribute("mode", "APPEND");
            }
            if (n.getNodeName().contentEquals("Overwrite") && n.getTextContent().contentEquals("true")) {
                ftpWrite.setAttribute("mode", "OVERWRITE");
            }
        }

        return ftpWrite;

    }

}

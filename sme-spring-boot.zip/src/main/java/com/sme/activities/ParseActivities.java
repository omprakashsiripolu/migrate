package com.sme.activities;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.sme.service.Accelerator;
import com.sme.util.ActivityOps;

@Component
public class ParseActivities {
    

    public Element transformActivity(Accelerator accelerator, Document tDoc, Node acNode, String acName, int seqId,
                                     ArrayList<Node> node, ActivityOps activityOps) {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:ee") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:ee", "http://www.mulesoft.org/schema/mule/ee/core");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/ee/core http://www.mulesoft.org/schema/mule/ee/core/current/mule-ee.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);

            // create driver depencency in pom.xml
        }

        Element transform = tDoc.createElement("ee:transform");
        transform.setAttribute("doc:name", acName);
        transform.setAttribute("doc:id", accelerator.generateRandom(8) + "-9b5e-4a86-b01c-cd738c5276d4");

        Element variables = tDoc.createElement("ee:variables");
        Element setVariable = tDoc.createElement("ee:set-variable");
        setVariable.setAttribute("variableName", acName.replace(" ", "-"));

        node.removeAll(node);
        accelerator.getNode(acNode.getChildNodes(), 0, node, "pd:type");
        String to = node.get(0).getTextContent();

        int manEff = 1;
        if (to.contains("com.tibco.plugin.mapper.MapperActivity")) {
        	   manEff = activityOps.calManualEfrt(accelerator, acNode);
               activityOps.addToDo(accelerator, "ee:transform", acName, seqId,manEff+45, manEff+20,"activity");
        } else {
        	 manEff = activityOps.calManualEfrt(accelerator, acNode);
            activityOps.addToDo(accelerator, "ee:transform", acName, seqId,manEff, manEff-5,"activity");
        }

        if (to.contentEquals("com.tibco.plugin.xml.XMLParseActivity")
                || to.contentEquals("com.tibco.plugin.java.JavaToXmlActivity")) {
            to = "xml";
        } else if (to.contentEquals("com.tibco.plugin.java.XmlToJavaActivity")) {
            to = "java";
        } else {
            to = "json";
        }

        String map = null;

        if (to == "xml") {
            node.removeAll(node);
            accelerator.getNode(acNode.getChildNodes(), 0, node, "xsl:value-of");
            for (Node n : node) {
                if (n.getNodeName().contentEquals("xsl:value-of")) {
                    map = n.getAttributes().getNamedItem("select").getNodeValue();
//            if(map.contains("/")) {
//            map = map.substring(map.indexOf("$")+1,map.indexOf("/"));
//            }
//            map = map.substring(map.indexOf("$")+1);
//            map = "\""+map+"\"";
                }
            }
        }
        if (to == "json") {
            node.removeAll(node);
            accelerator.getNode(acNode.getChildNodes(), 0, node, "xsl:value-of");
            for (Node n : node) {
                if (n.getNodeName().contentEquals("xsl:value-of")) {
                    map = n.getAttributes().getNamedItem("select").getNodeValue();
//            if(map.contains("/")) {
//            map = map.substring(map.indexOf("$")+1,map.indexOf("/"));
//            }
//            map = map.substring(map.indexOf("$")+1);
//            map = "\""+map+"\"";
                }
            }
        }
        if (to == "java") {
            node.removeAll(node);
            accelerator.getNode(acNode.getChildNodes(), 0, node, "xsl:value-of");
            for (Node n : node) {
                if (n.getNodeName().contentEquals("xsl:value-of")) {
                    map = n.getAttributes().getNamedItem("select").getNodeValue();
//            if(map.contains("/")) {
//            map = map.substring(map.indexOf("$")+1,map.indexOf("/"));
//            }
//            map = map.substring(map.indexOf("$")+1);
//            map = "\""+map+"\"";
                }
            }
        }
        setVariable.setTextContent("%dw 2.0\n" + "output application/" + to + "\n" + "---\n" + "vars." + map);

        variables.appendChild(setVariable);
        transform.appendChild(variables);

        return transform;
    }

}

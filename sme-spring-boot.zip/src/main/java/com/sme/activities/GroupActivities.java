package com.sme.activities;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.sme.dao.JDBCConnection;
import com.sme.service.Accelerator;
import com.sme.util.ActivityOps;
import com.sme.util.FlowOps;
import com.sme.util.RetrieveOps;

@Component
public class GroupActivities {
//	static JDBCConnection jdbc = new JDBCConnection();

    @Autowired
    private JDBCConnection jdbc;

    //    @Autowired
//    private FlowOps flowOps;
//    @Autowired
//    private GroupActivities groupActs;

    public void parseGroupActivities(Accelerator accelerator, String processName, String parentId, Document tDoc, Element until,
                                     String groupName, FlowOps flowOps)
            throws SQLException, SAXException, IOException, DOMException, ParserConfigurationException {

        List<com.sme.dao.entity.GroupActivities> groupActivities =
                jdbc.getActivityWithParentIdGroup(accelerator, processName, groupName, parentId, tDoc, until, flowOps);
        try {
            ArrayList<String> seqList = new ArrayList<>();

            for (com.sme.dao.entity.GroupActivities g : groupActivities) {
                seqList.add(Integer.toString(g.getSeqId()));
            }

            if (seqList.size() == 1) {
                flowOps.addActivityToGroupActivities(accelerator, processName, groupActivities, tDoc, until, parentId);
            }
            if (seqList.size() > 1) {
                flowOps.addActivitiesToGroupActivities(accelerator, processName, groupActivities, parentId, tDoc, until);
            }

            for (com.sme.dao.entity.GroupActivities g : groupActivities) {
                if (g.getParentId().contains(",")) {
                    seqList.remove(Integer.toString(g.getSeqId()));
                }
            }

            for (String seqId : seqList) {
                parseGroupActivities(accelerator, processName, seqId, tDoc, until, groupName, flowOps);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Element untilSuccessfulActivity(Accelerator accelerator, Document tDoc, Node acNode, String groupName, int seqId,
                                           ArrayList<Node> node, String mulesoftActivity, FlowOps flowOps,
                                           ActivityOps activityOps, RetrieveOps retrieveOps)
            throws SQLException, DOMException, SAXException, IOException, ParserConfigurationException {

        String processName = retrieveOps.getProcessName();
        Element group = tDoc.createElement("until-successful");
        node.removeAll(node);
        accelerator.getNode(acNode.getChildNodes(), 0, node, "pd:groupType");
        if (node.get(0).getTextContent().contentEquals("inputLoop")) {
            group = tDoc.createElement("foreach");
            group.setAttribute("doc:name", groupName);
            group.setAttribute("doc:id", accelerator.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
            node.removeAll(node);
            accelerator.getNode(acNode.getChildNodes(), 0, node, "pd:over");
            accelerator.getNode(acNode.getChildNodes(), 0, node, "pd:indexSlot");

            group.setAttribute("collection", node.get(0).getTextContent());
            group.setAttribute("counterVariableName", node.get(1).getTextContent());

            parseGroupActivities(accelerator, processName, Integer.toString(0), tDoc, group, groupName, flowOps);
            activityOps.addToDo(accelerator, "foreach", groupName, seqId, 6.0,2.0,"Activity");
            return group;
        }

        group.setAttribute("doc:name", groupName);
        group.setAttribute("doc:id", accelerator.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        group.setAttribute("maxRetries", "5");

        parseGroupActivities(accelerator, processName, Integer.toString(0), tDoc, group, groupName, flowOps);
        activityOps.addToDo(accelerator, "until-successful", groupName, seqId,6.0, 2.0, "Activity");
        return group;
    }
}

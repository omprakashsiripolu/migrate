package com.sme.activities;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;

import javax.xml.parsers.ParserConfigurationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.sme.dao.JDBCConnection;
import com.sme.service.Accelerator;
import com.sme.util.RetrieveOps;

@Component
public class JavaActivities {
    @Autowired
    private RetrieveOps retrieveOps;
//	static JDBCConnection jdbc = new JDBCConnection();

    @Autowired
    private JDBCConnection jdbc;

    public Element javaCodeActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,
                                    String MulesoftActivity) throws SQLException, SAXException, IOException, ParserConfigurationException {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:java") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:java", "http://www.mulesoft.org/schema/mule/java");
            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/java http://www.mulesoft.org/schema/mule/java/current/mule-java.xsd";
            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }
        Element javaInvoke = tDoc.createElement("java:invoke");
        Element javaArgs = tDoc.createElement("java:args");

        String processName = retrieveOps.getProcessName();
        if (processName.contains("/")) {
            processName = processName.substring(processName.lastIndexOf("/"), processName.lastIndexOf(".process"));
        } else {
            processName = processName.substring(0, processName.lastIndexOf(".process"));
        }

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "fullsource");
        ac.getNode(acNode.getChildNodes(), 0, node, "inputData");
        ac.getNode(acNode.getChildNodes(), 0, node, "javaCodeActivityInput");
        ArrayList<String> inputParams = new ArrayList<>();

        String argsStatement = "";
        ac.getNode(acNode.getChildNodes(), 0, node, "packageName");
        ac.getNode(acNode.getChildNodes(), 0, node, "fileName");
        String packName = "";
        String className = "";
        for (Node n : node) {
            if (n.getNodeName().contentEquals("packageName")) {
                packName = n.getTextContent();
            }
            if (n.getNodeName().contentEquals("fileName")) {
                className = n.getTextContent();
            }
        }
        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                javaInvoke.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("fullsource")) {
                javaInvoke.setAttribute("class", packName + "." + className);
                javaInvoke.setAttribute("method", "invoke()");
            }
            if (n.getNodeName().contentEquals("inputData")) {
                for (int i = 0; i < n.getChildNodes().getLength(); i++) {
                    inputParams.add(n.getChildNodes().item(i).getFirstChild().getTextContent());
                }
                argsStatement = "#[" + "{";
                for (String parameterName : inputParams) {
                    argsStatement += parameterName + ":" + "map" + ",";
                }
                argsStatement = argsStatement.substring(0, argsStatement.length() - 1) + "}]";

            }
            if (n.getNodeName().contentEquals("javaCodeActivityInput")) {

                ArrayList<String> inputBinds = new ArrayList<>();
                for (int i = 0; i < n.getChildNodes().getLength(); i++) {
                    if (n.getFirstChild() != null) {
                        // inputBinds.add(childNode.getFirstChild().getAttributes().getNamedItem("select").getNodeValue());
                        if (n.getChildNodes().item(i).getFirstChild().getAttributes().getNamedItem("select") != null) {
                            inputBinds.add(n.getChildNodes().item(i).getFirstChild().getAttributes()
                                    .getNamedItem("select").getNodeValue());
                        }
                    }
                }
                for (String inpData : inputBinds) {
                    argsStatement = argsStatement.replaceFirst("map", Matcher.quoteReplacement(inpData));
                }
                argsStatement = argsStatement.replace("$Start", "vars.Start");
                argsStatement = argsStatement.replace("input", "minput");
            }

            if (javaArgs != null) {

                // javaArgs.setTextContent(argsStatement);
                javaArgs.setTextContent(argsStatement);
            }

        }
        javaInvoke.setAttribute("instance", "#[vars." + acName.toLowerCase().replace(" ", "_") + "new" + "]");
        javaInvoke.setAttribute("doc:name", acName);
        javaInvoke.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        javaInvoke.setAttribute("target", acName.toLowerCase().replace(" ", "_"));

        javaInvoke.appendChild(javaArgs);
        return javaInvoke;

    }

    public Element muleJavaNewActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node,
                                       String MulesoftActivity) throws SQLException, SAXException, IOException, ParserConfigurationException {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:java") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:java", "http://www.mulesoft.org/schema/mule/java");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/java http://www.mulesoft.org/schema/mule/java/current/mule-java.xsd";
            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }
        Element javaNew = tDoc.createElement("java:new");
        // Element javaArgs = tDoc.createElement("java:args");

        String processName = retrieveOps.getProcessName();
        if (processName.contains("/")) {
            processName = processName.substring(processName.lastIndexOf("/"), processName.lastIndexOf(".process"));
        } else {
            processName = processName.substring(0, processName.lastIndexOf(".process"));
        }
        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "fullsource");
        ac.getNode(acNode.getChildNodes(), 0, node, "packageName");
        ac.getNode(acNode.getChildNodes(), 0, node, "fileName");
        String packName = "";
        String className = "";
        for (Node n : node) {
            if (n.getNodeName().contentEquals("packageName")) {
                packName = n.getTextContent().replace(".", File.separator);
            }
            if (n.getNodeName().contentEquals("fileName")) {
                className = n.getTextContent();
            }
        }
        for (Node n : node) {
            if (n.getNodeName().contentEquals("fullsource")) {
                String fullClassCode = n.getTextContent();
                Path directory = Paths
                        .get(ac.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                                + "main" + File.separator + "java" + File.separator + packName);
                Files.createDirectories(directory);
                try (FileWriter writer = new FileWriter(ac.getTrgProjectDir().getAbsolutePath()
                        + File.separator + "src" + File.separator + "main" + File.separator + "java" + File.separator
                        + packName + File.separator + className + ".java")) {
                    writer.write(fullClassCode);
                    javaNew.setAttribute("class", packName.replace(File.separator, ".") + "." + className);
                    javaNew.setAttribute("constructor", packName + className + "()");
                }

            }

        }
        javaNew.setAttribute("doc:name", acName + "New");
        javaNew.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        javaNew.setAttribute("target", acName.toLowerCase().replace(" ", "_") + "new");

        return javaNew;

    }

    public Element addInvokeStatic(Accelerator ac, Document tDoc, Node acNode, String activityName)
            throws SQLException, IOException {
        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:java") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:java", "http://www.mulesoft.org/schema/mule/java");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/java http://www.mulesoft.org/schema/mule/java/current/mule-java.xsd";
            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }
        Element javaInvokeStatic = tDoc.createElement("java:invoke-static");
        javaInvokeStatic.setAttribute("doc:name", activityName);
        javaInvokeStatic.setAttribute("doc:id", ac.generateRandom(8) + "-449f-462c-a23f-586ef47fb276");
        javaInvokeStatic.setAttribute("target", activityName.toLowerCase().replace(" ", "_"));
        ArrayList<Node> node = new ArrayList<>();
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "className");
        ac.getNode(acNode.getChildNodes(), 0, node, "methodName");
        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                javaInvokeStatic.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("className")) {
                javaInvokeStatic.setAttribute("class", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("methodName")) {
                javaInvokeStatic.setAttribute("method", n.getTextContent());
            }


            ArrayList<String> javaConfigFile = new ArrayList<>();
            ArrayList<String> javaConfigFileName = new ArrayList<>();

            jdbc.getJavaConfigFiles(javaConfigFile, javaConfigFileName);

            ArrayList<String> packName = new ArrayList<>();

            for (int i = 0; i < javaConfigFile.size(); i++) {
                String packageName = "";
                packageName = javaConfigFile.get(i);
                if (packageName.contains("package ")) {
                    packageName = packageName.substring(packageName.indexOf("package ") + 8, packageName.indexOf(";"));
                    if (!packName.contains(packageName)) {
                        packName.add(packageName);
                        Path directory = Paths.get(
                                ac.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator
                                        + "main" + File.separator + "java" + File.separator + packageName);
                        Files.createDirectories(directory);
                    }
                    try (FileOutputStream fos = new FileOutputStream(ac.getTrgProjectDir().getAbsolutePath()
                            + File.separator + "src" + File.separator + "main" + File.separator + "java"
                            + File.separator + packageName + File.separator + javaConfigFileName.get(i))) {
                        fos.write(javaConfigFile.get(i).getBytes());
                    }
                } else {
                    try (FileOutputStream fos = new FileOutputStream(ac.getTrgProjectDir().getAbsolutePath()
                            + File.separator + "src" + File.separator + "main" + File.separator + "java"
                            + File.separator + javaConfigFileName.get(i))) {
                        fos.write(javaConfigFile.get(i).getBytes());
                    }
                }

            }

        }
        return javaInvokeStatic;
    }
}

package com.sme.activities;

import java.io.File;
import java.util.ArrayList;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

//import com.sme.dao.JDBCConnection;
import com.sme.dao.SharedConnections;
import com.sme.service.Accelerator;
import com.sme.util.ActivityOps;

//@Component
@Component
public class FileActivities {
    //	@Autowired
//	private JDBCConnection jdbcConnection;

    @Autowired
    private SharedConnections sharedConnections;

    public Element filePollarActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node) {
        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        Element fileListner = tDoc.createElement("file:listener");
        Element strategy = tDoc.createElement("scheduling-strategy");
        Element frequency = tDoc.createElement("fixed-frequency");
        Element fileMatcher = tDoc.createElement("file:matcher");

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "fileName");
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "pollInterval");
        ac.getNode(acNode.getChildNodes(), 0, node, "includeCurrent");
        ac.getNode(acNode.getChildNodes(), 0, node, "includeSubDirectories");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                fileListner.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("fileName")) {
                if (n.getTextContent().contains("%")) {
                    fileListner.setAttribute("directory", n.getTextContent());
                    // fileMatcher.setAttribute("filenamePattern",
                    // n.getTextContent().substring(n.getTextContent().lastIndexOf("\\")+1,n.getTextContent().length()));
                } else {

                    fileListner.setAttribute("directory",
                            n.getTextContent().substring(0, n.getTextContent().lastIndexOf(File.separator)));
                    fileMatcher.setAttribute("filenamePattern", n.getTextContent()
                            .substring(n.getTextContent().lastIndexOf(File.separator) + 1, n.getTextContent().length()));
                }
            }
            if (n.getNodeName().contentEquals("pollInterval")) {
                frequency.setAttribute("frequency", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("includeCurrent")) {
                fileMatcher.setAttribute("directories", (n.getTextContent().equals("false")) ? "EXCLUDE" : "INCLUDE");
            }
            if (n.getNodeName().contentEquals("includeCurrent")) {
                fileMatcher.setAttribute("regularFiles", (n.getTextContent().equals("false")) ? "EXCLUDE" : "INCLUDE");
            }
        }
        fileListner.setAttribute("doc:name", acName);
        fileListner.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        fileListner.setAttribute("config-ref", "File_config1");
        fileListner.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
        frequency.setAttribute("timeUnit", "SECONDS");

//			String directory1= (node.get(3).getTextContent()=="false"?"EXCLUDE":"INCLUDE");

        node.removeAll(node);

        fileListner.appendChild(strategy);
        strategy.appendChild(frequency);

        fileListner.appendChild(fileMatcher);

        return fileListner;
    }

    public Element fileReadActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node) {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        Element fileRead = tDoc.createElement("file:read");

        node.removeAll(node);

        ac.getNode(acNode.getChildNodes(), 0, node, "fileName");
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                fileRead.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("fileName")) {
                if (n.getTextContent().contains("%")) {
                    fileRead.setAttribute("path",
                            n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue());
                } else {
                    fileRead.setAttribute("path",
                            n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue().substring(1,
                                    n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue().length()
                                            - 1));
                }
            }
        }

        fileRead.setAttribute("doc:name", acName);
        fileRead.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        fileRead.setAttribute("config-ref", "File_config1");
        fileRead.setAttribute("target", acName.replace(" ", "-"));

        return fileRead;
    }

    public Element listFilesActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node) {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        Element listFiles = tDoc.createElement("file:list");
        Element fileMatcher = tDoc.createElement("file:matcher");

        node.removeAll(node);

        ac.getNode(acNode.getChildNodes(), 0, node, "fileName");
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "mode");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                listFiles.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("fileName")) {
                String directoryName = n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue()
                        .substring(1,
                                n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue().length() - 1);
                if (directoryName.contains(File.separator)) {
                    listFiles.setAttribute("directoryPath",
                            directoryName.substring(0, directoryName.lastIndexOf(File.separator)));
                    fileMatcher.setAttribute("filenamePattern",
                            directoryName.substring(directoryName.lastIndexOf(File.separator) + 1));
                } else {
                    directoryName = n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
                    listFiles.setAttribute("directoryPath", directoryName);
                    // fileMatcher.setAttribute("filenamePattern",directoryName.substring(directoryName.lastIndexOf("/")+1));

                }

            }
            if (n.getNodeName().contentEquals("mode")) {
                if (n.getTextContent().contentEquals("only-files")) {
                    fileMatcher.setAttribute("regularFiles",
                            (n.getTextContent().contentEquals("only-files")) ? "INCLUDE" : "EXCLUDE");
                } else if ((n.getTextContent().contentEquals("only-directories"))) {
                    fileMatcher.setAttribute("directories",
                            (n.getTextContent().contentEquals("only-directories")) ? "INCLUDE" : "EXCLUDE");
                } else {
                    fileMatcher.setAttribute("regularFiles", "INCLUDE");
                    fileMatcher.setAttribute("directories", "INCLUDE");
                }
            }

        }

        listFiles.setAttribute("doc:name", acName);
        listFiles.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        listFiles.setAttribute("config-ref", "File_config1");
        listFiles.setAttribute("target", acName.toLowerCase().replace(" ", "_"));

        // substring(pName.lastIndexOf('/')+1,pName.lastIndexOf('.');
        // System.out.println(directoryName.substring(directoryName.lastIndexOf("\\")+1));
        listFiles.appendChild(fileMatcher);
        return listFiles;
    }

    public Element copyFileActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node) {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        Element copyFile = tDoc.createElement("file:copy");

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "fromFileName");
        ac.getNode(acNode.getChildNodes(), 0, node, "toFileName");
        ac.getNode(acNode.getChildNodes(), 0, node, "overwrite");
        ac.getNode(acNode.getChildNodes(), 0, node, "createMissingDirectories");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                copyFile.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("fromFileName")) {
                String fromFileName = n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
                copyFile.setAttribute("sourcePath", fromFileName.substring(1, fromFileName.length() - 1));
            }
            if (n.getNodeName().contentEquals("toFileName")) {
                String toFileName = n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
                copyFile.setAttribute("targetPath", toFileName.substring(1, toFileName.length() - 1));
            }
            if (n.getNodeName().contentEquals("overwrite")) {
                copyFile.setAttribute("overwrite", (n.getTextContent().equals("true")) ? "true" : "false");
            }
            if (n.getNodeName().contentEquals("createMissingDirectories")) {
                copyFile.setAttribute("createParentDirectories",
                        (n.getTextContent().equals("true")) ? "true" : "false");
            } else {
                copyFile.setAttribute("createParentDirectories", "false");
            }
        }

        copyFile.setAttribute("doc:name", acName);
        copyFile.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        copyFile.setAttribute("config-ref", "File_config1");

        return copyFile;
    }

    public Element removeFileActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node) {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        Element deleteFile = tDoc.createElement("file:delete");

        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "xsl:value-of");
        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                deleteFile.setAttribute("doc:description", n.getTextContent());
            }

            if (n.getNodeName().contentEquals("xsl:value-of")) {
                if (n.getTextContent().contains("%")) {
                    deleteFile.setAttribute("path", n.getAttributes().getNamedItem("select").getNodeValue());
                } else {
                    deleteFile.setAttribute("path", n.getAttributes().getNamedItem("select").getNodeValue().substring(1,
                            node.get(0).getAttributes().getNamedItem("select").getNodeValue().length() - 1));
                }
            }
        }

        deleteFile.setAttribute("doc:name", acName);
        deleteFile.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        deleteFile.setAttribute("config-ref", "File_config1");
        deleteFile.setAttribute("target", acName.toLowerCase().replace(" ", "_"));
        return deleteFile;
    }

    public Element renameFileActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node) {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        Element renameFile = tDoc.createElement("file:rename");

        node.removeAll(node);

        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "fromFileName");
        ac.getNode(acNode.getChildNodes(), 0, node, "toFileName");
        ac.getNode(acNode.getChildNodes(), 0, node, "overwrite");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                renameFile.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("fromFileName")) {
                String fromFileName = n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
                renameFile.setAttribute("path", fromFileName.substring(1, fromFileName.length() - 1));
            }
            if (n.getNodeName().contentEquals("toFileName")) {
                String toFileName = n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue();
                renameFile.setAttribute("to", toFileName.substring(1, toFileName.length() - 1));

            }
            if (n.getNodeName().contentEquals("overwrite")) {
                renameFile.setAttribute("overwrite", (n.getTextContent().equals("true")) ? "true" : "false");
            }

        }

        renameFile.setAttribute("doc:name", acName);
        renameFile.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        renameFile.setAttribute("config-ref", "File_config1");
        renameFile.setAttribute("target", acName.toLowerCase().replace(" ", "_"));

        return renameFile;
    }

    public Element writeFileActivity(Accelerator ac, Document tDoc, Node acNode, String acName, ArrayList<Node> node) {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }
        Element writeFile = tDoc.createElement("file:write");
        Element fileContent = tDoc.createElement("file:content");

        node.removeAll(node);

        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "createMissingDirectories");
        ac.getNode(acNode.getChildNodes(), 0, node, "fileName");
        ac.getNode(acNode.getChildNodes(), 0, node, "append");
        ac.getNode(acNode.getChildNodes(), 0, node, "textContent");

        writeFile.setAttribute("doc:name", acName);
        writeFile.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        writeFile.setAttribute("config-ref", "File_config1");

        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                writeFile.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("createMissingDirectories")) {
                writeFile.setAttribute("createParentDirectories",
                        (n.getTextContent().equals("true")) ? "true" : "false");
            }
            if (n.getNodeName().contentEquals("append")) {
                writeFile.setAttribute("mode", (n.getTextContent().equals("true")) ? "APPEND" : "OVERWRITE");
            }
            if (n.getNodeName().contentEquals("fileName")) {
                writeFile.setAttribute("path", n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue());
            }
            if (n.getNodeName().contentEquals("textContent")) {
                fileContent.setTextContent(n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue());
            }
        }
        writeFile.appendChild(fileContent);
        return writeFile;
    }

    public Element createDirectoryActivity(Accelerator ac, Document tDoc, Node acNode, String acName, int seqId,
                                           ArrayList<Node> node, ActivityOps activityOps) {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");
            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";
            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }

        Element createDir = tDoc.createElement("file:create-directory");
        node.removeAll(node);
        ac.getNode(acNode.getChildNodes(), 0, node, "fileName");
        createDir.setAttribute("doc:name", acName);
        createDir.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        createDir.setAttribute("config-ref", "File_config1");
        for (Node n : node) {
            if (n.getNodeName().contentEquals("fileName")) {
                createDir.setAttribute("directoryPath",
                        n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue());
            }
        }
        int manEff = activityOps.calManualEfrt(ac, acNode);
        activityOps.addToDo(ac, "file:create-directory", acName, seqId,manEff, manEff-5,"activity");
        return createDir;
    }

    public Element createFileActivity(Accelerator ac, Document tDoc, Node acNode, String acName, int seqId, ArrayList<Node> node,
                                      ActivityOps activityOps) {

        if (tDoc.getFirstChild().getAttributes().getNamedItem("xmlns:file") == null) {
            Element mule = (Element) tDoc.getFirstChild();
            mule.setAttribute("xmlns:file", "http://www.mulesoft.org/schema/mule/file");

            String schemaLocation = mule.getAttribute("xsi:schemaLocation");
            schemaLocation += " http://www.mulesoft.org/schema/mule/file http://www.mulesoft.org/schema/mule/file/current/mule-file.xsd";

            mule.setAttribute("xsi:schemaLocation", schemaLocation);
        }
        Element createFile = tDoc.createElement("file:write");

        node.removeAll(node);

        ac.getNode(acNode.getChildNodes(), 0, node, "pd:description");
        ac.getNode(acNode.getChildNodes(), 0, node, "createMissingDirectories");
        ac.getNode(acNode.getChildNodes(), 0, node, "fileName");
        createFile.setAttribute("doc:name", acName);
        createFile.setAttribute("doc:id", ac.generateRandom(8) + "-eadc-40b9-98cc-268d14076da0");
        createFile.setAttribute("config-ref", "File_config1");
        for (Node n : node) {
            if (n.getNodeName().contentEquals("pd:description")) {
                createFile.setAttribute("doc:description", n.getTextContent());
            }
            if (n.getNodeName().contentEquals("createMissingDirectories")) {
                createFile.setAttribute("createParentDirectories",
                        (n.getTextContent().equals("true")) ? "true" : "false");
            }
            if (n.getNodeName().contentEquals("fileName")) {
                createFile.setAttribute("path",
                        n.getFirstChild().getAttributes().getNamedItem("select").getNodeValue());
            }
        }
        int manEff = activityOps.calManualEfrt(ac, acNode);
        activityOps.addToDo(ac, "file:write", acName, seqId,manEff, manEff-5,"activity");
        return createFile;

    }

}

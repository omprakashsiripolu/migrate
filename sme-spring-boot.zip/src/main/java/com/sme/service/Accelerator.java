package com.sme.service;

import java.io.*;
import java.sql.SQLException;
import java.util.*;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import com.sme.dao.entity.ProjectStatus;
import com.sme.dao.entity.Projects;
import com.tibco.security.AXSecurityException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.sme.dao.InsertToDb;
import com.sme.dao.JDBCConnection;
import com.sme.util.ActivityOps;
import com.sme.util.FileOperations;
import com.sme.util.FlowOps;
import com.sme.util.RetrieveOps;
import org.xml.sax.SAXException;
import org.zeroturnaround.zip.ZipUtil;
import reactor.core.publisher.Flux;

@Service
public class Accelerator implements IAccelerator {

    private static final Logger logger = LoggerFactory.getLogger(Accelerator.class);

    private static final Set<Integer> executionList = Collections.synchronizedSet(new HashSet<>());

    private ArrayList<Node> node;

    @Autowired
    private InsertToDb insert;

    @Autowired
    private JDBCConnection jdbc;

    @Autowired
    private FileOperations fileOps;
    @Autowired
    private RetrieveOps retrieveOps;
    @Autowired
    private FlowOps flowOps;
    @Autowired
    private ActivityOps actOps;

    @Value("${working.dir}")
    private String workingDir;

    public String getWorkingDir() {
        return workingDir;
    }

    public void setWorkingDir(String workingDir) {
        this.workingDir = workingDir;
    }

    private File src;
    private File trg;

    public File getSrc() {
        return src;
    }

    public void setSrc(File src) {
        this.src = src;
    }

    public File getTrg() {
        return trg;
    }

    public void setTrg(File trg) {
        this.trg = trg;
    }

    private String srcPath;

    public String getSrcPath() {
        return srcPath;
    }

    public void setSrcPath(String srcPath) {
        this.srcPath = srcPath;
    }

    private String trgPath;

    public String getTrgPath() {
        return trgPath;
    }

    public void setTrgPath(String trgPath) {
        this.trgPath = trgPath;
    }

    private int currentExecutionId;

    public int getCurrentExecutionId() {
        return currentExecutionId;
    }

    protected void setCurrentExecutionId(int executionId) {
        this.currentExecutionId = executionId;
    }

    private String projectName;

    public String getProjectName() {
        return projectName;
    }

    protected void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    private File srcProjectDir;

    protected void setSrcProjectDir(File srcProjectDir) {
        this.srcProjectDir = srcProjectDir;
    }

    public File getSrcProjectDir() {
        return srcProjectDir;
    }

    private File trgProjectDir;

    protected void setTrgProjectDir(File trgProjectDir) {
        this.trgProjectDir = trgProjectDir;
    }

    public File getTrgProjectDir() {
        return trgProjectDir;
    }

    private String xsltToDwlFolder;

    public String getXsltToDwlFolder() {
        return xsltToDwlFolder;
    }

    public void setXsltToDwlFolder(String xsltToDwlFolder) {
        this.xsltToDwlFolder = xsltToDwlFolder;
    }

    public ArrayList<Node> getNode() {
        return node;
    }

    public void setNode(ArrayList<Node> node) {
        this.node = node;
    }

    private void extractZipFile(String zipFilePath) {
        if (zipFilePath == null) {
            Projects projects = jdbc.getProject(getCurrentExecutionId());
            ZipUtil.unpack(new ByteArrayInputStream(projects.getSourceProject()),
                    new File(getSrcPath()));
            return;
        }
        ZipUtil.unpack(new File(zipFilePath), new File(getSrcPath()));
    }

    private void saveProjectInformation(String zipFilePath) {
        // zip file name can be different to the folder/projectName that is archived
        // get zip file name by reading the .zip file
        File sourceProjectZip = new File(zipFilePath);
        String zipFileName = sourceProjectZip.getName();

        // temporarily set project name same as zip file name
        setProjectName(zipFileName);

        try (FileInputStream fis = new FileInputStream(sourceProjectZip)) {
            Projects projects = jdbc.insertNewProject(zipFileName, zipFileName, fis.readAllBytes());
            int executionId = projects.getExecId();
            setCurrentExecutionId(executionId);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    private void updateProjectInformation() {
        String targetDir = getTrg().getAbsolutePath();
        String input = targetDir + File.separator + getProjectName();
        ZipUtil.pack(
                new File(input),
                new File(input + ".zip"));
        File targetProjectZip = new File(targetDir + File.separator + getProjectName() + ".zip");
        try (FileInputStream fis = new FileInputStream(targetProjectZip)) {
            jdbc.updateProject(fis.readAllBytes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        // save the excel file in DB and cleanup
//        File xsltToDwlExcelBaseFolder = new File(getXsltToDwlFolder());
//        zipXsltToDwlExcelAndSaveToProjectRecord(xsltToDwlExcelBaseFolder, getTrg().getAbsolutePath());
//        FileSystemUtils.deleteRecursively(xsltToDwlExcelBaseFolder);
    	}


    private void zipXsltToDwlExcelAndSaveToProjectRecord(File xsltToDwlDir, String trgPath) {
        String filename = xsltToDwlDir.getAbsolutePath().substring(
                xsltToDwlDir.getAbsolutePath().lastIndexOf(File.separator) + 1);
        File outputFile = new File(trgPath + File.separator + filename + ".zip");
        ZipUtil.pack(xsltToDwlDir, outputFile);
        try (FileInputStream fis = new FileInputStream(outputFile)) {
            jdbc.updateProjectWithXsltToDwlExcel(fis.readAllBytes());
        } catch (IOException e) {
            logger.error("Unable to save XsltToDwlExcel zip file");
        }
    }

    /**
     * @param zipFilePath - read zip file from this location
     */
    protected void updateSourceVariablesWithInput(String zipFilePath) {
        String srcPath = getWorkingDir() + File.separator
                + getCurrentExecutionId() + File.separator + "src";
        setSrcPath(srcPath);
        setSrc(new File(srcPath));
        if (getSrc().mkdirs()) {
            logger.info("Directory created for {}", getSrc().getAbsolutePath());
        }

        extractZipFile(zipFilePath);

        String[] sourceProjects = new File(srcPath).list((dir, name) -> new File(dir, name).isDirectory());
        assert sourceProjects != null;
        assert sourceProjects.length == 1;
        if (!sourceProjects[0].equals(getProjectName())) {
            setProjectName(sourceProjects[0]);
            jdbc.updateProjectName(getCurrentExecutionId(), getProjectName());
        }

        setSrcProjectDir(new File(getSrcPath()
                + File.separator + getProjectName()));

        if (getSrcProjectDir().mkdirs()) {
            logger.info("Directories created for source project {}", getSrcProjectDir().getAbsolutePath());
        }

    }

    protected void updateTargetVariablesFromDB(int executionId) {
        Projects project = jdbc.getProject(executionId);
        if (project == null || project.getName() == null) {
            throw new RuntimeException("Unable to find project with provided executionId: " + executionId);
        }
        setProjectName(project.getName());

        String trgPath = getWorkingDir() + File.separator
                + executionId + File.separator + "trg";
        setTrgPath(trgPath);
        setTrg(new File(trgPath));
        if (getTrg().mkdirs()) {
            logger.info("Directory created {}", getTrg().getAbsolutePath());
        } else {
            logger.error("Unable to create directory for {}", getTrg().getAbsolutePath());
        }

        setTrgProjectDir(new File(trgPath
                + File.separator + getProjectName()));
        if (getTrgProjectDir().mkdirs()) {
            logger.info("Directory created {}", getTrgProjectDir().getAbsolutePath());
        } else {
            logger.error("Unable to create directory for {}", getTrgProjectDir().getAbsolutePath());
        }

        setXsltToDwlFolder(getTrgPath() + File.separator + "XsltToDwl");
        if (new File(getXsltToDwlFolder()).mkdirs()) {
            logger.info("Directory created {}", getXsltToDwlFolder());
        } else {
            logger.error("Unable to create directory for {}", getXsltToDwlFolder());
        }
    }

    /**
     * This method is responsible for extracting all elements of
     * source Tibco project.
     * <ul>
     *     <li>
     *         zip file argument is passed, it will be uploaded to database.
     *     </li>
     *     <li>
     *         local directories are created relative to working.dir and
     *         using executionId referencing source and target project dirs
     *     </li>
     *     <li>
     *         execution ID is tracked for referencing in rest of the classes
     *         and DB operations
     *     </li>
     *     <li>
     *         all the elements are then extracted from source project and saved to
     *         database using the same execution ID
     *     </li>
     * </ul>
     *
     * @param args - args passed from main method
     */
    private void analyze(String... args) {
        if (args.length != 1) {
            logger.error("project is not provided to process");
            throw new RuntimeException("project is not provided to process");
        }

        String zipFilePath = args[0];

        // read zip file name as initial project name
        // create table entry for the project being worked upon
        saveProjectInformation(zipFilePath);

        // use execution id to create execId/src folder and unzip to this folder
        // also update project name if zip file name is different to exploded project dir
        updateSourceVariablesWithInput(zipFilePath);

        analyze();
    }

    /**
     * This can be invoked with executionId
     * First application will upload zip file to DB to get executionId
     * This ID is passed as input for analysis
     *
     * @param executionId - execution ID of the project uploaded to DB
     */
    @Override
    public void analyze(int executionId) {
        if (checkExecutionInProgress(executionId)) {
            throw new RuntimeException("Another process is already running for the same project. " +
                    "Wait till it is complete.");
        }

        analyzePreStep(executionId);

        analyze();
    }

    private void analyzePreStep(int executionId) {
        // use executionId to save to DB
        setCurrentExecutionId(executionId);
        jdbc.setExecId(executionId);

        // create required folders in working.dir and unzip source project
        updateSourceVariablesWithInput(null);
    }

    public boolean checkExecutionInProgress(int executionId) {
        return executionList.contains(executionId);
    }

    @Override
    public void deleteProject(Projects projects) {
        jdbc.deleteProject(projects);
    }

    private void analyzeStepOneInitialization(ArrayList<File> processes) {
        executionList.add(getCurrentExecutionId());
        // creating array list variables
        node = new ArrayList<>();
        processes = new ArrayList<>();

        logger.info("Analysis stage running for project {} " +
                "and execution ID is {}", getProjectName(), getCurrentExecutionId());

        // this is required so that all rows can be created using correct execution ID
        jdbc.setExecId(getCurrentExecutionId());

        // set start of analyze after updating execution ID
        jdbc.updateProjectStatus(ProjectStatus.ANALYZE_START, null);
        logger.info(":STAGE:INITIALIZING");
        logger.info("Directories are created");
    }

    private void analyzeStepTwoLoadProperties(ArrayList<File> processes)
            throws SQLException, AXSecurityException, IOException,
            ParserConfigurationException, InterruptedException, SAXException {
        logger.info(":STAGE:VARIABLES");
        logger.info("Read source variables");
        fileOps.loadProperties(this, processes);
    }

    private void analyzeStepThreeExtractServiceAgents()
            throws TransformerConfigurationException, SQLException,
            ParserConfigurationException, IOException, SAXException {
        logger.info(":STAGE:SERVICE AGENT");
        logger.info("Service agents are extracted from source project");
        fileOps.findServiceAgent(this, getSrcProjectDir());
    }

    private void analyzeStepFourExtractWSDLs()
            throws SQLException, ParserConfigurationException,
            IOException, SAXException {
        logger.info(":STAGE:WSDL");
        logger.info("WSDLs are extracted from the source project");
        fileOps.insertWsdls(getSrcProjectDir());
    }

    private void analyzeStepFiveExtractJavaSrc()
            throws SQLException, ParserConfigurationException, IOException, SAXException {
        logger.info(":STAGE:JAVA");
        logger.info("Java files are extracted from the source project");
        fileOps.insertJavaFiles(getSrcProjectDir());
    }

    private void analyzeStepSixExtractProcess(ArrayList<File> processes)
            throws SQLException, ParserConfigurationException, IOException, SAXException {
        logger.info(":STAGE:PROCESS");
        logger.info("Operations are extracted from the source project");
        insert.insertOpertaion(this, processes);
    }

    private void analyzeStepSevenSourceProjectCleanup() {
        //            fileOps.removeSource(getSrc().getAbsolutePath());
        // commenting this line to remove deleting source files
        logger.info(":STAGE:CLEANUP");
        logger.info("Source project clean up is complete");

        jdbc.updateProjectStatus(ProjectStatus.ANALYZE_END, null);
    }

    private void analyzeStepEightWrapUp() {
        executionList.remove(getCurrentExecutionId());
    }

    private void analyzeStepsCatchExceptions(Exception e, int executionId) {
        jdbc.updateProjectStatus(ProjectStatus.ANALYZE_ERROR, e.getMessage());
        executionList.remove(executionId);
        logger.error(":STAGE:ERROR: An error occurred: " + e.getMessage(), e);
    }

    private void analyze() {
        ArrayList<File> processes = new ArrayList<>();
        analyzeStepOneInitialization(processes);
        try {
            analyzeStepTwoLoadProperties(processes);
            analyzeStepThreeExtractServiceAgents();
            analyzeStepFourExtractWSDLs();
            analyzeStepFiveExtractJavaSrc();
            analyzeStepSixExtractProcess(processes);
            analyzeStepSevenSourceProjectCleanup();
        } catch (Exception e) {
            analyzeStepsCatchExceptions(e, getCurrentExecutionId());
        }
        analyzeStepEightWrapUp();
        logger.info("analysis complete for project {} with id {}", getProjectName(), getCurrentExecutionId());
    }

    private void migrationPreStep(int executionId) {
        executionList.add(executionId);
        // allows for calling this method directly by passing executionId
        setCurrentExecutionId(executionId);
        jdbc.setExecId(executionId);

        jdbc.updateProjectStatus(ProjectStatus.MIGRATION_START, null);
        // fetch from DB, if not found throws RunTimeException
        // sets required directories for creating Mule project
        updateTargetVariablesFromDB(executionId);

        // creating node variable to ensure this is created
        if (node == null) node = new ArrayList<>();
    }

    private void migrationStepOneInitialization() {
        // delete target directories to allow for Mule template project to be created
        fileOps.removeTarget(getTrg().getAbsolutePath());

        logger.info("Migration step started for project {} " +
                "and execution ID is {}", getProjectName(), getCurrentExecutionId());
    }

    private void migrationStepTwoCreateMuleProject()
            throws IOException, InterruptedException {
        logger.info("Starting to create target project");

        fileOps.createMuleProjectAndDirs(this);
        logger.info(":STAGE:SCAFFOLD");
        logger.info("Mule project is created along with required target directories");
    }

    private void migrationStepThreeGlobalElements()
            throws SQLException, IOException, ParserConfigurationException, SAXException {
        flowOps.setGlobalElements(this);
        logger.info(":STAGE:GLOBAL ELEMENTS");
        logger.info("Global elements are inserted in target project");
    }

    private void migrationStepFourRAMLFiles() throws SQLException {
        // moved below out of insertRestService() method
        insert.insertRamlData(this);
        logger.info(":STAGE:RAML");
        logger.info("RAML files are created in target project");

    }

    private void migrationStepFiveConfigFiles() throws SQLException, IOException {
        retrieveOps.setConfigs(this);
        logger.info(":STAGE:CONFIG");
        logger.info("Configs are created in target project");
    }

    private void migrationStepSixFlows()
            throws SQLException, ParserConfigurationException, IOException, SAXException {
        retrieveOps.retrieve(this, flowOps);
        logger.info(":STAGE:FLOW");
        logger.info("Majority of the conversion is complete in target project");
    }

    private void migrationStepSevenFlowTodo() {
        flowOps.generateToDo(this);
        logger.info(":STAGE:FLOW TODO");
        logger.info("Created todo from flowOps in target project");
    }

    private void migrationStepEightActivityTodo() throws SQLException {
        actOps.generateToDo(this);
        actOps.insertManualEffort(this);
        logger.info(":STAGE:ACTIVITY TODO");
        logger.info("Created todo from actOps in target project");
    }

    private void migrationStepNineSaveOutput() {
        // update table with the output and completion time
        updateProjectInformation();

        jdbc.updateProjectStatus(ProjectStatus.MIGRATION_END, null);
    }

    private void migrationStepsCatchExceptions(Exception e, int executionId) {
        jdbc.updateProjectStatus(ProjectStatus.MIGRATION_ERROR, e.getMessage());
        executionList.remove(executionId);
        logger.error(":STAGE:ERROR: An error occurred: " + e.getMessage(), e);
    }

    private void migrationStepWrapUp() {
        executionList.remove(getCurrentExecutionId());
    }

    /**
     * project referenced in executionId parameter will be transformed
     * <ul>
     *     <li>
     *         fetch project name from DB using execution ID
     *     </li>
     *     <li>
     *         create required trg folders relative to working.dir
     *         and using execution ID
     *     </li>
     *     <li>
     *         clear target folder if it exists and start migration
     *     </li>
     * </ul>
     *
     * @param executionId - indicates the execution ID referenced from table
     */
    @Override
    public void migrate(int executionId) {
        if (checkExecutionInProgress(executionId)) {
            throw new RuntimeException("Another process is already running for the same project. " +
                    "Wait till it is complete.");
        }
        migrationPreStep(executionId);
        migrationStepOneInitialization();
        try {
            migrationStepTwoCreateMuleProject();
            migrationStepThreeGlobalElements();
            migrationStepFourRAMLFiles();
            migrationStepFiveConfigFiles();
            migrationStepSixFlows();
            migrationStepSevenFlowTodo();
            migrationStepEightActivityTodo();
            migrationStepNineSaveOutput();

        } catch (Exception e) {
            migrationStepsCatchExceptions(e, executionId);
        }
        migrationStepWrapUp();
        logger.info("migration complete for project {} with id {}", getProjectName(), getCurrentExecutionId());
    }


    /**
     * This method reads source project that exists in @see srcPath
     * and saves the transformed Mule project in @see trgPath
     * {mule.command} is invoked to create base mule project.
     * {mule.command}, pom.xml & template.xml along with required
     * directories exist in classpath part of resources
     *
     * @param args - args passed for main method
     */
    @Override
    public void convert(String... args) {
        analyze(args);
        migrate(getCurrentExecutionId());
    }

    /**
     * file is uploaded to server using controller
     *
     * @param file - file to upload
     */
    @Override
    public Projects saveProjectFile(MultipartFile file) {
        String projectName = file.getOriginalFilename();
        try {
            return jdbc.insertNewProject(projectName, projectName, file.getBytes());
        } catch (IOException e) {
            logger.error("Unable to save project to database");
            throw new RuntimeException("Unable to save project to database", e);
        }
    }

    @Override
    public Projects checkStatus(int executionId) {
        return jdbc.getProject(executionId);
    }

    @Override
    public Flux<String> streamMigration(int executionId) {
        ArrayList<File> processes = new ArrayList<>();
        return Flux.generate(() -> 0, (i, s) -> {
            try {
                switch (i) {
                    case 0:
                        analyzePreStep(executionId);
                        s.next("Initializing to analyze project with execution ID: " + executionId);
                        break;
                    case 1:
                        analyzeStepOneInitialization(processes);
                        s.next("Extracting global variables from source project");
                        break;
                    case 2:
                        analyzeStepTwoLoadProperties(processes);
                        s.next("Looking for service agents");
                        break;
                    case 3:
                        analyzeStepThreeExtractServiceAgents();
                        s.next("Reading WSDL files");
                        break;
                    case 4:
                        analyzeStepFourExtractWSDLs();
                        s.next("Store custom Java source");
                        break;
                    case 5:
                        analyzeStepFiveExtractJavaSrc();
                        s.next("Look for all process files");
                        break;
                    case 6:
                        analyzeStepSixExtractProcess(processes);
                        s.next("Cleanup working directories");
                        break;
                    case 7:
                        analyzeStepSevenSourceProjectCleanup();
                        s.next("Analysis is complete");
                        break;
                    case 8:
                        analyzeStepEightWrapUp();
                        s.next("Migration is starting for project with ID:" + executionId);
                        break;
                    case 9:
                        migrationPreStep(executionId);
                        s.next("Initializing migration");
                        break;
                    case 10:
                        migrationStepOneInitialization();
                        s.next("Create Mule project using maven template");
                        break;
                    case 11:
                        migrationStepTwoCreateMuleProject();
                        s.next("Global Elements are being created");
                        break;
                    case 12:
                        migrationStepThreeGlobalElements();
                        s.next("RAML files are converted");
                        break;
                    case 13:
                        migrationStepFourRAMLFiles();
                        s.next("Config Files processed");
                        break;
                    case 14:
                        migrationStepFiveConfigFiles();
                        s.next("Flows in mule are created");
                        break;
                    case 15:
                        migrationStepSixFlows();
                        s.next("TODO list created for Flows");
                        break;
                    case 16:
                        migrationStepSevenFlowTodo();
                        s.next("TODO list updated for remaining Activities");
                        break;
                    case 17:
                        migrationStepEightActivityTodo();
                        s.next("Output is saved to database");
                        break;
                    case 18:
                        migrationStepNineSaveOutput();
                        s.next("Migration is complete");
                        break;
                    case 19:
                        migrationStepWrapUp();
                        s.complete();
                        break;
                }
            } catch (Exception e) {
                if (i <= 8) {
                    analyzeStepsCatchExceptions(e, executionId);
                } else {
                    migrationStepsCatchExceptions(e, executionId);
                }
                s.complete();
            }
            return i + 1;
        });
    }

    public String nodeToString(Node node) {
        StringWriter sw = new StringWriter();
        try {
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            transformer.transform(new DOMSource(node), new StreamResult(sw));
        } catch (TransformerException te) {
            logger.error("An error occurred: " + te.getMessage());
        }
        return sw.toString();
    }

    public void removeBlankLines(Document doc) {
        try {
            XPath xp = XPathFactory.newInstance().newXPath();
            NodeList nl = (NodeList) xp.evaluate("//text()[normalize-space(.)='']", doc, XPathConstants.NODESET);

            for (int i = 0; i < nl.getLength(); ++i) {
                Node node = nl.item(i);
                node.getParentNode().removeChild(node);
            }
        } catch (Exception e) {
            logger.error("An error occurred: " + e.getMessage());
        }
    }

    public void getNode(NodeList nodeList, int i, ArrayList<Node> nlist, String nName) {
        if (i == nodeList.getLength()) {
            return;
        }
        if (nodeList.item(i).getNodeName().contentEquals(nName)) {
            nlist.add(nodeList.item(i));
        }
        if (nodeList.item(i).hasChildNodes()) {
            getNode(nodeList.item(i).getChildNodes(), 0, nlist, nName);
        }
        getNode(nodeList, i + 1, nlist, nName);
    }

    public void getNodeLike(NodeList nodeList, int i, ArrayList<Node> nlist, String nName) {
        if (i == nodeList.getLength()) {
            return;
        }
        if (nodeList.item(i).getNodeName().endsWith(nName)) {
            nlist.add(nodeList.item(i));
        }
        if (nodeList.item(i).hasChildNodes()) {
            getNodeLike(nodeList.item(i).getChildNodes(), 0, nlist, nName);
        }
        getNodeLike(nodeList, i + 1, nlist, nName);
    }

    public String generateRandom(int n) {
        int leftLimit = 97; // letter 'A'
        int rightLimit = 122; // letter 'Z'
        Random random = new Random();
        StringBuilder buffer = new StringBuilder(n);
        for (int i = 0; i < n; i++) {
            int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
            buffer.append((char) randomLimitedInt);
        }
        return buffer.toString();
    }

    public void writeFile(Document doc, File file) {
        try {
            doc.getDocumentElement().normalize();
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            doc.setXmlStandalone(true);
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(file.getAbsolutePath()));
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(source, result);
            logger.info("File updation : " + file.getName() + " file updated successfully at "
                    + file.getParentFile().getAbsolutePath());
        } catch (Exception e) {
            logger.error("An error occurred: " + e.getMessage());
        }
    }

}

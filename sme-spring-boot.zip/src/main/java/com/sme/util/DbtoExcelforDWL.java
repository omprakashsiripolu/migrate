package com.sme.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.List;

import com.sme.dao.entity.Flow;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.internal.build.AllowSysOut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sme.dao.JDBCConnection;
import com.sme.service.Accelerator;

@Component
public class DbtoExcelforDWL {

    private static final Logger logger = LoggerFactory.getLogger(DbtoExcelforDWL.class);
//	static JDBCConnection jdbc = new JDBCConnection();

    @Autowired
    private JDBCConnection jdbc;

    public void dbToExcel(Accelerator accelerator, String processName) throws SQLException, IOException {
        File baseFolder = new File(accelerator.getXsltToDwlFolder());
        if (!baseFolder.exists() || !baseFolder.isDirectory()) {
            Files.createDirectory(Paths.get(accelerator.getXsltToDwlFolder()));
        }

        processName = processName.substring(0, processName.lastIndexOf("."));
        List<Flow> flows = jdbc.getFlowDetails();

        // Create an Excel workbook and sheet
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Sheet1");

        // Create the header row
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("ACTIVITY_NAME");
        headerRow.createCell(1).setCellValue("ACTIVITY_XSLT");
        headerRow.createCell(2).setCellValue("DWL code");
        // Populate the data rows
        int rowNum = 1;
        for (Flow f : flows) {
            Row row = sheet.createRow(rowNum++);
            String pName = f.getProcessesName();
            pName = pName.substring(0, pName.lastIndexOf("."));
            if (f.getActivityXslt().length > 31000) {
                String xsltFolder = baseFolder.getAbsolutePath()
                        + File.separator + processName + "_text";
                Path folderPath = Paths.get(xsltFolder);
                if (!Files.exists(folderPath)) {
                    try {
                        Files.createDirectory(folderPath);
                    } catch (IOException e) {
                        logger.error("Failed to create the folder in XSLTtoDWL folder. " + e.getMessage());
                    }
                }
                try (FileOutputStream fos = new FileOutputStream(
                        folderPath + File.separator + processName + "_" + f.getActivityName() + ".txt")) {
                    fos.write(f.getActivityXslt());
                }
            }
            if (f.getActivityXslt().length <= 31000) {
                if (f.getActivityXslt() != null) {
                    row.createCell(0).setCellValue(pName + "_" + f.getActivityName());
                    row.createCell(1).setCellValue(new String(f.getActivityXslt(), StandardCharsets.UTF_8));
                }
            }
        }
        // Write the workbook to an Excel file
        try (FileOutputStream outputStream = new FileOutputStream(
                baseFolder.getAbsolutePath() + File.separator + accelerator.getProjectName() + ".xlsx")) {
            workbook.write(outputStream);
        }
        workbook.close();
        logger.info("Data written to Excel successfully.");
    }
}

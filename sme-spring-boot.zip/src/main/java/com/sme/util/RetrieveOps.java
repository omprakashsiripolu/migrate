package com.sme.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.sme.dao.JDBCConnection;
import com.sme.dao.entity.ConfigFiles;
import com.sme.dao.entity.Flow;
import com.sme.service.Accelerator;

@Component
public class RetrieveOps {

    private static final Logger logger = LoggerFactory.getLogger(RetrieveOps.class);
    ArrayList<String> processNames = new ArrayList<>();
    public ArrayList<String> sharedConfigs = new ArrayList<>();
    ArrayList<String> activityNames = new ArrayList<>();
    ArrayList<String> merges = new ArrayList<>();
//	static JDBCConnection jdbc = new JDBCConnection();

    @Autowired
    private JDBCConnection jdbc;

//    @Autowired
//    private FlowOps flowOps;

    @Autowired
    private DbtoExcelforDWL dbToExcelforDWL;

    @Autowired
    private FileOperations fileOps;

    //    static RetrieveOps retrieveOps = new RetrieveOps();
    //	static Accelerator accelerator = new Accelerator();
//    static FlowOps flowOps = new FlowOps();
    static DocumentBuilderFactory docFactory;
    public static DocumentBuilder docBuilder;
    //    static FileOperations fileOps = new FileOperations();
//    static DbtoExcelforDWL dbToExcelforDWL = new DbtoExcelforDWL();
    String process_Name = null;

    public void retrieve(Accelerator accelerator, FlowOps flowOps) throws SQLException, ParserConfigurationException, SAXException, IOException {
        List<Flow> flows = jdbc.getProcessNames();
        docFactory = DocumentBuilderFactory.newInstance();
        docBuilder = docFactory.newDocumentBuilder();

        for (Flow flow : flows) {
            processNames.add(flow.getProcessesName());
        }
        
        HashSet<String> uniqueSet = new HashSet<>(processNames);
        processNames = new ArrayList<>(uniqueSet);
        
        for (String processName : processNames) {
        	//ActivityOps.actCount = 0;
        	
            ClassLoader classLoader = getClass().getClassLoader();
            Document tDoc = docBuilder.parse(classLoader.getResourceAsStream("template.xml"));
            tDoc.normalizeDocument();
            accelerator.removeBlankLines(tDoc);

            sharedConfigs.removeAll(sharedConfigs);
            activityNames.removeAll(activityNames);
            merges.removeAll(merges);

            fileOps.writeWsdls(accelerator);

            Element flow = tDoc.createElement("flow");
            flow.setAttribute("name", processName.substring(processName.indexOf("/") + 1, processName.lastIndexOf("."))
                    .replace("/", "-").replace(" ", "_"));
            flow.setAttribute("doc:id", accelerator.generateRandom(8) + "-7384-4baa-8a93-6efa0670cce7");

            process_Name = processName;
            logger.info("Process Name: " + processName);

            parseActivities(accelerator, processName, Integer.toString(0), tDoc, flow, flowOps);

            // -------------------------------
            // Define the replacement strings
            String firstReplacement = "${";
            String lastReplacement = "}";

            // Find all text nodes in the XML and perform the replacements
            replaceAttributeValues(tDoc.getDocumentElement(), firstReplacement, lastReplacement);

            dbToExcelforDWL.dbToExcel(accelerator, processName.replace("/", "_"));
            if (processName.contains("/")) {
                File muleDir = new File(accelerator.getTrgProjectDir().getAbsolutePath()
                        + File.separator + "src" + File.separator + "main"
                        + File.separator + "mule" + File.separator
                        + processName.substring(0, processName.lastIndexOf("/")).replace(" ", "_"));
                muleDir.mkdirs();

                accelerator.writeFile(tDoc,
                        new File(accelerator.getTrgProjectDir().getAbsolutePath()
                                + File.separator + "src" + File.separator + "main"
                                + File.separator + "mule" + File.separator
                                + processName.substring(0, processName.lastIndexOf(".")).replace(" ", "_") + ".xml"));
            } else {
                accelerator.writeFile(tDoc,
                        new File(accelerator.getTrgProjectDir().getAbsolutePath()
                                + File.separator + "src" + File.separator + "main"
                                + File.separator + "mule" + File.separator
                                + processName.substring(0, processName.lastIndexOf(".")).replace(" ", "_") + ".xml"));
            }
          //  logger.info("Activity Count = "+ActivityOps.actCount);
        }
    }

    public void parseActivities(Accelerator accelerator, String processName, String parentId, Document tDoc,
                                Element flow, FlowOps flowOps)
            throws SQLException, SAXException, IOException, DOMException, ParserConfigurationException {

        List<Flow> flows = flowOps.getActivityWithParentId(accelerator, processName, parentId, tDoc, flow);
        ArrayList<String> seqList = new ArrayList<>();

        for (Flow f : flows) {
            seqList.add(String.valueOf(f.getSeqId()));
        }

        if (seqList.size() == 1) {
            flowOps.addActivityToFlow(accelerator, processName, flows, tDoc, flow, parentId);
        }
        if (seqList.size() > 1) {
            flowOps.addActivitiesToFlow(accelerator, processName, flows, parentId, tDoc, flow);
        }

        for (Flow f : flows) {
            if (f.getParentId().contains(",")) {
                seqList.remove(Integer.toString(f.getSeqId()));
            }
        }

//		if(processName.contains("/")) {
//			File muleDir = new File(Accelerator.trgProjectFile.getAbsolutePath()+"\\src\\main\\mule\\"+processName.substring(processName.indexOf("/"),processName.lastIndexOf("/")));
//			muleDir.mkdirs();
//
//			accelerator.writeFile(tDoc,new File(Accelerator.trgProjectFile.getAbsolutePath()+"\\src\\main\\mule\\"+processName.substring(processName.indexOf("/"),processName.lastIndexOf(".")).replace(" ", "_")+".xml"));
//		}
//		else {
//			accelerator.writeFile(tDoc,new File(Accelerator.trgProjectFile.getAbsolutePath()+"\\src\\main\\mule\\"+processName.substring(0,processName.lastIndexOf(".")).replace(" ", "_")+".xml"));
//		}

        for (String seqId : seqList) {
            parseActivities(accelerator, processName, seqId, tDoc, flow, flowOps);
        }

    }

    public String getProcessName() {
        return process_Name;
    }

    public void replaceAttributeValues(Node node, String firstReplacement, String lastReplacement) {
        try {
            NamedNodeMap attributes = node.getAttributes();
            if (attributes != null) {
                for (int i = 0; i < attributes.getLength(); i++) {
                    Node attribute = attributes.item(i);
                    String attributeValue = attribute.getNodeValue();
                    if (attributeValue.contains("%%")) {
                        attributeValue = attributeValue.substring(2, attributeValue.length() - 2);
                        attributeValue = firstReplacement + attributeValue + lastReplacement;
                        // attributeValue = attributeValue.replaceFirst("%%", firstReplacement);
                        // attributeValue = attributeValue.replaceAll("%%(?!.*%%)", lastReplacement);
                        if (attributeValue.contains("/")) {
                            attributeValue = attributeValue.replace("/", ".");
                        }
                        attribute.setNodeValue(attributeValue);
                    }
                    if (attributeValue.contains("$_globalVariables")) {
                        attributeValue = attributeValue.substring(attributeValue.lastIndexOf("GlobalVariables") + 16,
                                attributeValue.length());
                        attributeValue = attributeValue.replace("/", ".");
                        attributeValue = firstReplacement + attributeValue + lastReplacement;
                        attribute.setNodeValue(attributeValue);
                    }
                }
            }
        } catch (Exception e) {
            logger.error("An error occurred: " + e.getMessage());
        }

        NodeList children = node.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            replaceAttributeValues(child, firstReplacement, lastReplacement);
        }
    }

    public void setConfigs(Accelerator accelerator) throws SQLException, IOException {
        List<ConfigFiles> configFilesList = jdbc.getConfigs();
        for (ConfigFiles file : configFilesList) {
            if (file.getName().endsWith(".yaml")) {
                File yamlfile = new File(accelerator.getTrgProjectDir().getAbsolutePath()
                        + File.separator + "src" + File.separator + "main"
                        + File.separator + "resources" + File.separator + "config"
                        + file.getName());
                FileOutputStream fos = new FileOutputStream(yamlfile);
                fos.write(file.getConfig());
                fos.close();
            }
        }
    }

}

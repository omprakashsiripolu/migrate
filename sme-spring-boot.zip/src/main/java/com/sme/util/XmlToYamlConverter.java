package com.sme.util;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.yaml.snakeyaml.Yaml;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.sme.dao.JDBCConnection;
import com.tibco.security.AXSecurityException;
import com.tibco.security.ObfuscationEngine;

@Component
public class XmlToYamlConverter {
//    static XmlToYamlConverter converter = new XmlToYamlConverter();
//	static JDBCConnection jdbc = new JDBCConnection();

    @Autowired
    private JDBCConnection jdbc;

    public void setYamlData(File projectFile) throws ParserConfigurationException, SAXException,
            IOException, SQLException, InterruptedException, AXSecurityException {

        ArrayList<File> xmls = new ArrayList<>();
        this.getFiles(projectFile.listFiles(), 0, xmls, ".substvar");

        List<Map<String, Object>> globalConfigs = new ArrayList<>();

        for (File xml : xmls) {
            String path = xml.getAbsolutePath();
            String l = path.substring(path.lastIndexOf(File.separator + "defaultVars" + File.separator) + 13,
                    path.lastIndexOf(xml.getName()));
            this.convertXmlToYaml(xml, l.split("\\\\"), globalConfigs);
        }

        Map<String, Object> result = mergeMaps(globalConfigs);

        ObjectMapper yamlMapper = new ObjectMapper(new YAMLFactory());
        String yml = yamlMapper.writeValueAsString(result);

        Yaml yaml = new Yaml();
        Map<String, Object> yamlData = yaml.load(yml);
        insertYamlData(yamlData, "");
        jdbc.insertYamlFile("dev.yaml", yml);
    }

    public void convertXmlToYaml(File xmlFile, String[] levels, List<Map<String, Object>> globalConfigs)
            throws ParserConfigurationException, SAXException, IOException, InterruptedException, AXSecurityException {

        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
        Document document = documentBuilder.parse(xmlFile);

        NodeList globalVariablesNodes = document.getElementsByTagName("globalVariable");

        List<Map<String, String>> globalVariables = new ArrayList<>();

        for (int i = 0; i < globalVariablesNodes.getLength(); i++) {
            Node globalVariableNode = globalVariablesNodes.item(i);
            if (globalVariableNode.getNodeType() == Node.ELEMENT_NODE) {
                Element globalVariableElement = (Element) globalVariableNode;
                Map<String, String> globalVariableData = new LinkedHashMap<>();
                String value = globalVariableElement.getElementsByTagName("value").item(0).getTextContent();
                if (value.startsWith("#!")) {
                    value = new String(ObfuscationEngine.decrypt(value));
                }
                globalVariableData.put(globalVariableElement.getElementsByTagName("name").item(0).getTextContent(),
                        value);
                globalVariables.add(globalVariableData);
            }
        }

        Map<String, Object> node = new LinkedHashMap<>();

        if (levels.length >= 2) {
            Map<String, Object> values = new LinkedHashMap<>();
            for (Map<?, ?> g : globalVariables) {
                values.put((String) g.keySet().toArray()[0], (String) g.values().toArray()[0]);
            }
            node.put(levels[levels.length - 1], values);
        }
        for (int i = levels.length - 1; i >= 0; i--) {
            if (levels[i].length() == 0) {
                for (Map<?, ?> g : globalVariables) {
                    node.put((String) g.keySet().toArray()[0], (String) g.values().toArray()[0]);
                }
            } else {
                if (levels.length == 1) {
                    Map<String, Object> values1 = new LinkedHashMap<>();
                    for (Map<?, ?> g : globalVariables) {
                        values1.put((String) g.keySet().toArray()[0], (String) g.values().toArray()[0]);
                    }
                    node.put(levels[levels.length - 1], values1);
                } else {
                    if (i != levels.length - 1) {
                        Map<String, Object> tempNode = new LinkedHashMap<>();
                        tempNode.putAll(node);
                        node.clear();
                        node.put(levels[i], tempNode);
                    }
                }
            }
        }
        globalConfigs.add(node);
    }

    private void getFiles(File[] listFiles, int i, ArrayList<File> files, String fileStr) {
        if (i == listFiles.length) {
            return;
        }
        if (listFiles[i].isFile()) {
            if (listFiles[i].getName().endsWith(fileStr)) {
                files.add(listFiles[i]);
            }
        } else if (listFiles[i].isDirectory()) {
            getFiles(listFiles[i].listFiles(), 0, files, fileStr);
        }
        getFiles(listFiles, i + 1, files, fileStr);
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> mergeMaps(List<Map<String, Object>> maps) {
        Map<String, Object> mergedMap = new LinkedHashMap<>();
        for (Map<String, Object> map : maps) {
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                String key = entry.getKey();
                Object value = entry.getValue();
                if (mergedMap.containsKey(key) && mergedMap.get(key) instanceof Map && value instanceof Map) {
                    Map<String, Object> mergedValue = mergeMaps(
                            List.of((Map<String, Object>) mergedMap.get(key), (Map<String, Object>) value));
                    mergedMap.put(key, mergedValue);
                } else {
                    mergedMap.put(key, value);
                }
            }
        }
        return mergedMap;
    }

    @SuppressWarnings("unchecked")
    private void insertYamlData(Map<String, Object> yamlData, String parentKey)
            throws SQLException, IOException {
        // Insert YAML data recursively
        for (Map.Entry<String, Object> entry : yamlData.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            String fullKey = (parentKey.isEmpty()) ? key : parentKey + "/" + key;

            if (value instanceof Map) {
                // If the value is a nested map, recursively insert its key-value pairs
                insertYamlData((Map<String, Object>) value, fullKey);
            } else {
                // Insert the key-value pair into the database
                jdbc.insertKeyValuePair(fullKey, value);
            }
        }
    }
}

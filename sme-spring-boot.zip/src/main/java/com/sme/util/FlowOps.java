package com.sme.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import com.sme.dao.entity.*;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.sme.dao.JDBCConnection;
import com.sme.dao.SharedConnections;
import com.sme.service.Accelerator;

@Component
public class FlowOps {
    private static final Logger logger = LoggerFactory.getLogger(FlowOps.class);
//	static JDBCConnection jdbc = new JDBCConnection();
//	static Accelerator accelerator = new Accelerator();

    @Autowired
    private JDBCConnection jdbc;

    @Autowired
    private RetrieveOps retrieveOps;

    @Autowired
    private ActivityOps activityOps;

    @Autowired
    private SharedConnections sharedConnections;

    public ArrayList<String> conTypes = new ArrayList<>();
    public ArrayList<String> conNames = new ArrayList<>();
    public ArrayList<String> fileNames = new ArrayList<>();


    public void addActivityToGroupActivities(Accelerator accelerator, String processName,
                                             List<GroupActivities> groupActivitiesList,
                                             Document tDoc, Element flow, String parentId)
            throws SQLException, SAXException, IOException, DOMException, ParserConfigurationException {
        List<Flow> flows = new ArrayList<>();
        groupActivitiesList.forEach((groupActivities) -> flows.add(
                new Flow(groupActivities.getProcessesName(), groupActivities.getSeqId(),
                        groupActivities.getLvl(), groupActivities.getActivityName(),
                        groupActivities.getActivityType(), groupActivities.getActivityXslt(),
                        groupActivities.getParentId(), groupActivities.getConditionType(),
                        groupActivities.getXpath(), groupActivities.getParentCount(),
                        groupActivities.getExecId())
        ));
        addActivityToFlow(accelerator, processName, flows, tDoc, flow, parentId);
    }

    public void addActivityToFlow(Accelerator accelerator, String processName, List<Flow> flows, Document tDoc, Element flow, String parentId)
            throws SQLException, SAXException, IOException, DOMException, ParserConfigurationException {

        String mulesoftActivity = null;

        for (Flow flowToUpdate : flows) {

            if (!flowToUpdate.getParentId().contains(",")) {

                String acType = flowToUpdate.getActivityType();

//                if (acType.contentEquals("com.tibco.pe.core.CatchActivity")) {
//                    continue;
//                }

                String activityXslt = new String(flowToUpdate.getActivityXslt(), StandardCharsets.UTF_8);
                //Arrays.toString(flowToUpdate.getActivityXslt());
                String activityName = flowToUpdate.getActivityName();
                int seqId = flowToUpdate.getSeqId();

                if (retrieveOps.activityNames.contains(activityName)) {
                    return;
                }
                retrieveOps.activityNames.add(activityName);

//                if (acType.contentEquals("com.tibco.pe.core.GenerateErrorActivity")) {
//                    return;
//                }

                if (flowToUpdate.getParentId().contentEquals("0")) {
                    mulesoftActivity = null;

                    List<TMReferences> tmReferencesList = jdbc.getReference(flowToUpdate.getActivityType());
                    for (TMReferences tm : tmReferencesList) {
                        mulesoftActivity = tm.getMulesoft();

                        Node acNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(activityXslt)))
                                .getDocumentElement();
                        Element activity = activityOps.activityOperations(accelerator, tDoc, acNode, activityName, seqId,
                                accelerator.getNode(), mulesoftActivity, this, activityOps, retrieveOps);
                        if (flowToUpdate.getConditionType().contentEquals("xpath")
                                || flowToUpdate.getConditionType().contentEquals("otherwise")) {
                            Element choice = getChoiceRouterForActivity(tDoc, flowToUpdate, mulesoftActivity, activity);
                            flow.appendChild(choice);
                            tDoc.getFirstChild().appendChild(flow);
                        } else {
                            if (mulesoftActivity.contentEquals("java:invoke")) {
                                Element newActivity = activityOps.getJavaActivities().muleJavaNewActivity(accelerator, tDoc,
                                        acNode, activityName, accelerator.getNode(), mulesoftActivity);
                                flow.appendChild(newActivity);
                            }
                            flow.appendChild(activity);
                            tDoc.getFirstChild().appendChild(flow);
                        }
                    }
                    if (mulesoftActivity == null) {
                        Node acNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(activityXslt)))
                                .getDocumentElement();
                        Element activity = activityOps.activityOperations(accelerator, tDoc, acNode, activityName, seqId,
                                accelerator.getNode(), mulesoftActivity, this, activityOps, retrieveOps);
                        if (flowToUpdate.getConditionType().contentEquals("xpath")
                                || flowToUpdate.getConditionType().contentEquals("otherwise")) {
                            Element choice = getChoiceRouterForActivity(tDoc, flowToUpdate, mulesoftActivity, activity);
                            flow.appendChild(choice);
                            tDoc.getFirstChild().appendChild(flow);
                        } else {
                            flow.appendChild(activity);
                            tDoc.getFirstChild().appendChild(flow);
                        }
                    }
                } else {

                    mulesoftActivity = null;
                    String parentActivityName = getActivityName(flowToUpdate.getProcessesName(), parentId, flow);
                    String parentTibcoActivityType = getReferenceType(flowToUpdate.getProcessesName(), parentId, flow);
                    String parentMulesoftActivity = getReferenceName(parentTibcoActivityType);

                    parentMulesoftActivity = getParentMulesoftActivity(accelerator, parentMulesoftActivity, processName, parentId,
                            flow);

                    List<TMReferences> tmReferencesList = jdbc.getReference(flowToUpdate.getActivityType());
                    activityXslt = new String(flowToUpdate.getActivityXslt(), StandardCharsets.UTF_8);
                    activityName = flowToUpdate.getActivityName();
                    for (TMReferences tm : tmReferencesList) {
                        mulesoftActivity = tm.getMulesoft();
                        Node acNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(activityXslt)))
                                .getDocumentElement();
                        Element activity = activityOps.activityOperations(accelerator, tDoc, acNode, activityName, seqId,
                                accelerator.getNode(), mulesoftActivity, this, activityOps, retrieveOps);
                        addActivity(tDoc, parentMulesoftActivity, parentActivityName, activity);
                        if (mulesoftActivity.contentEquals("java:invoke")) {
                            Element newActivity = activityOps.getJavaActivities().muleJavaNewActivity(accelerator, tDoc,
                                    acNode, activityName, accelerator.getNode(), mulesoftActivity);
                            addActivity(tDoc, parentMulesoftActivity, parentActivityName, newActivity);
                        }
                    }
                    if (mulesoftActivity == null) {
                        Node acNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(activityXslt)))
                                .getDocumentElement();
                        Element activity = activityOps.activityOperations(accelerator, tDoc, acNode, activityName, seqId,
                                accelerator.getNode(), mulesoftActivity, this, activityOps, retrieveOps);
                        addActivity(tDoc, parentMulesoftActivity, parentActivityName, activity);
                    }

                }
            }
        }
    }

    public void addActivitiesToGroupActivities(Accelerator accelerator, String processName,
                                               List<GroupActivities> groupActivitiesList,
                                               String parentId, Document tDoc, Element flow)
            throws SQLException, SAXException, IOException, DOMException, ParserConfigurationException {
        List<Flow> flows = new ArrayList<>();
        groupActivitiesList.forEach((groupActivities) -> flows.add(
                new Flow(groupActivities.getProcessesName(), groupActivities.getSeqId(),
                        groupActivities.getLvl(), groupActivities.getActivityName(),
                        groupActivities.getActivityType(), groupActivities.getActivityXslt(),
                        groupActivities.getParentId(), groupActivities.getConditionType(),
                        groupActivities.getXpath(), groupActivities.getParentCount(),
                        groupActivities.getExecId())
        ));
        addActivitiesToFlow(accelerator, processName, flows, parentId, tDoc, flow);
    }

    public void addActivitiesToFlow(Accelerator accelerator, String processName, List<Flow> flows, String parentId, Document tDoc, Element flow)
            throws SQLException, SAXException, IOException, DOMException, ParserConfigurationException {
        ArrayList<String> conditionTypes = new ArrayList<>();
        ArrayList<String> xpaths = new ArrayList<>();
        ArrayList<String> activityNames = new ArrayList<>();
        ArrayList<String> activityTypes = new ArrayList<>();
        for (Flow f : flows) {
            if (!f.getParentId().contains(",")) {
                if (f.getConditionType() == null) {
                    List<Transitions> transitions = jdbc.getTransition(f.getProcessesName(), f.getSeqId(), parentId);
                    for (Transitions t : transitions) {
                        conditionTypes.add(t.getConditionType());
                        xpaths.add(t.getxPath());
                    }
                } else {
                    conditionTypes.add(f.getConditionType());
                    xpaths.add(f.getXpath());
                }
                activityTypes.add(f.getActivityType());
                activityNames.add(f.getActivityName());
            }
        }

        if (parentId.contentEquals("0")) {
            if (activityTypes.size() == 2) {
                if (activityTypes.contains("com.tibco.pe.core.CatchActivity")) {
                    List<Flow> flowsWithParentId = jdbc.getActivityWithParentId(accelerator, processName, parentId, tDoc, flow, this);
                    addActivityToFlow(accelerator, processName, flowsWithParentId, tDoc, flow, parentId);
                    return;
                }
            }
        }

        String parentActivityName = getActivityName(processName, parentId, flow);
        String parentTibcoActivityType = getReferenceType(processName, parentId, flow);
        String parentMulesoftActivity = getReferenceName(parentTibcoActivityType);

        if (conditionTypes.contains("always")) {
            Element scatter = getScatterGather(accelerator, tDoc, processName, activityNames, flow, conditionTypes, xpaths);

            parentMulesoftActivity = getParentMulesoftActivity(accelerator, parentMulesoftActivity, processName, parentId, flow);

            if (parentId.contentEquals("0")) {
                flow.appendChild(scatter);
            } else {
                addActivity(tDoc, parentMulesoftActivity, parentActivityName, scatter);
            }

        } else {

            Element choice = getChoiceRouter(accelerator, tDoc, processName, activityNames, flow, conditionTypes, xpaths);

            parentMulesoftActivity = getParentMulesoftActivity(accelerator, parentMulesoftActivity, processName, parentId, flow);

            if (parentId.contentEquals("0")) {
                flow.appendChild(choice);
            } else {
                addActivity(tDoc, parentMulesoftActivity, parentActivityName, choice);
            }
        }

        tDoc.getFirstChild().appendChild(flow);
    }

    private String getParentMulesoftActivity(Accelerator accelerator, String parentMulesoftActivity, String processName, String parentId,
                                             Element flow) throws SQLException, SAXException, IOException {

        String parentXslt = null;

        if (parentMulesoftActivity == null) {
            parentMulesoftActivity = "logger";
        }

        if (parentMulesoftActivity.contentEquals("file:create-directory")) {
            NamedObject no = jdbc.getActivityWithSeqId(processName, parentId, flow);
            if (no.flows != null && !no.flows.isEmpty()) {
                parentXslt = new String(no.flows.get(no.flows.size() - 1).getActivityXslt(), StandardCharsets.UTF_8);
            } else if (no.groupActivities != null && !no.groupActivities.isEmpty()) {
                parentXslt = new String(no.groupActivities.get(no.groupActivities.size() - 1).getActivityXslt(), StandardCharsets.UTF_8);
            }
            if (parentXslt != null) {
                String condition = "";
                ArrayList<Node> node = new ArrayList<>();
                Node pacNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(parentXslt)))
                        .getDocumentElement();
                accelerator.getNode(pacNode.getChildNodes(), 0, node, "createDirectory");
                for (Node n : node) {
                    if (n.getNodeName().contentEquals("createDirectory")) {
                        condition = n.getTextContent();
                    }
                }
                if (!condition.contains("true")) {
                    parentMulesoftActivity = "file:write";
                }
            }

        }

        if (parentMulesoftActivity.contentEquals("until-successful")) {
            NamedObject no = jdbc.getActivityWithSeqId(processName, parentId, flow);
            if (no.flows != null && !no.flows.isEmpty()) {
                parentXslt = new String(no.flows.get(no.flows.size() - 1).getActivityXslt(), StandardCharsets.UTF_8);
            } else if (no.groupActivities != null && !no.groupActivities.isEmpty()) {
                parentXslt = new String(no.groupActivities.get(no.groupActivities.size() - 1).getActivityXslt(),
                        StandardCharsets.UTF_8);
            }
            if (parentXslt != null) {
                Node pacNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(parentXslt)))
                        .getDocumentElement();
                ArrayList<Node> node = new ArrayList<>();
                accelerator.getNode(pacNode.getChildNodes(), 0, node, "pd:groupType");
                if (node.size() > 0) {
                    if (node.get(0).getTextContent().contentEquals("inputLoop")) {
                        parentMulesoftActivity = "foreach";
                    }
                }
            }

        }

        if (parentMulesoftActivity.contentEquals("jms:consume")) {
            String queueRecXSLT = null;
            String jmsRepActXSLT = null;

            List<Flow> flows = jdbc.getActivitiesType(processName);

            for (Flow f : flows) {
                if (f.getActivityType().contentEquals("com.tibco.plugin.jms.JMSQueueEventSource")
                        || f.getActivityType().contentEquals("com.tibco.plugin.jms.JMSTopicEventSource")) {
                    queueRecXSLT = new String(f.getActivityXslt(), StandardCharsets.UTF_8);
                }
                if (f.getActivityType().contentEquals("com.tibco.plugin.jms.JMSReplyActivity")) {
                    jmsRepActXSLT = new String(f.getActivityXslt(), StandardCharsets.UTF_8);
                }
            }

            if (queueRecXSLT != null && jmsRepActXSLT != null) {
                parentMulesoftActivity = "jms:listener";
            }
        }

        if (parentMulesoftActivity.contentEquals("db:update")) {
            NamedObject no = jdbc.getActivityWithSeqId(processName, parentId, flow);
            if (no.flows != null && !no.flows.isEmpty()) {
                parentXslt = new String(no.flows.get(no.flows.size() - 1).getActivityXslt(), StandardCharsets.UTF_8);
            } else if (no.groupActivities != null && !no.groupActivities.isEmpty()) {
                parentXslt = new String(no.groupActivities.get(no.groupActivities.size() - 1).getActivityXslt(),
                        StandardCharsets.UTF_8);
            }
            if (parentXslt != null) {
                Node pacNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(parentXslt)))
                        .getDocumentElement();
                ArrayList<Node> node = new ArrayList<>();
                accelerator.getNode(pacNode.getChildNodes(), 0, node, "statement");
                accelerator.getNode(pacNode.getChildNodes(), 0, node, "batchUpdate");

                if (node.size() == 2) {
                    if ((node.get(0).getTextContent().toUpperCase().contains("INSERT")
                            && node.get(1).getTextContent().contentEquals("false"))) {
                        parentMulesoftActivity = "db:insert";
                    } else if ((node.get(0).getTextContent().toUpperCase().contains("DELETE")
                            && node.get(1).getTextContent().contentEquals("false"))) {
                        parentMulesoftActivity = "db:delete";
                    } else if ((node.get(0).getTextContent().toUpperCase().contains("UPDATE")
                            && node.get(1).getTextContent().contentEquals("false"))) {
                        parentMulesoftActivity = "db:update";
                    } else if (node.get(0).getTextContent().toUpperCase().contains("INSERT")
                            && node.get(1).getTextContent().contentEquals("true")) {
                        parentMulesoftActivity = "db:bulk-insert";
                    } else if (node.get(0).getTextContent().toUpperCase().contains("UPDATE")
                            && node.get(1).getTextContent().contentEquals("true")) {
                        parentMulesoftActivity = "db:bulk-update";
                    } else if (node.get(0).getTextContent().toUpperCase().contains("DELETE")
                            && node.get(1).getTextContent().contentEquals("true")) {
                        parentMulesoftActivity = "db:bulk-delete";
                    }

                }
                if (node.size() == 1) {
                    if ((node.get(0).getTextContent().toUpperCase().contains("INSERT"))) {
                        parentMulesoftActivity = "db:insert";
                    } else if ((node.get(0).getTextContent().toUpperCase().contains("DELETE"))) {
                        parentMulesoftActivity = "db:delete";
                    } else if ((node.get(0).getTextContent().toUpperCase().contains("UPDATE"))) {
                        parentMulesoftActivity = "db:update";
                    }
                }
            }
        }
        if (parentMulesoftActivity.contentEquals("salesforce:query-all")) {
        	 NamedObject no = jdbc.getActivityWithSeqId(processName, parentId, flow);
             if (no.flows != null && !no.flows.isEmpty()) {
                 parentXslt = new String(no.flows.get(no.flows.size() - 1).getActivityXslt(), StandardCharsets.UTF_8);
             } else if (no.groupActivities != null && !no.groupActivities.isEmpty()) {
                 parentXslt = new String(no.groupActivities.get(no.groupActivities.size() - 1).getActivityXslt(),
                         StandardCharsets.UTF_8);
             }
			if (parentXslt != null) {
				Node pacNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(parentXslt)))
						.getDocumentElement();
				ArrayList<Node> node = new ArrayList<>();
				node.removeAll(node);
				accelerator.getNode(pacNode.getChildNodes(), 0, node, "mode");
				String sfMode ="";
				for (Node n : node) {
					if (n.getNodeName().contentEquals("mode")) {
						sfMode = n.getTextContent();
					}
				}
				if(sfMode.contentEquals("Query")) {
					parentMulesoftActivity = "salesforce:query";
				}
				
			}
		}

        return parentMulesoftActivity;
    }

    private String getReferenceName(String tibcoActivityType) throws SQLException {
        List<TMReferences> tmReferencesList = jdbc.getReference(tibcoActivityType);
        String mulesoftActivity = null;
        for (TMReferences tm : tmReferencesList) {
            mulesoftActivity = tm.getMulesoft();
        }
        return mulesoftActivity;
    }

    private String getReferenceType(String processName, String parentId, Element flow) throws SQLException {
        String activityType = null;
        NamedObject no = jdbc.getActivityWithSeqId(processName, parentId, flow);
        if (no.flows != null && !no.flows.isEmpty()) {
            activityType = no.flows.get(no.flows.size() - 1).getActivityType();
        } else if (no.groupActivities != null && !no.groupActivities.isEmpty()) {
            activityType = no.groupActivities.get(no.groupActivities.size() - 1).getActivityType();
        }
        return activityType;
    }

    private String getActivityName(String processName, String parentId, Element flow) throws SQLException {
        String activityName = null;
        NamedObject no = jdbc.getActivityWithSeqId(processName, parentId, flow);
        if (no.flows != null && !no.flows.isEmpty()) {
            activityName = no.flows.get(no.flows.size() - 1).getActivityName();
        } else if (no.groupActivities != null && !no.groupActivities.isEmpty()) {
            activityName = no.groupActivities.get(no.groupActivities.size() - 1).getActivityName();
        }
        return activityName;
    }

    public void addActivity(Document tDoc, String parentMulesoftActivity, String parentActivityName, Element activity) {

        NodeList activityNodes = tDoc.getElementsByTagName(parentMulesoftActivity);

        for (int i = 0; i < activityNodes.getLength(); i++) {
            Element activityElement = (Element) activityNodes.item(i);
            String nameAttribute = activityElement.getAttribute("doc:name");

            if (nameAttribute.equals(parentActivityName)) {
                Node parent = activityElement.getParentNode();
                parent.insertBefore(activity, activityElement.getNextSibling());
                break;
            }
        }
    }

    public Element getChoiceRouterForActivity(Document tDoc, Flow flow, String mulesoftActivity,
                                              Element activity) throws SQLException {
        Element choice = tDoc.createElement("choice");
        choice.setAttribute("doc:name", "choice");
        Element otherwise = null;
        if (flow.getConditionType().contentEquals("xpath")
                || flow.getConditionType().contentEquals("otherwise")) {
            if (flow.getConditionType().contentEquals("xpath")) {
                Element when = tDoc.createElement("when");
                when.setAttribute("expression", flow.getXpath());
                when.appendChild(activity);
                choice.appendChild(when);
            }
            if (flow.getConditionType().contentEquals("otherwise")) {
                otherwise = tDoc.createElement("otherwise");
                mulesoftActivity = null;
                otherwise.appendChild(activity);
            }
            if (otherwise != null) {
                choice.appendChild(otherwise);
            }
        }
        return choice;
    }

    public Element getScatterGather(Accelerator accelerator, Document tDoc, String processName, ArrayList<String> activityNames, Element flow,
                                    ArrayList<String> conditionTypes, ArrayList<String> xpaths)
            throws DOMException, SQLException, SAXException, IOException, ParserConfigurationException {
        Element scatter = tDoc.createElement("scatter-gather");
        scatter.setAttribute("doc:name", "Scatter-Gather");

        if (conditionTypes.contains("xpath")) {
            Element route = tDoc.createElement("route");
            Element choice = getChoiceRouter(accelerator, tDoc, processName, activityNames, flow, conditionTypes, xpaths);

            route.appendChild(choice);
            scatter.appendChild(route);
        }

        if (conditionTypes.size() == 0) {
            for (int i = 0; i < activityNames.size(); i++) {
                logger.info("Activity Name: " + activityNames.get(i));
            }
        }
        for (int i = 0; i < conditionTypes.size(); i++) {
            if (conditionTypes.get(i).contentEquals("always") || conditionTypes.get(i).contentEquals("error")) {
                Element route = tDoc.createElement("route");
                NamedObject no = jdbc.getActivityWithActivityName(processName, activityNames.get(i), flow);
                List<?> items = no.flows != null ? no.flows : no.groupActivities;
                String mulesoftActivity = null;
                for (Object o : items) {
                    String activityXslt;
                    String activityName;
                    String activityType;
                    int seqId;
                    Flow f;
                    GroupActivities g;
                    if (o instanceof Flow) {
                        f = (Flow) o;
                        activityXslt = new String(f.getActivityXslt(), StandardCharsets.UTF_8);
                        activityName = f.getActivityName();
                        activityType = f.getActivityType();
                        seqId = f.getSeqId();
                    } else {
                        g = (GroupActivities) o;
                        activityXslt = new String(g.getActivityXslt(), StandardCharsets.UTF_8);
                        activityName = g.getActivityName();
                        activityType = g.getActivityType();
                        seqId = g.getSeqId();
                    }
                    List<TMReferences> tmReferencesList = jdbc.getReference(activityType);
                    for (TMReferences tm : tmReferencesList) {
                        mulesoftActivity = tm.getMulesoft();

                        Node acNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(activityXslt)))
                                .getDocumentElement();
                        Element activity = activityOps.activityOperations(accelerator, tDoc, acNode, activityName, seqId,
                                accelerator.getNode(), mulesoftActivity, this, activityOps, retrieveOps);

                        route.appendChild(activity);
                        scatter.appendChild(route);
                    }
                    if (mulesoftActivity == null) {
                        Node acNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(activityXslt)))
                                .getDocumentElement();
                        Element activity = activityOps.activityOperations(accelerator, tDoc, acNode, activityName, seqId,
                                accelerator.getNode(), mulesoftActivity, this, activityOps, retrieveOps);
                        route.appendChild(activity);
                        scatter.appendChild(route);
                    }
                }
            }
        }
        return scatter;
    }

    public Element getChoiceRouter(Accelerator accelerator, Document tDoc, String processName, ArrayList<String> activityNames, Element flow,
                                   ArrayList<String> conditionTypes, ArrayList<String> xpaths)
            throws SQLException, SAXException, IOException, DOMException, ParserConfigurationException {
        Element choice = tDoc.createElement("choice");
        choice.setAttribute("doc:name", "choice");
        Element otherwise = null;
        for (int i = 0; i < conditionTypes.size(); i++) {
            if (conditionTypes.get(i).contentEquals("xpath") || conditionTypes.get(i).contentEquals("otherwise")
                    || conditionTypes.get(i).contentEquals("error")) {
                if (conditionTypes.get(i).contentEquals("xpath")) {
                    Element when = tDoc.createElement("when");
                    when.setAttribute("expression", xpaths.get(i));

                    NamedObject no = jdbc.getActivityWithActivityName(processName, activityNames.get(i), flow);
                    List<?> items = no.flows != null ? no.flows : no.groupActivities;
                    String mulesoftActivity = null;
                    for (Object o : items) {
                        String activityXslt;
                        String activityName;
                        String activityType;
                        int seqId;
                        Flow f;
                        GroupActivities g;
                        if (o instanceof Flow) {
                            f = (Flow) o;
                            activityXslt = new String(f.getActivityXslt(), StandardCharsets.UTF_8);
                            activityName = f.getActivityName();
                            activityType = f.getActivityType();
                            seqId = f.getSeqId();
                        } else {
                            g = (GroupActivities) o;
                            activityXslt = new String(g.getActivityXslt(), StandardCharsets.UTF_8);
                            activityName = g.getActivityName();
                            activityType = g.getActivityType();
                            seqId = g.getSeqId();
                        }
                        List<TMReferences> tmReferencesList = jdbc.getReference(activityType);
                        for (TMReferences tm : tmReferencesList) {
                            mulesoftActivity = tm.getMulesoft();

                            Node acNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(activityXslt)))
                                    .getDocumentElement();
                            Element activity = activityOps.activityOperations(accelerator, tDoc, acNode, activityName, seqId,
                                    accelerator.getNode(), mulesoftActivity, this, activityOps, retrieveOps);

                            when.appendChild(activity);
                        }
                        if (mulesoftActivity == null) {
                            Node acNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(activityXslt)))
                                    .getDocumentElement();
                            Element activity = activityOps.activityOperations(accelerator, tDoc, acNode, activityName, seqId,
                                    accelerator.getNode(), mulesoftActivity, this, activityOps, retrieveOps);
                            when.appendChild(activity);
                        }
                    }
                    choice.appendChild(when);
                }
                if (conditionTypes.get(i).contentEquals("otherwise") || conditionTypes.get(i).contentEquals("error")) {
                    otherwise = tDoc.createElement("otherwise");

                    NamedObject no = jdbc.getActivityWithActivityName(processName, activityNames.get(i), flow);
                    String mulesoftActivity = null;
                    List<?> items = no.flows != null ? no.flows : no.groupActivities;
                    for (Object o : items) {
                        String activityXslt;
                        String activityName;
                        String activityType;
                        int seqId;
                        Flow f;
                        GroupActivities g;
                        if (o instanceof Flow) {
                            f = (Flow) o;
                            activityXslt = new String(f.getActivityXslt(), StandardCharsets.UTF_8);
                            activityName = f.getActivityName();
                            activityType = f.getActivityType();
                            seqId = f.getSeqId();
                        } else {
                            g = (GroupActivities) o;
                            activityXslt = new String(g.getActivityXslt(), StandardCharsets.UTF_8);
                            activityName = g.getActivityName();
                            activityType = g.getActivityType();
                            seqId = g.getSeqId();
                        }
                        List<TMReferences> tmReferencesList = jdbc.getReference(activityType);
                        for (TMReferences tm : tmReferencesList) {
                            mulesoftActivity = tm.getMulesoft();

                            Node acNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(activityXslt)))
                                    .getDocumentElement();
                            Element activity = activityOps.activityOperations(accelerator, tDoc, acNode, activityName, seqId,
                                    accelerator.getNode(), mulesoftActivity, this, activityOps, retrieveOps);

                            otherwise.appendChild(activity);
                        }
                        if (mulesoftActivity == null) {
                            Node acNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(activityXslt)))
                                    .getDocumentElement();
                            Element activity = activityOps.activityOperations(accelerator, tDoc, acNode, activityName, seqId,
                                    accelerator.getNode(), mulesoftActivity, this, activityOps, retrieveOps);
                            otherwise.appendChild(activity);
                        }
                    }
                }
                if (otherwise != null) {
                    choice.appendChild(otherwise);
                }
            }
        }
        return choice;
    }

    public void mergingActivity(Accelerator accelerator, String processName, String parentId, Document tDoc,
                                Element flow, GroupActivities groupActivities)
            throws SQLException, DOMException, ParserConfigurationException, SAXException, IOException {
        Flow flowToMerge = new Flow(groupActivities.getProcessesName(), groupActivities.getSeqId(),
                groupActivities.getLvl(), groupActivities.getActivityName(),
                groupActivities.getActivityType(), groupActivities.getActivityXslt(),
                groupActivities.getParentId(), groupActivities.getConditionType(),
                groupActivities.getXpath(), groupActivities.getParentCount(),
                groupActivities.getExecId());

        mergingActivity(accelerator, processName, parentId, tDoc, flow, flowToMerge);
    }

    public void mergingActivity(Accelerator accelerator, String processName, String parentId, Document tDoc,
                                Element flow, Flow flowToMerge)
            throws SQLException, DOMException, ParserConfigurationException, SAXException, IOException {
        String parent = flowToMerge.getParentId();
        String acName = flowToMerge.getActivityName();
        String[] numberStrings = parent.split(",");

        logger.info("Merge : " + acName);

        retrieveOps.merges.add(acName);
        if (Collections.frequency(retrieveOps.merges, acName) == numberStrings.length - 1) {
            NamedObject no = jdbc.getActivityWithSeqId(processName, parentId, flow);
            String parentTibcoActivity = null;
            String parentActivityName = null;
            if (no.flows != null && !no.flows.isEmpty()) {
                parentTibcoActivity = no.flows.get(no.flows.size() - 1).getActivityType();
                parentActivityName = no.flows.get(no.flows.size() - 1).getActivityName();
            } else if (no.groupActivities != null && !no.groupActivities.isEmpty()) {
                parentTibcoActivity = no.groupActivities.get(no.groupActivities.size() - 1).getActivityType();
                parentActivityName = no.groupActivities.get(no.groupActivities.size() - 1).getActivityName();
            }

            String parentMulesoftActivity = null;
            List<TMReferences> tmReferencesList = jdbc.getReference(parentTibcoActivity);
            for (TMReferences tm : tmReferencesList) {
                parentMulesoftActivity = tm.getMulesoft();
            }
            String mulesoftActivity = null;
            tmReferencesList = jdbc.getReference(flowToMerge.getActivityType());
            for (TMReferences tm : tmReferencesList) {
                mulesoftActivity = tm.getMulesoft();
            }

            mulesoftActivity = getParentMulesoftActivity(accelerator, mulesoftActivity, processName, parentId, flow);
            parentMulesoftActivity = getParentMulesoftActivity(accelerator, parentMulesoftActivity, processName, parentId, flow);

            String activityName = flowToMerge.getActivityName();
            String activityXslt = new String(flowToMerge.getActivityXslt(), StandardCharsets.UTF_8);
            int seqId = flowToMerge.getSeqId();

            ArrayList<Node> node = new ArrayList<>();

            accelerator.getNode(tDoc.getChildNodes(), 0, node, parentMulesoftActivity);
            for (Node n : node) {
                if (n.getAttributes().getNamedItem("doc:name").getNodeValue().contentEquals(parentActivityName)) {
                    logger.info("Group Activity : ");
                    Node acNode = RetrieveOps.docBuilder.parse(new InputSource(new StringReader(activityXslt)))
                            .getDocumentElement();
                    Element activity = activityOps.activityOperations(accelerator, tDoc, acNode, activityName, seqId,
                            accelerator.getNode(), mulesoftActivity, this, activityOps, retrieveOps);
                    try {
                        n.getParentNode().getParentNode().getParentNode().appendChild(activity);
                    } catch (Exception e) {
                        logger.error("An error occurred: " + e.getMessage());
                    }
                    retrieveOps.parseActivities(accelerator, processName, Integer.toString(flowToMerge.getSeqId()),
                            tDoc, flow, this);
                }
            }
        }
    }

    public void setGlobalElements(Accelerator accelerator) throws SQLException, SAXException, IOException, ParserConfigurationException {
        List<com.sme.dao.entity.SharedConnections> sc = jdbc.getSharedConnections();

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        ClassLoader classLoader = getClass().getClassLoader();

        Document tDoc = docBuilder.parse(classLoader.getResourceAsStream("template.xml"));
        File globalElements = new File(
                accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator + "main"
                        + File.separator + "mule" + File.separator + "GlobalElements.xml");

        Element props = tDoc.createElement("configuration-properties");
        props.setAttribute("doc:name", "Configuration properties");
        props.setAttribute("doc:id", accelerator.generateRandom(8) + "-6db8-40ea-99b8-38d5a2997486");
        props.setAttribute("file", "config/${env}.yaml");
        tDoc.getFirstChild().appendChild(props);

        for (com.sme.dao.entity.SharedConnections rs : sc) {
            if (rs.getSharedName().endsWith(".sharedjdbc")) {
                String globalElementName = rs.getSharedName();
                String globalElementXslt = new String(rs.getSharedConfig(), StandardCharsets.UTF_8);
                sharedConnections.addJdbcConfigTag(accelerator, tDoc, globalElementName, globalElementXslt);
                conTypes.add("Jdbc configuration");
                conNames.add(globalElementName.substring(0, globalElementName.lastIndexOf(".")));
                fileNames.add(globalElements.getAbsolutePath());
            }
            if (rs.getSharedName().endsWith(".sharedjmscon")) {
                String globalElementName = rs.getSharedName();
                String globalElementXslt = new String(rs.getSharedConfig(), StandardCharsets.UTF_8);
                sharedConnections.addJmsConfigTag(accelerator, tDoc, globalElementName, globalElementXslt);
                conTypes.add("Jms configuration");
                conNames.add(globalElementName.substring(0, globalElementName.lastIndexOf(".")));
                fileNames.add(globalElements.getAbsolutePath());
            }
            if (rs.getSharedName().endsWith(".sharedhttp")) {
                String globalElementName = rs.getSharedName();
                String globalElementXslt = new String(rs.getSharedConfig(), StandardCharsets.UTF_8);
                sharedConnections.addHttpListenerConfigTag(accelerator, tDoc, globalElementName, globalElementXslt);
                conTypes.add("Http configuration");
                conNames.add(globalElementName.substring(0, globalElementName.lastIndexOf(".")));
                fileNames.add(globalElements.getAbsolutePath());
            }
            if (rs.getSharedName().endsWith(".sharedftp")) {
                String globalElementName = rs.getSharedName();
                String globalElementXslt = new String(rs.getSharedConfig(), StandardCharsets.UTF_8);
                sharedConnections.addFtpConfigTag(accelerator, tDoc, globalElementName, globalElementXslt);
                conTypes.add("Ftp configuration");
                conNames.add(globalElementName.substring(0, globalElementName.lastIndexOf(".")));
                fileNames.add(globalElements.getAbsolutePath());
            }
            if (rs.getSharedName().endsWith(".sharedvariable")) {
                String globalElementName = rs.getSharedName();
                String globalElementXslt = new String(rs.getSharedConfig(), StandardCharsets.UTF_8);
                sharedConnections.addObjectStoreConfigTag(accelerator, tDoc, globalElementName, globalElementXslt);
                conTypes.add("Shared Variable configuration");
                conNames.add(globalElementName.substring(0, globalElementName.lastIndexOf(".")));
                fileNames.add(globalElements.getAbsolutePath());
            }
        
         	if (rs.getSharedName().endsWith(".sharedsalesforce")) {
				String globalElementName = rs.getSharedName();
				String globalElementXslt =  new String(rs.getSharedConfig(), StandardCharsets.UTF_8);
				sharedConnections.salesforceConfigTag(accelerator, tDoc, globalElementName, globalElementXslt);
				conTypes.add("Salesforce Config");
				conNames.add(globalElementName.substring(0, globalElementName.lastIndexOf(".")));
				fileNames.add(globalElements.getAbsolutePath());
			}
			if (rs.getSharedName().endsWith(".adb")) {
				String globalElementName = rs.getSharedName();
				String globalElementXslt =  new String(rs.getSharedConfig(), StandardCharsets.UTF_8);
				sharedConnections.addAdbConfigTag(accelerator, tDoc, globalElementName, globalElementXslt);
			}
        }

        String firstReplacement = "${";
        String lastReplacement = "}";
        retrieveOps.replaceAttributeValues(tDoc.getDocumentElement(), firstReplacement, lastReplacement);

        accelerator.writeFile(tDoc,
                new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "src" + File.separator + "main"
                        + File.separator + "mule" + File.separator + "GlobalElements.xml"));
    }

    public void generateToDo(Accelerator accelerator) {

        File worksheet = new File(accelerator.getTrgProjectDir() + File.separator + "ConfigsToDo.xlsx");

        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            XSSFSheet sheet = workbook.createSheet("Sheet1");

            // Create header row
            XSSFRow headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("ConfigurationType");
            headerRow.createCell(1).setCellValue("ConfigurationName");
            headerRow.createCell(2).setCellValue("Filename");

            // Insert data into subsequent rows
            for (int i = 0; i < conTypes.size(); i++) {
                XSSFRow dataRow = sheet.createRow(i + 1);
                dataRow.createCell(0).setCellValue(conTypes.get(i));
                dataRow.createCell(1).setCellValue(conNames.get(i));
                dataRow.createCell(2).setCellValue(fileNames.get(i));
            }

            // Write the workbook to a file
            try (FileOutputStream fileOut = new FileOutputStream(worksheet.getAbsolutePath())) {
                workbook.write(fileOut);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Flow> getActivityWithParentId(Accelerator accelerator, String processName, String parentId, Document tDoc, Element flow)
            throws SQLException, SAXException, IOException, DOMException, ParserConfigurationException {
        return jdbc.getActivityWithParentId(accelerator, processName, parentId, tDoc, flow, this);
    }
}

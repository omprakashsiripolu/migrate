package com.sme.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.sme.activities.ADBAdapterActivities;
import com.sme.activities.FTPActivities;
import com.sme.activities.FileActivities;
import com.sme.activities.GeneralActivities;
import com.sme.activities.GroupActivities;
import com.sme.activities.HTTPActivities;
import com.sme.activities.JDBCActivities;
import com.sme.activities.JMSActivities;
import com.sme.activities.JavaActivities;
import com.sme.activities.MailActivities;
import com.sme.activities.ParseActivities;
import com.sme.activities.RestActivities;
import com.sme.activities.SalesforceActivities;
import com.sme.dao.JDBCConnection;
import com.sme.dao.SharedConnections;
import com.sme.dao.entity.RestService;
import com.sme.service.Accelerator;

@Component
public class ActivityOps {

    @Autowired
    JDBCConnection jdbc;

    @Autowired
    private GeneralActivities genActivities;
    @Autowired
    private HTTPActivities httpActivities;
    @Autowired
    private JDBCActivities jdbcActivities;
    //	static Accelerator accelerator = new Accelerator();
    @Autowired
    private RetrieveOps retrieveOps;
    //    @Autowired
//    private FlowOps flowOps;
    @Autowired
    private ParseActivities parseActivities;
    @Autowired
    private SharedConnections shared;
    @Autowired
    private JMSActivities jmsActivities;
    @Autowired
    private FTPActivities ftpActivities;
    @Autowired
    private FileActivities fileActivities;
    @Autowired
    private GroupActivities groupActs;
    @Autowired
    private JavaActivities javaActivities;
    @Autowired
    private SalesforceActivities sfActivities;
    @Autowired
    private ADBAdapterActivities adb;
    
    @Value("${wsdl.manual.effort}")
    int wsdlEffort;
    @Value("${rest.manual.effort}")
	int restEffort;
    @Value("${total.mule.time}")
  	double muleTime;

    public JavaActivities getJavaActivities() {
        return javaActivities;
    }

    public void setJavaActivities(JavaActivities javaActivities) {
        this.javaActivities = javaActivities;
    }

    @Autowired
    private RestActivities rest;
    @Autowired
    private MailActivities mail;
    
    public ArrayList<String> types = new ArrayList<>();
    public ArrayList<String> actTypes = new ArrayList<>();
    public ArrayList<String> actNames = new ArrayList<>();
    public ArrayList<Integer> seqIds = new ArrayList<>();
    public ArrayList<String> fileNames = new ArrayList<>();
    public ArrayList<Double> manualEffort = new ArrayList<>();
    public ArrayList<Double> reqTime = new ArrayList<>();

    static int actCount = 0;
    
    public Element activityOperations(Accelerator accelerator, Document tDoc, Node acNode, String acName, int seqId,
                                      ArrayList<Node> node, String mulesoftActivity, FlowOps flowOps , ActivityOps activityOps, RetrieveOps retriveOps)
            throws DOMException, SQLException, ParserConfigurationException, SAXException, IOException {

    	System.out.println(actCount++);
    	
    	
    	
        Element activity = null;

        node.removeAll(node);
        accelerator.getNode(acNode.getChildNodes(), 0, node, "jdbcSharedConfig");
        for (Node n : node) {
            if (!retrieveOps.sharedConfigs.contains(n.getTextContent())) {
                shared.addJdbcAttributes(accelerator, tDoc, n.getTextContent());
                retrieveOps.sharedConfigs.add(n.getTextContent());
            }
        }
        node.removeAll(node);
        accelerator.getNode(acNode.getChildNodes(), 0, node, "ConnectionReference");
        for (Node n : node) {
            if (!retrieveOps.sharedConfigs.contains(n.getTextContent())) {
                shared.addJmsAttributes(accelerator, tDoc, n.getTextContent());
                retrieveOps.sharedConfigs.add(n.getTextContent());
            }
        }
        node.removeAll(node);
        accelerator.getNode(acNode.getChildNodes(), 0, node, "sharedChannel");
        for (Node n : node) {
            if (!retrieveOps.sharedConfigs.contains(n.getTextContent())) {
                shared.addHttpAttributes(accelerator, tDoc, n.getTextContent());
                retrieveOps.sharedConfigs.add(n.getTextContent());
            }
        }
        node.removeAll(node);
        accelerator.getNode(acNode.getChildNodes(), 0, node, "pd:type");
        if (node.get(0).getTextContent().contains("com.tibco.plugin.file.")) {
            if (!retrieveOps.sharedConfigs.contains("com.tibco.plugin.file.")) {
                shared.addFileConfigTag(accelerator, tDoc, node.get(0).getTextContent(), flowOps);
                retrieveOps.sharedConfigs.add("com.tibco.plugin.file.");
            }
        }
        // Set & get shared Variable configuration
        node.removeAll(node);
        accelerator.getNode(acNode.getChildNodes(), 0, node, "pd:type");
        accelerator.getNode(acNode.getChildNodes(), 0, node, "variableConfig");
        if (node.get(0).getTextContent().contains("com.tibco.pe.core.GetSharedVariableActivity")
                || node.get(0).getTextContent().contains("com.tibco.pe.core.SetSharedVariableActivity")) {
            if (!retrieveOps.sharedConfigs.contains("com.tibco.pe.core.GetSharedVariableActivity")
                    && !retrieveOps.sharedConfigs.contains("com.tibco.pe.core.SetSharedVariableActivity")) {
                for (Node n : node) {
                    if (n.getNodeName().contentEquals("variableConfig")) {
                        shared.addObjectStoreAttribute(accelerator, tDoc, node.get(1).getTextContent());
                    }
                }
                retrieveOps.sharedConfigs.add(node.get(0).getTextContent());
            }
        }

        // FTP configuration
        node.removeAll(node);
        accelerator.getNode(acNode.getChildNodes(), 0, node, "SharedUserData");
        for (Node n : node) {
            if (!retrieveOps.sharedConfigs.contains(n.getTextContent())) {

                shared.addFtpAttribute(accelerator, tDoc, n.getTextContent());
                retrieveOps.sharedConfigs.add(n.getTextContent());
            }
        }
        
     // Salesforce configuration
     		node.removeAll(node);
     		accelerator.getNode(acNode.getChildNodes(), 0, node, "salesforceSharedConfig");
     		for (Node n : node) {
     			if (retriveOps.sharedConfigs.contains(n.getTextContent())) {
     				shared.addFtpAttribute(accelerator, tDoc, n.getTextContent());
     				retriveOps.sharedConfigs.add(n.getTextContent());
     			}
     		}
     		
     		//ADB configuration
     		node.removeAll(node);
     		accelerator.getNode(acNode.getChildNodes(), 0, node, "ae.aepalette.sharedProperties.adapterService");
     		for(Node n : node) {
     			if(!retrieveOps.sharedConfigs.contains(n.getTextContent())){
     				shared.addAdbAttributes(accelerator,tDoc,n.getTextContent());
     				retrieveOps.sharedConfigs.add(n.getTextContent());
     			}
     		}

     		 if (mulesoftActivity == null) {
             	addToDo(accelerator, "UnMigrated", acName, seqId, 10 , 10,"UnMigrated activity");
             	jdbc.insertIntoUnmigratedActivities(accelerator.getCurrentExecutionId(), seqId, acName, retrieveOps.getProcessName(), "This activity cannot be migrated.");
                 mulesoftActivity = "default";
             }
     		 
        int manEff = 1;
       
     
    
        switch (mulesoftActivity) {
        
            case "logger":
                activity = genActivities.addLoggerActivity(accelerator, tDoc, acNode, acName, node);
                addToDo(accelerator, "Logger", acName, seqId, 3 , 3,"activity");
                break;

            case "scheduler":
                activity = genActivities.addSchedulerActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                addToDo(accelerator, "file:list", acName, seqId, 3 , 3,"activity");
                break;

            case "file:list":
                activity = fileActivities.listFilesActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "file:list", acName, seqId,manEff, manEff-5,"activity");
                break;

            case "file:listener":
                activity = fileActivities.filePollarActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "file:listener", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "file:read":
                activity = fileActivities.fileReadActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "file:read", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "file:delete":
                activity = fileActivities.removeFileActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "file:delete", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "file:rename":
                activity = fileActivities.renameFileActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "file:rename", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "file:copy":
                activity = fileActivities.copyFileActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "file:copy", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "file:write":
                activity = fileActivities.writeFileActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "file:write", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "file:create-directory":
                String condition = "";
                node.removeAll(node);
                accelerator.getNode(acNode.getChildNodes(), 0, node, "createDirectory");
                for (Node n : node) {
                    if (n.getNodeName().contentEquals("createDirectory")) {
                        condition = n.getTextContent();
                    }
                }
                if (condition.contains("true")) {
                    activity = fileActivities.createDirectoryActivity(accelerator, tDoc, acNode, acName, seqId, accelerator.getNode(), this);
                } else {
                    activity = fileActivities.createFileActivity(accelerator, tDoc, acNode, acName, seqId, accelerator.getNode(), this);
                }
                break;

            case "http:listener":
                activity = httpActivities.addHttpListener(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "http:listener", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "set-payload":
                activity = httpActivities.addSetPayload(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "set-payload", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "http:request":

                ArrayList<Node> temp = new ArrayList<>();
                accelerator.getNode(acNode.getChildNodes(), 0, temp, "pd:type");

                for (Node n : temp) {
                    if (n.getNodeName().contentEquals("pd:type")
                            && n.getTextContent().contentEquals("com.tibco.plugin.json.activities.RestActivity")) {
                        activity = rest.addRestHttpRequestActivity(accelerator, tDoc, acNode, acName);
                    }

                    if (n.getNodeName().contentEquals("pd:type")
                            && n.getTextContent().contentEquals("com.tibco.plugin.http.client.HttpRequestActivity")) {
                        activity = httpActivities.addHttpRequest(accelerator, tDoc, acNode, acName, flowOps);
                    }
                }
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "http:request", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "db:select":
                activity = jdbcActivities.jdbcQueryActivity(accelerator, tDoc, acNode, acName, accelerator.getNode(),
                        mulesoftActivity);
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "db:select", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "db:execute-ddl":
                activity = jdbcActivities.sqlDirectActivity(accelerator, tDoc, acNode, acName, accelerator.getNode(),
                        mulesoftActivity);
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "db:execute-ddl", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "db:update":
                activity = jdbcActivities.jdbcUpdateActivity(accelerator, tDoc, acNode, acName, seqId, accelerator.getNode(),
                        mulesoftActivity, this);
                break;

            case "db:stored-procedure":
                activity = jdbcActivities.jdbcCallProcdureActivity(accelerator, tDoc, acNode, acName, accelerator.getNode(),
                        mulesoftActivity);
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "db:stored-procedure", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "ee:transform":
                activity = parseActivities.transformActivity(accelerator, tDoc, acNode, acName, seqId, accelerator.getNode(), this);
                break;

            case "jms:publish":
                activity = jmsActivities.addJMSPublishActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "jms:publish", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "jms:consume":
                activity = jmsActivities.addJMSConsumeActivity(accelerator, tDoc, acNode, acName);
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "jms:consume", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "jms:publish-consume":
                activity = jmsActivities.addJMSPublishConsumeActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "jms:publish-consume", acName, seqId, manEff, manEff-5,"activity");
                break;
            case "jms:listener":
            	
            	ArrayList<Node> actType = new ArrayList<>();
    			accelerator.getNode(acNode.getChildNodes(), 0, actType, "pd:type");

    			for (Node n : actType) {
    				if (n.getNodeName().contentEquals("pd:type")
    						&& n.getTextContent().contentEquals("com.tibco.plugin.ae.AESubscriberActivity")) {
    					activity = adb.addJMSOnNewMessageActivity(accelerator, tDoc, acNode, acName);
    					manEff = calManualEfrt(accelerator,acNode);
    					addToDo(accelerator, "jms:listener", acName, seqId, manEff, manEff-5,"activity");
    					
    				} else {
    					activity = jmsActivities.addJMSOnNewMessageActivity(accelerator, tDoc, acNode, acName , retrieveOps);
    					manEff = calManualEfrt(accelerator,acNode);
    					addToDo(accelerator, "jms:listener", acName, seqId, manEff, manEff-5,"activity");
    					
    				}
    			}
//                activity = jmsActivities.addJMSOnNewMessageActivity(accelerator, tDoc, acNode, acName, retrieveOps);
//                addToDo(accelerator, "jms:listener", acName, 2);
                break;

//		case "jms:ack":
//			activity = jmsActivities.addJMSAckActivity(accelerator,tDoc,acNode,acName, accelerator.getNode());
//		break;

            case "ftp:delete":
                activity = ftpActivities.addFtpDeleteActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "ftp:delete", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "ftp:rename":
                activity = ftpActivities.addFtpRenameActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "ftp:rename", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "ftp:list":
                activity = ftpActivities.addFtpListActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "ftp:list", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "ftp:create-directory":
                activity = ftpActivities.addFtpCreateDirectoryActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "ftp:create-directory", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "ftp:read":
                activity = ftpActivities.addFtpReadActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "ftp:read", acName, seqId, manEff, manEff-5,"activity");
                break;

//		case "ftp:copy":
//			activity = ftpActivities.addFtpCopyActivity(accelerator,tDoc,acNode,acName, accelerator.getNode());
//		break;

            case "ftp:write":
                activity = ftpActivities.addFtpWriteActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "ftp:write", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "os:store":
                activity = genActivities.setVariableActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "os:store", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "os:retrieve":
                activity = genActivities.getVariableActivity(accelerator, tDoc, acNode, acName, accelerator.getNode());
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "os:retrieve", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "wsc:consume":
                activity = genActivities.soapReqReplyActivity(accelerator, tDoc, acNode, acName, accelerator.getNode(),
                        mulesoftActivity);
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "wsc:consume", acName, seqId, manEff+15, manEff-5,"activity");
                break;

            case "flow-ref":
                activity = genActivities.flowRefActivity(accelerator, tDoc, acNode, acName, accelerator.getNode(),
                        mulesoftActivity);
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "flow-ref", acName, seqId,manEff, manEff-5,"activity");
                break;

            case "apikit-soap:router":
                activity = genActivities.serviceAgentActivity(accelerator, tDoc, acNode, acName, accelerator.getNode(),
                        mulesoftActivity, "hello");
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "apikit-soap:router", acName, seqId,manEff, manEff-5,"activity");
                break;

            case "until-successful":
                activity = groupActs.untilSuccessfulActivity(accelerator, tDoc, acNode, acName, seqId, accelerator.getNode(),
                        mulesoftActivity, flowOps, this, retrieveOps);
                break;

            case "set-variable":
                activity = genActivities.assignActivity(accelerator, tDoc, acNode, acName, accelerator.getNode(),
                        mulesoftActivity);
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "set-variable", acName, seqId, manEff, manEff-5,"activity");
                break;

            case "apikit:router":
                activity = rest.addApikitRouterActivity(accelerator, tDoc, acNode, acName);
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "apikit:router", acName, seqId, manEff, manEff,"activity");
                break;

            case "java:invoke":

                activity = javaActivities.javaCodeActivity(accelerator, tDoc, acNode, acName, accelerator.getNode(),
                        mulesoftActivity);
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "java:invoke", acName, seqId,manEff+20, manEff+20,"activity");
                break;

            case "java:invoke-static":

                activity = javaActivities.addInvokeStatic(accelerator, tDoc, acNode, acName);
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "java:invoke-static", acName, seqId, manEff+20, manEff=10,"activity");
                break;

            case "email:listener-pop3":
                activity = mail.addOnNewEmail(accelerator, tDoc, acNode, acName);
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "email:listener-pop3", acName, seqId,manEff, manEff-5,"activity");
                break;

            case "email:send":
                activity = mail.addEmailSend(accelerator, tDoc, acNode, acName);
                manEff = calManualEfrt(accelerator,acNode);
                addToDo(accelerator, "email:send", acName, seqId,manEff, manEff-5,"activity");
                break;
                
            case "salesforce:query-all":
				node.removeAll(node);
				accelerator.getNode(acNode.getChildNodes(), 0, node, "mode");
				String sfMode ="";
				for (Node n : node) {
					if (n.getNodeName().contentEquals("mode")) {
						sfMode = n.getTextContent();
					}
				}
				if(sfMode.contentEquals("Query")) {
					mulesoftActivity = "salesforce:query";
					activity = sfActivities.sfQuery(accelerator, tDoc, acNode, acName, accelerator.getNode(), mulesoftActivity);
					manEff = calManualEfrt(accelerator,acNode);
					addToDo(accelerator, "salesforce:query", acName, seqId,manEff, manEff-5,"activity");
					
				}
				else {
					activity = sfActivities.sfQueryAll(accelerator, tDoc, acNode, acName, accelerator.getNode(), mulesoftActivity);
					manEff = calManualEfrt(accelerator,acNode);
					addToDo(accelerator, "salesforce:query", acName, seqId,manEff, manEff-5,"activity");
				}
			break;
			
			case "salesforce:delete":
				activity = sfActivities.sfDeleteAll(accelerator, tDoc, acNode, acName, accelerator.getNode(), mulesoftActivity);
				manEff = calManualEfrt(accelerator,acNode);
				addToDo(accelerator, "salesforce:delete", acName, seqId,manEff, manEff-5,"activity");

				break;
			case "salesforce:update":
				activity = sfActivities.sfUpdateAll(accelerator, tDoc, acNode, acName, accelerator.getNode(), mulesoftActivity);
				manEff = calManualEfrt(accelerator,acNode);
				addToDo(accelerator, "salesforce:update", acName, seqId,manEff, manEff-5,"activity");

				break;
				
			case "salesforce:create":
				activity = sfActivities.sfCreateAll(accelerator, tDoc, acNode, acName, accelerator.getNode(), mulesoftActivity);
				manEff = calManualEfrt(accelerator,acNode);
				addToDo(accelerator, "salesforce:create", acName, seqId,manEff, manEff-5,"activity");

				break;
				
			case "salesforce:retrieve":
				activity = sfActivities.sfRetriveAll(accelerator, tDoc, acNode, acName, accelerator.getNode(), mulesoftActivity);
				manEff = calManualEfrt(accelerator,acNode);
				addToDo(accelerator, "salesforce:retrieve", acName, seqId,manEff, manEff-5,"activity");
				break;
				
			case "salesforce:upsert":
				activity = sfActivities.sfUpsert(accelerator, tDoc, acNode, acName, accelerator.getNode(), mulesoftActivity);
				manEff = calManualEfrt(accelerator,acNode);
				addToDo(accelerator, "salesforce:upsert", acName, seqId,manEff, manEff-5,"activity");
				break;
				
			case "salesforce:new-object-listener":
				activity = sfActivities.sfOutMsgLsnr(accelerator, tDoc, acNode, acName, accelerator.getNode(), mulesoftActivity);
				manEff = calManualEfrt(accelerator,acNode);
				addToDo(accelerator, "salesforce:new-object-listener", acName, seqId,manEff, manEff-5,"activity");
				break;
				
			default:
				activity = genActivities.addLoggerActivity(accelerator, tDoc, acNode, acName, node);
				break;   
        }
        return activity;

    }

    public void addToDo(Accelerator accelerator, String type, String acName, int seqId, double manEfTime, double i,String nameOfRes) {
        actTypes.add(type);
        actNames.add(acName);
        seqIds.add(seqId);
       
	        if (nameOfRes.contentEquals("activity")) {
		        fileNames.add(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator+ "src"+File.separator+"main"+File.separator+"mule"+File.separator
		                  + retrieveOps.getProcessName().substring(0, retrieveOps.getProcessName().lastIndexOf(".")) + ".xml");
		        types.add("Activity");
	      } else if(nameOfRes.contains("UnMigrated"))  {
	        	fileNames.add(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator+"src"+File.separator+"main"+File.separator+"mule"+File.separator
	                    + retrieveOps.getProcessName().substring(0, retrieveOps.getProcessName().lastIndexOf(".")) + ".xml");
	          	types.add("UnMigrated");
	        } else{
		      	fileNames.add(acName);
		      	types.add("Connection");
	        }
	      
	    manualEffort.add(manEfTime);
        reqTime.add(i);
    }
    
    public int calManualEfrt(Accelerator ac,Node acNode){
    	int calTime = 6;
    	int Valueof = 1;
    	int ifCond = 2;
    	int foreach =2;
    	ArrayList<Node> xslValNode = new ArrayList<Node>();
    	ArrayList<Node> xslifNode = new ArrayList<Node>();
    	ArrayList<Node> xslforeachNode = new ArrayList<Node>();
         ac.getNode(acNode.getChildNodes(), 0, xslValNode, "xsl:value-of");
         ac.getNode(acNode.getChildNodes(), 0, xslifNode, "xsl:if");
         ac.getNode(acNode.getChildNodes(), 0, xslforeachNode, "xsl:for-each");
                
         if(xslifNode.size()!=0) {
        	 calTime += ifCond*xslifNode.size();
        	 
         }
         if(xslforeachNode.size()!=0) {
        	 calTime += foreach*xslforeachNode.size();
         }
         if(xslValNode.size()!=0) {
        	 calTime += Valueof*xslValNode.size();
         }
    	return calTime ;
    }
    
public void insertManualEffort(Accelerator accelerator) throws SQLException {
		
		
    	int afterMigTime = 0; 
    	double savedTime = 0; 
    	 for (int i = 0; i < actTypes.size(); i++) {
    		
    		 muleTime += manualEffort.get(i);
    		 afterMigTime += reqTime.get(i);
    	 }
    	 
    	int globalVarsCount = jdbc.getGlobalVariableCount(); 
    	
    	List<com.sme.dao.entity.SharedConnections> getWsdlCount = jdbc.getWsdls();
    	int wsdlCount = getWsdlCount.size();
    
    	List<RestService> restServs = jdbc.getRestResultSet();
    	int restServCount = restServs.size();
    	
    	double wsdlTime = (wsdlCount*wsdlEffort);
    	double restTime = (restServCount*restEffort);
    	
    	
    	types.add("Global Variables");
    	actTypes.add("Global Variables");
    	actNames.add("Global Variables");
    	seqIds.add(-1);
    	manualEffort.add((globalVarsCount+10.0));
    	fileNames.add(accelerator.getTrgProjectDir().getAbsolutePath() +File.separator +"src" +File.separator +"main" +File.separator +"resources" +File.separator +"configdev.yaml");
    	reqTime.add(0.0);
    	
    	types.add("Wsdl");
    	actTypes.add("WSDL");
    	actNames.add("WSDL");
    	seqIds.add(-2);
    	manualEffort.add(wsdlTime);
    	fileNames.add(accelerator.getTrgProjectDir().getAbsolutePath()  +File.separator + "src" +File.separator +"main" +File.separator +"resources" +File.separator +"api");
    	reqTime.add(0.0);
    	
    	types.add("Rest Raml");
    	actTypes.add("Raml");
    	actNames.add("Raml");
    	seqIds.add(-3);
    	manualEffort.add(restTime);
    	fileNames.add(accelerator.getTrgProjectDir().getAbsolutePath()  +File.separator + "src" +File.separator +"main" +File.separator +"resources" +File.separator +"api" +File.separator +"api.raml");
    	reqTime.add(0.0);
    	
    	 muleTime += (globalVarsCount+10) ;
    	 muleTime += wsdlTime;
    	 muleTime += restTime+10;
    	 savedTime = muleTime-afterMigTime;
		
    	 
		 // insert Manual Effort 
        jdbc.insertTotalManualEffort(accelerator,muleTime,savedTime);
		jdbc.insertAnalysis(accelerator , types , actTypes , actNames , seqIds, fileNames , manualEffort , reqTime);
        
		
        
	}

    public void xsltInsertion(Accelerator accelerator, String acName, Node acNode) throws SQLException {
        ArrayList<Node> node = new ArrayList<>();
        accelerator.getNode(acNode.getChildNodes(), 0, node, "pd:inputBindings");

        Node inputBinding = node.get(0);

        if (inputBinding != null) {
            if (retrieveOps.getProcessName().contains("/")) {
                jdbc.insertXslt(
                        retrieveOps.getProcessName().substring(retrieveOps.getProcessName().lastIndexOf("/") + 1,
                                retrieveOps.getProcessName().lastIndexOf(".")) + "-" + acName,
                        accelerator.nodeToString(inputBinding));
            } else {
                jdbc.insertXslt(
                        retrieveOps.getProcessName().substring(0, retrieveOps.getProcessName().lastIndexOf(".")) + "-"
                                + acName,
                        accelerator.nodeToString(inputBinding));
            }
        }
    }

    public void generateToDo(Accelerator accelerator)throws SQLException {

        File worksheet = new File(accelerator.getTrgProjectDir().getAbsolutePath() + File.separator + "ActivitiesToDo.xlsx");

        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            XSSFSheet sheet = workbook.createSheet("Sheet1");

            // Create header row
            XSSFRow headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("InputType");
            headerRow.createCell(1).setCellValue("Name");
            headerRow.createCell(2).setCellValue("Filename");
            headerRow.createCell(3).setCellValue("ManualEffort");
            headerRow.createCell(4).setCellValue("Time Required (Min)");

            // Insert data into subsequent rows
            for (int i = 0; i < actTypes.size(); i++) {
                XSSFRow dataRow = sheet.createRow(i + 1);
                dataRow.createCell(0).setCellValue(actTypes.get(i));
                dataRow.createCell(1).setCellValue(actNames.get(i));
                dataRow.createCell(2).setCellValue(fileNames.get(i));
                dataRow.createCell(3).setCellValue(manualEffort.get(i));
                dataRow.createCell(3).setCellValue(reqTime.get(i));
                if (i == actTypes.size() - 1) {
                	 dataRow = sheet.createRow(i + 2);
                     dataRow.createCell(0).setCellValue("Total Time Required (Hrs)");
                     int endD = actTypes.size() + 1;
                     dataRow.createCell(3).setCellFormula("SUM(" + "D2" + ":D" + endD + ")/60");
                     dataRow.createCell(4).setCellFormula("SUM(" + "E2" + ":E" + endD + ")/60");
                }
            }

            // Write the workbook to a file
            try (FileOutputStream fileOut = new FileOutputStream(worksheet.getAbsolutePath())) {
                workbook.write(fileOut);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    


}

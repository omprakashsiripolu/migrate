package com.sme.dao;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.*;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.stream.StreamResult;

import com.sme.dao.entity.Flow;
import com.sme.dao.entity.GroupActivities;
import com.sme.dao.entity.RestService;
import org.apache.xerces.xs.XSModel;
import org.hibernate.hql.internal.ast.tree.AbstractMapComponentNode;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.sme.service.Accelerator;

import ch.qos.logback.core.subst.NodeToStringTransformer;
import jlibs.xml.sax.XMLDocument;
import jlibs.xml.xsd.XSInstance;
import jlibs.xml.xsd.XSParser;

@Component
public class InsertToDb {
    private static final Logger logger = LoggerFactory.getLogger(InsertToDb.class);
//	static Accelerator accelerator = new Accelerator();
//	static JDBCConnection jdbc = new JDBCConnection();

    @Autowired
    private JDBCConnection jdbc;

    public JDBCConnection getJdbc() {
        return jdbc;
    }

    public void setJdbc(JDBCConnection jdbc) {
        this.jdbc = jdbc;
    }

    ArrayList<String> processesCompleted;

    public void insertOpertaion(Accelerator accelerator, ArrayList<File> processes) throws ParserConfigurationException, SAXException,
            IOException, SQLException, JSONException {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

        for (File process : processes) {

            Document prcDoc = docBuilder.parse(process);
            accelerator.removeBlankLines(prcDoc);

            String fullProcessName = prcDoc.getElementsByTagName("pd:name").item(0).getTextContent();
            String processName = fullProcessName.substring(fullProcessName.lastIndexOf('/') + 1,
                    fullProcessName.lastIndexOf('.'));
            processName = processName.replace(' ', '_');
            // Inserts .process files to configfiles table
            jdbc.insertProcessFile(fullProcessName, accelerator.nodeToString(prcDoc));

            if (prcDoc.getElementsByTagName("pd:starter").getLength() == 1) {
                insertRows(accelerator, prcDoc, fullProcessName, processName, 1);
            }
            if (processesCompleted == null) {
                processesCompleted = new ArrayList<>();
            }
            if (!processesCompleted.contains(process.getName())) {
                insertRows(accelerator, prcDoc, fullProcessName, processName, 1);
            }
        }

        insertXslt(accelerator);
    }

    public void insertXslt(Accelerator accelerator) throws SQLException, ParserConfigurationException {

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

        List<Flow> flows = jdbc.getFlowRecords();
        try {
            for (Flow f : flows) {
                String processName = f.getProcessesName();
                String acName = f.getActivityName();
                String acXslt = new String(f.getActivityXslt(), StandardCharsets.UTF_8);
                logger.info("Activity Name: " + acName);

                Node acNode = docBuilder.parse(new InputSource(new StringReader(acXslt))).getDocumentElement();

                ArrayList<Node> node = new ArrayList<>();
                accelerator.getNode(acNode.getChildNodes(), 0, node, "pd:inputBindings");
                Node inputBinding = node.get(0);

                if (inputBinding != null) {
                    node = new ArrayList<>();
                    accelerator.getNode(inputBinding.getChildNodes(), 0, node, "xsl:value-of");
                    if (node.size() > 1) {

                        if (processName.contains("/")) {
                            jdbc.insertXslt(
                                    processName.substring(processName.lastIndexOf("/") + 1,
                                            processName.lastIndexOf(".")) + "-" + acName,
                                    accelerator.nodeToString(inputBinding));
                        } else {
                            jdbc.insertXslt(
                                    processName.substring(0, processName.lastIndexOf(".")) + "-" + acName,
                                    accelerator.nodeToString(inputBinding));
                        }

                    }
                }
            }
        } catch (Exception e) {
            logger.error("An error occurred: " + e.getMessage());
        }
        List<GroupActivities> groupActivities = jdbc.getGroupActivitiesRecords();
        try {
            for (GroupActivities g : groupActivities) {
                String processName = g.getProcessesName();
                String acName = g.getActivityName();
                String acXslt = new String(g.getActivityXslt(), StandardCharsets.UTF_8);
                Node acNode = docBuilder.parse(new InputSource(new StringReader(acXslt))).getDocumentElement();

                ArrayList<Node> node = new ArrayList<>();
                accelerator.getNode(acNode.getChildNodes(), 0, node, "pd:inputBindings");
                Node inputBinding = node.get(0);

                if (inputBinding != null) {
                    node = new ArrayList<>();
                    accelerator.getNode(inputBinding.getChildNodes(), 0, node, "xsl:value-of");
                    if (node.size() > 1) {

                        if (processName.contains("/")) {
                            jdbc.insertXslt(
                                    processName.substring(processName.lastIndexOf("/") + 1,
                                            processName.lastIndexOf(".")) + "-" + acName,
                                    accelerator.nodeToString(inputBinding));
                        } else {
                            jdbc.insertXslt(
                                    processName.substring(0, processName.lastIndexOf(".")) + "-" + acName,
                                    accelerator.nodeToString(inputBinding));
                        }

                    }
                }
            }
        } catch (Exception e) {
            logger.error("An error occurred: " + e.getMessage());
        }
    }

    public void insertRows(Accelerator accelerator, Document prcDoc, String fullProcessName, String processName, int level) throws SQLException,
            ParserConfigurationException, SAXException, IOException, JSONException {

        if (processesCompleted == null) {
            processesCompleted = new ArrayList<>();
        }
        processesCompleted.add(fullProcessName);

        NodeList transitions = prcDoc.getElementsByTagName("pd:transition");
        NodeList activities = prcDoc.getElementsByTagName("pd:activity");
        NodeList groups = prcDoc.getElementsByTagName("pd:group");

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

        ArrayList<File> subProcesses = new ArrayList<>();
        ArrayList<String> wsdlNames = new ArrayList<>();
        ArrayList<String> serviceNames = new ArrayList<>();

        logger.info("Process Name : " + fullProcessName);
        ArrayList<Node> nodes;

        for (int i = 0; i < activities.getLength(); i++) {
            String acType = activities.item(i).getFirstChild().getTextContent();
            if (acType.contentEquals("com.tibco.pe.core.CallProcessActivity")) {
                nodes = new ArrayList<>();
                accelerator.getNode(activities.item(i).getChildNodes(), 0, nodes, "processName");
                File subPrc = new File(
                        accelerator.getSrcProjectDir().getAbsolutePath()
                                + nodes.get(0).getTextContent());
                subProcesses.add(subPrc);
            }
            if (acType.contentEquals("com.tibco.plugin.soap.SOAPSendReceiveActivity")) {
                nodes = new ArrayList<>();
                accelerator.getNode(activities.item(i).getChildNodes(), 0, nodes, "soapAction");

                for (Node n : nodes) {
                    String service = "";
                    String wsdlName = null;
                    if (n.getTextContent().contains(".serviceagent")) {
                        service = n.getTextContent().substring(0, n.getTextContent().indexOf(".serviceagent") + 13);
                    }

                    if (!n.getTextContent().contains(".serviceagent")) {
                        ArrayList<Node> node = new ArrayList<>();
                        accelerator.getNode(prcDoc.getChildNodes(), 0, node, "wsdl:import");
                        for (Node n1 : node) {
                            String namespace = n1.getAttributes().getNamedItem("namespace").getNodeValue();
                            namespace = namespace.substring(namespace.indexOf(".com/") + 5);
                            namespace = namespace.replace("/", "_");
                            if (n.getTextContent().contains(namespace)) {
                                wsdlName = n1.getAttributes().getNamedItem("location").getNodeValue();
                            }
                        }
                    }

                    if (wsdlName != null) {
                        if (!wsdlNames.contains(wsdlName)) {
                            File wsdlFile = new File(accelerator.getSrcProjectDir().getAbsolutePath()
                                    + wsdlName);
                            if (wsdlFile.exists()) {
                                jdbc.insertSharedResources(
                                        wsdlName.substring(wsdlName.lastIndexOf("/") + 1),
                                        Files.readString(wsdlFile.toPath()));
                            }
                            wsdlNames.add(wsdlName);
                        }
                    } else {
                        if (!serviceNames.contains(service)) {

                            File agent = new File(accelerator.getSrcProjectDir().getAbsolutePath() + service);
                            if (agent.isFile()) {
                                Document agentDoc = docBuilder.parse(agent);
                                accelerator.removeBlankLines(agentDoc);
                                ArrayList<Node> node1 = new ArrayList<>();
                                accelerator.getNode(agentDoc.getChildNodes(), 0, node1, "wsdlDetail");
                                String wsdl = node1.get(0).getAttributes().getNamedItem("location").getNodeValue();
                                if (!wsdlNames.contains(wsdl)) {
                                    File wsdlFile = new File(accelerator.getSrcProjectDir().getAbsolutePath() + wsdl);
                                    if (wsdlFile.exists()) {
                                        jdbc.insertSharedResources(
                                                wsdl.substring(wsdl.lastIndexOf("/") + 1),
                                                Files.readString(wsdlFile.toPath()));
                                    }
                                    wsdlNames.add(wsdl);
                                }
                                jdbc.insertSharedResources(service.substring(service.lastIndexOf("/") + 1),
                                        Files.readString(agent.toPath()));
                                serviceNames.add(service);
                            } else {
                                logger.info("No service agent exists!!!");
                            }
                        }
                    }
                }

            }

        }

        if (!jdbc.checkIfAlreadyExist(fullProcessName)) {

            if (prcDoc.getElementsByTagName("pd:starter").getLength() == 1) {
                String acName = prcDoc.getElementsByTagName("pd:starter").item(0).getAttributes().getNamedItem("name")
                        .getNodeValue();
                String acType = prcDoc.getElementsByTagName("pd:starter").item(0).getFirstChild().getTextContent();
                String acXslt = accelerator.nodeToString(prcDoc.getElementsByTagName("pd:starter").item(0));
                jdbc.insertRow(fullProcessName, level, acName, acType, acXslt);
                insertResources(accelerator, acXslt);

            }

            for (int i = 0; i < activities.getLength(); i++) {

                String acName = activities.item(i).getAttributes().getNamedItem("name").getNodeValue();
                String acType = activities.item(i).getFirstChild().getTextContent();
                String acXslt = accelerator.nodeToString(activities.item(i));

                if (acType.contentEquals("com.tibco.plugin.json.rest.server.activities.RestAdapterActivity")) {
                    insertRestService(accelerator, processName, acXslt);
                }

                jdbc.insertRow(fullProcessName, level, acName, acType, acXslt);
                insertResources(accelerator, acXslt);

            }

            for (int i = 0; i < groups.getLength(); i++) {

                String acName = groups.item(i).getAttributes().getNamedItem("name").getNodeValue();
                String acType = groups.item(i).getFirstChild().getTextContent();
                String acXslt = accelerator.nodeToString(groups.item(i));

                jdbc.insertRow(fullProcessName, level, acName, acType, acXslt);
            }
            insertTransitions(accelerator, transitions, fullProcessName);

            for (int i = 0; i < groups.getLength(); i++) {
                ArrayList<Node> node = new ArrayList<>();
                for (int j = 0; j < groups.item(i).getChildNodes().getLength(); j++) {
                    if (groups.item(i).getChildNodes().item(j).getNodeName().contentEquals("pd:activity")) {
                        node.add(groups.item(i).getChildNodes().item(j));
                    }
                    if (groups.item(i).getChildNodes().item(j).getNodeName().contentEquals("pd:group")) {
                        node.add(groups.item(i).getChildNodes().item(j));
                    }
                }
                String groupName = groups.item(i).getAttributes().getNamedItem("name").getNodeValue();
                for (Node n : node) {
                    String acName = n.getAttributes().getNamedItem("name").getNodeValue();
                    jdbc.moveActivityToGroupActivitiesStarter(groupName, fullProcessName, acName);
                }
            }

        }
        for (File subPrc : subProcesses) {
            Document subPrcDoc = docBuilder.parse(subPrc);
            accelerator.removeBlankLines(subPrcDoc);
            String fullSubProcessName = subPrcDoc.getElementsByTagName("pd:name").item(0).getTextContent();
            String subProcessName = fullSubProcessName.substring(fullSubProcessName.lastIndexOf('/') + 1,
                    fullSubProcessName.lastIndexOf('.'));
            subProcessName = subProcessName.replace(' ', '_');

            insertRows(accelerator, subPrcDoc, fullSubProcessName, subProcessName, level + 1);
        }
    }

    public void insertRestService(Accelerator accelerator, String processName, String acXslt) throws ParserConfigurationException, SAXException,
            IOException, SQLException, JSONException {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Node acNode = docBuilder.parse(new InputSource(new StringReader(acXslt))).getDocumentElement();

        ArrayList<Node> resourcesNode = new ArrayList<>();
        accelerator.getNodeLike(acNode.getChildNodes(), 0, resourcesNode, ":resources");
        for (Node rsn : resourcesNode) {

            String resourceName = rsn.getAttributes().getNamedItem("name").getNodeValue();
            String base = rsn.getAttributes().getNamedItem("base").getNodeValue();
            ArrayList<Node> resourceNode = new ArrayList<>();
            accelerator.getNodeLike(rsn.getChildNodes(), 0, resourceNode, ":resource");
            for (Node n : resourceNode) {
                String path = n.getAttributes().getNamedItem("path").getNodeValue();
                ArrayList<Node> node1 = new ArrayList<>();
                accelerator.getNodeLike(n.getChildNodes(), 0, node1, ":method");
                for (Node n1 : node1) {
                    String methodName = n1.getAttributes().getNamedItem("name").getNodeValue();
                    ArrayList<Node> node2 = new ArrayList<>();
                    accelerator.getNode(n1.getChildNodes(), 0, node2, "Binding");
                    String bindingProcess = node2.get(0).getAttributes().getNamedItem("process").getNodeValue();
                    String inp;
                    String out;
                    String xsdStrIn = "";
                    String xsdStrOut = "";
                    File processfile = new File(accelerator.getSrcProjectDir().getAbsolutePath()
                            + bindingProcess);

                    if (processfile.exists()) {
                        Document processDoc = docBuilder.parse(processfile);
                        node2 = new ArrayList<>();
                        accelerator.getNode(processDoc.getChildNodes(), 0, node2, "pd:startType");
                        accelerator.getNode(processDoc.getChildNodes(), 0, node2, "pd:endType");

                        if (node2.get(0).hasChildNodes()) {

                            xsdStrIn = accelerator.nodeToString(node2.get(0)).replace("<pd:startType>", "")
                                    .replace("</pd:startType>", "");
                            inp = xsdStrIn.substring(xsdStrIn.indexOf("\"") + 1);
                            inp = inp.substring(0, inp.indexOf("\""));
                        } else {
                            inp = node2.get(0).getAttributes().getNamedItem("ref").getNodeValue();
                            if (inp.contains(":")) {
                                inp = inp.substring(inp.indexOf(":") + 1);

                                ArrayList<Node> node3 = new ArrayList<>();
                                accelerator.getNode(processDoc.getChildNodes(), 0, node3, "xsd:import");
                                for (Node n3 : node3) {
                                    String xsd = n3.getAttributes().getNamedItem("schemaLocation").getNodeValue();
                                    String xsdStr = readFileToString(
                                            new File(accelerator.getSrcProjectDir().getAbsolutePath()
                                                    + xsd).getAbsolutePath());
                                    if (xsdStr.contains("name=\"" + inp + "\"")) {
                                        Node xsdNode = docBuilder.parse(new InputSource(new StringReader(xsdStr)))
                                                .getDocumentElement();
                                        ArrayList<Node> elements = new ArrayList<>();
                                        accelerator.getNode(xsdNode.getChildNodes(), 0, elements, "xs:element");
                                        for (Node ele : elements) {
                                            if (ele.getAttributes().getNamedItem("name") != null) {
                                                if (ele.getAttributes().getNamedItem("name").getNodeValue()
                                                        .contentEquals(inp)) {
                                                    xsdStrIn = accelerator.nodeToString(ele);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (node2.get(1).hasChildNodes()) {
                            xsdStrOut = accelerator.nodeToString(node2.get(1)).replace("<pd:endType>", "")
                                    .replace("</pd:endType>", "");
                            out = xsdStrOut.substring(xsdStrOut.indexOf("\"") + 1);
                            out = out.substring(0, out.indexOf("\""));
                        } else {
                            out = node2.get(1).getAttributes().getNamedItem("ref").getNodeValue();
                            if (out.contains(":")) {
                                out = out.substring(out.indexOf(":") + 1);

                                ArrayList<Node> node3 = new ArrayList<>();
                                accelerator.getNode(processDoc.getChildNodes(), 0, node3, "xsd:import");
                                for (Node n3 : node3) {
                                    String xsd = n3.getAttributes().getNamedItem("schemaLocation").getNodeValue();
                                    String xsdStr = readFileToString(
                                            new File(accelerator.getSrcProjectDir().getAbsolutePath()
                                                    + xsd).getAbsolutePath());

                                    if (xsdStr.contains("name=\"" + out + "\"")) {
                                        xsdStrOut = xsdStr;
                                    }
                                }
                            }
                        }

                        jdbc.insertRestService(processName, resourceName, path, base, methodName, inp, out, xsdStrIn,
                                xsdStrOut);
                    }

                }
            }
        }
    }

    public void insertRamlData(Accelerator accelerator) throws SQLException, JSONException {

        String mainRaml = "#%RAML 1.0\r\n" + "title: Member System API\r\n"
                + "description: This RAML file desribe structure of all member system API.\r\n" + "types:\r\n";

        StringBuilder types = new StringBuilder();

        List<RestService> restServices = jdbc.getRestResultSet();
        try {
            for (RestService rs : restServices) {
                String resourceName = rs.getResourceName();
                String path = rs.getPath();
                String methodName = rs.getMethodName();
                String inp = rs.getInput();
                String out = rs.getOutput();
                String inpSchema = new String(rs.getInpSchema(), StandardCharsets.UTF_8);
                String outSchema = new String(rs.getOutSchema(), StandardCharsets.UTF_8);

                try (BufferedWriter writer = new BufferedWriter(new FileWriter("temp.xml"))) {
                    if (inpSchema.contains("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")) {
                        writer.write(inpSchema);
                    } else {
                        writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
                                + "<xsd:schema xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">"
                                + inpSchema.replace("xs:", "xsd:") + "</xsd:schema>");

                    }
//		        logger.info("written to file successfully.");
                } catch (IOException e) {
                    logger.error("An error occurred: " + e.getMessage());
                }
                convertxml(accelerator, "temp.xml", resourceName, path, inp, methodName, "request");

                try (BufferedWriter writer = new BufferedWriter(new FileWriter("temp.xml"))) {
                    if (outSchema.contains("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")) {
                        writer.write(outSchema);
                    } else {
                        writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
                                + "<xsd:schema xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">"
                                + outSchema.replace("xs:", "xsd:") + "</xsd:schema>");
                    }

//	        	logger.info("written to file successfully.");
                } catch (IOException e) {
                    logger.error("An error occurred: " + e.getMessage());
                }
                convertxml(accelerator, "temp.xml", resourceName, path, out, methodName, "response");
            }
        } catch (Exception e) {
            logger.error("An error occurred: " + e.getMessage());
        }

        StringBuilder resources = new StringBuilder();
        StringBuilder resource = new StringBuilder();
        String tempResource = "";

        try {
            for (RestService rs1 : restServices) {
                String resourceName = rs1.getResourceName();
                String path = rs1.getPath();
                String methodName = rs1.getMethodName();
                String inp = rs1.getInput();
                String out = rs1.getOutput();
                if (!tempResource.contentEquals(resourceName)) {
                    resources.append(resource);
                    resource = new StringBuilder(path + ":\r\n");
                    tempResource = resourceName;
                }
                String typein = resourceName + "_" + path.substring(1) + "_" + methodName + "_" + "request" + "_" + inp;
                String typeout = resourceName + "_" + path.substring(1) + "_" + methodName + "_" + "response" + "_"
                        + out;

                types.append("  ").append(typein).append(": !include types/").append(typein).append(".raml\r\n");
                types.append("  ").append(typeout).append(": !include types/").append(typeout).append(".raml\r\n");

                if (methodName.toLowerCase().contentEquals("get")) {
                    resource.append("  ").append(methodName.toLowerCase()).append(":\r\n").append("    responses:\r\n").append("      200:\r\n").append("        body:\r\n").append("          application/json:\r\n").append("            type: ").append(typeout).append("\r\n").append("            example: !include examples/").append(typeout).append("-example.json\r\n");
                } else {
                    resource.append("  ").append(methodName.toLowerCase()).append(":\r\n").append("    body:\r\n").append("      application/json:\r\n").append("        type: ").append(typein).append("\r\n").append("        example: !include examples/").append(typein).append("-example.json\r\n").append("    responses:\r\n").append("      200:\r\n").append("        body:\r\n").append("          application/json:\r\n").append("            type: ").append(typeout).append("\r\n").append("            example: !include examples/").append(typeout).append("-example.json\r\n");
                }
            }
        } catch (Exception e) {
            logger.error("An error occurred: " + e.getMessage());
        }
        resources.append(resource);

        mainRaml += types.toString() + resources;

        try (BufferedWriter writer = new BufferedWriter(
                new FileWriter(accelerator.getTrgProjectDir().getAbsolutePath()
                        + File.separator + "src" + File.separator + "main" + File.separator
                        + "resources" + File.separator + "api" + File.separator + "api.raml"))) {
            writer.write(mainRaml);
//          logger.info("written to file successfully.");
        } catch (IOException e) {
            logger.error("An error occurred: " + e.getMessage());
        }
    }

    public void convertxml(Accelerator accelerator, String filename, String resourceName, String path, String elementName, String methodName,
                           String reqres) throws IOException, TransformerConfigurationException, ParserConfigurationException,
            SAXException, JSONException {

        Document doc = loadXsdDocument(accelerator, filename);

        final Element rootElem = doc.getDocumentElement();
//        String nodeName = rootElem.getNodeName();
        String targetNamespace = rootElem.getAttribute("targetNamespace");

        XSModel xsModel = new XSParser().parse(filename);
        XSInstance instance = new XSInstance();
        instance.minimumElementsGenerated = 1;
        instance.maximumElementsGenerated = 1;
        instance.generateDefaultAttributes = true;
        instance.generateOptionalAttributes = true;
        instance.maximumRecursionDepth = 0;
        instance.generateAllChoices = true;
        instance.showContentModel = true;
        instance.generateOptionalElements = true;

        QName rootElement = new QName(targetNamespace, elementName);
        XMLDocument sampleXml = new XMLDocument(new StreamResult("out.xml"), true, 4, null);
        instance.generate(xsModel, rootElement, sampleXml);
        String json = convertjson(accelerator);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(
                accelerator.getTrgProjectDir()
                        + File.separator + "src" + File.separator + "main" + File.separator
                        + "resources" + File.separator + "api" + File.separator + "examples" + File.separator
                        + resourceName + "_"
                        + path.substring(1) + "_" + methodName + "_" + reqres + "_" + elementName + "-example.json"))) {
            writer.write(json);
//			logger.info(elementName+" to file successfully.");
        } catch (IOException e) {
            logger.error("An error occurred: " + e.getMessage());
        }
        JSONObject jsonNode = new JSONObject(json);

        String raml = generateRaml(jsonNode);
        try (BufferedWriter writer = new BufferedWriter(
                new FileWriter(accelerator.getTrgProjectDir().getAbsolutePath()
                        + File.separator + "src" + File.separator + "main" + File.separator
                        + "resources" + File.separator + "api" + File.separator + "types" + File.separator
                        + resourceName + "_"
                        + path.substring(1) + "_" + methodName + "_" + reqres + "_" + elementName + ".raml"))) {
            writer.write(raml);
//		    logger.info(elementName+" to file successfully.");
        } catch (IOException e) {
            logger.error("An error occurred: " + e.getMessage());
        }

    }

    private String generateRaml(JSONObject json) {
        StringBuilder ramlBuilder = new StringBuilder("#%RAML 1.0 DataType\n");

        generateRamlType(json, ramlBuilder, 0);

        return ramlBuilder.toString();
    }

    private void generateRamlType(JSONObject json, StringBuilder ramlBuilder, int indentationLevel) {
        String indentation = getIndentation(indentationLevel);

        ramlBuilder.append(indentation).append("type: object\n");
        ramlBuilder.append(indentation).append("properties:\n");

        try {
            // Get the keys of the JSON object
            String[] keys = JSONObject.getNames(json);

            if (keys != null) {
                // Iterate over the keys
                for (String key : keys) {
                    Object value = json.get(key);

                    ramlBuilder.append(indentation).append("  ").append(key).append(":\n");
                    generateProperty(value, ramlBuilder, indentationLevel + 2);
                }
            }
        } catch (JSONException e) {
            logger.error("An error occurred: " + e.getMessage());
        }
    }

    private void generateProperty(Object value, StringBuilder ramlBuilder, int indentationLevel)
            throws JSONException {
        String indentation = getIndentation(indentationLevel);

        if (value instanceof JSONObject) {
            generateRamlType((JSONObject) value, ramlBuilder, indentationLevel);
        } else if (value instanceof JSONArray) {
            JSONArray jsonArray = (JSONArray) value;
            if (!jsonArray.isEmpty()) {
                Object firstElement = jsonArray.get(0);
                if (firstElement instanceof JSONObject) {
                    ramlBuilder.append(indentation).append("  ").append("type: array\n");
                    ramlBuilder.append(indentation).append("  ").append("items:\n");
                    generateRamlType((JSONObject) firstElement, ramlBuilder, indentationLevel + 2);
                } else {
                    ramlBuilder.append(indentation).append("  ").append("type: ").append(getRamlType(firstElement))
                            .append("[]\n");
                }
            }
        } else {
            ramlBuilder.append(indentation).append("  ").append("type: ").append(getRamlType(value)).append("\n");
        }
    }

    private String getRamlType(Object value) {
        if (value instanceof String) {
            return "string";
        } else if (value instanceof Number) {
            return "number";
        } else if (value instanceof Boolean) {
            return "boolean";
        }
        return "any";
    }

    private String getIndentation(int indentationLevel) {
        return "  ".repeat(Math.max(0, indentationLevel));
    }

    public Document loadXsdDocument(Accelerator accelerator, String inputName) {

        final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setValidating(false);
        factory.setIgnoringElementContentWhitespace(true);
        factory.setIgnoringComments(true);
        Document doc = null;

        try {
            final DocumentBuilder builder = factory.newDocumentBuilder();
            final File inputFile = new File(inputName);
            doc = builder.parse(inputFile);
            accelerator.removeBlankLines(doc);
        } catch (final Exception e) {
            logger.error("An error occurred: " + e.getMessage());
            // throw new ContentLoadException(msg);
        }

        return doc;
    }

    public String convertjson(Accelerator accelerator) throws ParserConfigurationException, SAXException, IOException {
        File file = new File("out.xml");
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        // an instance of builder to parse the specified xml file
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse(file);

        String TEST_XML_STRING = accelerator.nodeToString(doc.getDocumentElement());

        try {
            JSONObject xmlJSONObj = XML.toJSONObject(TEST_XML_STRING);
            return xmlJSONObj.toString(4);
        } catch (JSONException je) {
            logger.error("An error occurred: " + je.getMessage());
        }
        return "";
    }

    public String readFileToString(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        byte[] bytes = Files.readAllBytes(path);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    public void insertResources(Accelerator accelerator, String acXslt1) throws SAXException, IOException, ParserConfigurationException {

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Node acNode = docBuilder.parse(new InputSource(new StringReader(acXslt1))).getDocumentElement();

        ArrayList<Node> nodes = new ArrayList<>();
        accelerator.getNode(acNode.getChildNodes(), 0, nodes, "jdbcSharedConfig");
        if (!nodes.isEmpty()) {
            insertSharedResources(accelerator, acXslt1, "jdbcSharedConfig");
        }
        nodes = new ArrayList<>();
        accelerator.getNode(acNode.getChildNodes(), 0, nodes, "ConnectionReference");
        if (!nodes.isEmpty()) {
            insertSharedResources(accelerator, acXslt1, "ConnectionReference");
        }
        nodes = new ArrayList<>();
        accelerator.getNode(acNode.getChildNodes(), 0, nodes, "sharedChannel");
        if (!nodes.isEmpty()) {
            insertSharedResources(accelerator, acXslt1, "sharedChannel");
        }
        nodes = new ArrayList<>();
        accelerator.getNode(acNode.getChildNodes(), 0, nodes, "SharedUserData");
        if (!nodes.isEmpty()) {
            insertSharedResources(accelerator, acXslt1, "SharedUserData");
        }
        nodes = new ArrayList<>();
        accelerator.getNode(acNode.getChildNodes(), 0, nodes, "variableConfig");
        if (!nodes.isEmpty()) {
            insertSharedResources(accelerator, acXslt1, "variableConfig");
        }

    }

    public void insertTransitions(Accelerator accelerator, NodeList transitions, String processName) throws SQLException {

        ArrayList<String> toActivities = new ArrayList<>();

        for (int i = 0; i < transitions.getLength(); i++) {
            ArrayList<Node> nodes = new ArrayList<>();
            accelerator.getNode(transitions.item(i).getChildNodes(), 0, nodes, "pd:from");
            accelerator.getNode(transitions.item(i).getChildNodes(), 0, nodes, "pd:to");
            accelerator.getNode(transitions.item(i).getChildNodes(), 0, nodes, "pd:conditionType");
            accelerator.getNode(transitions.item(i).getChildNodes(), 0, nodes, "pd:xpath");
            String from = "", to = "", conditionType = "", xpath = null;
            toActivities.add(to);

            try {
                for (int j = 0; j < nodes.size(); j++) {
                    if (nodes.get(j).getNodeName().contentEquals("pd:from")) {
                        from = nodes.get(j).getTextContent();
                    }
                    if (nodes.get(j).getNodeName().contentEquals("pd:to")) {
                        to = nodes.get(j).getTextContent();
                    }
                    if (nodes.get(j).getNodeName().contentEquals("pd:conditionType")) {
                        conditionType = nodes.get(j).getTextContent();
                    }
                    if (nodes.get(j).getNodeName().contentEquals("pd:xpath")) {
                        xpath = nodes.get(j).getTextContent();
                    }
                }


            } catch (Exception e) {
                e.printStackTrace();
//                logger.error(e.getMessage());
            }
            jdbc.insertTransitionToMainTable(from, to, conditionType, xpath, processName);
        }
        insertTransitionsToTransitionTable(accelerator, transitions, toActivities, processName);
        jdbc.setStartActivityParentId(processName);

    }

    public void insertTransitionsToTransitionTable(Accelerator accelerator, NodeList transitions, ArrayList<String> toActivities,
                                                   String processName) throws SQLException {
        Set<String> activities = new HashSet<>(toActivities);
        for (String activity : activities) {
            if (Collections.frequency(toActivities, activity) > 1) {
                StringBuilder fromList = new StringBuilder(",");
                int transitionCount = 0;
                for (int i = 0; i < transitions.getLength(); i++) {
                    String from = transitions.item(i).getFirstChild().getTextContent();
                    String to = transitions.item(i).getFirstChild().getNextSibling().getTextContent();

                    if (to.contentEquals(activity)) {

                        List<Integer> flowListSeqId = jdbc.getSeqId(from, processName);
                        for (Integer seqId : flowListSeqId) {
                            fromList.append(seqId).append(",");
                        }

                        ArrayList<Node> nodes = new ArrayList<>();
                        accelerator.getNode(transitions.item(i).getChildNodes(), 0, nodes,
                                "pd:conditionType");
                        accelerator.getNode(transitions.item(i).getChildNodes(), 0, nodes, "pd:xpath");
                        String conditionType = nodes.get(0).getTextContent();
                        String xpath = null;
                        try {
                            xpath = nodes.get(1).getTextContent();
                        } catch (Exception e) {
                            logger.error(e.getMessage());
                        }
                        jdbc.insertTransitionToTransitionTable(from, to, conditionType, xpath, processName);
                        transitionCount++;
                    }
                }

                jdbc.UpdateActivityParentId(activity, processName, fromList.toString(), transitionCount);
            }
        }
    }

    public void insertSharedResources(Accelerator accelerator, String acXslt, String resourceTag) {

        try {
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Node acNode = docBuilder.parse(new InputSource(new StringReader(acXslt))).getDocumentElement();

            ArrayList<Node> nodes = new ArrayList<>();
            accelerator.getNode(acNode.getChildNodes(), 0, nodes, resourceTag);

            String resourceName = nodes.get(0).getTextContent();
            File sharedResource = new File(accelerator.getSrcProjectDir().getAbsolutePath() + resourceName);
            Document sharedResourceDoc = docBuilder.parse(sharedResource);
            accelerator.removeBlankLines(sharedResourceDoc);
            String sharedResourceXslt = accelerator.nodeToString(sharedResourceDoc.getFirstChild());
            resourceName = resourceName.substring(resourceName.lastIndexOf("/") + 1).replaceAll(" ", "_");

            if (!jdbc.ifResourceExist(resourceName)) {
                jdbc.insertSharedResources(resourceName, sharedResourceXslt);

                logger.info("Inserted Shared Resources : " + resourceName);
            }
        } catch (ParserConfigurationException | SQLException | SAXException | IOException e) {
            // TODO Auto-generated catch block
            logger.error("An error occurred: " + e.getMessage());
        }

    }

}

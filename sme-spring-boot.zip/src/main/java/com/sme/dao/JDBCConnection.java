package com.sme.dao;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import javax.xml.parsers.ParserConfigurationException;

import com.sme.dao.entity.*;
import com.sme.dao.entity.SharedConnections;
import com.sme.dao.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.sme.service.Accelerator;
import com.sme.util.FlowOps;

@Transactional
@Component
public class JDBCConnection {

    private static final Logger logger = LoggerFactory.getLogger(JDBCConnection.class);

    @Autowired
    private ProjectsRepository projectsRepository;

    @Autowired
    private MigrationStatsRepository migrationStatsRepository;

    @Autowired
    private UnmigratedActivitesRepository unmigratedActivitesRepository;

    @Autowired
    private ConfigFilesRepository configFilesRepository;

    @Autowired
    private FlowRepository flowRepository;

    @Autowired
    private GlobalVariablesRepository globalVariablesRepository;

    @Autowired
    private GroupActivitiesRepository groupActivitiesRepository;

    @Autowired
    private RestServiceRepository restServiceRepository;

    @Autowired
    private SharedConnectionsRepository sharedConnectionsRepository;

    @Autowired
    private TransitionsRepository transitionsRepository;

    @Autowired
    private XsltToDwRepository xsltToDwRepository;

    @Autowired
    private TMReferencesRepository tmReferencesRepository;

    public Connection conn1 = null;
    //	static Accelerator acc = new Accelerator();

    private int seqId = 1;
    private int execId;

    public void setExecId(int execId) {
        this.execId = execId;
    }

// check the manual effort column initially updated as 0
    
    public Projects insertNewProject(String name, String description, byte[] sourceBytes) {
        Projects arcProjects = projectsRepository.save(new Projects(name, new Timestamp(System.currentTimeMillis()),
                description, sourceBytes, null, null, 0,0));
        return arcProjects;
    }
    
  



    public void updateProject(byte[] targetBytes) {
        Projects arcProjects = projectsRepository.findById(execId).orElse(null);
        if (arcProjects != null) {
            arcProjects.setTargetProject(targetBytes);
            projectsRepository.save(arcProjects);
        }
    }

    public void updateProjectWithXsltToDwlExcel(byte[] xsltToDwlExcel) {
        Projects arcProjects = projectsRepository.findById(execId).orElse(null);
        if (arcProjects != null) {
            arcProjects.setXsltToDwlExcel(xsltToDwlExcel);
            projectsRepository.save(arcProjects);
        }
    }

    public void insertRow(String pName, int level, String acName, String acType, String acXslt) {

        flowRepository.save(new Flow(pName, seqId++, level, acName, acType,
                acXslt.getBytes(), null, null, null, 0, execId));

        logger.info("Row inserted : " + acName);

    }

    public void insertSharedResources(String sharedResourceName, String configParameters) throws SQLException {
        sharedConnectionsRepository.save(
                new SharedConnections(sharedResourceName, configParameters.getBytes(StandardCharsets.UTF_8), execId)
        );
    }

    public void insertTransitionToMainTable(String from, String to, String conditionType, String xpath,
                                            String processName) {
        List<Flow> flows = flowRepository.findByProcessesNameAndActivityNameAndExecId(processName, from, execId);
        if (!flows.isEmpty()) {
            Flow flow = flows.get(flows.size() - 1);
            int parentId = flow.getSeqId();
            List<Flow> flowsToUpdate = flowRepository.findByProcessesNameAndActivityNameAndExecId(processName, to, execId);
            for (Flow flowToUpdate : flowsToUpdate) {
                flowToUpdate.setParentId(String.valueOf(parentId));
                flowToUpdate.setConditionType(conditionType);
                flowToUpdate.setXpath(xpath);
                flowRepository.save(flowToUpdate);
                logger.info("Transition inserted to Main table : " + to);
            }
        }

        // TODO: check if this is correct?
//        PreparedStatement preparedStatement1 = conn1.prepareStatement(
//                "UPDATE FLOW SET PARENTID=?, CONDITIONTYPE=? , XPATH=? WHERE ACTIVITY_NAME=? AND PROCESSES_NAME=?");
//        preparedStatement1.setString(1, "0");
//        preparedStatement1.setString(2, conditionType);
//        preparedStatement1.setString(3, xpath);
//        preparedStatement1.setString(4, to);
//        preparedStatement1.setString(5, processName);
//        preparedStatement1.execute();
//        logger.info("Transition inserted to Main table : " + to);
    }

    public void insertTransitionToTransitionTable(String from, String to, String conditionType, String xpath,
                                                  String processName) {

        List<Flow> flowsFrom = flowRepository.findByProcessesNameAndActivityNameAndExecId(processName, from, execId);
        List<Flow> flowsTo = flowRepository.findByProcessesNameAndActivityNameAndExecId(processName, to, execId);

        int parentId = -1;
        if (!flowsFrom.isEmpty()) {
            parentId = flowsFrom.get(flowsFrom.size() - 1).getSeqId();
        }
        int seqId = -1;
        if (!flowsTo.isEmpty()) {
            seqId = flowsTo.get(flowsTo.size() - 1).getSeqId();
        }

        if (parentId != -1 && seqId != -1) {
            transitionsRepository.save(
                    new Transitions(processName, seqId, parentId, conditionType, xpath, execId)
            );
            logger.info("Transition inserted to Transition table : " + to);
        }
    }

    public List<Integer> getSeqId(String processName, String activityName) {
        List<Integer> seqIdList = new ArrayList<>();
        flowRepository.findByProcessesNameAndActivityNameAndExecId(processName, activityName, execId)
                .forEach((flow) -> {
                    seqIdList.add(flow.getSeqId());
                });
        return seqIdList;
    }

    public void setStartActivityParentId(String processName) {
        List<Flow> flowsToUpdate = flowRepository.findAllByProcessesNameAndExecIdAndParentIdIsNull(processName, execId);
        for (Flow flowToUpdate : flowsToUpdate) {
            flowToUpdate.setParentId("0");
            flowToUpdate.setConditionType("ALWAYS");
            flowRepository.save(flowToUpdate);
        }
        logger.info(processName + " : Start Activities PARENTID is set to 0 ");
    }

    public void UpdateActivityParentId(String activity, String processName, String fromList, int transitionCount) {
        List<Flow> flowsToUpdate = flowRepository.findByProcessesNameAndActivityNameAndExecId(processName, activity, execId);
        for (Flow flowToUpdate : flowsToUpdate) {
            flowToUpdate.setConditionType(null);
            flowToUpdate.setXpath(null);
            flowToUpdate.setParentId(fromList);
            flowToUpdate.setParentCount(transitionCount);
            flowRepository.save(flowToUpdate);
        }
        logger.info(processName + " - " + activity + " : PARENTID Set to " + fromList
                + " : CONDITIONTYPE and XPATH set to NULL : PARENTCOUNT set to " + transitionCount);
    }

    public boolean checkIfAlreadyExist(String processName) {
        List<Flow> flows = flowRepository.findAllByProcessesNameAndExecId(processName, execId);
        return !flows.isEmpty();
    }

    public List<Flow> getProcessNames() {
        return flowRepository.findAllByExecId(execId);
    }

    public List<Flow> getActivityWithParentId(Accelerator accelerator, String processName, String parentId,
                                              Document tDoc, Element flow, FlowOps flowOps)
            throws SQLException, DOMException, ParserConfigurationException, SAXException, IOException {
        List<Flow> flowsToMerge = flowRepository
                .findAllByProcessesNameAndExecIdAndParentIdLike(processName, execId, "%" + parentId + "%");

        for (Flow flowToMerge : flowsToMerge) {
            flowOps.mergingActivity(accelerator, processName, parentId, tDoc, flow, flowToMerge);
        }

        return flowRepository
                .findAllByProcessesNameAndExecIdAndParentIdAndParentIdLike(processName, execId,
                        parentId, "%" + parentId + "%");
    }

    public List<GroupActivities> getActivityWithParentIdGroup(Accelerator accelerator, String processName,
                                                              String GroupName, String parentId, Document tDoc,
                                                              Element until, FlowOps flowOps)
            throws SQLException, DOMException, ParserConfigurationException, SAXException, IOException {
        List<GroupActivities> groupActivitiesList = groupActivitiesRepository
                .findAllByProcessesNameAndExecIdAndParentIdLikeAndGroupName
                        (processName, execId, "%" + parentId + "%", GroupName);
        for (GroupActivities groupActivities : groupActivitiesList) {
            flowOps.mergingActivity(accelerator, processName, parentId, tDoc, until, groupActivities);
        }
        return groupActivitiesRepository
                .findAllByProcessesNameAndExecIdAndParentIdAndParentIdLikeAndGroupName
                        (processName, execId, parentId, "%" + parentId + "%", GroupName);

    }

    public List<Transitions> getTransition(String processName, int seqId, String parentId) {
        return transitionsRepository
                .findAllByExecIdAndProcessesNameAndSeqIdAndParentId(execId, processName, seqId, parentId);
    }

    public List<TMReferences> getReference(String tibcoActivityType) {
        return tmReferencesRepository.findAllByTibco(tibcoActivityType);
    }

    public NamedObject getActivityWithSeqId(String processName, String seqId, Element flow) {
        if (flow.getNodeName().contentEquals("flow")) {
            return new NamedObject(
                    flowRepository.findAllByProcessesNameAndExecIdAndSeqId(processName,
                            execId, Integer.parseInt(seqId)),
                    new ArrayList<>());
        }
        if (flow.getNodeName().contentEquals("until-successful") || flow.getNodeName().contentEquals("foreach")) {
            return new NamedObject(new ArrayList<>(),
                    groupActivitiesRepository
                            .findAllByProcessesNameAndSeqIdAndExecId(processName, Integer.parseInt(seqId), execId));
        }

        return null;

    }

    public NamedObject getActivityWithActivityName(String processName, String activityName, Element flow) {
        if (flow.getNodeName().contentEquals("flow")) {
            return new NamedObject(
                    flowRepository.findByProcessesNameAndActivityNameAndExecId(processName, activityName, execId),
                    new ArrayList<>());
        }
        if (flow.getNodeName().contentEquals("until-successful") || flow.getNodeName().contentEquals("foreach")) {
            return new NamedObject(
                    new ArrayList<>(),
                    groupActivitiesRepository
                            .findByProcessesNameAndActivityNameAndExecId(processName, activityName, execId));
        }

        return null;
    }

    public boolean ifResourceExist(String resourceName) throws SQLException {
        List<SharedConnections> sharedConnections =
                sharedConnectionsRepository.findAllBySharedNameAndExecId(resourceName, execId);
        return !sharedConnections.isEmpty();
    }

    public List<SharedConnections> getSharedConfig(String resourceName) {
        return sharedConnectionsRepository.findAllBySharedNameAndExecId(resourceName, execId);
    }

    public void insertKeyValuePair(String key, Object value) {
        globalVariablesRepository.save(new GlobalVariables(key, value.toString(), execId));
    }

    public void moveActivityToGroupActivitiesStarter(String groupName, String fullProcessName, String acName)
            throws SQLException {
        List<Flow> flows = flowRepository.findByProcessesNameAndActivityNameAndExecId(fullProcessName, acName, execId);
        flows.forEach((f) -> {
            groupActivitiesRepository.save(
                    new GroupActivities(
                            groupName, f.getProcessesName(), f.getSeqId(), f.getLvl(), f.getActivityName(),
                            f.getActivityType(), f.getActivityXslt(), f.getParentId(), f.getConditionType(),
                            f.getXpath(), f.getParentCount(), f.getExecId()
                    )
            );
            flowRepository.delete(f);
        });
        logger.info(acName + " : Activity moved from flow table to groupactivities table ");

        // TODO: What does the below logic do?
//        PreparedStatement preparedStatement = conn1
//                .prepareStatement("SELECT * FROM FLOW WHERE PROCESSES_NAME = ? AND ACTIVITY_NAME = ?");
//        preparedStatement.setString(1, fullProcessName);
//        preparedStatement.setString(2, acName);
//        ResultSet rs = preparedStatement.executeQuery();
//        while (rs.next()) {
//            PreparedStatement preparedStatement1 = conn1
//                    .prepareStatement("INSERT INTO GROUPACTIVITIES VALUES (?,?,?,?,?,?,?,?,?,?,?)");
//            preparedStatement1.setString(1, groupName);
//            preparedStatement1.setString(2, rs.getString(1));
//            preparedStatement1.setInt(3, rs.getInt(2));
//            preparedStatement1.setInt(4, rs.getInt(3));
//            preparedStatement1.setString(5, rs.getString(4));
//            preparedStatement1.setString(6, rs.getString(5));
//            preparedStatement1.setString(7, rs.getString(6));
//            preparedStatement1.setString(8, rs.getString(7));
//            preparedStatement1.setString(9, rs.getString(8));
//            preparedStatement1.setString(10, rs.getString(9));
//            preparedStatement1.setInt(11, rs.getInt(10));
//            preparedStatement1.execute();
//
//            PreparedStatement preparedStatement2 = conn1
//                    .prepareStatement("DELETE FROM FLOW WHERE PROCESSES_NAME = ? AND ACTIVITY_NAME = ?");
//            preparedStatement2.setString(1, fullProcessName);
//            preparedStatement2.setString(2, acName);
//            preparedStatement2.execute();
//
//        }
//        PreparedStatement preparedStatement1 = conn1
//                .prepareStatement("SELECT * FROM GROUPACTIVITIES WHERE PROCESSES_NAME = ? AND ACTIVITY_NAME = ?");
//        preparedStatement1.setString(1, fullProcessName);
//        preparedStatement1.setString(2, acName);
//        ResultSet rs1 = preparedStatement.executeQuery();
//        while (rs1.next()) {
//
//            PreparedStatement preparedStatement12 = conn1
//                    .prepareStatement("DELETE FROM GROUPACTIVITIES WHERE PROCESSES_NAME = ? AND ACTIVITY_NAME = ?");
//            preparedStatement12.setString(1, fullProcessName);
//            preparedStatement12.setString(2, acName);
//            preparedStatement12.execute();
//
//            PreparedStatement preparedStatement11 = conn1
//                    .prepareStatement("INSERT INTO GROUPACTIVITIES VALUES (?,?,?,?,?,?,?,?,?,?,?)");
//            preparedStatement11.setString(1, groupName);
//            preparedStatement11.setString(2, rs.getString(2));
//            preparedStatement11.setInt(3, rs.getInt(3));
//            preparedStatement11.setInt(4, rs.getInt(4));
//            preparedStatement11.setString(5, rs.getString(5));
//            preparedStatement11.setString(6, rs.getString(6));
//            preparedStatement11.setString(7, rs.getString(7));
//            preparedStatement11.setString(8, rs.getString(8));
//            preparedStatement11.setString(9, rs.getString(9));
//            preparedStatement11.setString(10, rs.getString(10));
//            preparedStatement11.setInt(11, rs.getInt(11));
//            preparedStatement11.execute();
//        }
    }


    public List<GlobalVariables> getGlobalVariable(String key) {
        return globalVariablesRepository.findAllByKeyS(key);
    }
 public int getGlobalVariableCount() throws SQLException {
        List<GlobalVariables> globalVariables = globalVariablesRepository.findAllByExecId(execId);
        return globalVariables.size();
    }
    public List<SharedConnections> getWsdls() {
        return sharedConnectionsRepository.findAllByExecIdAndSharedNameLike(execId, "%.wsdl");
    }

    public List<SharedConnections> getSharedConnections() {
        return sharedConnectionsRepository.findAllByExecId(execId);
    }

    public List<Flow> getActivitiesType(String processName) {
        return flowRepository.findAllByProcessesNameAndExecId(processName, execId);
    }

    public void insertXslt(String acName, String inputBinding) {
        xsltToDwRepository.save(
                new XsltToDw(acName, inputBinding.getBytes(StandardCharsets.UTF_8), execId)
        );
    }

    public List<Flow> getFlowRecords() {
        return flowRepository.findAllByExecId(execId);
    }

    public List<GroupActivities> getGroupActivitiesRecords() {
        return groupActivitiesRepository.findAllByExecId(execId);
    }

    public void insertRestService(String processName, String resourceName, String path,
                                  String base, String methodName,
                                  String inp, String out, String xsdStrIn, String xsdStrOut) {
        restServiceRepository.save(
                new RestService(processName, resourceName, path, base, methodName,
                        inp, out, xsdStrIn.getBytes(StandardCharsets.UTF_8),
                        xsdStrOut.getBytes(StandardCharsets.UTF_8), execId)
        );
    }

    public List<Flow> getFlowDetails() {
        return flowRepository.findAllByExecId(execId);
    }

    public void insertIntoConfigFiles(String fileName, String fileContent) {
        configFilesRepository.save(new ConfigFiles(fileName, fileContent.getBytes(), execId));
    }

    // Inserts .process files in DB
    public void insertProcessFile(String fileName, String fileContent) {
        insertIntoConfigFiles(fileName, fileContent);
    }

    public void insertYamlFile(String fileName, String fileContent) {
        insertIntoConfigFiles(fileName, fileContent);
    }

    public void insertJavaFiles(String fileName, String fileContent) {
        insertIntoConfigFiles(fileName, fileContent);
    }

    public List<ConfigFiles> getConfigs() {
        return configFilesRepository.findByExecId(execId);
    }

    public List<ConfigFiles> getConfigsProcess(String processName) {
        return configFilesRepository.findByNameAndExecId(processName, execId);
    }

    public List<RestService> getRestResultSet() {
        return restServiceRepository.findAllByExecId(execId);
    }

    public void archive() throws SQLException {

        logger.info("ARCHIVING COMPLETE...");
    }
    public void getJavaConfigFiles(ArrayList<String> javaConfigFile, ArrayList<String> javaConfigFileName) {
        List<ConfigFiles> configFilesList =
                configFilesRepository.findByNameLikeAndExecId("%.java%", execId);
        for (ConfigFiles cf : configFilesList) {
            javaConfigFileName.add(cf.getName());
            javaConfigFile.add(new String(cf.getConfig(), StandardCharsets.UTF_8));
        }
    }

    public Projects getProject(int executionId) {
        Optional<Projects> projectsOptional = projectsRepository.findById(executionId);
        return projectsOptional.orElse(null);
    }

    public void updateProjectName(int currentExecutionId, String projectName) {
        Optional<Projects> projectsOptional = projectsRepository.findById(currentExecutionId);
        if (projectsOptional.isPresent()) {
            Projects projects = projectsOptional.get();
            projects.setName(projectName);
            projectsRepository.save(projects);
        }
    }

    public void updateProjectStatus(ProjectStatus status, String error) {
        Optional<Projects> projectsOptional = projectsRepository.findById(execId);
        if (projectsOptional.isPresent()) {
            Projects projects = projectsOptional.get();
            projects.setStatus(status.toString());
            if (error == null) {
                error = "";
            }
            projects.setError(error);
            switch (status) {
                case ANALYZE_START:
                    projects.setAnalyzeStart(new Timestamp(System.currentTimeMillis()));
                    break;
                case ANALYZE_END:
                case ANALYZE_ERROR:
                    projects.setAnalyzeEnd(new Timestamp(System.currentTimeMillis()));
                    break;
                case MIGRATION_START:
                    projects.setMigrationStart(new Timestamp(System.currentTimeMillis()));
                    break;
                case MIGRATION_END:
                case MIGRATION_ERROR:
                    projects.setMigrationEnd(new Timestamp(System.currentTimeMillis()));
                    break;
            }
            projectsRepository.save(projects);
        }
    }

    public void deleteProject(Projects projects) {
        projectsRepository.delete(projects);
    }
    // Insertion of Unmigrated activites to DB
    
    public void insertIntoUnmigratedActivities(int execId, int seqId, String activityName, String processName, String description) {
    	unmigratedActivitesRepository.save(new UnmigratedActivities(execId, seqId, activityName, processName, description));
    }
    

     // insert manual effort to DB
    public void insertTotalManualEffort(Accelerator accelerator,double totalTime, double savedTime) throws SQLException {
    	 Projects arcProjects = projectsRepository.findById(execId).orElse(null);
         if (arcProjects != null) {
             arcProjects.setManualEffort(totalTime/60);
             arcProjects.setSavedTime(savedTime/60);
             projectsRepository.save(arcProjects);
         }
        
    }

    
    public void truncateTableByExecId(int execId) {
        migrationStatsRepository.truncateByExecId(execId);
    }
    

    @Transactional
    public void insertAnalysis(Accelerator accelerator, ArrayList<String> types, ArrayList<String> actTypes, ArrayList<String> actNames, ArrayList<Integer> seqIds, ArrayList<String> fileNames, ArrayList<Double> manualEffort, ArrayList<Double> reqTime) throws SQLException {
       
    	List<MigrationStats> migratnStatsExist = migrationStatsRepository.findByExecId(execId);
    	if (!migratnStatsExist.isEmpty()) {
    		truncateTableByExecId(accelerator.getCurrentExecutionId());
    	}
    	
    	List<MigrationStats> mgrtnStatsList = new ArrayList<>();
        
        for (int i = 0; i < actTypes.size(); i++) {
            MigrationStats arcMigrationStats = new MigrationStats();
            arcMigrationStats.setExecIdAnalysis(accelerator.getCurrentExecutionId());

            if (types.get(i).contains("Activity")) {
                arcMigrationStats.setType("Activity");
            } else if (types.get(i).contains("Connection")) {
                arcMigrationStats.setType("Connection");
            } else if(types.get(i).contains("Global Variables")){
                arcMigrationStats.setType("Global Variables");
            }  else if(types.get(i).contains("Wsdl")){
                arcMigrationStats.setType("Wsdl");
            } else if(types.get(i).contains("Rest Raml")){
                arcMigrationStats.setType("Rest Raml");
            } else if(types.get(i).contains("UnMigrated")){
                arcMigrationStats.setType("UnMigrated");
            } 
            else {
            	 arcMigrationStats.setType(null);
            }
            
            arcMigrationStats.setSeqId(seqIds.get(i));
            arcMigrationStats.setInputType(actTypes.get(i));
            arcMigrationStats.setNameOfAct(actNames.get(i));
            arcMigrationStats.setFileName(fileNames.get(i));
            arcMigrationStats.setManualEffort(manualEffort.get(i));
            arcMigrationStats.setAfterMigration(reqTime.get(i));
            arcMigrationStats.setSavedTime(manualEffort.get(i) - reqTime.get(i));

            mgrtnStatsList.add(arcMigrationStats);
        }
        // Save all the Analysis instances in one go
        migrationStatsRepository.saveAll(mgrtnStatsList);
    }
}

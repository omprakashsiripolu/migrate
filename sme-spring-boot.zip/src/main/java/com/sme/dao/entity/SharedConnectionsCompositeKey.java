package com.sme.dao.entity;

import java.io.Serializable;
import java.util.Objects;

public class SharedConnectionsCompositeKey implements Serializable {
    private String sharedName;

    private int execId;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SharedConnectionsCompositeKey that = (SharedConnectionsCompositeKey) o;
        return execId == that.execId && Objects.equals(sharedName, that.sharedName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(sharedName, execId);
    }

    public String getSharedName() {
        return sharedName;
    }

    public void setSharedName(String sharedName) {
        this.sharedName = sharedName;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }

    public SharedConnectionsCompositeKey(String sharedName, int execId) {
        this.sharedName = sharedName;
        this.execId = execId;
    }

    public SharedConnectionsCompositeKey() {
    }
}

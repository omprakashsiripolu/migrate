package com.sme.dao.entity;

import java.io.Serializable;
import java.util.Objects;

public class TransitionsCompositeKey implements Serializable {

    private int seqId;

    private int parentId;

    private int execId;

    public TransitionsCompositeKey() {
    }

    public TransitionsCompositeKey(int seqId, int parentId, int execId) {
        this.seqId = seqId;
        this.parentId = parentId;
        this.execId = execId;
    }

    public int getSeqId() {
        return seqId;
    }

    public void setSeqId(int seqId) {
        this.seqId = seqId;
    }

    public int getParentId() {
        return parentId;
    }

    public void setParentId(int parentId) {
        this.parentId = parentId;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TransitionsCompositeKey that = (TransitionsCompositeKey) o;
        return seqId == that.seqId && parentId == that.parentId && execId == that.execId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(seqId, parentId, execId);
    }
}

package com.sme.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Arrays;
import java.util.Objects;

@Entity
@Table(name = "ARC_XSLTTODW")
@IdClass(XsltToDwCompositeKey.class)
public class XsltToDw {

    @Id
    @Column(name = "ACTIVITY_NAME")
    private String activityName;

    @Lob
    @JsonIgnore
    private byte[] xslt;

    @Id
    @Column(name = "EXEC_ID")
    private int execId;

    public XsltToDw() {
    }

    public XsltToDw(String activityName, byte[] xslt, int execId) {
        this.activityName = activityName;
        this.xslt = xslt;
        this.execId = execId;
    }


    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public byte[] getXslt() {
        return xslt;
    }

    public void setXslt(byte[] xslt) {
        this.xslt = xslt;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        XsltToDw xsltToDw = (XsltToDw) o;
        return execId == xsltToDw.execId && Objects.equals(activityName, xsltToDw.activityName) && Arrays.equals(xslt, xsltToDw.xslt);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(activityName, execId);
        result = 31 * result + Arrays.hashCode(xslt);
        return result;
    }
}

package com.sme.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name = "ARC_PROJECTS")
public class Projects {

    private String name;

    @Id
    @Column(name = "exec_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int execId;

    private Timestamp datetime;

    private String description;

    @Lob
    @JsonIgnore
    @Column(name = "source_project")
    private byte[] sourceProject;

    @Lob
    @JsonIgnore
    @Column(name = "target_project")
    private byte[] targetProject;

    @Column(name = "finish_time")
    private Timestamp finishTime;

    @Lob
    @JsonIgnore
    @Column(name = "xslt_to_dwl_excel")
    private byte[] xsltToDwlExcel;

    private String status;

    @Column(name = "ANALYZE_START")
    private Timestamp analyzeStart;

    @Column(name = "ANALYZE_END")
    private Timestamp analyzeEnd;

    @Column(name = "MIGRATION_START")
    private Timestamp migrationStart;

    @Column(name = "MIGRATION_END")
    private Timestamp migrationEnd;

    private String error;

    @OneToMany(mappedBy = "execId", fetch = FetchType.LAZY)
    @LazyCollection(LazyCollectionOption.EXTRA)
    @JsonIgnore
    private List<ConfigFiles> configFilesList;

    @OneToMany(mappedBy = "execId", fetch = FetchType.LAZY)
    @LazyCollection(LazyCollectionOption.EXTRA)
    @JsonIgnore
    private List<Flow> flowList;
    
    @OneToMany(mappedBy = "execId", fetch = FetchType.LAZY)
    @LazyCollection(LazyCollectionOption.EXTRA)
    @JsonIgnore
    private List<UnmigratedActivities> unmigratedActivitiesList;

	@OneToMany(mappedBy = "execId", fetch = FetchType.LAZY)
    @LazyCollection(LazyCollectionOption.EXTRA)
    @JsonIgnore
    private List<GlobalVariables> globalVariablesList;

    @OneToMany(mappedBy = "execId", fetch = FetchType.LAZY)
    @LazyCollection(LazyCollectionOption.EXTRA)
    @JsonIgnore
    private List<GroupActivities> groupActivitiesList;

    @OneToMany(mappedBy = "execId", fetch = FetchType.LAZY)
    @LazyCollection(LazyCollectionOption.EXTRA)
    @JsonIgnore
    private List<RestService> restServiceList;

    @OneToMany(mappedBy = "execId", fetch = FetchType.LAZY)
    @LazyCollection(LazyCollectionOption.EXTRA)
    @JsonIgnore
    private List<SharedConnections> sharedConnectionsList;

    @OneToMany(mappedBy = "execId", fetch = FetchType.LAZY)
    @LazyCollection(LazyCollectionOption.EXTRA)
    @JsonIgnore
    private List<Transitions> transitionsList;

    @OneToMany(mappedBy = "execId", fetch = FetchType.LAZY)
    @LazyCollection(LazyCollectionOption.EXTRA)
    @JsonIgnore
    private List<XsltToDw> xsltToDwList;
    
    @Column(name = "manual_effort")
    private Double manualEffort;
    
    @Column(name = "saved_time")
    private Double savedTime;

    public Projects(String name, int execId, Timestamp datetime, String description, byte[] sourceProject,
                    byte[] targetProject, byte[] xsltToDwlExcel, String status, Timestamp analyzeStart,
                    Timestamp analyzeEnd, Timestamp migrationStart, Timestamp migrationEnd, String error,
                    List<ConfigFiles> configFilesList, List<Flow> flowList, List<UnmigratedActivities> unmigratedActivities,
                    List<GlobalVariables> globalVariablesList, List<GroupActivities> groupActivitiesList,
                    List<RestService> restServiceList, List<SharedConnections> sharedConnectionsList,
                    List<Transitions> transitionsList, List<XsltToDw> xsltToDwList ) {
        this.name = name;
        this.execId = execId;
        this.datetime = datetime;
        this.description = description;
        this.sourceProject = sourceProject;
        this.targetProject = targetProject;
        this.xsltToDwlExcel = xsltToDwlExcel;
        this.status = status;
        this.analyzeStart = analyzeStart;
        this.analyzeEnd = analyzeEnd;
        this.migrationStart = migrationStart;
        this.migrationEnd = migrationEnd;
        this.error = error;
        this.configFilesList = configFilesList;
        this.flowList = flowList;
        this.unmigratedActivitiesList = unmigratedActivitiesList;
        this.globalVariablesList = globalVariablesList;
        this.groupActivitiesList = groupActivitiesList;
        this.restServiceList = restServiceList;
        this.sharedConnectionsList = sharedConnectionsList;
        this.transitionsList = transitionsList;
        this.xsltToDwList = xsltToDwList;
      
    }

    protected Projects() {

    }
   

    public Projects(String name, Timestamp datetime, String description,
                    byte[] sourceProject, byte[] targetProject, byte[] xsltToDwlExcel,  double manualEffort , double savedTime) {
        this.name = name;
        this.datetime = datetime;
        this.description = description;
        this.sourceProject = sourceProject;
        this.targetProject = targetProject;
        this.xsltToDwlExcel = xsltToDwlExcel;
       // this.finishTime = finishTime;
   
        this.manualEffort = manualEffort;
        
        this.savedTime = savedTime;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }

    public Timestamp getDatetime() {
        return datetime;
    }

    public void setDatetime(Timestamp datetime) {
        this.datetime = datetime;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public byte[] getSourceProject() {
        return sourceProject;
    }

    public void setSourceProject(byte[] sourceProject) {
        this.sourceProject = sourceProject;
    }

    public byte[] getTargetProject() {
        return targetProject;
    }

    public void setTargetProject(byte[] targetProject) {
        this.targetProject = targetProject;
    }

    public byte[] getXsltToDwlExcel() {
        return xsltToDwlExcel;
    }

    public void setXsltToDwlExcel(byte[] xsltToDwlExcel) {
        this.xsltToDwlExcel = xsltToDwlExcel;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getAnalyzeStart() {
        return analyzeStart;
    }

    public void setAnalyzeStart(Timestamp analyzeStart) {
        this.analyzeStart = analyzeStart;
    }

    public Timestamp getAnalyzeEnd() {
        return analyzeEnd;
    }

    public void setAnalyzeEnd(Timestamp analyzeEnd) {
        this.analyzeEnd = analyzeEnd;
    }

    public Timestamp getMigrationStart() {
        return migrationStart;
    }

    public void setMigrationStart(Timestamp migrationStart) {
        this.migrationStart = migrationStart;
    }

    public Timestamp getMigrationEnd() {
        return migrationEnd;
    }

    public void setMigrationEnd(Timestamp migrationEnd) {
        this.migrationEnd = migrationEnd;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public List<ConfigFiles> getConfigFilesList() {
        return configFilesList;
    }

    public void setConfigFilesList(List<ConfigFiles> configFilesList) {
        this.configFilesList = configFilesList;
    }

    public List<Flow> getFlowList() {
        return flowList;
    }

    public void setFlowList(List<Flow> flowList) {
        this.flowList = flowList;
    }
    

    public List<UnmigratedActivities> getUnmigratedActivitiesList() {
		return unmigratedActivitiesList;
	}

	public void setUnmigratedActivitiesList(List<UnmigratedActivities> unmigratedActivitiesList) {
		this.unmigratedActivitiesList = unmigratedActivitiesList;
	}

    public List<GlobalVariables> getGlobalVariablesList() {
        return globalVariablesList;
    }

    public void setGlobalVariablesList(List<GlobalVariables> globalVariablesList) {
        this.globalVariablesList = globalVariablesList;
    }

    public List<GroupActivities> getGroupActivitiesList() {
        return groupActivitiesList;
    }

    public void setGroupActivitiesList(List<GroupActivities> groupActivitiesList) {
        this.groupActivitiesList = groupActivitiesList;
    }

    public List<RestService> getRestServiceList() {
        return restServiceList;
    }

    public void setRestServiceList(List<RestService> restServiceList) {
        this.restServiceList = restServiceList;
    }

    public List<SharedConnections> getSharedConnectionsList() {
        return sharedConnectionsList;
    }

    public void setSharedConnectionsList(List<SharedConnections> sharedConnectionsList) {
        this.sharedConnectionsList = sharedConnectionsList;
    }

    public List<Transitions> getTransitionsList() {
        return transitionsList;
    }

    public void setTransitionsList(List<Transitions> transitionsList) {
        this.transitionsList = transitionsList;
    }

    public List<XsltToDw> getXsltToDwList() {
        return xsltToDwList;
    }

    public void setXsltToDwList(List<XsltToDw> xsltToDwList) {
        this.xsltToDwList = xsltToDwList;
    }

    public double getManualEffort() {
        return manualEffort;
    }
     public void setManualEffort(double manualEffort) {
        this.manualEffort = manualEffort;
    }
    
    public double getSavedTime() {
        return savedTime;
    }

    public void setSavedTime(double savedTime) {
        this.savedTime = savedTime;
    }
}

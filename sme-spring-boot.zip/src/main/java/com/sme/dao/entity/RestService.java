package com.sme.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Arrays;
import java.util.Objects;

@Entity
@Table(name = "ARC_RESTSERVICE")
@IdClass(RestServiceCompositeKey.class)
public class RestService {

    @Id
    @Column(name = "PROCESSES_NAME")
    private String processesName;

    @Id
    @Column(name = "RESOURCE_NAME")
    private String resourceName;

    private String path;

    private String base;

    @Column(name = "METHOD_NAME")
    private String methodName;

    private String input;

    private String output;

    @Lob
    @JsonIgnore
    @Column(name = "INP_SCHEMA")
    private byte[] inpSchema;

    @Lob
    @JsonIgnore
    @Column(name = "OUT_SCHEMA")
    private byte[] outSchema;

    @Id
    @Column(name = "EXEC_ID")
    private int execId;

    public RestService(String processesName, String resourceName, String path, String base, String methodName, String input, String output, byte[] inpSchema, byte[] outSchema, int execId) {
        this.processesName = processesName;
        this.resourceName = resourceName;
        this.path = path;
        this.base = base;
        this.methodName = methodName;
        this.input = input;
        this.output = output;
        this.inpSchema = inpSchema;
        this.outSchema = outSchema;
        this.execId = execId;
    }

    public RestService() {
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RestService that = (RestService) o;
        return execId == that.execId && Objects.equals(processesName, that.processesName) && Objects.equals(resourceName, that.resourceName) && Objects.equals(path, that.path) && Objects.equals(base, that.base) && Objects.equals(methodName, that.methodName) && Objects.equals(input, that.input) && Objects.equals(output, that.output) && Arrays.equals(inpSchema, that.inpSchema) && Arrays.equals(outSchema, that.outSchema);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(processesName, resourceName, path, base, methodName, input, output, execId);
        result = 31 * result + Arrays.hashCode(inpSchema);
        result = 31 * result + Arrays.hashCode(outSchema);
        return result;
    }

    public String getProcessesName() {
        return processesName;
    }

    public void setProcessesName(String processesName) {
        this.processesName = processesName;
    }

    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getBase() {
        return base;
    }

    public void setBase(String base) {
        this.base = base;
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public String getInput() {
        return input;
    }

    public void setInput(String input) {
        this.input = input;
    }

    public String getOutput() {
        return output;
    }

    public void setOutput(String output) {
        this.output = output;
    }

    public byte[] getInpSchema() {
        return inpSchema;
    }

    public void setInpSchema(byte[] inpSchema) {
        this.inpSchema = inpSchema;
    }

    public byte[] getOutSchema() {
        return outSchema;
    }

    public void setOutSchema(byte[] outSchema) {
        this.outSchema = outSchema;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }
}

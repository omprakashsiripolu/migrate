package com.sme.dao.entity;

import com.sme.dao.repository.ConfigFilesRepository;

import java.io.Serializable;
import java.util.Objects;

public class ConfigFilesCompositeKey implements Serializable {

    private String name;

    private int execId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }

    protected ConfigFilesCompositeKey() {
    }

    public ConfigFilesCompositeKey(String name, int execId) {
        this.name = name;
        this.execId = execId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConfigFilesCompositeKey that = (ConfigFilesCompositeKey) o;
        return Objects.equals(name, that.name) && Objects.equals(execId, that.execId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, execId);
    }
}

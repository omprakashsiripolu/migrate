package com.sme.dao.entity;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@Table(name = "ARC_UNMIGRATEDACTIVITIES")
@IdClass(UnmigratedActivitiesCompositeKey.class)
public class UnmigratedActivities {

	@Id
    @Column(name = "exec_id")
    private int execId;

	@Column(name = "seqid")
	private int seqId;
	
	@Column(name = "activityname")
	private String activityName;

	@Column(name = "processname")
	private String processName;
	
	@Column(name = "description")
	private String description;
	
	public int getExecId() {
		return execId;
	}

	public void setExecId(int execId) {
		this.execId = execId;
	}
	

	public int getSeqId() {
		return seqId;
	}

	public void setSeqId(int seqId) {
		this.seqId = seqId;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	protected UnmigratedActivities() {
		
	}
	
	public UnmigratedActivities(int execId,int seqId, String activityName, String processName, String description) {
		this.execId = execId;
		this.seqId = seqId;
		this.activityName = activityName;
		this.processName = processName;
		this.description = description;
	}
	
	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UnmigratedActivities that = (UnmigratedActivities) o;
        return execId == that.execId && Objects.equals(seqId, that.seqId) && Objects.equals(activityName, that.activityName) && Objects.equals(processName, that.processName) && Objects.equals(description, that.description);
    }
	
	@Override
    public int hashCode() {
        return Objects.hash(execId, seqId, activityName, processName, description);
    }
	
}

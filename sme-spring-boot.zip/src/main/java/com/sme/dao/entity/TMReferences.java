package com.sme.dao.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.util.Objects;

@Entity
@Table(name = "TMREFERENCES")
@IdClass(TMReferencesCompositeKey.class)
public class TMReferences {

    @Id
    private String tibco;

    @Id
    private String mulesoft;

    public TMReferences() {
    }

    public TMReferences(String tibco, String mulesoft) {
        this.tibco = tibco;
        this.mulesoft = mulesoft;
    }

    public String getTibco() {
        return tibco;
    }

    public void setTibco(String tibco) {
        this.tibco = tibco;
    }

    public String getMulesoft() {
        return mulesoft;
    }

    public void setMulesoft(String mulesoft) {
        this.mulesoft = mulesoft;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TMReferences that = (TMReferences) o;
        return Objects.equals(tibco, that.tibco) && Objects.equals(mulesoft, that.mulesoft);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tibco, mulesoft);
    }
}

package com.sme.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Arrays;
import java.util.Objects;

@Entity
@Table(name = "ARC_SHAREDCONNECTIONS")
@IdClass(SharedConnectionsCompositeKey.class)
public class SharedConnections {

    @Id
    @Column(name = "SHARED_NAME")
    private String sharedName;

    @Lob
    @JsonIgnore
    @Column(name = "SHARED_CONFIG")
    private byte[] sharedConfig;

    @Id
    @Column(name = "EXEC_ID")
    private int execId;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SharedConnections that = (SharedConnections) o;
        return execId == that.execId && Objects.equals(sharedName, that.sharedName) && Arrays.equals(sharedConfig, that.sharedConfig);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(sharedName, execId);
        result = 31 * result + Arrays.hashCode(sharedConfig);
        return result;
    }

    public String getSharedName() {
        return sharedName;
    }

    public void setSharedName(String sharedName) {
        this.sharedName = sharedName;
    }

    public byte[] getSharedConfig() {
        return sharedConfig;
    }

    public void setSharedConfig(byte[] sharedConfig) {
        this.sharedConfig = sharedConfig;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }

    public SharedConnections(String sharedName, byte[] sharedConfig, int execId) {
        this.sharedName = sharedName;
        this.sharedConfig = sharedConfig;
        this.execId = execId;
    }

    public SharedConnections() {
    }
}

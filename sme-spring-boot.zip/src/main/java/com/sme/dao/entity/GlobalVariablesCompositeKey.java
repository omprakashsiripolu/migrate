package com.sme.dao.entity;

import java.io.Serializable;
import java.util.Objects;

public class GlobalVariablesCompositeKey implements Serializable {

    private String keyS;

    private int execId;

    public GlobalVariablesCompositeKey() {
    }

    public GlobalVariablesCompositeKey(String keyS, int execId) {
        this.keyS = keyS;
        this.execId = execId;
    }

    public String getKeyS() {
        return keyS;
    }

    public void setKeyS(String keyS) {
        this.keyS = keyS;
    }

    public int getExecId() {
        return execId;
    }

    public void setExecId(int execId) {
        this.execId = execId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GlobalVariablesCompositeKey that = (GlobalVariablesCompositeKey) o;
        return execId == that.execId && Objects.equals(keyS, that.keyS);
    }

    @Override
    public int hashCode() {
        return Objects.hash(keyS, execId);
    }
}

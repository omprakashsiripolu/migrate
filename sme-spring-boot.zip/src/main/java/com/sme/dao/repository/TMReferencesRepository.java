package com.sme.dao.repository;

import com.sme.dao.entity.TMReferences;
import com.sme.dao.entity.TMReferencesCompositeKey;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface TMReferencesRepository extends CrudRepository<TMReferences, TMReferencesCompositeKey> {
    List<TMReferences> findAllByTibco(String tibco);
}

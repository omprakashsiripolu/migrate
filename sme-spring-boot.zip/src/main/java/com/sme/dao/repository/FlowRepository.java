package com.sme.dao.repository;

import com.sme.dao.entity.Flow;
import com.sme.dao.entity.FlowCompositeKey;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface FlowRepository extends CrudRepository<Flow, FlowCompositeKey> {

    List<Flow> findByProcessesNameAndActivityNameAndExecId(String processesName,
                                                           String activityName,
                                                           int execId);

    List<Flow> findAllByProcessesNameAndExecIdAndParentIdIsNull(String processesName, int execId);

    List<Flow> findAllByProcessesNameAndExecId(String processesName, int execId);

    List<Flow> findAllByExecId(int execId);


    List<Flow> findAllByProcessesNameAndExecIdAndParentIdLike(String processesName, int execId, String parentId);

    List<Flow> findAllByProcessesNameAndExecIdAndParentIdAndParentIdLike(String processesName, int execId,
                                                                         String parentId, String similar);

    List<Flow> findAllByProcessesNameAndExecIdAndSeqId(String processesName, int execId, int seqId);
}

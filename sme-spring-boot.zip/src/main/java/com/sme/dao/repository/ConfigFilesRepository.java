package com.sme.dao.repository;

import com.sme.dao.entity.ConfigFiles;
import com.sme.dao.entity.ConfigFilesCompositeKey;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ConfigFilesRepository extends CrudRepository<ConfigFiles, ConfigFilesCompositeKey> {

    List<ConfigFiles> findByNameAndExecId(String name, int execId);

    List<ConfigFiles> findByExecId(int execId);

    List<ConfigFiles> findByNameLikeAndExecId(String name, int execId);
}

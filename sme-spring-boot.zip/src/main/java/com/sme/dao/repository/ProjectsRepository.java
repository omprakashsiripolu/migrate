package com.sme.dao.repository;

import com.sme.dao.entity.Projects;
import org.springframework.data.repository.CrudRepository;

public interface ProjectsRepository extends CrudRepository<Projects, Integer> {
}

package com.sme.dao.repository;


import com.sme.dao.entity.GroupActivities;
import com.sme.dao.entity.GroupActivitiesCompositeKey;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface GroupActivitiesRepository extends CrudRepository<GroupActivities, GroupActivitiesCompositeKey> {
    List<GroupActivities> findAllByProcessesNameAndSeqIdAndExecId(String processesName, int seqId, int execId);

    List<GroupActivities> findAllByProcessesNameAndExecIdAndParentIdLikeAndGroupName(String processesName, int execId, String parentId, String groupName);

    List<GroupActivities> findAllByProcessesNameAndExecIdAndParentIdAndParentIdLikeAndGroupName(String processesName,
                                                                                                int execId,
                                                                                                String parentId,
                                                                                                String similar,
                                                                                                String groupName);


    List<GroupActivities> findByProcessesNameAndActivityNameAndExecId(String processesName, String activityName, int execId);

    List<GroupActivities> findAllByExecId(int execId);
}

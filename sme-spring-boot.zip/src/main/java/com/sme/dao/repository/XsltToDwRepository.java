package com.sme.dao.repository;

import com.sme.dao.entity.XsltToDw;
import com.sme.dao.entity.XsltToDwCompositeKey;
import org.springframework.data.repository.CrudRepository;

public interface XsltToDwRepository extends CrudRepository<XsltToDw, XsltToDwCompositeKey> {
}

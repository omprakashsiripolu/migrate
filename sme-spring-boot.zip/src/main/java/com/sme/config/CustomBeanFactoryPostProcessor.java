package com.sme.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.stereotype.Component;

//@Component
// TODO: retrieveOps is not scoped correctly and references to its process list is throwing null pointers
public class CustomBeanFactoryPostProcessor implements BeanFactoryPostProcessor {

    private static final Logger logger = LoggerFactory.getLogger(CustomBeanFactoryPostProcessor.class);

    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory factory) throws BeansException {
        logger.info("Loading CustomBeanFactoryPostProcessor for making all beans as prototype scoped");
        for (String beanName : factory.getBeanDefinitionNames()) {
            BeanDefinition beanDef = factory.getBeanDefinition(beanName);
            String beanClassName = beanDef.getBeanClassName();
            if (beanClassName != null && beanClassName.startsWith("com.sme")
                    && !beanClassName.contains("Jwt")
                    && !beanClassName.contains("SmeAcceleratorApplication")
                    && !beanClassName.endsWith("BeanFactoryPostProcessor")
                    && !beanClassName.contains("SecurityConfig")) {
                logger.info("beanName {} with class {} is updated to prototype scope", beanName, beanClassName);
                beanDef.setScope("prototype");
            }
        }
    }
}
